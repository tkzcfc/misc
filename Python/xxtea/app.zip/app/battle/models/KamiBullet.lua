
local c = require "app.configs.constants"

local random = require "app.battle.Random"
local BattleController = require "app.battle.controllers.BattleController"
local ViewController = require "app.battle.controllers.ViewController"
local BuffController = require "app.battle.controllers.BuffController"
local globalBattleConf = require "app.configs.globalBattle"
local StatisticsController = require "app.battle.controllers.StatisticsController"

local KamiBullet = class("KamiBullet")

function KamiBullet:ctor(owner)
	self.uid = 0
	self.attr = {}
	self.targetUids = {}
	self.triggers = {}
	self.owner = owner
	self.dt = 0
	self.totalTime = 0
	self.kamiSkill = nil
	self.skillTriggerCnt = 0
	self.bulletTriggerCnt = 0
	self.isFirstTrigger = false
end

function KamiBullet:update(dt)
	-- 定屏
	if BattleController.isFreezing() and self.kamiSkill.isFreezing == false then
		return
	end

	self.dt = self.dt + dt

	for i = #self.triggers, 1, -1 do
		local trigger = self.triggers[i]
		if trigger.time <= self.dt then
			self:triggerEvent(trigger)
			table.remove(self.triggers, i)
		else
			break
		end
	end

	ViewController.updateBullet(self.uid, dt)

	if self.dt > self.totalTime then
		ViewController.removeBullet(self.uid)
		return true
	end

	return false
end

function KamiBullet:triggerEvent(trigger)
	if trigger.name == "bullet_fly" then
		ViewController.bulletFly(self.uid, self.owner.uid, self.targetUids, trigger)
	elseif trigger.name == "bullet_effect" then
		ViewController.bulletEffect(self.uid, self.owner.uid, trigger.jsonName)
	elseif trigger.name == "trigger" then
		self.bulletTriggerCnt = self.bulletTriggerCnt + 1
		self.isFirstTrigger = self.bulletTriggerCnt == 1 and  self.skillTriggerCnt == 1 
		-- 添加buff
		if self.attr.buffId then
			for _, uid in pairs(self.targetUids) do
				local unit = BattleController.getUnitByUid(uid)
				if random:random() <= self.attr.buffHit then
					BuffController.addBuff(self.attr.buffId, unit, self.owner)
				end
			end
		end

		self:calcDamage()
		self.isFirstTrigger = false
		ViewController.bulletHit(self.uid, self.targetUids, trigger.jsonName)
	elseif trigger.name == "hit_down" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_high" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_far" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	end
end

function KamiBullet:calcDamage()
	for _, uid in pairs(self.targetUids) do
		local defender = BattleController.getUnitByUid(uid)
		local cr = true

		ViewController.showCombo(self.owner.group, BattleController.dt)

		local damage = self.attr.attack * self.attr.skill_coefficient
		local factor = 1 -- 衰减系数
		local fightStatus = BattleController.fightStatus
		if fightStatus and globalBattleConf[1].battleGhostWeak then
			for _, conf in pairs(globalBattleConf[1].battleGhostWeak) do
				if conf.stat == fightStatus then
					factor = conf.n
					break
				end
			end
		end
		damage = damage * factor

		StatisticsController.kamiDamageStatistics(self.owner.group,damage)
		ViewController.updateKamiDamage(self.owner.group, damage)

		defender:updateDamage(damage, cr)
		if self.isFirstTrigger then
			-- 驱散buff
			if self.attr.skillFunc == "dispel" then
				BuffController.dispelBuff(defender.uid, self.attr.funcParameter[1], self.attr.funcParameter[2])
			end

			-- 烧能量
			if self.attr.skillFunc == "burnEnergy" then
				defender:updateEnergy(-1 * defender.attr.energy * self.attr.funcParameter[1])
			end

			-- 加能量
			if self.attr.skillFunc == "addEnergy" then
				defender:updateEnergy(defender.attr.energy * self.attr.funcParameter[1])
			end
		end
	end
end

return KamiBullet
