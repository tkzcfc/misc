
local c = require "app.configs.constants"

local random = require "app.battle.Random"
local globalBattleConf = require "app.configs.globalBattle"
local BattleController = require "app.battle.controllers.BattleController"
local ViewController = require "app.battle.controllers.ViewController"
local BuffController = require "app.battle.controllers.BuffController"
local StatisticsController = require "app.battle.controllers.StatisticsController"
local TeamController = require "app.battle.controllers.TeamController"

local Bullet = class("Bullet")

function Bullet:ctor(owner)
	self.uid = 0
	self.attr = {}
	self.targetUids = {}
	self.triggers = {}
	self.owner = owner
	self.dt = 0
	self.totalTime = 0
	self.unitSkill = nil
	self.skillTriggerCnt = 0
	self.bulletTriggerCnt = 0
	self.isFirstTrigger = false
end

function Bullet:update(dt)
	-- 定屏
	if BattleController.isFreezing() then
		return
	end

	self.dt = self.dt + dt

	for i = #self.triggers, 1, -1 do
		local trigger = self.triggers[i]
		if trigger.time <= self.dt then
			self:triggerEvent(trigger)
			table.remove(self.triggers, i)
		else
			break
		end
	end

	ViewController.updateBullet(self.uid, dt)

	if self.dt > self.totalTime then
		ViewController.removeBullet(self.uid)
		return true
	end

	return false
end

function Bullet:triggerEvent(trigger)
	if trigger.name == "bullet_fly" then
		ViewController.bulletFly(self.uid, self.owner.uid, self.targetUids, trigger)
	elseif trigger.name == "bullet_effect" then
		ViewController.bulletEffect(self.uid, self.owner.uid, trigger.jsonName)
	elseif trigger.name == "trigger" then
		self.bulletTriggerCnt = self.bulletTriggerCnt + 1
		self.isFirstTrigger = self.bulletTriggerCnt == 1 and  self.skillTriggerCnt == 1 --(self.skillTriggerCnt >= self.unitSkill.triggerCnt and (trigger.lastTrigger == true))
		-- 变身
		if self.attr.skillFunc == "change" then
			BattleController.transfrom(self.owner, self.attr.funcParameter)
			return
		end

		-- 复活
		if self.attr.skillFunc == "revive" then
			if self.isFirstTrigger then
				self.targetUids = BattleController.reviveUnits(self.targetUids, self.attr.targetValue, self.attr.group, self.attr.funcParameter[1])
			end
			return
		end

		self:calcDamage()

		-- 添加buff
		if self.isFirstTrigger then
			if self.attr.buffId then
				for _, uid in pairs(self.targetUids) do
					local unit = BattleController.getUnitByUid(uid)
					local buffHit = self.attr.buffHit
					if self.attr.isBuffHitAdded == 1 then
						buffHit = self.attr.buffHit - unit.attr.effectDodge
					end
					if random:random() <= buffHit then
						BuffController.addBuff(self.attr.buffId, unit, self.owner)
					end
				end
			end
		end
		self.isFirstTrigger = false
		ViewController.bulletHit(self.uid, self.targetUids, trigger.jsonName)
	elseif trigger.name == "hit_down" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_high" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_far" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "duang_start" then
		if trigger.int then
			ViewController.startShake(trigger.int)
		end
	elseif trigger.name == "duang_end" then
		ViewController.stopShake()
	end
end

function Bullet:calcDamage()

	-- 判断暴击
	local function checkCrit(defender)
		if self.attr.mustCrit then
			return true
		end

		if self.attr.skillFunc == "enemyBuffToCrit" and BuffController.groupIsExist(defender.uid, self.attr.funcParameter[1]) then
			return true
		end

		local critResult = math.min(
			self.attr.crit / (globalBattleConf[1].basicCritStd + (self.attr.level - 1) * globalBattleConf[1].critStdLvIncr),
			globalBattleConf[1].basicCritRatioLimit
		)
		local critChance = (critResult / 100 + self.attr.critodds + self.attr.skill_critodds - defender.attr.calmOdds)
		local cr = (random:random() <= critChance)

		return cr
	end

	-- 判断治疗暴击
	local function checkHealingCrit(defender)
		if self.attr.mustCrit then
			return true
		end

		if self.attr.skillFunc == "enemyBuffToCrit" and BuffController.groupIsExist(defender.uid, self.attr.funcParameter[1]) then
			return true
		end

		local critResult = math.min(
			self.attr.crit / (globalBattleConf[1].basicCritStd + (self.attr.level - 1) * globalBattleConf[1].critStdLvIncr),
			globalBattleConf[1].basicCritRatioLimit
		)
		local critChance = (critResult / 100 + self.attr.critodds + self.attr.skill_critodds)
		local cr = (random:random() <= critChance)

		return cr
	end

	-- 判断命中
	local function checkHitChance(defender)
		local levelSuppress = math.max(defender.level - self.attr.level, 0) * globalBattleConf[1].levelSuppressHitRatio
		local hitResult = math.max( (self.attr.hit - defender.attr.dodge) + math.max(globalBattleConf[1].basicHitRatio - levelSuppress, 0), globalBattleConf[1].basicHitRatioLimit)
		
		local hitChance = (hitResult / 100 + self.attr.skill_hitodds)

		-- 未命中
		if random:random() > hitChance then
			return false
		else
			return true
		end
	end

	local isCrit = false
	for _, uid in pairs(self.targetUids) do
		local defender = BattleController.getUnitByUid(uid)
		local cr = false

		if self.attr.damageType == 0 then -- buff

		elseif self.attr.skill_coefficient < 0 then -- 治疗
			if self.attr.skillFunc == "liferenew" then	--按最大生命比恢复
				local healingBonusResult = defender.attr.maxLife * self.attr.funcParameter[1]
				defender:healingHp(math.abs(healingBonusResult), false)
			else
				-- 暴击
				cr = checkHealingCrit(defender)

				-- 治疗效果
				local critDamage = cr and self.attr.critdamage or 1
				local healingBonusResult = (self.attr.attack * self.attr.skill_coefficient
											* critDamage * (1 + self.attr.cureratio) + self.attr.addcure) * defender.attr.healingRatio
				-- healingBonusResult = healingBonusResult * (0.9 + 0.2 * random:random())
				defender:healingHp(math.abs(healingBonusResult), cr)
			end
		else
			ViewController.showCombo(self.owner.group, BattleController.dt)

			local damage = nil
			local hit = true
			local kill = false
			local actualDamage = 0

			if self.attr.damageType == 1 then -- 普通伤害
				-- 暴击
				cr = checkCrit(defender)

				-- 计算伤害
				local basicDamage = math.max( (self.attr.attack - defender.attr.defense) * globalBattleConf[1].subtractionRatio, 0 ) 
									+ (self.attr.attack * self.attr.attack) / (self.attr.attack + defender.attr.defense) * globalBattleConf[1].divisionRatio
				local critDamage = cr and self.attr.critdamage or 1
				damage = basicDamage * self.attr.skill_coefficient * critDamage * math.max(self.attr.damageUpRatio - defender.attr.damageRatio + 1, 0.1)
				damage = damage * (0.9 + 0.2 * random:random())

				-- 命中
				hit = checkHitChance(defender)
			elseif self.attr.damageType == 2 then -- 神圣伤害
				damage = self.attr.attack * self.attr.skill_coefficient
			end

			if hit == true then
				----------------------------------------------------------------------
				-- 额外伤害
				----------------------------------------------------------------------
				local extraDamage = 0

				-- 状态额外伤害
				local buff = BuffController.getBuffByFunc(self.owner.uid, "targetAddDamage")
				if buff then
					local groups = {}
					for i = 1, #buff.funcParameter - 1 do
						groups[i] = buff.funcParameter[i]
					end
					
					if  BuffController.eitherGroupExist(defender.uid, groups) then
						extraDamage = extraDamage + damage * buff.funcParameter[#buff.funcParameter]
					end
				end

				-- 破势
				local buff = BuffController.getBuffByFunc(self.owner.uid, "largeLifeAddDamage")
				if buff and (defender.attr.hp / defender.attr.maxLife) > buff.funcParameter[1] then
					extraDamage = extraDamage + damage * buff.funcParameter[2]
				end

				-- 斩杀
				local buff = BuffController.getBuffByFunc(self.owner.uid, "smallLifeAddDamage")
				if buff then
					extraDamage = extraDamage + damage * (1 - defender.attr.hp / defender.attr.maxLife) * buff.funcParameter[1]
				end

				-- 暴击额外伤害
				if cr then
					local buff = BuffController.getBuffByFunc(self.owner.uid, "critAddDamage")
					if buff then
						extraDamage = extraDamage + math.min(defender.attr.maxLife * buff.funcParameter[1], self.owner.attr.attack * buff.funcParameter[2])
					end
				end

				if self.attr.skillFunc == "groupToDamage" then
					local buffGroup = clone(self.attr.funcParameter)
					local extraParam = table.remove(buffGroup, 1) --数组第一个值为额外伤害系数,其他的是buffgroup
					if BuffController.eitherGroupExist(defender.uid, buffGroup) then
						extraDamage = extraDamage + damage * extraParam
					end
				end

				if self.attr.skillFunc == "groupLapToDamage" then
					local buffGroup = clone(self.attr.funcParameter)--数组第一个值为额外伤害系数,其他的是buffgroup
					local extraParam = table.remove(buffGroup, 1)										
					local groupCnt = BuffController.getBuffGroupCnt(defender.uid, buffGroup[1])					
					if groupCnt > 0 then
						extraDamage = extraDamage + damage * extraParam * groupCnt						
					end
				end

				local buffs = BuffController.getBuffsByFunc(self.owner.uid, "targetToDamage")
				if #buffs > 0 then
					for _, buff in pairs(buffs) do
						if (buff.funcParameter[1] == 1 and defender.order < 3) or (buff.funcParameter[1] == 2 and defender.order >= 3) then
							extraDamage = extraDamage + damage * buff.funcParameter[2]
						end
					end
				end

				damage = damage + extraDamage
				----------------------------------------------------------------------
				local totalDamage = damage
				local buff = BuffController.getSpurtBuff(self.owner.uid) --溅射伤害
				if buff then
					local spurtDamage = damage * buff.funcParameter[1]
					local units = BattleController.getGroupMateUnits(defender)
					for k,unit in pairs(units or {}) do
						unit:spurtDamage(spurtDamage, cr)
						totalDamage = totalDamage + spurtDamage
					end
				end

				-- 伤害统计
				StatisticsController.damageStatistics(self.owner, totalDamage)
				ViewController.updateDamage(self.owner.uid, damage)
				kill,actualDamage = defender:updateDamage(damage, cr)

				-- 击杀回能，击杀幻化神不回能
				if kill then
					self.owner:updateEnergy(globalBattleConf[1].killEnergyGain,true)
				end

				-- 吸血计算，只计算实际伤害
				if actualDamage < 0 then
					local lifePerHitPercentage = math.min(
					self.attr.lifeperhit / globalBattleConf[1].basicLifePerHitStd
					, globalBattleConf[1].lifePerHitRatioLimit
					)
					local lifePerHitValue = math.abs(actualDamage) * (lifePerHitPercentage / 100)
					self.owner:lifePerHitHp(lifePerHitValue)
				end

				-- 攻击回复
				if self.attr.skillFunc == "attackReply" then
					if self.unitSkill.attackReplyUids == nil then
						self.unitSkill.attackReplyUids = BattleController.getTarget(self.owner, {isFriendly = 1, targetType = self.attr.funcParameter[2], targetValue = {self.attr.funcParameter[3]}})
					end

					BattleController.unitAttackReply(damage * self.attr.funcParameter[1], self.unitSkill.attackReplyUids)
				end
				
				-- 技能回复血量
				if self.attr.skillFunc == "lifeSteal" then
					local skillHealing = damage * self.attr.funcParameter[1]
					local healingBonusResult = (skillHealing * (1 + self.attr.cureratio) + self.attr.addcure) * defender.attr.healingRatio
					self.owner:skillHp(healingBonusResult)
				end

				-- 吸血标记
				local buff = BuffController.getSuckMarker(defender.uid)
				if buff then
					self.owner:suckMarkerHp(damage * buff.funcParameter[1])
				end

				self.unitSkill.isHit = true
			else
				defender:increaseDodgeCnt()
				ViewController.hitMiss(defender.uid)
			end

			if kill then
				self.unitSkill.isKill = true
			end

			if not self.unitSkill.isExtra then
				-- 反弹
				local buff = BuffController.getBuffByFunc(defender.uid, "needle")
				if buff then
					if random:random() <= buff.funcParameter[1] then
						--12.6 修改 反弹伤害不能超过受击者攻击*系数3
						local needleDamage = math.min(damage * buff.funcParameter[2], defender.attr.attack * buff.funcParameter[3])
						self.owner:needleHp(needleDamage)
					end
				end

				-- 醉酒
				local buff = BuffController.getChoiceSkillBuff(defender.uid)
				if buff then
					BuffController.removeBuff(defender.uid, buff.uid)
					BattleController.unitChoiceSkill(defender, buff.funcParameter[1])
				end

				-- 弹射
				if self.attr.skillFunc == "bounce" then
					BattleController.bounceBullet(self, defender)
				end

				--神圣反击
				BattleController.unitGodBackAttack(defender, self.owner)

				-- 受击反击
				BattleController.unitCounterAttack(defender, self.owner)

				if self.isFirstTrigger then

					-- 受伤驱散
					local buff = BuffController.getBuffByFunc(defender.uid, "InjuredDispel")
					if buff then
						if random:random() <= buff.funcParameter[1] then
							BuffController.dispelBuff(defender.uid, buff.funcParameter[2], buff.funcParameter[3] or 1)
						end
					end

					-- 攻击驱散
					local buff = BuffController.getBuffByFunc(self.owner.uid,"damageDispel")
					if buff then
						if random:random() <= buff.funcParameter[1] then
							BuffController.dispelBuff(defender.uid, buff.funcParameter[2], buff.funcParameter[3] or 1)
						end
					end

					-- 魅惑2
					if actualDamage < 0 then
						BattleController.unitConfuse2Attack(defender, self.owner)
					end

					----------------------------------------------------------------------------
					-- 给buff
					----------------------------------------------------------------------------
					
					-- 反击给buff
					local buff = BuffController.getCounterBuff(defender.uid)
					if buff and BuffController.getBuffAddBuffHit(buff,defender,self.owner) then
						BuffController.addBuff(buff.funcParameter[1], self.owner, defender)
					end

					-- 受伤单个buff
					local buff = BuffController.getBuffByFunc(defender.uid, "InjuredBuff")
					if buff then
						local target = (buff.funcParameter[4] == 1) and defender or self.owner
						if BuffController.getBuffAddBuffHit(buff,defender,target) then
							BuffController.addBuff(buff.funcParameter[1], target, defender)
						end
					end

					-- 伤害施加buff
					local buff = BuffController.getBuffByFunc(self.owner.uid, "damageToBuff")
					if buff and BuffController.getBuffAddBuffHit(buff,self.owner,defender) then
						BuffController.addBuff(buff.funcParameter[1], defender, self.owner)
					end
					----------------------------------------------------------------------------
				end
			end
		end

		if cr then
			isCrit = true
			self.unitSkill.isCrit = true
		end

		if self.isFirstTrigger then
			-- 暴击给buff
			if cr then
				local buff = BuffController.getCritToBuff(self.owner.uid)
				if buff and BuffController.getBuffAddBuffHit(buff,self.owner,defender) then
					BuffController.addBuff(buff.funcParameter[1], defender, self.owner)
				end

				-- 受暴击触发
				local buff = BuffController.getCritedToSkill(defender.uid)
				if buff then
					local skill = TeamController.newUnitSkill(defender, buff.funcParameter[1])
					defender:useCritedToSkill(skill)
				end
			end

			-- 驱散buff
			if self.attr.skillFunc == "dispel" then
				BuffController.dispelBuff(defender.uid, self.attr.funcParameter[1], self.attr.funcParameter[2])
			end

			-- 烧能量
			if self.attr.skillFunc == "burnEnergy" then
				defender:updateEnergy(-1 * defender.attr.energy * self.attr.funcParameter[1])
			end

			-- 加能量
			if self.attr.skillFunc == "addEnergy" then
				defender:updateEnergy(defender.attr.energy * self.attr.funcParameter[1])
			end


			if self.attr.skillFunc == "groupToSkill" and self.unitSkill.hasGroupBuff ~= 1 then--0不是groupToSkill类型技能,1有groupBuff,2没有groupBuff
				if BuffController.eitherGroupExist(defender.uid, self.attr.funcParameter) then
					self.unitSkill.hasGroupBuff = 1
				else
					self.unitSkill.hasGroupBuff = 2
				end
			end

			if self.attr.skillFunc == "groupLapToEnergy" then --buff组层数回能				
				local buffGroup = clone(self.attr.funcParameter)--数组第一个值为额外伤害系数,其他的是buffgroup
				local baseVal = table.remove(buffGroup, 1) --基础值
				local groupCntType = table.remove(buffGroup, 1) --是否通过buff组层数计算回复能量值 0只回复基础值 1根据层数回复
				local groupCnt = BuffController.getBuffGroupCnt(defender.uid, buffGroup[1])				
				if groupCnt > 0 then
					local addEnergy = baseVal
					if groupCntType == 1 then
						addEnergy = baseVal * groupCnt
					end
					self.owner:updateEnergy(addEnergy)
				end
			end

			if self.attr.skillFunc == "groupToBuff" then
				local skillFuncData = clone(self.attr.funcParameter)
				local buff1Hit = table.remove(skillFuncData, 1)
				local buff1Id = table.remove(skillFuncData, 1)
				local addBuff2 = table.remove(skillFuncData, 1)
				local buff2Hit = table.remove(skillFuncData, 1)
				local buff2Id = table.remove(skillFuncData, 1)
				local buffGroup = skillFuncData								
				local totalCnt = 0
				for k,v in ipairs(buffGroup or {}) do
					totalCnt = totalCnt + BuffController.getBuffGroupCnt(defender.uid, v)
				end				
				if totalCnt > 0 then
					buff1Hit = buff1Hit - defender.attr.effectDodge					
					if random:random() <= buff1Hit then						
						BuffController.addBuff(buff1Id, defender, self.owner)
					end

					if addBuff2 == 1 then
						local buffConf = require "app.configs.buff"
						local buffData = buffConf[buff2Id]

						buff2Hit = buff2Hit - defender.attr.effectDodge						
						if random:random() <= buff2Hit then							
							BuffController.addBuff(buff2Id, defender, self.owner) --添加一次buff 剩下的buff层数不触发监听等行为

							for i = totalCnt - 1, 1, -1 do
								local buffGroupCnt = BuffController.getBuffGroupCnt(defender.uid, buffData.group)
								if buffGroupCnt < buffData.overlap then
									local buff = BuffController.factory:createBuff(buff2Id, defender, self.owner)
									table.insert(BuffController.buffs[defender.uid], buff)
									buff:add()
								else
									break
								end
							end
						end
					end
				end
			end
		end
	end

	if self.isFirstTrigger then
		if not self.unitSkill.isExtra then
			-- 协同攻击
			self.unitSkill:checkAssist()
			-- 暴击触发技能
			if isCrit then
				BattleController.unitEachCritToSkill(self.owner)
			end
		end
	end
end

return Bullet
