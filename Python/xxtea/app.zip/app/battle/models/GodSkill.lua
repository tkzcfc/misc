
local c = require "app.configs.constants"

local skillConf = require "app.configs.skill"
local spineConf = require "app.configs.spine"
local roleConf = require "app.configs.role"
local ViewController = require "app.battle.controllers.ViewController"
local BattleController = require "app.battle.controllers.BattleController"

local GodSkill = class("GodSkill")

function GodSkill:ctor(owner, skillId)
	assert(skillConf[skillId] ~= nil, "skillConf invalid skillId" .. (skillId or "nil"))

	self.owner = owner
	self.attr = clone(skillConf[skillId])

	self.isFreezing = false
	self.isCrit = true -- 是否暴击

	local spineInfo = spineConf[roleConf[self.owner.role].spine][self.attr.skillAnim]
	self.animTime = (spineInfo ~= nil) and spineInfo.totalTime or -1
	self.events = (spineInfo ~= nil) and spineInfo.events or {}
	self.triggerCnt = (spineInfo ~= nil) and spineInfo.triggerCnt or 0
	self.curCnt = 0
end

function GodSkill:start()
	self.dt = 0
	self.triggers = clone(self.events)
	self.targetUids = BattleController.getUnitSkillTarget(self)
	self.totalTime = self.animTime
	self.curCnt = 0

	table.sort(self.triggers, function(a, b)
		return a.time > b.time
	end)

	table.insert(self.triggers, {
		time = 0,
		name = "start_skill",
	})
end

function GodSkill:update(dt)
	self.dt = self.dt + dt

	for i = #self.triggers, 1, -1 do
		local trigger = self.triggers[i]
		if trigger.time <= self.dt then
			self:triggerEvent(trigger)
			table.remove(self.triggers, i)
		else
			break
		end
	end

	if self.dt > self.totalTime then
		return true
	end

	return false
end

function GodSkill:triggerEvent(trigger)
	if trigger.name == "start_skill" then
		ViewController.godUseSkill(self.owner.uid, self.attr.Id)
	elseif trigger.name == "trigger" then
		self.curCnt = self.curCnt + 1
		BattleController.addGodSkillBullet(self)
	elseif trigger.name == "hit_down" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_high" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_far" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "duang_start" then
		if trigger.int then
			ViewController.startShake(trigger.int)
		end
	elseif trigger.name == "duang_end" then
		ViewController.stopShake()
	end
end

return GodSkill
