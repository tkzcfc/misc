
local buffConf = require "app.configs.buff"
local attributeConf = require "app.configs.attribute"
local ViewController = require "app.battle.controllers.ViewController"
local BattleController = require "app.battle.controllers.BattleController"
local BuffController = require "app.battle.controllers.BuffController"

local Buff = class("Buff")

function Buff:ctor(id, owner, attackerUid)
	local conf = buffConf[id]

	self.uid = 0
	self.bType = conf.buffType
	self.id = id
	self.owner = owner
	self.idleAction = conf.action
	self.attackerUid = attackerUid
	self.duration = conf.time
	self.isDispel = conf.isDispel
	self.group = conf.group
	self.overlap = conf.overlap
	self.func = conf.func
	self.funcParameter = conf.funcParameter
	self.funcParameter2 = conf.funcParameter2
	self.buffHp = nil
	self.buffEnergy = nil
end

function Buff:addAttr()
	local conf = buffConf[self.id]

	for _, info in pairs(conf.attribute) do
		local attrName = nil
		local d, e = 0, 0

		if info.id >= 100 then -- 属性百分比加成
			d = d + info.val
			attrName = attributeConf[info.id/10].alias
		else -- 附加属性加成
			e = e + info.val
			attrName = attributeConf[info.id].alias
		end

		self.owner:updateBuffAttr(attrName, d, e)
	end
end

function Buff:removeAttr()
	local conf = buffConf[self.id]

	for _, info in pairs(conf.attribute) do
		local attrName = nil
		local b, c = 0, 0

		if info.id >= 100 then -- 属性百分比加成
			b = b - info.val
			attrName = attributeConf[info.id/10].alias
		else -- 附加属性加成
			c = c - info.val
			attrName = attributeConf[info.id].alias
		end

		self.owner:updateBuffAttr(attrName, b, c)
	end
end

function Buff:add()
	self:addAttr()
	if self.func == "startEnergy" then
		self.owner:updateEnergy(self.funcParameter[1], true) --8.6 不影响幻化神能量
	end
	if self.func == "lifePct" then
		self.owner:buffLifePctHp(self.funcParameter[1] * self.owner.attr.maxLife)
	end
	if self.buffHp ~= nil then
		self.owner:buffHp(self.buffHp, self.attackerUid)
	end
	if self.buffEnergy ~= nil then
		self.owner:buffEnergy(self.buffEnergy)
	end

	BuffController.increaseBuffCnt(self)
	ViewController.addBuff(self)
end

function Buff:remove()
	self:removeAttr()


	BuffController.decreaseBuffCnt(self)
	ViewController.removeBuff(self)
end

function Buff:update()
	if self.buffHp ~= nil then
		self.owner:buffHp(self.buffHp, self.attackerUid)
	end
	if self.buffEnergy ~= nil then
		self.owner:buffEnergy(self.buffEnergy)
	end

	if self.func == "stateToBuff" then
		local units = {}
		local params = clone(self.funcParameter)

		local isFriend = table.remove(params, 1) --0敌方 1友方
		local targetVal = table.remove(params, 1) --0全体 1前排 2后排
		local checkType = table.remove(params, 1) --0大于等于 1小于等于
		local liveCnt = table.remove(params, 1) --存活人数
		for _,unit in pairs(BattleController.units) do
			if unit:isAlive() and ((isFriend == 0 and unit.group ~= self.owner.group) or (isFriend == 1 and unit.group == self.owner.group)) then
				if targetVal == 0 then
					units[#units + 1] = unit
				elseif targetVal == 1 and unit.order < 3 then
					units[#units + 1] = unit
				elseif targetVal == 2 and unit.order >= 3 then
					units[#units + 1] = unit
				end
			end
		end

		if (checkType == 0 and #units >= liveCnt) or (checkType == 1 and #units <= liveCnt) then
			for _,buffId in pairs(params) do
				BuffController.addBuff(buffId, self.owner, self.owner)
			end
		end
	end

	self.duration = self.duration - 1

	local ret = (self.duration <= 0)

	return ret
end

function Buff:execute()
end

function Buff:copy(buff)
	self.bType = buff.bType
	self.id = buff.id
	self.idleAction = buff.idleAction
	self.attackerUid = buff.attackerUid
	self.duration = buff.duration
	self.isDispel = buff.isDispel
	self.group = buff.group
	self.overlap = buff.overlap
	self.func = buff.func
	self.funcParameter = buff.funcParameter
	self.buffHp = buff.buffHp
	self.buffEnergy = buff.buffEnergy
end

function Buff:getDesc()
	return buffConf[self.id].name
end

----------------------------------------------------------------------
-- 减伤盾	受到伤害时，优先扣除护盾的生命
-- 无敌	受到伤害时，不扣除生命
-- 免控	不受控制类状态
-- 持续伤害	持续影响生命
-- 协同	队友攻击时，几率对刚才受击的敌人再发送一次普攻，如果敌人有多个，则随机
-- 2次普攻	发送普攻时，几率再发动一次
-- 伤害分摊	受到伤害时，将伤害平分给有“伤害分摊”状态的队友
-- 伤害链接	受到伤害时，转移一定百分比伤害给有“伤害链接”状态的目标（一般是敌人）
-- 反击	受到伤害时，几率对攻击者发动一次普攻
-- 灵魂石	死亡后复活，回复一定百分比生命
-- 受击回血	受到伤害时，伤害不再扣除生命，按照一定比例回复生命
-- 百分比反弹	受到伤害时，按照伤害的一定比例，扣除攻击者生命
-- 蓄力下回合	影响下一个回合的属性
-- 其它特殊	个别特殊英雄，单独功能
----------------------------------------------------------------------

-- -- 收到伤害前
-- function Buff:beforeHurt(damage)
-- end

-- -- 回合结束
-- function Buff:roundEnd()
-- 	self.duration = self.duration - 1

-- 	if self.duration <= 0 then
-- 		self.owner:removeBuff(self)
-- 	end
-- end

-- -- 回合开始
-- function Buff:roundStart()
-- end

-- -- 攻击前
-- function Buff:beforeAttack()
-- end

-- -- 死亡时
-- function Buff:die()
-- end

return Buff
