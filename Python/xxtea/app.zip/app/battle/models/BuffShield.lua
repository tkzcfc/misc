
local buffConf = require "app.configs.buff"

local Buff = require "app.battle.models.Buff"

local BuffShield = class("BuffShield", Buff)

-------------------------------------------
-- 护盾（东方星辰减伤盾，防御转护盾）
-------------------------------------------

function BuffShield:ctor(id, owner, attackerUid, shieldHp)
	BuffShield.super.ctor(self, id, owner, attackerUid)

	local conf = buffConf[id]
	self.isShield = true
	self.shieldHp = shieldHp
end

function BuffShield:execute(delta)
	BuffShield.super.execute(self)
	
	self.shieldHp = self.shieldHp + delta

	return self.shieldHp
end

function BuffShield:getDesc()
	local name = BuffShield.super.getDesc(self)

	return name .. " : " .. string.format("%.2f", self.shieldHp)
end

function BuffShield:copy(buff)
	BuffShield.super.copy(self, buff)

	self.isShield = buff.isShield
	self.shieldHp = buff.shieldHp
end

return BuffShield
