
local BattleController = require "app.battle.controllers.BattleController"
local Buff = require "app.battle.models.Buff"

local BuffHitDamageToLife = class("BuffHitDamageToLife", Buff)

-------------------------------------------
-- 受伤回血
-------------------------------------------

function BuffHitDamageToLife:ctor(id, owner, attackerUid, atk)
    BuffHitDamageToLife.super.ctor(self, id, owner, attackerUid)

    self.attackerAtk = atk
end

function BuffHitDamageToLife:execute(delta)
    BuffHitDamageToLife.super.execute(self)
    
    self.owner:healingHp(self.attackerAtk * self.funcParameter[1], false)
end

function BuffHitDamageToLife:getDesc()
    local name = BuffHitDamageToLife.super.getDesc(self)

    return name .. " : " .. string.format("%.2f", self.attackerAtk)
end

function BuffHitDamageToLife:copy(buff)
    BuffHitDamageToLife.super.copy(self, buff)

    self.attackerAtk = buff.attackerAtk
end

return BuffHitDamageToLife
