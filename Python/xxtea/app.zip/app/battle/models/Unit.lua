
local c = require "app.configs.constants"

local random = require "app.battle.Random"
local ViewController = require "app.battle.controllers.ViewController"
local BuffController = require "app.battle.controllers.BuffController"
local BattleController = require "app.battle.controllers.BattleController"
local spineConf = require "app.configs.spine"
local roleConf = require "app.configs.role"
local StatisticsController = require "app.battle.controllers.StatisticsController"

local Unit = class("Unit")

function Unit:ctor()
	self.part_attr = {}
	self.attr = {}
	self.uid = 0
	self.heroId = 0
	self.originHeroId = 0 --2019.3.4 最初heroId 变成monster也保持不变
	self.role = 0
	self.order = 0
	self.level = 1
	self.star = 1
	self.fightBodyScale = 1--战斗英雄缩放
	self.uType = c.UnitType.NONE
	self.group = c.UnitGroup.NONE
	self.state = c.UnitState.IDLE
	self.skills = {}
	self.artifactSkill = nil -- 神器技能
	self.armorsID = {}
	self.curSkill = nil
	self.blowEnergyRatio = 0 -- 受击能量
	self.lifecycle = 0 -- 生命周期
	self.lifecycleData = nil -- 变回原来单位的数据
	self.atkFactor = 1 --攻击倍数
	self.dodgeCnt = 0 -- 闪避次数
	self.originData = nil
	self.isSummon = false
	self.exSkills = {} --拓展技能 限时挑战加buff等
	self.titleStore = {} --玩家称号 用来replace技能

	for _, skillType in pairs(c.SkillType) do
		self.skills[skillType] = {}
	end
end

function Unit:setAtkFactor(value)
	self.atkFactor = value
	self.attr.attack = self.attr.attack * value
end

function Unit:increaseDodgeCnt()
	self.dodgeCnt = self.dodgeCnt + 1

	BattleController.unitDodgeToSkill(self)
end

------------------------------------ buff ------------------------------------
function Unit:updateBuffAttr(attrName, deltaD, deltaE)
	assert(self.part_attr[attrName] ~= nil, "Unit:updateAttr invalid attrName: " .. (attrName or "nil"))

	local a = self.part_attr[attrName].a
	local b = self.part_attr[attrName].b
	local c = self.part_attr[attrName].c
	local d = (self.part_attr[attrName].d or 0) + deltaD
	local e = (self.part_attr[attrName].e or 0) + deltaE

	--战斗中，属性百分比只作用于基础属性
	--local value = a * (1 + b + d ) + c + e  

	--战斗中，属性百分比作用于外围所有属性
	local value = (a * (1 + b) + c) * (1 + d) + e

	-- 生命上限发生变化，当前血量保持百分比
	if attrName == "maxLife" and self.attr.hp > 0 then
		self.attr.hp = value * (self.attr.hp / self.attr.maxLife)
	end

	self.part_attr[attrName] = {a = a, b = b, c = c, d = d, e = e}
	self.attr[attrName] = value

	--伤害*伤害系数
	if attrName == "attack" then
		self.attr[attrName] = self.attr[attrName] * self.atkFactor
	end
	
end

function Unit:updateControlBuff()
	local noAttack,noSkill = BuffController.getControlState(self.uid)
	if noSkill then
		self:setState(c.UnitState.IDLE)
	end
	ViewController.updateControlBuff(self.uid)
end
------------------------------------------------------------------------------

-- 治疗效果
function Unit:healingHp(value, cr)
	self:updateHp(value, c.UpdateHpType.HEALING, cr)
end

-- 计算伤害
function Unit:updateDamage(damage, cr)
	-- 分摊
	local buff = BuffController.getShareBuff(self.uid)
	if buff then
		local units = BattleController.getUnitsByShareBuff(buff)
		if #units > 1 then
			damage = (damage / #units)

			for _, unit in pairs(units) do
				if unit.uid ~= self.uid then
					unit:shareDamage(damage, cr)
				end
			end

			return self:shareDamage(damage, cr)
		end
	end

	-- 受击回血buff
	local buff = BuffController.getDamageToLifeBuff(self.uid)
	if buff then
		return self:updateHp(damage * buff.funcParameter[1], c.UpdateHpType.DAMAGE_TO_LIFE_BUFF, cr)
	else
		return self:updateHp(-1 * damage, c.UpdateHpType.DAMAGE, cr)
	end
end

-- 溅射伤害
function Unit:spurtDamage(damage, cr)
	return self:updateHp(-1 * damage, c.UpdateHpType.SPURT_DAMAGE, cr)
end

-- 分摊伤害
function Unit:shareDamage(damage, cr)
	return self:updateHp(-1 * damage, c.UpdateHpType.SHARE_DAMAGE, cr)
end

-- 吸血
function Unit:lifePerHitHp(value)
	self:updateHp(value, c.UpdateHpType.LIFE_PER_HIT)
end

-- 技能回复
function Unit:skillHp(value)
	self:updateHp(value, c.UpdateHpType.SKILL)
end

-- 攻击回复
function Unit:attackReplyHp(value)
	self:updateHp(value, c.UpdateHpType.ATTACK_REPLY)
end

-- 死亡回血
function Unit:dieHp(value)
	self:updateHp(value, c.UpdateHpType.DIE)
end

-- 技能掉血
function Unit:skillReduceHp(value)
	self:updateHp(-1 * value, c.UpdateHpType.SKILL_REDUCE)
end

-- buff持续治疗或伤害
function Unit:buffHp(value, attackerUid)
	if value > 0 then	--2019-3-8 buff伤害添加到伤害统计中
		StatisticsController.damageStatistics(BattleController.getUnitByUid(attackerUid), value)
	end
	self:updateHp(-1 * value, c.UpdateHpType.BUFF)
end

-- lifePct buff
function Unit:buffLifePctHp(value)
	self:updateHp(value, c.UpdateHpType.BUFF_LIFE_PCT)
end

-- buff持续加能量或减能量
function Unit:buffEnergy(value)
	self:updateEnergy(value, true)   --8.6 buff不影响幻化神能量
end

-- 吸血标记
function Unit:suckMarkerHp(value)
	self:updateHp(value, c.UpdateHpType.SUCK_MARKER)
end

-- 反弹
function Unit:needleHp(value)
	self:updateHp(-1 * value)
end

function Unit:updateHp(delta, updateType, cr)
	if not self:isAlive() then
		return false,0
	end

	if delta < 0 then
		-- 无敌
		if BuffController.getInvincibleBuff(self.uid) then
			ViewController.invincible(self.uid)
			return false,0
		end

		-- 护盾
		delta = BuffController.reduceShieldHp(self.uid, delta)
		if delta >= 0 then
			ViewController.shield(self.uid)
			return false,0
		end

		--受伤驱散睡眠
		local buff = BuffController.getSleepBuff(self.uid)
		if buff then
			BuffController.removeBuff(self.uid, buff.uid)
		end

		-- 受伤回能
		local energy = (math.abs(delta) / self.attr.maxLife * self.attr.energy) * self.blowEnergyRatio
		self:updateEnergy(energy)
	end

	local ret = nil
	local fightStatus = BattleController.fightStatus
	-- 家族妖兽不掉血（需求：永远打不死）
	if fightStatus == c.FightStatus.guildMonster and self.group == c.UnitGroup.DEFENDER then
		self.attr.hp = self.attr.maxLife
	else
		self.attr.hp = self.attr.hp + delta
	end

	if self.attr.hp < 0 then
		self.attr.hp = 0
	elseif self.attr.hp > self.attr.maxLife then
		self.attr.hp = self.attr.maxLife
	end

	if self.attr.hp <= 0 then

		local reviveBuff = BuffController.getReviveBuff(self.uid)
		local rebornBuff = BuffController.getRebornBuff(self.uid)
		self.useReviveBuff = false
		if reviveBuff and random:random() < reviveBuff.funcParameter[1] then --几率复活
			self.useReviveBuff = true
			self:setState(c.UnitState.REBORN)
		elseif rebornBuff then -- 重生
			self:setState(c.UnitState.REBORN)
		else
			if not BattleController.unitDeathSkill(self) then
				self:setState(c.UnitState.DIE)
			end
		end

		ret = true
	else
		BuffController.rage(self)
		BuffController.buffSkill(self)
	end

	ViewController.updateHpDelta(self.uid, delta, cr, updateType)
	ViewController.updateHp(self.uid, self.attr.hp, self.attr.maxLife)
	BattleController.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_UPDATEHP, data = {group = self.group, order = self.order, uid = self.uid, hp = self.attr.hp, maxLife = self.attr.maxLife}})
	if self.attr.hp > 0 and delta < 0 then
		local buff = BuffController.getHitDamageToLifeBuff(self.uid)
		if buff then
			buff:execute()
		end
	end

	return ret,delta
end

function Unit:updateEnergy(delta,isKill)
	if not self:isAlive() then
		return
	end

	if delta > 0 then
		local buff = BuffController.getEnergyRatioBuff(self.uid)
		if buff then
			delta = delta * (1 + buff.funcParameter[1])
		end

		if not isKill then
			BattleController.updateKamiEnergy(self.group, delta)
		end
	end

	self.attr.mp = self.attr.mp + delta

	if self.attr.mp < 0 then
		self.attr.mp = 0
	elseif self.attr.mp > self.attr.energy then
		self.attr.mp = self.attr.energy
	end

	ViewController.updateEnergy(self.uid, self.attr.mp, self.attr.energy)
	BattleController.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_UPDATEMP, data = {group = self.group, order = self.order, uid = self.uid, mp = self.attr.mp, energy = self.attr.energy}})
end

function Unit:isAlive()
	return self.state ~= c.UnitState.REMOVED and 
			self.state ~= c.UnitState.DIE and
			self.state ~= c.UnitState.REBORN and
			self.attr.hp > 0
end

function Unit:attack()
	if self.state ~= c.UnitState.IDLE then
		return
	end

	--魅惑
	local buff = BuffController.getConfuseBuff(self.uid)
	if buff then
		BattleController.unitConfuseAttack(self)
		return
	end

	--嘲讽
	local buff = BuffController.getTauntBuff(self.uid)
	if buff then
		local target = BattleController.getUnitByUid(buff.attackerUid)
		if target and target:isAlive() then
			BattleController.unitTauntAttack(self,target.uid)
			return
		end
	end

	local noAttack, noSkill = BuffController.getControlState(self.uid)

	-- 小技能
	if not noSkill then
		for _, skill in ipairs(self.skills[c.SkillType.SPECIAL]) do
			if self:useSkill(skill) then
				return
			end
		end
	end

	-- 普攻
	if not noAttack then
		for _, skill in ipairs(self.skills[c.SkillType.NORMAL]) do
			if self:useSkill(skill) then
				return
			end
		end
	end
end

function Unit:useSkill(skill)
	if not skill:valid() then
		return false
	end

	if self:setState(c.UnitState.ATTACK) then
		self.curSkill = skill
		skill:start()

		if skill.attr.skillType == c.SkillType.POWERMAX and self.group == c.UnitGroup.ATTACKER then
			ViewController.autoUsePowermaxSkill(self)
		end
	end
	BattleController.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_UNITUSESKILL, data = {group = self.group, order = self.order, uid = self.uid, skillId = skill.attr.Id}})
	return true
end

-- 连击
function Unit:useSkillTrigger(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if not self:setState(c.UnitState.ATTACK) then
		return
	end

	self.curSkill = skill
	skill:start()

	return true
end

-- 反击
function Unit:useCounterattack(skill, uid)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if noAttack then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start({uid})

		return true
	end
end

-- 协同
function Unit:useAssist(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if noAttack then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 他人死亡触发技能
function Unit:useEachDeathSkill(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 每回合触发技能
function Unit:useRoundBeginSkill(skill)
	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 暴击触发技能
function Unit:useEachCritToSkill(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 受到暴击时触发技能
function Unit:useCritedToSkill(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

--使用神器技能
function Unit:useArtifactSkill(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)
	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if self:setState(c.UnitState.ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 重复buff触发技能
function Unit:useRepeatToAttack(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if noAttack then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 闪避触发技能
function Unit:useDodgeToSkill(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()

		self.dodgeCnt = 0
	end
end

-- 死亡触发技能
function Unit:useDeathSkill(skill)
	if self:setState(c.UnitState.DEATH_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	else
		assert(false, "Unit:useDeathSkill invalid transform")
	end
end

-- 醉酒
function Unit:useChoiceSkill(skill)
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if skill.attr.skillType == c.SkillType.NORMAL and noAttack then
		return
	end

	if skill.attr.skillType ~= c.SkillType.NORMAL and noSkill then
		return
	end

	if self:setState(c.UnitState.EXTRA_ATTACK) then
		self.curSkill = skill
		self.curSkill:start()
	end
end

-- 释放被动技能
function Unit:usePassiveSkill()
	for _, unitSkill in pairs(self.skills[c.SkillType.PASSIVE]) do
		unitSkill:start()
	end
end

-- 释放进场技能
function Unit:useEnteringSkill()
	for _, unitSkill in pairs(self.skills[c.SkillType.ENTERING]) do
		self:useSkill(unitSkill)
	end
end

-- 大招
function Unit:usePowermaxSkill()
	local noAttack, noSkill = BuffController.getControlState(self.uid)

	if not noSkill then
		local skill = self.skills[c.SkillType.POWERMAX][1]
		if skill then
			self:useSkill(skill)

			local buff = BuffController.getPowerMaxBuff(self.uid)
			if buff then
				BuffController.addBuff(buff.funcParameter[1], self, self)
			end
		end
	end
end

------------------------------------ 状态 state ------------------------------------
local transform = {
	[c.UnitState.IDLE] = {
		[c.UnitState.IDLE] = true,
		[c.UnitState.ATTACK] = true,
		[c.UnitState.DIE] = true,
		[c.UnitState.REMOVED] = true,
		[c.UnitState.REBORN] = true,
		[c.UnitState.EXTRA_ATTACK] = true,
		[c.UnitState.DEATH_ATTACK] = true,
	},
	[c.UnitState.DEATH_ATTACK] = {
		[c.UnitState.DIE] = true,
	},
	[c.UnitState.EXTRA_ATTACK] = {
		[c.UnitState.IDLE] = true,
		[c.UnitState.DIE] = true,
		[c.UnitState.REMOVED] = true,
		[c.UnitState.REBORN] = true,
		[c.UnitState.ATTACK] = true,
		[c.UnitState.DEATH_ATTACK] = true,
	},
	[c.UnitState.ATTACK] = {
		[c.UnitState.IDLE] = true,
		[c.UnitState.DIE] = true,
		[c.UnitState.REMOVED] = true,
		[c.UnitState.REBORN] = true,
		[c.UnitState.ATTACK] = true,
		[c.UnitState.DEATH_ATTACK] = true,
	},
	[c.UnitState.DIE] = {
		[c.UnitState.REMOVED] = true,
	},
	[c.UnitState.REBORN] = {
		[c.UnitState.REMOVED] = true,
	},
	[c.UnitState.REMOVED] = {
	},
}

-- 变身
function Unit:transfrom()
	self:setState(c.UnitState.REMOVED)
end

function Unit:remove()
	self:setState(c.UnitState.REMOVED)
end

function Unit:setState(state)
	if transform[self.state][state] ~= true then
		return false
	end

	self.state = state
	self.curSkill = nil

	if state == c.UnitState.DIE then
		self.dt = 0
		self.stateTime = spineConf[roleConf[self.role].spine]["die"].totalTime
		if roleConf[self.role].deathEffect ~= "" then
			local deathEffectTime = spineConf[roleConf[self.role].deathEffect]["idle"].totalTime
			if deathEffectTime > self.stateTime then
				self.stateTime = deathEffectTime
			end
		end
		BattleController.unitDieStart()
	elseif self.state == c.UnitState.REBORN then
		self.dt = 0
		self.stateTime = spineConf[roleConf[self.role].spine]["idle"].totalTime --skill_b
	elseif state == c.UnitState.REMOVED then
		BattleController.unitRemoved(self)
	end

	ViewController.setUnitState(self.uid, state)

	return true
end

function Unit:update(dt)
	if BattleController.isFreezing() and (self.curSkill == nil or self.curSkill.isFreezing == false) then
		return
	end

	if self.state == c.UnitState.IDLE then

	elseif self.state == c.UnitState.REMOVED then

	elseif self.state == c.UnitState.ATTACK then
		if self.curSkill:update(dt) == true then
			local skill = self.curSkill
			self:setState(c.UnitState.IDLE)
			
			skill:checkNextSkill()
		end
	elseif self.state == c.UnitState.DIE then
		self.dt = self.dt + dt

		if self.dt > self.stateTime then
			BattleController.unitDieComplete(self)

			self:setState(c.UnitState.REMOVED)
		end
	elseif self.state == c.UnitState.REBORN then
		self.dt = self.dt + dt

		if self.dt > self.stateTime then
			local reviveBuff = BuffController.getReviveBuff(self.uid)
			local rebornBuff = BuffController.getRebornBuff(self.uid)

			if reviveBuff and self.useReviveBuff then
				self.useReviveBuff = false
				BattleController.reviveUnit(self, reviveBuff.funcParameter[2])
			elseif rebornBuff then
				BuffController.removeBuff(self.uid, rebornBuff.uid)
				rebornBuff:execute()
			end

			self:setState(c.UnitState.REMOVED)
		end
	elseif self.state == c.UnitState.EXTRA_ATTACK then
		if self.curSkill:update(dt) == true then
			self:setState(c.UnitState.IDLE)
		end
	elseif self.state == c.UnitState.DEATH_ATTACK then
		if self.curSkill:update(dt) == true then
			self:setState(c.UnitState.DIE)
		end
	end

	ViewController.updateAnim(self.uid, dt)
end
------------------------------------------------------------------------------

function Unit:updateRound()
	for _, skills in pairs(self.skills) do
		for _, skill in pairs(skills) do
			skill:updateRound()
		end
	end

	self:updateEnergy(self.attr.energyPerRound)

	-- 变身单位
	if self.uType == c.UnitType.TRANSFROM then
		self.lifecycle = self.lifecycle - 1

		if self.lifecycle < 0 then
			BattleController.transfromTurnBack(self)
			self:setState(c.UnitState.REMOVED)
		end
	end

	if self:isAlive() then
		BattleController.unitRoundBeginSkill(self)
	end
end

function Unit:updateWave()
	for _, skills in pairs(self.skills) do
		for _, skill in pairs(skills) do
			skill:resetCD()
		end
	end

	-- 变身单位
	if self.uType == c.UnitType.TRANSFROM then
		BattleController.transfromTurnBack(self)
		self:setState(c.UnitState.REMOVED)
	end

	self.dodgeCnt = 0
end

return Unit
