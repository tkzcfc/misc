
local BuffController = require "app.battle.controllers.BuffController"
local BattleController = require "app.battle.controllers.BattleController"
local Buff = require "app.battle.models.Buff"

local BuffEnemyBuffToBuff = class("BuffEnemyBuffToBuff", Buff)

-------------------------------------------
-- 敌对buff触发buff
-------------------------------------------

function BuffEnemyBuffToBuff:execute(cnt)
	BuffEnemyBuffToBuff.super.execute(self)

	
	local targetType = self.funcParameter[2]
	local targetCnt = self.funcParameter[3]
	local buffId = self.funcParameter[4]
	local conf = {isFriendly = 1, targetValue = {targetCnt}}
	if targetType == 1 then
		conf.targetType = "self"
	else
		conf.targetType = "random"
	end
	local uids = BattleController.getTarget(self.owner, conf)

	for _, uid in pairs(uids) do
		local unit = BattleController.getUnitByUid(uid)
		local curCnt = BuffController.getBuffCnt(unit.uid, buffId)

		if curCnt < cnt then
			for i = curCnt, cnt - 1 do
				BuffController.addBuff(buffId, unit, unit)
			end
		elseif curCnt > cnt then
			local buffs = BuffController.getBuffByBuffId(unit.uid, buffId)

			for i = cnt, curCnt - 1 do
				if #buffs < 0 then
					break
				end

				local buff = buffs[#buffs]
				if buff then
					BuffController.removeBuff(unit.uid, buff.uid)
				end
			end
		end
	end
end

return BuffEnemyBuffToBuff
