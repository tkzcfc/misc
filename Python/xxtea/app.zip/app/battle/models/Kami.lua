
local c = require "app.configs.constants"
local ghostUpConf = require "app.configs.ghostUp"
local ghostSkinConf = require "app.configs.ghostSkin"
local monsterConf = require "app.configs.monster"
local skillConf = require "app.configs.skill"
local spineConf = require "app.configs.spine"
local roleConf = require "app.configs.role"
local ViewController = require "app.battle.controllers.ViewController"
local BattleController = require "app.battle.controllers.BattleController"
local KamiSkill = require "app.battle.models.KamiSkill"

local Kami = class("Kami")

function Kami:ctor(id, skin, group, attack, curMp)
	self.uid = 0
	self.id = id
	self.skin = skin
	self.group = group
	self.astSkill = {}
	self.order = 6
	self.summonCnt = 0
	self.state = c.UnitState.IDLE
	self.attr = {
		mp = curMp or 0,
		energy = 0,
		attack = attack,
	}
	self.dt = 0
	self.totalTime = 0

	local monsterIds = ghostSkinConf[skin].ghostUpMonsterId
	table.sort(monsterIds,function (a,b)
		return a.lv < b.lv
	end)
	local finalMonsterId = monsterIds[1].id
	for _,v in pairs(monsterIds) do
		if id >= v.lv then
			finalMonsterId = v.id
		end
	end

	local conf = monsterConf[finalMonsterId]
	self.role = conf.role
	self.skill = KamiSkill.new(self, conf.skillNormal)

	self:updateEnergyLimit()
end

function Kami:isAlive()
	return true
end

function Kami:updateEnergyLimit()
	local conf = ghostUpConf[self.id]
	self.attr.energy = conf.basicEnergyLimit + self.summonCnt * conf.energyLimitLvIncr
end

function Kami:updateMp(delta)
	self.attr.mp = self.attr.mp + delta

	if self.attr.mp < 0 then
		self.attr.mp = 0
	elseif self.attr.mp > self.attr.energy then
		self.attr.mp = self.attr.energy
	end

	ViewController.updateKamiEnergy(self.group, self.attr.mp, self.attr.energy)
end

function Kami:usePowermaxSkill()
	if self.attr.mp < self.attr.energy then
		return
	end

	self.summonCnt = self.summonCnt + 1
	self:updateEnergyLimit()
	self:updateMp(-1 * self.attr.energy)

	self.skill.isFreezing = true
	BattleController.freezing = BattleController.freezing + 1
	
	self.curSkill = self.skill
	self.curAstSkillIdx = 0
	
	self:setState(c.UnitState.KAMI_APPEAR)
	BattleController.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_KAMIUSESKILL, data = {group = self.group, skillId = self.skill.attr.Id}})
end

function Kami:setState(state)
	if state == c.UnitState.KAMI_APPEAR then
		self.dt = 0

		local info = spineConf[roleConf[self.role].spine]["appear"]
		self.totalTime = info.totalTime
		self.triggers = clone(info.events or {})
	elseif state == c.UnitState.DIE then
		self.dt = 0
		self.stateTime = spineConf[roleConf[self.role].spine]["die"].totalTime
	end

	self.state = state

	ViewController.setKamiState(self.uid, state)
end

function Kami:update(dt)
	if BattleController.isFreezing() and self.skill.isFreezing == false then
		return
	end

	if self.state == c.UnitState.KAMI_APPEAR then
		self.dt = self.dt + dt

		for i = #self.triggers, 1, -1 do
			local trigger = self.triggers[i]
			if trigger.time <= self.dt then
				self:triggerEvent(trigger)
				table.remove(self.triggers, i)
			else
				break
			end
		end

		if self.dt > self.totalTime then
			self:setState(c.UnitState.ATTACK)
			self.skill:start()
		end
	elseif self.state == c.UnitState.ATTACK then
		if self.curSkill:update(dt) then
			self:useNextAstSkill()
		end
	elseif self.state == c.UnitState.DIE then
		self.dt = self.dt + dt

		if self.dt > self.totalTime then
			self:setState(c.UnitState.IDLE)

			-- self.skill.isFreezing = false
			-- BattleController.freezing = BattleController.freezing - 1
		end
	end

	ViewController.updateAnim(self.uid, dt)
end

function Kami:useNextAstSkill()
	if self.curAstSkillIdx == 0 then --释放星盘技能的时候幻化神隐藏
		ViewController.hideKami(self.uid)
	end

	self.curAstSkillIdx = self.curAstSkillIdx + 1
	local skill = self.astSkill[self.curAstSkillIdx]

	if not skill then
		self:setState(c.UnitState.DIE)
		return false
	end

	self:setState(c.UnitState.ATTACK)
	self.curSkill = skill
	skill:start()

	return true
end

function Kami:triggerEvent(trigger)
	if trigger.name == "black" and self.state == c.UnitState.KAMI_APPEAR then -- 黑屏
		self:startVideo()
	end
end

function Kami:startVideo()
	BattleController.pause()
	local success = ViewController.kamiVideo(self.skill.attr.video, self.uid)
	if not success then
		self:completeVideo()
	end
end

function Kami:completeVideo()	
	BattleController.pause()
	self.skill.isFreezing = false
	BattleController.freezing = BattleController.freezing - 1

	ViewController.updateBlackLayer()
end

return Kami
