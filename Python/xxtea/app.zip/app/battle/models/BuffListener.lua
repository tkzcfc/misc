
local buffConf = require "app.configs.buff"
local BattleController = require "app.battle.controllers.BattleController"
local Buff = require "app.battle.models.Buff"
local TeamController = require "app.battle.controllers.TeamController"

local BuffListener = class("BuffListener", Buff)

-------------------------------------------
-- 监听buff 当添加某些buff时触发
-------------------------------------------

function BuffListener:execute()
	BuffListener.super.execute(self)

	if not self.listenerCnt then
		self.listenerCnt = 0
	end
	self.listenerCnt = self.listenerCnt + 1
	if self.listenerCnt >= self.funcParameter[3] then
		self.listenerCnt = 0
		local skill = TeamController.newUnitSkill(self.owner, self.funcParameter[2])
		self.owner:useSkill(skill)
	end
end

return BuffListener
