
local c = require "app.configs.constants"

local random = require "app.battle.Random"
local BattleController = require "app.battle.controllers.BattleController"
local ViewController = require "app.battle.controllers.ViewController"
local BuffController = require "app.battle.controllers.BuffController"
local StatisticsController = require "app.battle.controllers.StatisticsController"

local GodBullet = class("GodBullet")

function GodBullet:ctor(owner)
	self.uid = 0
	self.attr = {}
	self.targetUids = {}
	self.triggers = {}
	self.owner = owner
	self.dt = 0
	self.totalTime = 0
	self.skillTriggerCnt = 0
	self.bulletTriggerCnt = 0
	self.isFirstTrigger = false
end

function GodBullet:update(dt)
	-- 定屏
	if BattleController.isFreezing() then
		return
	end

	self.dt = self.dt + dt

	for i = #self.triggers, 1, -1 do
		local trigger = self.triggers[i]
		if trigger.time <= self.dt then
			self:triggerEvent(trigger)
			table.remove(self.triggers, i)
		else
			break
		end
	end

	ViewController.updateBullet(self.uid, dt)

	if self.dt > self.totalTime then
		ViewController.removeBullet(self.uid)
		return true
	end

	return false
end

function GodBullet:triggerEvent(trigger)
	if trigger.name == "bullet_fly" then
		ViewController.bulletFly(self.uid, self.owner.uid, self.targetUids, trigger)
	elseif trigger.name == "bullet_effect" then
		ViewController.bulletEffect(self.uid, self.owner.uid, trigger.jsonName)
	elseif trigger.name == "trigger" then
		self.bulletTriggerCnt = self.bulletTriggerCnt + 1
		self.isFirstTrigger = self.bulletTriggerCnt == 1 and  self.skillTriggerCnt == 1 --(self.skillTriggerCnt >= self.unitSkill.triggerCnt and (trigger.lastTrigger == true))

		if self.attr.skillFunc == "revive" then
			self.targetUids = BattleController.reviveUnits(self.targetUids, self.attr.targetValue, self.attr.group, self.attr.funcParameter[1])

			if #self.targetUids <= 0 then
				ViewController.godSkillReviveMissed(self.owner.uid,self.attr.group)
			end
		end

		self:calcDamage()

		-- 添加buff
		if self.attr.buffId then
			for _, uid in pairs(self.targetUids) do
				local unit = BattleController.getUnitByUid(uid)
				if random:random() <= self.attr.buffHit then
					BuffController.addBuff(self.attr.buffId, unit, self.owner)
				end
			end
		end

		self.isFirstTrigger = false

		ViewController.bulletHit(self.uid, self.targetUids, trigger.jsonName)
	elseif trigger.name == "hit_down" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_high" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_far" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	end
end

function GodBullet:calcDamage()
	for _, uid in pairs(self.targetUids) do
		local defender = BattleController.getUnitByUid(uid)
		if self.isFirstTrigger then
			-- 驱散buff
			if self.attr.skillFunc == "dispel" then
				BuffController.dispelBuff(defender.uid, self.attr.funcParameter[1], self.attr.funcParameter[2])
			end

			-- 烧能量
			if self.attr.skillFunc == "burnEnergy" then
				defender:updateEnergy(-1 * defender.attr.energy * self.attr.funcParameter[1])
			end

			-- 加能量
			if self.attr.skillFunc == "addEnergy" then
				defender:updateEnergy(defender.attr.energy * self.attr.funcParameter[1])
			end
		end
	end
end

return GodBullet
