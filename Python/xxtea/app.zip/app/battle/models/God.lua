
local c = require "app.configs.constants"
local monsterConf = require "app.configs.monster"
local reinGodConf = require "app.configs.reinGod"
local GodSkill = require "app.battle.models.GodSkill"
local ViewController = require "app.battle.controllers.ViewController"
local BattleController = require "app.battle.controllers.BattleController"

local God = class("God")

function God:ctor(level, group, skillIds)
	self.uid = 0
	self.level = level
	self.group = group
	self.skillIds = skillIds
	self.order = 7
	self.state = c.UnitState.IDLE
	self.attr = {}
	self.dt = 0
	self.totalTime = 0

	local conf = monsterConf[reinGodConf[level].monsterID]
	self.role = conf.role
end

function God:useSkill(round)
	local skillId = self.skillIds[round]

	if not skillId or skillId == 0 then
		return
	end

	self:setState(c.UnitState.ATTACK)
	self.skill = GodSkill.new(self, skillId)
	self.skill:start()
end

function God:setState(state)
	self.state = state

	ViewController.setGodState(self.uid, state)
end

function God:update(dt)
	if BattleController.isFreezing() then
		return
	end

	if self.state == c.UnitState.ATTACK then
		if self.skill:update(dt) then
			self:setState(c.UnitState.IDLE)
		end
	end

	ViewController.updateAnim(self.uid, dt)
end

return God
