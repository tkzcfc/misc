
local buffConf = require "app.configs.buff"

local Buff = require "app.battle.models.Buff"

local BuffControl = class("BuffControl", Buff)

-------------------------------------------
-- 眩晕	禁止任何行动
-- 禁锢	不可发动普攻
-- 沉默	只可发动普攻
-- 魅惑	只可发动普攻，并且目标只能是队友
-- 睡眠	禁止任何行动，受击会解除状态
-- 嘲讽	只可发动普攻，并且目标攻击发动嘲讽的目标
-------------------------------------------

function BuffControl:ctor(id, owner, attackerUid)
	BuffControl.super.ctor(self, id, owner, attackerUid)

	local conf = buffConf[id]
	self.isControl = true
	self.noSkill = conf.noSkill
	self.noAttack = conf.noAttack
end

function BuffControl:add()
	BuffControl.super.add(self)

	self.owner:updateControlBuff()
end

function BuffControl:remove()
	BuffControl.super.remove(self)

	self.owner:updateControlBuff()
end

function BuffControl:copy(buff)
	BuffControl.super.copy(self, buff)

	self.isControl = buff.isControl
	self.noSkill = buff.noSkill
	self.noAttack = buff.noAttack
end

return BuffControl
