
local buffConf = require "app.configs.buff"

local BattleController = require "app.battle.controllers.BattleController"
local Buff = require "app.battle.models.Buff"

local BuffReborn = class("BuffReborn", Buff)

-------------------------------------------
-- 重生
-------------------------------------------

function BuffReborn:execute(...)
	BuffReborn.super.execute(self, ...)
	
	BattleController.addRebornUnit(self.owner, self.funcParameter)
end

return BuffReborn
