
local c = require "app.configs.constants"

local skillConf = require "app.configs.skill"
local spineConf = require "app.configs.spine"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local globalBattleConf = require "app.configs.globalBattle"
local random = require "app.battle.Random"
local ViewController = require "app.battle.controllers.ViewController"
local BattleController = require "app.battle.controllers.BattleController"
local BuffController = require "app.battle.controllers.BuffController"

local UnitSkill = class("UnitSkill")

function UnitSkill:ctor(owner, skillId)
	assert(skillConf[skillId] ~= nil, "skillConf invalid skillId" .. (skillId or "nil"))

	self.owner = owner
	self.attr = clone(skillConf[skillId])

	self.curCd = 0
	self.isFreezing = false
	self.isExtra = false -- 是否赠送
	self.isCrit = false -- 是否暴击
	self.isHit = false -- 是否命中
	self.isKill = false -- 是否击杀
	self.isAssist = false -- 是否已经判定协同攻击
	self.nextSkillInfo = {}
	self.attackReplyUids = nil

	local spineInfo = spineConf[roleConf[self.owner.role].spine][self.attr.skillAnim]
	self.animTime = (spineInfo ~= nil) and spineInfo.totalTime or -1
	self.events = (spineInfo ~= nil) and spineInfo.events or {}
	self.triggerCnt = (spineInfo ~= nil) and spineInfo.triggerCnt or 0
	self.curCnt = 0
end

function UnitSkill:valid()
	-- cd时间未到
	if self.curCd > 0 then
		return false
	end

	-- 释放概率
	if random:random() > self.attr.chance then
		return false
	end

	-- 消耗能量
	if self.attr.energyChange < 0 and self.owner.attr.mp < math.abs(self.attr.energyChange) then
		return false
	end

	return true
end

function UnitSkill:updateRound()
	self.curCd = self.curCd - 1
	
	if self.curCd < 0 then
		self.curCd = 0
	end
end

function UnitSkill:resetCD()
	self.curCd = 0
end

function UnitSkill:start(targetUids)
	self.dt = 0
	self.triggers = clone(self.events)
	self.targetUids = targetUids or BattleController.getUnitSkillTarget(self)
	self.totalTime = self.animTime
	self.isAssist = false
	self.isCrit = false
	self.isHit = false
	self.isKill = false
	self.curCnt = 0
	self.hasGroupBuff = 0 --0不是groupToSkill类型技能,1有groupBuff,2没有groupBuff

	-- 没有目标
	if #self.targetUids <= 0 then
		self.totalTime = 0
		self.triggers = {}

		self.owner:setState(c.UnitState.IDLE)
		return
	end

	-- 重置cd
	self.curCd = self.attr.cd

	-- 技能掉血
	if self.attr.skillFunc == "lifeCost" then
		self.owner:skillReduceHp(self.owner.attr.hp * self.attr.funcParameter[1])
	end

	-- 赠送的技能不回能
	if not self.isExtra then
		-- 能量
		self.owner:updateEnergy(self.attr.energyChange)
	end

	-- 修改技能连击上限
	if self.attr.skillFunc == "changeLimit" then
		local params = self.attr.funcParameter
		local offset = table.remove(params, 1)
		local min = table.remove(params, 1)
		local max = table.remove(params, 1)

		local changeSkills = {}
		for k,v in ipairs(params) do
			changeSkills[v] = true
		end

		for _, skills in pairs(self.owner.skills) do
			for _, skill in pairs(skills) do
				if changeSkills[skill.attr.Id] then
					for _, nextSkill in ipairs(skill.attr.nextSkill) do
						nextSkill.n = nextSkill.n + offset
						nextSkill.n = math.min(nextSkill.n, max)
						nextSkill.n = math.max(nextSkill.n, min)
					end
				end
			end
		end

		return
	end

	-- 没有动作或是被动技能，直接加buff
	if self.animTime < 0 or self.attr.skillType == c.SkillType.PASSIVE then
		self.totalTime = 0
		local buffId = self.attr.buffId

		if buffId > 0 then
			for _, uid in pairs(self.targetUids) do
				BuffController.addBuff(buffId, BattleController.getUnitByUid(uid), self.owner)
			end
		end

		return
	end

	if self.attr.skillType == c.SkillType.POWERMAX then
		for _, trigger in pairs(self.triggers) do
			if trigger.name == "freezingstart" then

				local t = (trigger.int / 30.0)
				table.insert(self.triggers, {
					name = "freezingend",
					time = t,
				})

				-- if self.attr.skillType == c.SkillType.POWERMAX and BattleController.canFreezing[self.owner.group] then
				-- 	self.isFreezing = true
				-- 	BattleController.freezing = BattleController.freezing + 1
				-- 	ViewController.freezingStart(self.owner.uid)
				-- end
				
				break
			end
		end
	end


	local jsonName = roleConf[self.owner.role].spine
	local jumpTime = globalBattleConf[1].nearTime
	if spineConf[jsonName].jump then
		jumpTime = spineConf[jsonName].jump.totalTime
	end

	local moveTime = 0
	if self.attr.distance == 1 then -- 远程
		moveTime = 0
	else -- 2.近程单体, 3.近程群体, 4.屏幕中间
		moveTime = jumpTime
	end

	if moveTime > 0 then
		self.totalTime = self.totalTime + 2 * moveTime
		for _, info in pairs(self.triggers) do
			if info.name == "freezingstart" and self.attr.skillType == c.SkillType.POWERMAX then
				-- print("  ddddddddddddddddddddddd ")
			else
				info.time = info.time + moveTime
			end
		end

		table.insert(self.triggers, {
			time = self.totalTime - moveTime,
			name = "move_back",
			duration = moveTime,
		})

		table.insert(self.triggers, {
			time = moveTime,
			name = "start_skill",
		})

		table.insert(self.triggers, {
			time = 0,
			name = "move_towards",
			duration = moveTime,
		})

	else
		table.insert(self.triggers, {
			time = 0,
			name = "start_skill",
		})
	end

	table.sort(self.triggers, function(a, b)
		return a.time > b.time
	end)

end

function UnitSkill:update(dt)
	self.dt = self.dt + dt

	for i = #self.triggers, 1, -1 do
		local trigger = self.triggers[i]
		if trigger.time <= self.dt then
			self:triggerEvent(trigger)
			table.remove(self.triggers, i)
		else
			break
		end
	end

	if self.dt > self.totalTime then
		return true
	end

	return false
end

function UnitSkill:checkAssist()
	if self.isAssist == false then
		self.isAssist = true
		BattleController.checkUnitAssist(self.owner)
	end
end

function UnitSkill:checkNextSkill()
	local info = self.attr.nextSkill[1]
	if info and info.func == "endTrigger" 
	and BattleController.nextSkillTrigger(self.owner, self.nextSkillInfo, info.id, info.n) then -- 无条件连击
		
	elseif info and info.func == "killTrigger" and self.isKill 
	and BattleController.nextSkillTrigger(self.owner, self.nextSkillInfo, info.id, info.n) then -- 击杀连击
		
	elseif info and info.func == "critTrigger" and self.isCrit 
	and BattleController.nextSkillTrigger(self.owner, self.nextSkillInfo, info.id, info.n) then -- 暴击连击

	elseif self.hasGroupBuff ~= 0 and self.attr.nextSkill[self.hasGroupBuff]
	and BattleController.nextSkillTrigger(self.owner, self.nextSkillInfo, self.attr.nextSkill[self.hasGroupBuff].id, self.attr.nextSkill[self.hasGroupBuff].n) then --监听buffGroup连接
	
	elseif self.isHit then	-- 命中时触发
		BattleController.unitEachHitToSkill(self.owner, self.isExtra)
	end
end

function UnitSkill:triggerEvent(trigger)
	if trigger.name == "start_skill" then
		ViewController.unitUseSkill(self.owner.uid, self.attr.Id)
	elseif trigger.name == "move_towards" then
		ViewController.unitMoveTowards(self.owner.uid, self.attr.Id, self.targetUids, trigger.duration)
	elseif trigger.name == "move_back" then
		ViewController.unitMoveBack(self.owner.uid, trigger.duration)
	elseif trigger.name == "trigger" then
		self.curCnt = self.curCnt + 1
		BattleController.addSkillBullet(self)
	elseif trigger.name == "freezingstart" then
		if self.attr.skillType == c.SkillType.POWERMAX and BattleController.canFreezing[self.owner.group] then
			self.isFreezing = true
			BattleController.freezing = BattleController.freezing + 1
			ViewController.freezingStart(self.owner.uid)
		end
	elseif trigger.name == "freezingend" then
		if self.attr.skillType == c.SkillType.POWERMAX and BattleController.canFreezing[self.owner.group] then
			self.isFreezing = false
			BattleController.freezing = BattleController.freezing - 1
			ViewController.freezingEnd(self.owner.uid)
		end
	elseif trigger.name == "hit_down" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_high" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "hit_far" then
		ViewController.unitHitEffect(self.targetUids,trigger.name)
	elseif trigger.name == "duang_start" then
		if trigger.int then
			ViewController.startShake(trigger.int)
		end
	elseif trigger.name == "duang_end" then
		ViewController.stopShake()
	elseif trigger.name == "break" then
		ViewController.breakEffect()
	end
end

return UnitSkill
