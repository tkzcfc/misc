
local Random = {}

function Random:ctor()
    self.seed = 0
    self.A = 16807
    self.M = 2^31 - 1
end

function Random:randomseed(userSeed) --期望传入整形
    self.seed = userSeed

    self:random()
    self:random()
    self:random()
    self:random()
end

function Random:newrandomseed()
    local ok, socket = pcall(function()
        return require("socket")
    end)

    if ok then
        -- 如果集成了 socket 模块，则使用 socket.gettime() 获取随机数种子
        self:randomseed(socket.gettime() * 1000)
    else
        self:randomseed(os.time())
    end
end

function Random:random(starts, ends) --期望传入整形
    self.seed = math.floor((self.seed * self.A) % self.M + 0.5)
    
    if starts then 
        if ends then
            return math.floor(self.seed / self.M * (ends - starts + 1)) + starts 
        else
            return math.floor(self.seed /self.M  * starts) + 1
        end
    else
        return self.seed / self.M
    end
end

return Random
