package.path = "./calcbattle/?.lua;" .. package.path

require "app.battle.server.depend"
local msgPack = require "app.battle.server.MessagePack"

function StartBattle(data)
	local c = require "app.configs.constants"
	local BattleController = require "app.battle.controllers.BattleController"
	local TeamController = require "app.battle.controllers.TeamController"
	local random = require "app.battle.Random"
	local monsterConf = require "app.configs.monster"
	local globalPublicConf = require "app.configs.globalPublic"
	
	local uData = msgPack.unpack(data)
	local teams = uData.T
	local fightStatus = c.FightStatus.arena
	local forceBuff = {}
	local atkDonAttr = {}
	local defDonAttr = {}
	local damageBuff = 0
	if uData.Ex then
		if uData.Ex.fs then
			fightStatus = tonumber(uData.Ex.fs)
		end

		if uData.Ex.monster_force_buff then
			for k,v in ipairs(uData.Ex.monster_force_buff) do
				forceBuff[300+k] = v
			end
		end

		if uData.Ex.monster_inspire then
			damageBuff = uData.Ex.monster_inspire
		end
		--王者之剑捐赠属性加成
		if uData.Ex.attack_donation_attr then
			for _, info in pairs(uData.Ex.attack_donation_attr) do
				atkDonAttr[info.Id] = info.Num
			end
		end 

		if uData.Ex.defencer_donation_attr then
			for _, info in pairs(uData.Ex.defencer_donation_attr) do
				defDonAttr[info.Id] = info.Num
			end
		end 
	end
	math.randomseed(os.time())
	math.random()
	math.random()
	local seed = math.random(1,100000000)

	local data = TeamController.getDataFromServer(teams)
	data.params.fightStatus = fightStatus
	data.params.forceBuff = forceBuff
	data.params.damageBuff = damageBuff
	data.params.attackDonationAttr = atkDonAttr
	data.params.defDonationAttr = defDonAttr
	BattleController.ctor(data, seed)
	BattleController.initializeUnits()

	-- 开启自动战斗
	BattleController.autoFight = {
		[c.UnitGroup.ATTACKER] = true,
		[c.UnitGroup.DEFENDER] = true,
	}

	BattleController.canFreezing = {
		[c.UnitGroup.ATTACKER] = true,
		[c.UnitGroup.DEFENDER] = true,
	}
	
	BattleController.start()

	local time = 0
	local cnt = 0

	local dt = 0.016
	while true do
		BattleController.update(dt)

		cnt = cnt + 1
		time = time + dt

		local state = BattleController.state

		if state == c.GameState.NEXT_WAVE then
			BattleController.updateNextWave()
			BattleController.start()
		elseif state == c.GameState.ATTACK_WIN or state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
			break
		end
	end

	local ret = {
		Win = (BattleController.state == c.GameState.ATTACK_WIN) and 1 or 2,
		T = {
			[c.UnitGroup.ATTACKER] = {
				Leader = teams[c.UnitGroup.ATTACKER].Leader,
				Fighters = {{Id = 0}, {Id = 0}, {Id = 0}, {Id = 0}, {Id = 0}},
				Ghost = teams[c.UnitGroup.ATTACKER].Ghost,
				Ex = {total_damage = 0, round = BattleController.curRound, state = BattleController.state},
			},
			[c.UnitGroup.DEFENDER] = {
				Leader = teams[c.UnitGroup.DEFENDER].Leader,
				Fighters = {{Id = 0}, {Id = 0}, {Id = 0}, {Id = 0}, {Id = 0}},
				Ghost = teams[c.UnitGroup.DEFENDER].Ghost,
				Ex = {total_damage = 0, round = BattleController.curRound, state = BattleController.state},
			},
		},
		Seed = seed,
	}

	for _, unit in pairs(BattleController.units) do
		if unit.group and unit.order then
			ret.T[unit.group].Fighters[unit.order] = {
				Id = unit.originHeroId or unit.heroId,
				Hp = unit.attr.hp,
				MaxHp = unit.attr.maxLife,
				DecHp = math.ceil((unit.attr.maxLife - unit.attr.hp) / unit.attr.maxLife * 1000000)
			}
		end
	end

	local StatisticsController = require "app.battle.controllers.StatisticsController"
	for idx, value in pairs(StatisticsController.damage) do
		local group = (idx <= 5) and c.UnitGroup.ATTACKER or c.UnitGroup.DEFENDER
		local damage = ret.T[group].Ex.total_damage + value
		local order = idx - (group-1) * 5
		ret.T[group].Ex.total_damage = damage
		ret.T[group].Ex.damages = ret.T[group].Ex.damages or {}
		ret.T[group].Ex.damages[order] = value
	end
	for group, value in pairs(StatisticsController.kamiDamage) do
		ret.T[group].Ex.kamiDamage = value
		ret.T[group].Ex.total_damage = math.ceil(ret.T[group].Ex.total_damage + value)
	end

	ret.T[c.UnitGroup.ATTACKER].Ex.total_damage = tostring(ret.T[c.UnitGroup.ATTACKER].Ex.total_damage)
	ret.T[c.UnitGroup.DEFENDER].Ex.total_damage = tostring(ret.T[c.UnitGroup.DEFENDER].Ex.total_damage)

	if fightStatus == c.FightStatus.towerElite then --精英爬塔传星级
		local star_ = 0
		if BattleController.state == c.GameState.ATTACK_WIN then
			star_ = 1--胜利 最低1星
	        local dieCnt = 0
	        for k,v in pairs(StatisticsController.hp or {}) do
	            if k <= 5 and v <= 0 then
	                dieCnt = dieCnt + 1
	            end
	        end
	        for i,v in ipairs(globalPublicConf[1].towerStarCond) do
	            if dieCnt >= v then
	                star_ = i
	                break
	            end
	        end
	    end
        ret.T[c.UnitGroup.ATTACKER].Ex.star = star_
	end

	return msgPack.pack(ret)


	-- local content = "state = " .. BattleController.state .. ", seed = " .. random.seed .. "\n"
	-- content = content .. table.concat(random.log, "\n")

	-- local file = io.open("/Users/liuna1/Desktop/serverBattle.lua", "w+")
 --    file:write(content)
 --    io.close(file)
end

-- local function main()
	-- local file = io.open("app/battle/server/data.bin", "rb")
	-- StartBattle(file:read("*a"))
-- end

-- local status, msg = xpcall(main, function(msg)
--     return debug.traceback(msg, 3)
-- end)

-- if not status then
--     print(msg)
-- end
