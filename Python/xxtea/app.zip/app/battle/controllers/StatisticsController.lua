-- 统计

local c = require "app.configs.constants"


local StatisticsController = {}
local self = StatisticsController

function StatisticsController.new()
	self.damage = {}
	self.hp = {}
	self.maxLife = {}
	self.kamiDamage = {
		[c.UnitGroup.ATTACKER] = 0,
		[c.UnitGroup.DEFENDER] = 0,
	}
end

function StatisticsController.getUnitIdx(unit)
	return (unit.group - 1) * 5 + unit.order
end

-- 伤害统计
function StatisticsController.damageStatistics(unit, value)
	local idx = self.getUnitIdx(unit)
	local damage = self.damage[idx] or 0
	damage = damage + value

	self.damage[idx] = damage
end

function StatisticsController.kamiDamageStatistics(group, value)
	self.kamiDamage[group] = self.kamiDamage[group] + value
end

function StatisticsController.life(unit)
	local idx = self.getUnitIdx(unit)
	self.hp[idx] = unit.attr.hp
	self.maxLife[idx] = unit.attr.maxLife
end

function StatisticsController.getGroupDamage(group, withKami)
	local damage = 0
	for idx, value in pairs(self.damage) do
		local g = (idx <= 5) and c.UnitGroup.ATTACKER or c.UnitGroup.DEFENDER
		if g == group then
			damage = damage + value
		end
	end
	if withKami then
		damage = damage + self.kamiDamage[group]
	end
	return damage
end

return StatisticsController
