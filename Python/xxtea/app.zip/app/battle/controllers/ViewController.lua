
local ViewController = {}
local self = ViewController

function ViewController.new(scene)
	self.scene = scene
end

setmetatable(ViewController, {
	__index = function(controller, funcName)
		local scene = rawget(controller, "scene")
		if not scene or tolua.isnull(scene) then
			return function()end
		else
			assert(scene[funcName] ~= nil, "ViewController." .. funcName .. " is nil!!!!!")
			return handler(scene, scene[funcName])
		end
	end,
})

return ViewController
