
local heroConf = require "app.configs.hero"
local monsterConf = require "app.configs.monster"
local monsterPowerConf = require "app.configs.monsterPower"
local skillConf = require "app.configs.skill"
local itemConf = require "app.configs.item"
local suitConf = require "app.configs.suit"
local skinConf = require "app.configs.skin"
local talentConf = require "app.configs.talent"
local globalBattleConf = require "app.configs.globalBattle"
local astrolabeSkillConf = require "app.configs.astrolabeSkill"
local playerTitleConf = require "app.configs.playerTitle"
local rollSkillConf = require "app.configs.rollSkill"
local c = require "app.configs.constants"
local Unit = require "app.battle.models.Unit"
local Kami = require "app.battle.models.Kami"
local God = require "app.battle.models.God"
local UnitSkill = require "app.battle.models.UnitSkill"
local KamiSkill = require "app.battle.models.KamiSkill"

local UnitFactory = class("UnitFactory")

local attributes = {
    "attack", -- 攻击
    "defense", -- 防御
    "maxLife", -- 生命上限
    "energy", -- 能量上限
    "crit", -- 暴击
    "critDamage", -- 暴击伤害
    "hit", -- 命中
    "dodge", -- 闪避
    "speed", -- 速度
    "lifePerHit", -- 吸血
    "lifePerRound", -- 生命回复
    "energyPerRound", -- 能量回复
    "addCure", -- 附加治疗
    "cureRatio", -- 治疗加成
    "damageRatio", -- 伤害减免
    "healingRatio", -- 治疗减免
    "effectHit", -- 效果命中
    "effectDodge", -- 效果抵抗
    "critOdds", -- 暴击率
    "calmOdds", -- 抗暴
    "damageUpRatio", --伤害加深
}

local default_attr = {a = 0, b = 0, c = 0}

function UnitFactory:ctor()
	self.uid = 1
	self.rollSkillConf = {}
	for k,v in pairs(rollSkillConf) do
		self.rollSkillConf[v.id] = {skillType = v.skillType, skillFirst = v.skillFirst}
	end
end

function UnitFactory:createKami(id, skin, astSkill, group, attack, curMp)
	local kami = Kami.new(id, skin, group, attack, curMp)
    self:initKamiAstSkill(kami, astSkill)

    kami.uid = self.uid
    self.uid = self.uid + 1

	return kami
end

function UnitFactory:createGod(level, group, skillIds)
	local god = God.new(level, group, skillIds)

	god.uid = self.uid
	self.uid = self.uid + 1

	return god
end

function UnitFactory:createUnit(data)
	local id = data.id
	local conf = heroConf[id] or monsterConf[id]
	assert(conf ~= nil, "UnitFactory:createUnit invalid id:" .. id)

	local unit = Unit.new()
	unit.originData = data
	unit.blowEnergyRatio = conf.blowEnergyRatio or 0
	unit.role = conf.role
	unit.heroId = id
	unit.originHeroId = unit.heroId
	unit.level = data.level or 1
	unit.star = data.star or 1
	unit.cls = data.cls or 0
	unit.aoyi = data.aoyi or false
	unit.armorsID = data.armors
	unit.uid = self.uid
	unit.fightBodyScale = conf.fightBodyScale or 1
	unit.skin = data.skin or skinConf[1].spineName
	unit.artifactSkill = data.artifactSkill or nil
	unit.exSkills = data.exSkills or {}
	unit.titleStore = data.titleStore or {}
	unit.runeSkills = data.runeSkills or {}
	self.uid = self.uid + 1

	for attr, value in pairs(data.props) do
		unit.part_attr[attr] = clone(value)
		unit.attr[attr] = (value.a * (1 + value.b) + value.c) * (1 + (value.d or 0)) + (value.e or 0)
	end
	unit.attr.energy = globalBattleConf[1].energyLimit
	unit.attr.hp = data.curHp or unit.attr.maxLife
	unit.attr.mp = data.curMp or 0
	-- skills
	self:initSkills(unit, conf)

	if data.atkFactor then
		unit:setAtkFactor(data.atkFactor)
	end

	return unit
end

function UnitFactory:initKamiAstSkill(kami, astSkill)
    local astSkillLv = {}
    for k,v in pairs(astSkill or {}) do
        if v.Lv > 0 then
            astSkillLv[v.Pos] = v.Lv
        end
    end

    for i = 1, 4 do --4个星盘技能按顺序释放
        if astSkillLv[i] then
            local skillId = nil
            local idx = i * 1000 + astSkillLv[i]
            if astrolabeSkillConf[idx] then
                skillId = astrolabeSkillConf[idx].skillId
            end
            
            if skillId then
                table.insert(kami.astSkill, KamiSkill.new(kami, skillId))
            end
        end
    end
end

function UnitFactory:initSkills(unit, conf)
	local skillIds = {}
	local function getUpgradeSkillId(skillId, talentLevel)
		if skillConf[skillId] then
			local skillData = skillConf[skillId]

			if skillData.upgradeSkill == 0 and skillData.talentUnlock <= talentLevel then
				return skillId
			end

			if skillData.talentUnlock > talentLevel then
				return 0
			end

			if skillData.talentUnlock <= talentLevel then
				local skill = getUpgradeSkillId(skillData.upgradeSkill, talentLevel)
				if skill == 0 then
					return skillId
				else
					return skill
				end
			else
				return 0
			end
		end
		return 0
	end

	for _, key in ipairs({"skillUltimate","skillNormal"}) do
		local skillId = conf[key]
		if skillConf[skillId] then
			if heroConf[unit.heroId] or unit.cls > 0 then
				skillId = getUpgradeSkillId(skillId, unit.cls)
			else
				local limit = skillConf[skillId].levelUnlock or 1
				if unit.level < limit then
					skillId = 0
				end
			end

			if skillId ~= 0 then
				if key == "skillUltimate" and unit.aoyi then	--替换大招为奥义技能
					if conf.maxSkill and conf.maxSkill ~= 0 then
						skillId = conf.maxSkill
					end
				end

				skillIds[#skillIds + 1] = skillId
			end
		end
	end
	
	-- 需要开启的技能
	for _, key in pairs({"skill1", "skill2", "skill3", "skill4", "skill5"}) do
		local skillId = conf[key]
		if skillConf[skillId] then
			if heroConf[unit.heroId] or unit.cls > 0 then
				skillId = getUpgradeSkillId(skillId, unit.cls)
			else
				local limit = skillConf[skillId].levelUnlock or 1
				if unit.level < limit then
					skillId = 0
				end
			end

			if skillId ~= 0 then
				skillIds[#skillIds + 1] = skillId
			end
		end
	end

	for _, skillId in ipairs(table.values(skillIds)) do
		local info = skillConf[skillId]
		if info and info.skillFunc == "replace" then
			local oldId = info.funcParameter[1]
			local newId = info.funcParameter[2]

			for idx, id in pairs(skillIds) do
				if oldId == id then
					skillIds[idx] = newId
				end
			end
		end
	end

	-- 天赋技能
	for _,skillId in pairs(self:getHeroTalentSkillID(unit.heroId,unit.cls)) do
		skillIds[#skillIds + 1] = skillId
	end

	-- 装备技能
	for _,skillId in pairs(self:getHeroArmorSkillID(unit.armorsID)) do
		skillIds[#skillIds + 1] = skillId
	end

	--额外附加技能
	for _,skillId in pairs(unit.exSkills or {}) do
		skillIds[#skillIds + 1] = skillId
	end

	--称号替换技能↓↓↓↓↓
	local topSortTitles = {}
	for k,v in ipairs(unit.titleStore or {}) do --同titleType的称号只作用priority最大的
		local cData = playerTitleConf[v]
		if cData then
			local titleType = cData.titletype
			if topSortTitles[titleType] then
				if cData.priority > playerTitleConf[topSortTitles[titleType]].priority then
					topSortTitles[titleType] = cData.id
				end
			else
				topSortTitles[titleType] = cData.id
			end 
		end
	end
	for _,titleId in pairs(topSortTitles) do
		for k, skillId in pairs(skillIds) do
			if playerTitleConf[titleId].titleskill[1] == skillId then
				skillIds[k] = playerTitleConf[titleId].titleskill[2]
				break
			end
		end
	end
	--↑↑↑↑↑↑↑↑↑↑

	--符文技能
	local reTabSkills = {}
	for _, skillId in pairs(unit.runeSkills) do
		reTabSkills[self.rollSkillConf[skillId].skillType] = reTabSkills[self.rollSkillConf[skillId].skillType] or {}
		table.insert(reTabSkills[self.rollSkillConf[skillId].skillType], skillId)
	end
	for _,skillTypeTab in pairs(reTabSkills) do
		if #skillTypeTab > 1 then
			table.sort(skillTypeTab, function(a, b)
				return self.rollSkillConf[a].skillFirst > self.rollSkillConf[b].skillFirst
			end)
		end
	end
	for _,skillTypeTab in pairs(reTabSkills) do
		skillIds[#skillIds + 1] = skillTypeTab[1]
	end
	
	for _, id in pairs(skillIds) do
		if skillConf[id] then
			local skillType = skillConf[id].skillType
			table.insert(unit.skills[skillType], UnitSkill.new(unit, id))
		end
	end
end

function UnitFactory:getHeroArmorSkillID(armorsID)
	local topColor = c.ITEM_TOP_COLOR
    local skillID = {}

    local groupList = {}
    for _,id in pairs(armorsID or {}) do
    	local cData = itemConf[id]
    	if not groupList[cData.armorType] then
    		groupList[cData.armorType] = {}
    		groupList[cData.armorType][cData.color] = {cnt = 1, suitData = suitConf[cData.suit]}
    	elseif not groupList[cData.armorType][cData.color] then
    		groupList[cData.armorType][cData.color] = {cnt = 1, suitData = suitConf[cData.suit]}
    	else
    		groupList[cData.armorType][cData.color] = {cnt = groupList[cData.armorType][cData.color].cnt + 1, suitData = suitConf[cData.suit]} 
    	end
    end

    for k,v in pairs(groupList) do
    	local totalCnt = 0
    	for i = topColor, 1, -1 do
    		local insertSkill = false
    		if v[i] then
    			totalCnt = totalCnt + v[i].cnt
    			for m,n in pairs(v[i].suitData.skill or {}) do 
    				if totalCnt >= n.n then
    					table.insert(skillID, n.skill)
    					insertSkill = true
    					break	--仅支持套装只有1个技能
    				end
    			end
    			if insertSkill then
    				break
    			end
    		end
    	end
    end

    return skillID
end

function UnitFactory:getHeroTalentSkillID(heroId,cls)
	local skillID = {}
	local cData = talentConf[heroId]

	if not cData then
		return skillID
	end

	for k,attribute in ipairs(cData.extraAttribute) do
		if cls >= k and attribute.type == 2 then
			table.insert(skillID,attribute.id)
		end
	end

	return skillID
end

function UnitFactory:newUnitSkill(unit, skillId)
	local skill = UnitSkill.new(unit, skillId)
	skill.isExtra = true

	return skill
end

return UnitFactory
