
local c = require "app.configs.constants"

local random = require "app.battle.Random"

local BuffController = {}
local self = BuffController

function BuffController.new()
	local BuffFactory = require "app.battle.controllers.BuffFactory"
	self.factory = BuffFactory.new()
	self.buffs = {}
	self.buffsCnt = {}
	self.enemyBuffToBuffs = {}
	self.unitGroupBuffsInfo = {
		[c.UnitGroup.ATTACKER] = {},
		[c.UnitGroup.DEFENDER] = {},
	}
end

function BuffController.reset()
	local uids = table.keys(self.buffs)
	for _, uid in pairs(uids) do
		self.removeBuffByUid(uid)
	end

	self.buffsCnt = {}
	self.enemyBuffToBuffs = {}
	self.unitGroupBuffsInfo = {
		[c.UnitGroup.ATTACKER] = {},
		[c.UnitGroup.DEFENDER] = {},
	}
end

function BuffController.increaseBuffCnt(buff)
	-- self.buffsCnt
	local uid = buff.owner.uid
	local buffId = buff.id
	self.buffsCnt[uid] = self.buffsCnt[uid] or {}

	local cnt = self.buffsCnt[uid][buffId] or 0
	self.buffsCnt[uid][buffId] = cnt + 1

	-- self.unitGroupBuffsInfo
	if cnt == 0 then -- 获得新buff
		local group = buff.owner.group
		if group then
			if not self.unitGroupBuffsInfo[group] then
				self.unitGroupBuffsInfo[group] = {}
			end
			self.unitGroupBuffsInfo[group][buffId] = self.unitGroupBuffsInfo[group][buffId] or {cnt = 0, dirty = false}
			local value = self.unitGroupBuffsInfo[group][buffId].cnt
			self.unitGroupBuffsInfo[group][buffId].cnt = value + 1
			self.unitGroupBuffsInfo[group][buffId].dirty = true
		end
	end

	-- self.enemyBuffToBuffs
	if buff.func == "enemyBuffToBuff" then
		self.enemyBuffToBuffs[buff.uid] = buff
	end
end

function BuffController.decreaseBuffCnt(buff)
	-- self.buffsCnt
	local uid = buff.owner.uid
	local buffId = buff.id
	self.buffsCnt[uid] = self.buffsCnt[uid] or {}

	local cnt = self.buffsCnt[uid][buffId] or 0
	self.buffsCnt[uid][buffId] = (cnt - 1 < 0) and 0 or (cnt - 1)

	-- self.unitGroupBuffsInfo
	if cnt == 1 then -- buffId全部清除
		local group = buff.owner.group
		self.unitGroupBuffsInfo[group][buffId] = self.unitGroupBuffsInfo[group][buffId] or {cnt = 0, dirty = false}
		local pre = self.unitGroupBuffsInfo[group][buffId].cnt
		local cur = (pre - 1 < 0) and 0 or (pre - 1)
		self.unitGroupBuffsInfo[group][buffId].cnt = cur
		if pre ~= cur then
			self.unitGroupBuffsInfo[group][buffId].dirty = true
		end
	end

	-- self.enemyBuffToBuffs
	if buff.func == "enemyBuffToBuff" then
		self.enemyBuffToBuffs[buff.uid] = nil
	end
end

function BuffController.getBuffGroupCnt(uid, group)
	local buffs = self.buffs[uid] or {}

	local cnt = 0
	for _, buff in pairs(buffs) do
		if buff.group == group then
			cnt = cnt + 1
		end
	end

	return cnt
end

function BuffController.getBuffCnt(uid, buffId)
	if not self.buffsCnt[uid] then
		return 0
	end

	return self.buffsCnt[uid][buffId] or 0
end

function BuffController.getBuffByBuffId(uid, buffId)
	local buffs = {}

	for _, buff in pairs(self.buffs[uid] or {}) do
		if buff.id == buffId then
			table.insert(buffs, buff)
		end
	end

	return buffs
end

-- 继承增益buff
function BuffController.inheritBuff(uid, target)
	self.buffs[target.uid] = self.buffs[target.uid] or {}

	local targetBuffs = self.buffs[target.uid]
	local buffs = self.buffs[uid] or {}

	for _, buff in pairs(buffs) do
		if buff.bType == 1 then -- 增益
			local b = self.factory:cloneBuff(buff, target)
			table.insert(targetBuffs, b)
			b:add()
		end
	end
end

-- 驱散
function BuffController.dispelBuff(uid, buffType, cnt)
	local BattleController = require "app.battle.controllers.BattleController"
	local buffs = {}

	for _, buff in pairs(self.buffs[uid] or {}) do
		if buff.bType == buffType and buff.isDispel == 1 then
			buffs[#buffs + 1] = buff.uid
		end
	end

	while #buffs > 0 and cnt > 0 do
		local idx = random:random(1, #buffs)
		self.removeBuff(uid, buffs[idx])

		cnt = cnt - 1
		table.remove(buffs, idx)
	end

	local buff = self.getDispeledToSkill(uid) --2019.10.17 受到驱散时 释放技能
	if buff then
		if buff.funcParameter[1] == 0 or buff.funcParameter[1] == buffType then
			local unit = BattleController.getUnitByUid(uid)
			local skill = TeamController.newUnitSkill(unit, buff.funcParameter[2])
			unit:useSkill(skill)
		end
	end
end

function BuffController.addBuff(buffId, target, attacker)
	local BattleController = require "app.battle.controllers.BattleController"
	self.buffs[target.uid] = self.buffs[target.uid] or {}

	local buffs = self.buffs[target.uid]
	local count = #buffs
	local buff = self.factory:createBuff(buffId, target, attacker)
	local repeatToAttack = false
	local immune = false

	for _, b in pairs(buffs) do
		if b.func == "immuneBuff"  then
		   	for i = 1, #b.funcParameter do
			   	if b.funcParameter[i] == buff.group then
					immune = true
					break
				end
			end
		end

		if b.func == "repeatToAttack" then
			repeatToAttack = true
		end
	end

	-- 免疫buff
	if immune then
		return
	end
	

	local groupCnt = 1
	local overlap = false
	local hasSameBuff = false

	for idx = count, 1, -1 do
		local b = buffs[idx]

		-- if b.id == buff.id then --7.27修改 重复buff的判断由id变为group
		-- 	hasSameBuff = true
		-- end

		if b.group == buff.group then
			hasSameBuff = true    --7.27修改 重复buff的判断由id变为group

			groupCnt = groupCnt + 1

			if groupCnt > b.overlap then
				overlap = true
				table.remove(buffs, idx)
				b:remove()
			end
		end
	end

	for _, unit in pairs(BattleController.units) do
		local listenerBuff = self.getListenerBuff(unit.uid)
		if unit:isAlive() and listenerBuff then
			if (listenerBuff.funcParameter[1] == 0 and unit.group ~= target.group) or
				(listenerBuff.funcParameter[1] == 1 and unit.group == target.group) then
				for _,listenGroup in ipairs(listenerBuff.funcParameter2 or {}) do
					if buff.group == listenGroup then
						listenerBuff:execute()
						break
					end
				end
			end
		end
	end

	local attackerBuffs = self.buffs[attacker.uid] or {}
	for _,atkBuff in pairs(attackerBuffs) do
		if atkBuff.func == "groupAddRound" then
			local groups = atkBuff.funcParameter2
			for _,group in ipairs(groups) do
				if buff.group == group then
					buff.duration = buff.duration + atkBuff.funcParameter[1]
					break
				end
			end
		end
	end

	local defenderBuffs = self.buffs[target.uid] or {}
	for _,dfdBuff in pairs(defenderBuffs) do
		if dfdBuff.func == "groupedAddRound" then
			local groups = dfdBuff.funcParameter2
			for _,group in ipairs(groups) do
				if buff.group == group then
					buff.duration = buff.duration + dfdBuff.funcParameter[1]
					break
				end
			end
		end
	end

	if buff.func == "eaststarShield" and overlap == true then
		self.addBuff(buff.funcParameter[2], target, attacker)
		return
	end

	table.insert(buffs, buff)
	buff:add()

	if repeatToAttack and hasSameBuff then
		BattleController.unitRepeatToAttack(target)
	end
end

function BuffController.removeBuff(uid, buffUid)
	local buffs = self.buffs[uid] or {}
	for idx = #buffs, 1, -1 do
		local buff = buffs[idx]
		if buff.uid == buffUid then
			table.remove(buffs, idx)
			buff:remove()
			return
		end
	end
end

function BuffController.removeBuffByUid(uid)
	local buffs = self.buffs[uid] or {}
	for _, buff in pairs(buffs or {}) do
		buff:remove()
	end
	self.buffs[uid] = nil
end

function BuffController.updateRound()
	-- buff update时，不能有删除buff的操作，否则for循环会有问题
	local BattleController = require "app.battle.controllers.BattleController"
	local choiceSkills = {}

	for uid, buffs in pairs(self.buffs) do
		for idx = #buffs, 1, -1 do
			local buff = buffs[idx]
			if buff and buff:update() then
				if buff.func == "choiceSkill" then
					table.insert(choiceSkills, {owner = buff.owner, skillId = buff.funcParameter[2]})
				end

				table.remove(buffs, idx)
				buff:remove()
			end
		end
	end

	for _, value in pairs(choiceSkills) do
		BattleController.unitChoiceSkill(value.owner, value.skillId)
	end
end

function BuffController.update(dt)
	local resetDirty = {}

	for _, buff in pairs(self.enemyBuffToBuffs) do
		local unit = buff.owner

		if unit:isAlive() then
			local buffId = buff.funcParameter[1]
			local group = (unit.group == c.UnitGroup.ATTACKER) and c.UnitGroup.DEFENDER or c.UnitGroup.ATTACKER
			local dirty = false

			if self.unitGroupBuffsInfo[group] and self.unitGroupBuffsInfo[group][buffId] then
				dirty = self.unitGroupBuffsInfo[group][buffId].dirty
			end

			if dirty then
				buff:execute(self.unitGroupBuffsInfo[group][buffId].cnt)
				
				table.insert(resetDirty, {group = group, buffId = buffId})
			end
		end
	end

	for _, value in pairs(resetDirty) do
		self.unitGroupBuffsInfo[value.group][value.buffId].dirty = false
	end
end

function BuffController.groupIsExist(uid, group)
	local buffs = self.buffs[uid] or {}

	for _, buff in pairs(buffs) do
		if buff.group == group then
			return true
		end
	end

	return false
end

function BuffController.eitherGroupExist(uid, groups)
	local exist = {}
	for _, id in pairs(groups) do
		exist[id] = true
	end

	local buffs = self.buffs[uid] or {}

	for _, buff in pairs(buffs) do
		if exist[buff.group] then
			return true
		end
	end

	return false
end

-- buff控制状态
function BuffController.getControlState(uid)
	local buffs = self.buffs[uid] or {}
	local noAttack, noSkill = 0, 0

	for _, buff in pairs(buffs) do
		if buff.isControl then
			noAttack = noAttack + buff.noAttack
			noSkill = noSkill + buff.noSkill
		end
	end

	return (noAttack > 0), (noSkill > 0)
end

function BuffController.getIdleAction(uid)
	local buffs = self.buffs[uid] or {}
	local cnt = #buffs

	for idx = cnt, 1, -1 do
		local buff = buffs[idx]
		if buff.idleAction ~= "" then
			return buff.idleAction
		end
	end

	return "idle"
end

-- 护盾减血
function BuffController.reduceShieldHp(uid, delta)
	local buffs = self.buffs[uid] or {}
	local count = #buffs

	for idx = count, 1, -1 do
		local buff = buffs[idx]
		if buff.isShield then
			
			delta = buff:execute(delta)

			if delta <= 0 then
				table.remove(buffs, idx)
				buff:remove()
			end

			if delta >= 0 then
				return delta
			end
		end
	end

	return delta
end

-- 血少暴走
function BuffController.rage(unit)
	local BattleController = require "app.battle.controllers.BattleController"
	local hpPercent = (unit.attr.hp / unit.attr.maxLife)
	local buffs = {}
	for _, buff in pairs(self.buffs[unit.uid] or {}) do
		if buff.func == "rage" and buff.funcParameter[1] >= hpPercent then
			buffs[#buffs + 1] = buff
		end
	end

	for _, buff in pairs(buffs) do
		local newBuffId = buff.funcParameter[2]
		local attacker = BattleController.getUnitByUid(buff.attackerUid)
		self.addBuff(newBuffId, buff.owner, attacker)
		self.removeBuff(unit.uid, buff.uid)
	end
end

-- 血少触发技能
function BuffController.buffSkill(unit)
	local TeamController = require "app.battle.controllers.TeamController"
	local hpPercent = (unit.attr.hp / unit.attr.maxLife)
	local buff = self.getSkillBuff(unit.uid)

	if buff and buff.funcParameter[1] >= hpPercent then
		local _, noskill = self.getControlState(unit.uid)
		if not noskill then
			local skill = TeamController.newUnitSkill(unit, buff.funcParameter[2])
			unit:useSkill(skill)
		end
		self.removeBuff(unit.uid, buff.uid)
	end
end

-- buff重生
function BuffController.getRebornBuff(uid)
	return self.getBuffByFunc(uid, "reborn")
end

-- 判断是否有无敌
function BuffController.getInvincibleBuff(uid)
	return self.getBuffByFunc(uid, "Invincible")
end

-- 神圣反击
function BuffController.getGodBackAttackBuff(uid)
	return self.getBuffByFunc(uid, "godBackAttack")
end

-- 反击
function BuffController.getCounterattackBuff(uid)
	return self.getBuffByFunc(uid, "counterattack")
end

-- 死亡回血
function BuffController.getAbsorbBuff(uid)
	return self.getBuffByFunc(uid, "absorb")
end

-- 死亡召唤
function BuffController.getDeathSummon(uid)
	return self.getBuffByFunc(uid, "deathSummon")
end

-- 受击回血
function BuffController.getDamageToLifeBuff(uid)
	return self.getBuffByFunc(uid, "damageToLife")
end

-- 受伤回血
function BuffController.getHitDamageToLifeBuff(uid)
	return self.getBuffByFunc(uid, "hitDamageToLife")
end

-- 伤害分摊
function BuffController.getShareBuff(uid)
	return self.getBuffByFunc(uid, "share")
end

-- 吸血标记
function BuffController.getSuckMarker(uid)
	return self.getBuffByFunc(uid, "suckMarker")
end

-- 反击给buff
function BuffController.getCounterBuff(uid)
	return self.getBuffByFunc(uid, "counterBuff")
end

-- 暴击给buff
function BuffController.getCritToBuff(uid)
	return self.getBuffByFunc(uid, "critToBuff")
end

-- 协同攻击
function BuffController.getAssistBuff(uid)
	return self.getBuffByFunc(uid, "assist")
end

-- 他人死亡触发技能
function BuffController.getEachDeathSkillBuff(uid)
	return self.getBuffByFunc(uid, "eachDeathSkill")
end

-- 每回合触发技能
function BuffController.getRoundBeginSkillBuff(uid)
	return self.getBuffByFunc(uid, "roundBeginSkill")
end

-- 暴击触发技能
function BuffController.getEachCritToSkillBuff(uid)
	return self.getBuffByFunc(uid, "eachCritToSkill")
end

-- 闪避触发技能
function BuffController.getDodgeToSkillBuff(uid)
	return self.getBuffByFunc(uid, "dodgeToSkill")
end

-- 自己死亡触发技能
function BuffController.getDeathSkillBuff(uid)
	return self.getBuffByFunc(uid, "deathSkill")
end

-- 醉酒
function BuffController.getChoiceSkillBuff(uid)
	return self.getBuffByFunc(uid, "choiceSkill")
end

-- 睡眠
function BuffController.getSleepBuff(uid)
	return self.getBuffByFunc(uid, "sleep")
end

-- 魅惑
function BuffController.getConfuseBuff(uid)
	return self.getBuffByFunc(uid, "confuse")
end

-- 魅惑2
function BuffController.getConfuse2Buff(uid)
	return self.getBuffByFunc(uid, "confuse2")
end

-- 嘲讽
function BuffController.getTauntBuff(uid)
	return self.getBuffByFunc(uid, "taunt")
end

-- 血少触发攻击
function BuffController.getSkillBuff(uid)
	return self.getBuffByFunc(uid, "buffSkill")
end

-- 敌对buff触发buff
function BuffController.getEnemyBuffToBuff(uid)
	return self.getBuffByFunc(uid, "enemyBuffToBuff")
end

-- 每添加buff时 触发监听buff
function BuffController.getListenerBuff(uid)
	return self.getBuffByFunc(uid, "listenerBuff")
end

-- 受到暴击时触发
function BuffController.getCritedToSkill(uid)
	return self.getBuffByFunc(uid, "critedToSkill")
end

-- 受到驱散时触发
function BuffController.getDispeledToSkill(uid)
	return self.getBuffByFunc(uid, "dispeledToSkill")
end

function BuffController.getPowerMaxBuff(uid)
	return self.getBuffByFunc(uid, "powerToBuff")
end

function BuffController.getEnergyRatioBuff(uid)
	return self.getBuffByFunc(uid, "energyRatio")
end

function BuffController.getReviveBuff(uid)
	return self.getBuffByFunc(uid, "reviveRatio")
end

function BuffController.getReviveToBuff(uid)
	return self.getBuffByFunc(uid, "reviveToBuff")
end

function BuffController.getSpurtBuff(uid)
	return self.getBuffByFunc(uid, "spurt")
end

function BuffController.getBuffByFunc(uid, func)
	local buffs = self.buffs[uid] or {}

	for _, buff in pairs(buffs) do
		if buff.func == func then
			return buff
		end
	end
end

function BuffController.getBuffsByFunc(uid, func)
	local buffs = self.buffs[uid] or {}
	local funcBuffs = {}
	for _, buff in pairs(buffs) do
		if buff.func == func then
			funcBuffs[#funcBuffs + 1] = buff
		end
	end 

	return funcBuffs
end

--buff产生buff是否命中
function BuffController.getBuffAddBuffHit(buff,attacker,defender)
	local buffHit = buff.funcParameter[2]
	if buff.funcParameter[3] >= 1 then
		buffHit = buffHit + attacker.attr.effectHit - defender.attr.effectDodge
	end
	return random:random() <= buffHit
end

return BuffController
