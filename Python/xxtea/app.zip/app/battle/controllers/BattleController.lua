
local c = require "app.configs.constants"

local random = require "app.battle.Random"
local skillConf = require "app.configs.skill"
local ghostUpConf = require "app.configs.ghostUp"
local wfightConf = require "app.configs.wfight"
local heroConf = require "app.configs.hero"
local globalBattleConf = require "app.configs.globalBattle"
local attributeConf = require "app.configs.attribute"
local ViewController = require "app.battle.controllers.ViewController"
local BuffController = require "app.battle.controllers.BuffController"
local TeamController = require "app.battle.controllers.TeamController"
local StatisticsController = require "app.battle.controllers.StatisticsController"

local BattleController = {}
local self = BattleController

function BattleController.ctor(data, seed)
	random:ctor()
	random:randomseed(seed)

	BuffController.new()
	StatisticsController.new()
	TeamController.ctor()

	local BulletFactory = require "app.battle.controllers.BulletFactory"
	self.bulletFactory = BulletFactory.new()
	self.curRound = 0
	self.maxRound = globalBattleConf[1].roundLimit
	self.atkCnt = 0
	self.defCnt = 0
	self.defWaveCnt = 0
	self.freezing = 0
	self.canFreezing = {
		[c.UnitGroup.ATTACKER] = true,
		[c.UnitGroup.DEFENDER] = false,
	}
	self.dt = 0
	self.state = c.GameState.NONE
	self.fightStatus = data.params and data.params.fightStatus or nil
	self.rounds = data.params and data.params.rounds or nil
	self.monsterColor = {}
	self.isPaused = false
	self.manualLogic = false -- 手动逻辑（调试)
	self.autoFight = {
		[c.UnitGroup.ATTACKER] = false,
		[c.UnitGroup.DEFENDER] = true,
	}
	self.pendingFightUids = {} -- 满能量队列（倒序）
	self.bullets = {}
	self.units = {}
	self.waitAtkUnits = {}
	self.attackers = {}
	self.defenders = {}
	self.kamis = {}
	self.gods = {}
	self.reviveData = {
		[c.UnitGroup.ATTACKER] = {},
		[c.UnitGroup.DEFENDER] = {},
	}

	self.originBuff(data)

	self.startUnit = {}
    self.startUnit[c.UnitGroup.ATTACKER] = {}
    self.startUnit[c.UnitGroup.DEFENDER] = {}

	for _, info in pairs(data.attacker) do
		local idx = #self.attackers + 1
		self.attackers[idx] = {}
		for order, value in pairs(info) do
			if idx == 1 then
				self.reviveData[c.UnitGroup.ATTACKER][order] = value
			end

			local unit = TeamController.createUnit(value)
			unit.order = order
			unit.group = c.UnitGroup.ATTACKER
			table.insert(self.attackers[idx], unit)
		end
	end

	for _, info in pairs(data.defender) do
		local idx = #self.defenders + 1
		self.defenders[idx] = {}
		for order, value in pairs(info) do
			if idx == 1 then
				self.reviveData[c.UnitGroup.DEFENDER][order] = value
			end

			local unit = TeamController.createUnit(value)
			unit.order = order
			unit.group = c.UnitGroup.DEFENDER
			table.insert(self.defenders[idx], unit)
		end
	end

	for group, value in pairs(data.kami) do
		local attack = 0
		local cnt = 0
		local units = (group == c.UnitGroup.ATTACKER) and self.attackers[1] or self.defenders[1]
		for _, unit in pairs(units) do
			attack = attack + unit.attr.attack
			cnt = cnt + 1
		end

		if cnt > 0 then
			attack = attack / cnt
		end
		local curMp = 0
		if data.kamiMp then
			curMp = data.kamiMp[value.id] or 0
		end
		self.kamis[group] = TeamController.createKami(value.id, value.skin, value.astSkill, group, attack, curMp)
	end

	for group, info in pairs(data.gods or {}) do
		self.gods[group] = TeamController.createGod(info.level, group, info.skillIds)
	end
end

function BattleController.originBuff(data) --属性变化
	-- 血量上限系数
	local maxLifeFactor = 1
	for _, value in pairs(globalBattleConf[1].battleLifeRatio) do
		if value.stat == self.fightStatus then
			maxLifeFactor = value.n
			break
		end
	end

	--忍界争霸连斩属性衰减
	local function getComboEx(ex)
		if ex and ex.combo then
			local combo = tonumber(ex.combo)
			if combo > wfightConf[1].contWinWeakTimesLimit then
				combo = wfightConf[1].contWinWeakTimesLimit
			end
			combo = combo - wfightConf[1].contWinLimit
			if combo > 0  then
				return combo
			end
		end

		return nil
	end

	local attackCombo = nil
	local defenderCombo = nil
	if self.fightStatus == c.FightStatus.worldFight then
		attackCombo = getComboEx(data.params.attackPlayerInfo.ex)
		defenderCombo = getComboEx(data.params.defenderPlayerInfo.ex)
	end

	for _, info in pairs(data.attacker) do
		for order, value in pairs(info) do
			value.props.maxLife.a = value.props.maxLife.a * maxLifeFactor
			value.props.maxLife.c = value.props.maxLife.c * maxLifeFactor

			if attackCombo then
				for _, v in pairs(wfightConf[1].contWinWeak) do
					local attr = attributeConf[v.attr].alias
					value.props[attr].a = value.props[attr].a * (1 + v.n * attackCombo)
					value.props[attr].c = value.props[attr].c * (1 + v.n * attackCombo)
				end
			end
			--王者之剑家族boss都有抗性buff
			if self.fightStatus == c.FightStatus.guildMonster then
				local heroData = heroConf[value.id]
				if data.params.forceBuff then
					value.props.damageUpRatio.a = value.props.damageUpRatio.a - data.params.forceBuff[heroData.feature[3]]
				end
				if data.params.damageBuff then
					value.props.damageUpRatio.a = value.props.damageUpRatio.a + data.params.damageBuff
				end
			end

			--王者之剑捐赠属性加成
			if self.fightStatus == c.FightStatus.KingSwordFightOther
				or self.fightStatus == c.FightStatus.KingSwordBoss then
				if data.params.attackDonationAttr then
					for id, num in pairs(data.params.attackDonationAttr or {}) do
						local attrName = ""
						local d, e = 0, 0
						if id >= 100 then -- 属性百分比加成
							attrName = attributeConf[id/10].alias
							d = d + num
						else -- 附加属性加成
							attrName = attributeConf[id].alias
							e = e + num
						end
						local d = (value.props[attrName].d or 0) + d
						value.props[attrName].d = d
						local e = (value.props[attrName].e or 0) + e
						value.props[attrName].e = e
					end
				end
				--王者之剑boss抗性
				local heroData = heroConf[value.id]
				if data.params.forceBuff then
					value.props.damageUpRatio.a = value.props.damageUpRatio.a - (data.params.forceBuff[heroData.feature[3]] or 0)
				end
			end
		end
	end

	for _, info in pairs(data.defender) do
		for order, value in pairs(info) do
			value.props.maxLife.a = value.props.maxLife.a * maxLifeFactor
			value.props.maxLife.c = value.props.maxLife.c * maxLifeFactor

			if defenderCombo then
				for _, v in pairs(wfightConf[1].contWinWeak) do
					local attr = attributeConf[v.attr].alias
					value.props[attr].a = value.props[attr].a * (1 + v.n * defenderCombo)
					value.props[attr].c = value.props[attr].c * (1 + v.n * defenderCombo)
				end
			end

			--攻击对手时，对手加上王者之剑捐赠属性加成
			if self.fightStatus == c.FightStatus.KingSwordFightOther then
				if data.params.defDonationAttr then
					for id, num in pairs(data.params.defDonationAttr or {}) do
						local attrName = ""
						local d, e = 0, 0
						if id >= 100 then -- 属性百分比加成
							attrName = attributeConf[id/10].alias
							d = d + num
						else -- 附加属性加成
							attrName = attributeConf[id].alias
							e = e + num
						end
						local d = (value.props[attrName].d or 0) + d
						value.props[attrName].d = d
						local e = (value.props[attrName].e or 0) + e
						value.props[attrName].e = e
					end
				end
			end
		end
	end

end

function BattleController.initializeUnits()
	self.addAttackers()
	self.updateNextWave()
end

function BattleController.setState(state)
	self.state = state

	if state == c.GameState.ATTACK_WIN or
		state == c.GameState.ATTACK_LOSE or
		state == c.GameState.COMPLETE then

		-- 统计当前血量和血量上限
		for _, unit in pairs(self.units) do
			StatisticsController.life(unit)
		end

	end
	
	ViewController.setGameState(self.state)
	self.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_UPDATESTATE, data = self.state})
end

function BattleController.start()
	self.waitAtkUnits["entering"] = true
	self.setState(c.GameState.RUNNING)

	if self.checkSendEvent() then
		local data = {}
		for k,v in pairs(self.units) do
			table.insert(data, {
				uid = v.uid, 
				heroId = v.heroId, 
				group = v.group, 
				order = v.order,
				cls = v.cls,
				level = v.level,
				star = v.star,
				hp = v.attr.maxLife,
			})
		end
		local params = {event = c.BATTLE_EVENT.BATTLE_START, data = data}
		self.sendFightEvent(params)
	end
end

function BattleController.updateNextWave()
	self.curRound = 0

	local units = table.values(self.units)
	for _, unit in pairs(units) do
		if unit:isAlive() then
			unit:updateWave()
		end
	end

	-- 重置buff
	BuffController.reset()

	-- 删除防守方已经死亡的单位
	for uid, unit in pairs(self.units) do
		if unit.group == c.UnitGroup.DEFENDER and unit.state == c.UnitState.REMOVED then
			self.units[uid] = nil
		end
	end

	-- 添加下一波怪物
	self.addNextWave()

	self.updateRound()

	self.waitAtkUnits["passive"] = true


	if self.checkSendEvent() then
		local data = {}
		for k,v in pairs(self.units) do
			table.insert(data, {
				uid = v.uid, 
				heroId = v.heroId, 
				group = v.group, 
				order = v.order,
				cls = v.cls,
				level = v.level,
				star = v.star,
				hp = v.attr.maxLife,
			})
		end
		local params = {event = c.BATTLE_EVENT.BATTLE_NEXTWAVE, data = data}
		self.sendFightEvent(params)
	end
end

function BattleController.updateRound()
	self.curRound = self.curRound + 1

	ViewController.updateRound(self.curRound, self.maxRound)

	self.waitAtkUnits = {}

	local groupSpeed = {
		[c.UnitGroup.ATTACKER] = {cnt = 0, val = 0},
		[c.UnitGroup.DEFENDER] = {cnt = 0, val = 0},
	}
	local units = {}
	for _, unit in pairs(self.units) do
		if unit.state ~= c.UnitState.REMOVED then
			table.insert(units, unit)

			groupSpeed[unit.group].cnt = groupSpeed[unit.group].cnt + 1
			groupSpeed[unit.group].val = groupSpeed[unit.group].val + math.max(unit.attr.speed, 1)
		end
	end

	table.sort(units, function(a, b)
		if a.attr.speed ~= b.attr.speed then
			return a.attr.speed < b.attr.speed
		elseif a.group ~= b.group then
			return a.group ~= c.UnitGroup.ATTACKER
		else
			return a.order > b.order
		end
	end)
	self.waitAtkUnits["wait"] = units


	local v = {}
	for _, god in pairs(self.gods) do
		table.insert(v, god)
	end
	table.sort(v, function(a, b)
		local sa = (groupSpeed[a.group].cnt > 0) and (groupSpeed[a.group].val / groupSpeed[a.group].cnt) or 1
		local sb = (groupSpeed[b.group].cnt > 0) and (groupSpeed[b.group].val / groupSpeed[b.group].cnt) or 1

		if sa ~= sb then
			return sa < sb
		else
			return a.group ~= c.UnitGroup.ATTACKER
		end
	end)
	self.waitAtkUnits["god"] = v

	if self.checkSendEvent() then
		local params = {event = c.BATTLE_EVENT.BATTLE_UPDATEROUND, data = self.curRound}
		self.sendFightEvent(params)
	end
end

function BattleController.pause()
	self.isPaused = not self.isPaused
end

function BattleController.isFreezing()
	return self.freezing > 0
end

function BattleController.updateKamiEnergy(group, delta)
	local kami = self.kamis[group]
	if kami then
		kami:updateMp(delta * ghostUpConf[kami.id].energyRatio)
	end
end

function BattleController.addAttackers()
	for _, unit in pairs(self.attackers[1]) do
		self.addUnit(unit)
	end
end

function BattleController.addNextWave()
	self.defWaveCnt = self.defWaveCnt + 1

	-----大地图boss改变最大回合----
	if self.rounds then
		self.maxRound = self.rounds[self.defWaveCnt] or globalBattleConf[1].roundLimit
	end

	if self.defenders and self.defenders[self.defWaveCnt] then
		self.refreshNameColor(self.defenders[self.defWaveCnt])
		for _, unit in ipairs(self.defenders[self.defWaveCnt]) do
			self.addUnit(unit)
		end
	end
end

function BattleController.updatePendingUids(unit)
	for _, u in pairs(self.pendingFightUids) do
		if u.uid == unit.uid then
			return
		end
	end

	table.insert(self.pendingFightUids, 1, unit)
end

function BattleController.update(dt)
	if self.isPaused then
		return
	end

	self.dt = self.dt + dt

	if self.state == c.GameState.RUNNING then
		self.logicUpdate()
	end

	for idx = #self.bullets, 1, -1 do
		local bullet = self.bullets[idx]
		if bullet:update(dt) then
			table.remove(self.bullets, idx)
		end
	end

	for _, unit in pairs(self.units) do
		unit:update(dt)

		if unit:isAlive() and unit.attr.mp >= unit.attr.energy then
			self.updatePendingUids(unit)
		end
	end

	for _, kami in pairs(self.kamis) do
		kami:update(dt)

		if kami.attr.mp >= kami.attr.energy then
			self.updatePendingUids(kami)
		end
	end

	for _, god in pairs(self.gods) do
		god:update(dt)
	end

	BuffController.update(dt)

	ViewController.updateEffects(dt)
end

function BattleController.logicUpdate()
	if self.manualLogic then
		return
	end

	for _, god in pairs(self.gods) do
		if god.state ~= c.UnitState.IDLE then
			return
		end
	end

	-- 下一个攻击
	if self.waitAtkUnits["god"] and #self.waitAtkUnits["god"] > 0 then
		local cnt = #self.waitAtkUnits["god"]
		local unit = self.waitAtkUnits["god"][cnt]
		unit:useSkill(self.curRound)

		self.waitAtkUnits["god"][cnt] = nil
		return
	end

	if self.waitAtkUnits["passive"] == true then
		-- 释放被动技能
		for uid, unit in pairs(self.units) do
			if unit.state ~= c.UnitState.REMOVED then
				unit:usePassiveSkill()
			end
		end

		self.waitAtkUnits["passive"] = nil
		return
	end

	if self.waitAtkUnits["entering"] == true then
		-- 释放entering技能
		for _, unit in pairs(self.units) do
			if unit:isAlive() then
				unit:useEnteringSkill()
			end
		end

		self.waitAtkUnits["entering"] = nil
		return
	end

	if self.waitAtkUnits["round"] == true then
		local units = table.values(self.units)
		for _, unit in pairs(units) do
			if unit:isAlive() then
				unit:updateRound()
			end
		end

		self.waitAtkUnits["round"] = nil
		return
	end

	-- 大招
	if not self.isFreezing() and self.atkCnt > 0 and self.defCnt > 0 then
		for idx = #self.pendingFightUids, 1, -1 do
			local unit = self.pendingFightUids[idx]
			if not unit or not unit:isAlive() or unit.attr.mp < unit.attr.energy then
				table.remove(self.pendingFightUids, idx)
			else
				local noAttack, noSkill = BuffController.getControlState(unit.uid)
				if noSkill then
					-- continue
				elseif unit.state ~= c.UnitState.IDLE then
					break
				elseif self.autoFight[unit.group] == true then
					self.unitPowermaxSkill(unit)
					break
				end
			end
		end
	end

	-- 战斗中
	if #self.bullets > 0 then
		return
	end

	for _, unit in pairs(self.units) do
		if unit.state ~= c.UnitState.IDLE and unit.state ~= c.UnitState.REMOVED then
			return
		end
	end

	for _, kami in pairs(self.kamis) do
		if kami.state ~= c.UnitState.IDLE then
			return
		end
	end

	-- 攻击方全部阵亡
	if self.atkCnt <= 0 then
		self.setState(c.GameState.ATTACK_LOSE)
		return
	end


	-- 防守方全部阵亡
	if self.defCnt <= 0 then

		-- 攻击方胜利
		if self.defWaveCnt >= #self.defenders then
			self.setState(c.GameState.ATTACK_WIN)
		else
			self.setState(c.GameState.NEXT_WAVE)
		end

		return
	end

	if self.waitAtkUnits["wait"] and #self.waitAtkUnits["wait"] > 0 then
		local cnt = #self.waitAtkUnits["wait"]
		local unit = self.waitAtkUnits["wait"][cnt]
		unit:attack()

		ViewController.refreshFightSequenceHead()

		self.waitAtkUnits["wait"][cnt] = nil
		return
	end

	-- 回合达到上限，战斗完成
	if self.curRound >= self.maxRound then
		self.setState(c.GameState.COMPLETE)
		return
	end


	-- 下回合
	self.updateRound()
	BuffController.updateRound()
	self.waitAtkUnits["round"] = true
end

function BattleController.getUnitSkillTarget(unitSkill)
	return self.getTarget(unitSkill.owner, skillConf[unitSkill.attr.Id])
end

function BattleController.getTarget(owner, conf)
	local group = owner.group
	local units = {}
	local uids = {}

	-- isFriendly
	for _, unit in pairs(self.units) do
		if unit:isAlive() then
			if conf.isFriendly == 0 and unit.group ~= owner.group then
				units[#units + 1] = unit
			elseif conf.isFriendly == 1 and unit.group == owner.group then
				units[#units + 1] = unit
			end
		end
	end

	-- targetType
	if conf.targetType == "current" then
		local target
		for _, unit in pairs(units) do
			if target == nil or target.order > unit.order then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "random" then

	elseif conf.targetType == "array" then

	elseif conf.targetType == "fullScreen" then

	elseif conf.targetType == "frontRow" then
		local fronts = {}
		local backs = {}
		for _, unit in pairs(units) do
			if unit.order <= 2 then
				fronts[#fronts + 1] = unit
			else
				backs[#backs + 1] = unit
			end
		end

		if #fronts > 0 then
			units = fronts
		else
			units = backs
		end
	elseif conf.targetType == "backRow" then
		local fronts = {}
		local backs = {}
		for _, unit in pairs(units) do
			if unit.order <= 2 then
				fronts[#fronts + 1] = unit
			else
				backs[#backs + 1] = unit
			end
		end

		if #backs > 0 then
			units = backs
		else
			units = fronts
		end
	elseif conf.targetType == "self" then
		units = {owner}
	elseif conf.targetType == "lowestHealth" then
		local target
		for _, unit in pairs(units) do
			if target == nil or (target.attr.hp / target.attr.maxLife) > (unit.attr.hp / unit.attr.maxLife) then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "lowestDefense" then
		local target
		for _, unit in pairs(units) do
			if target == nil or target.attr.defense > unit.attr.defense then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "maximalSpeed" then
		local target
		for _, unit in pairs(units) do
			if target == nil or target.attr.speed < unit.attr.speed then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "maximalAttack" then
		local target
		for _, unit in pairs(units) do
			if target == nil or target.attr.attack < unit.attr.attack then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "maximalEnergy" then
		local target
		for _, unit in pairs(units) do
			if target == nil or target.attr.mp < unit.attr.mp then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "maximalDefense" then
		local target
		for _, unit in pairs(units) do
			if target == nil or target.attr.defense < unit.attr.defense then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "maximalAttr" then
		local attrName = attributeConf[conf.targetValue[1]].alias
		local target
		for _, unit in pairs(units) do
			if target == nil or target.attr[attrName] < unit.attr[attrName] then
				target = unit
			end
		end
		units = {target}
	elseif conf.targetType == "notSelf" then
		for idx = #units, 1, -1 do
			if units[idx].uid == owner.uid then
				table.remove(units, idx)
			end
		end
	elseif conf.targetType == "die" then
		for _, unit in pairs(units) do
			uids[#uids + 1] = unit.uid
		end
		return uids
	end

	-- targetValue
	local targetCnt = conf.targetValue[random:random(1, #conf.targetValue)]
	while targetCnt > 0 and #units > 0 do
		local idx = random:random(1, #units)
		uids[#uids + 1] = units[idx].uid

		targetCnt = targetCnt - 1
		table.remove(units, idx)
	end

	return uids
end

function BattleController.reviveUnits(aliveUids, targetValue, group, percent)
	local uids = {}
	local info = {}
	for _, uid in pairs(aliveUids) do
		local unit = BattleController.getUnitByUid(uid)
		info[unit.order] = unit
	end

	local orders = {}
	for order, _ in pairs(self.reviveData[group]) do
		if not info[order] or info[order].isSummon == true then
			orders[#orders + 1] = order
		end
	end

	local values = {}

	local targetCnt = targetValue[random:random(1, #targetValue)]
	while targetCnt > 0 and #orders > 0 do
		local idx = random:random(1, #orders)
		values[#values + 1] = orders[idx]

		targetCnt = targetCnt - 1
		table.remove(orders, idx)
	end

	for _, order in pairs(values) do
		local target = info[order]

		if target then
			target:remove()
		end

		local lastDieUnit = self.getLastDieUnitByGroupOrder(group, order)
		local reviveBuffId = nil
		if lastDieUnit then
			local buff = BuffController.getReviveToBuff(lastDieUnit.uid)
			if buff then
				reviveBuffId = buff.funcParameter[1]
			end
		end

		local unit = TeamController.getReviveUnit(self.reviveData[group][order], percent)
		unit.order = order
		unit.group = group
		self.addUnit(unit, true)

		unit:usePassiveSkill()

		if reviveBuffId then
			BuffController.addBuff(reviveBuffId, unit, unit)
		end

		uids[#uids + 1] = unit.uid
	end

	return uids
end

function BattleController.reviveUnit(dieUnit, percent)
	local unit = TeamController.getReviveUnit(self.reviveData[dieUnit.group][dieUnit.order], percent)
	unit.order = dieUnit.order
	unit.group = dieUnit.group

	local reviveBuffId = nil
	local buff = BuffController.getReviveToBuff(dieUnit.uid)
	if buff then
		reviveBuffId = buff.funcParameter[1]
	end

	if dieUnit then
		dieUnit:remove()
	end

	self.addUnit(unit, true)
	unit:usePassiveSkill()

	if reviveBuffId then
		BuffController.addBuff(reviveBuffId, unit, unit)
	end
end

function BattleController.getUnitByUid(uid)
	return self.units[uid]
end

function BattleController.getUnitByGroupOrder(group, order)
	for _, unit in pairs(self.units) do
		if unit.group == group and unit.order == order and unit:isAlive() then
			return unit
		end
	end
end

function BattleController.getLastDieUnitByGroupOrder(group, order)
	local lastUnit = nil
	for _, unit in pairs(self.units) do
		if unit.group == group and unit.order == order and not unit:isAlive() then
			if not lastUnit or lastUnit.uid < unit.uid then
				lastUnit = unit
			end
		end
	end
	return lastUnit
end

function BattleController.getKamiByUid(uid)
	for group, kami in pairs(self.kamis) do
		if kami.uid == uid then
			return kami
		end
	end
end

function BattleController.getGodByUid(uid)
	for group, god in pairs(self.gods) do
		if god.uid == uid then
			return god
		end
	end
end

function BattleController.addSkillBullet(unitSkill)
	local bullets = self.bulletFactory:createSkillBullets(unitSkill)
	for _, bullet in pairs(bullets) do
		self.bullets[#self.bullets + 1] = bullet
	end
end

function BattleController.addKamiSkillBullet(kamiSkill)
	local bullets = self.bulletFactory:createKamiSkillBullets(kamiSkill)
	for _, bullet in pairs(bullets) do
		self.bullets[#self.bullets + 1] = bullet
	end
end

function BattleController.addGodSkillBullet(godSkill)
	local bullets = self.bulletFactory:createGodSkillBullets(godSkill)
	for _, bullet in pairs(bullets) do
		self.bullets[#self.bullets + 1] = bullet
	end
end

-- 弹射
function BattleController.bounceBullet(sourceBullet, defender)
	if sourceBullet.attr.bounceCnt <= 0 then
		return
	end

	local units = {}
	for _, unit in pairs(self.units) do
		if unit:isAlive() and unit.group == defender.group and unit.uid ~= defender.uid then
			units[#units + 1] = unit
		end
	end

	if #units <= 0 then
		return
	end

	local target = units[random:random(1, #units)]
	local bullet = self.bulletFactory:createBounceBullet(sourceBullet, {target.uid}, defender)
	self.bullets[#self.bullets + 1] = bullet
end

function BattleController.unitRemoved(unit)
	BuffController.removeBuffByUid(unit.uid)

	if unit.group == c.UnitGroup.ATTACKER then
		self.atkCnt = self.atkCnt - 1
	elseif unit.group == c.UnitGroup.DEFENDER then
		self.defCnt = self.defCnt - 1
	end
end

function BattleController.unitDieStart()
	for _, unit in pairs(self.units) do
		if unit:isAlive() then
			local buff = BuffController.getAbsorbBuff(unit.uid)
			if buff then
				unit:dieHp(unit.attr.maxLife * buff.funcParameter[1])
			end

			-- 他人死亡触发技能
			local buff = BuffController.getEachDeathSkillBuff(unit.uid)
			if buff then
				local skillId = buff.funcParameter[1]
				local unitSkill = TeamController.newUnitSkill(unit, skillId)
				unit:useEachDeathSkill(unitSkill)
			end

			--清除嘲讽
			local buff = BuffController.getTauntBuff(unit.uid)
			if buff then
				local target = self.getUnitByUid(buff.attackerUid)

				if not target or not target:isAlive() then
					BuffController.removeBuff(unit.uid, buff.uid)
				end
			end
		end
	end
end

function BattleController.unitDieComplete(unit)
	local buff = BuffController.getDeathSummon(unit.uid)

	if buff then
		local unit = TeamController.getRebornUnit(unit, buff.funcParameter[1], 1, 0)
		unit.isSummon = true
		self.addUnit(unit)
		self.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_UNITREBORN, data = {
			uid = unit.uid, 
			heroId = unit.heroId, 
			group = unit.group, 
			order = unit.order,
			cls = unit.cls,
			level = unit.level,
			star = unit.star,
			hp = unit.attr.hp, 
			maxLife = unit.attr.maxLife
		}})
	end
end

function BattleController.unitPowermaxSkill(unit)
	if unit and self.state == c.GameState.RUNNING and not self.isFreezing() then
		unit:usePowermaxSkill()
	end
end

function BattleController.addUnit(unit, revive)
	if unit.group == c.UnitGroup.ATTACKER then
		self.atkCnt = self.atkCnt + 1
	else
		self.defCnt = self.defCnt + 1
	end

	self.units[unit.uid] = unit

	ViewController.addUnit(unit, revive)
end

-- 重生
function BattleController.addRebornUnit(target, params)
	local unit = TeamController.getRebornUnit(target, params[1], params[2], params[3])
	self.addUnit(unit)

	BuffController.inheritBuff(target.uid, unit)

	--reviveBuffId
	local buff = BuffController.getReviveToBuff(target.uid)
	if buff then
		BuffController.addBuff(buff.funcParameter[1], unit, unit)
	end

	self.sendFightEvent({event = c.BATTLE_EVENT.BATTLE_UNITREBORN, data = {
		uid = unit.uid, 
		heroId = unit.heroId, 
		group = unit.group, 
		order = unit.order,
		cls = unit.cls,
		level = unit.level,
		star = unit.star,
		hp = unit.attr.hp, 
		maxLife = unit.attr.maxLife
	}})
end

function BattleController.nextSkillTrigger(unit, nextSkillInfo, skillId, limit)
	local info = clone(nextSkillInfo)
	if info[skillId] == nil then
		info[skillId] = {limit = limit, cnt = 0}
	end

	info[skillId].cnt = info[skillId].cnt + 1

	if info[skillId].cnt > info[skillId].limit then
		return
	end

	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unitSkill.nextSkillInfo = info
	return unit:useSkillTrigger(unitSkill)
end

-- 神圣反击
function BattleController.unitGodBackAttack(unit, target)
	-- 没有普攻
	local skill = unit.skills[c.SkillType.NORMAL][1]
	if not skill then
		return
	end

	local buff = BuffController.getGodBackAttackBuff(unit.uid)

	if not buff then
		return
	end

	-- 反击几率
	local chance = random:random()
	if chance > buff.funcParameter[1] then
		return
	end

	local skillId = skill.attr.Id
	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unitSkill.attr.distance = 1 -- 远程
	unitSkill.attr.bulletJsonName = ""
	unitSkill.attr.releaseJsonName = ""
	unitSkill.attr.damageType = 2
	unitSkill.attr.coefficient = buff.funcParameter[2]
	local valid = unit:useCounterattack(unitSkill, target.uid)
	if valid then
		ViewController.counterattack(unit.uid)
	end
end

-- 受击反击
function BattleController.unitCounterAttack(unit, target)
	-- 没有普攻
	local skill = unit.skills[c.SkillType.NORMAL][1]
	if not skill then
		return
	end

	local buff = BuffController.getCounterattackBuff(unit.uid)

	if not buff then
		return
	end

	-- 反击几率
	local chance = random:random()
	if chance > buff.funcParameter[1] then
		return
	end

	local skillId = skill.attr.Id
	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unitSkill.attr.distance = 1 -- 远程
	unitSkill.attr.bulletJsonName = ""
	unitSkill.attr.releaseJsonName = ""
	local valid = unit:useCounterattack(unitSkill, target.uid)
	if valid then
		ViewController.counterattack(unit.uid)
	end
end

-- 攻击回复
function BattleController.unitAttackReply(damage, uids)
	if uids and #uids > 0 then
		local healing = damage / #uids
		for _, uid in pairs(uids) do
			local target = self.getUnitByUid(uid)
			target:attackReplyHp(healing)
		end
	end
end

-- 魅惑攻击
function BattleController.unitConfuseAttack(unit)
	-- 没有普攻
	local skill = unit.skills[c.SkillType.NORMAL][1]
	if not skill then
		return
	end

	local uids = self.getTarget(unit, {isFriendly = 1, targetType = "notSelf", targetValue = {1}})
	local uid = uids[1]

	if uid then
		local skillId = skill.attr.Id
		local unitSkill = TeamController.newUnitSkill(unit, skillId)
		unitSkill.attr.distance = 1 -- 远程
		unitSkill.attr.bulletJsonName = ""
		unitSkill.attr.releaseJsonName = ""
		unitSkill.isExtra = false
		unit:useCounterattack(unitSkill, uid)
	end
end

-- 魅惑2
function BattleController.unitConfuse2Attack(target, attacker)
	for _, unit in pairs(self.units) do
		if unit:isAlive() and unit.group ~= target.group and unit.uid ~= target.uid then
			local buff = BuffController.getConfuse2Buff(unit.uid)
			if buff and buff.attackerUid == target.uid then
				local chance = random:random()
				if chance <= buff.funcParameter[1] then

					local skill = unit.skills[c.SkillType.NORMAL][1]
					if skill then
						local skillId = skill.attr.Id
						local unitSkill = TeamController.newUnitSkill(unit, skillId)
						unitSkill.attr.distance = 1 -- 远程
						unitSkill.attr.bulletJsonName = ""
						unitSkill.attr.releaseJsonName = ""
						unit:useCounterattack(unitSkill, attacker.uid)
					end

				end
			end
		end
	end
end

-- 嘲讽攻击
function BattleController.unitTauntAttack(unit,targetUid)
	-- 没有普攻
	local skill = unit.skills[c.SkillType.NORMAL][1]
	if not skill then
		return
	end

	if targetUid then
		local skillId = skill.attr.Id
		local unitSkill = TeamController.newUnitSkill(unit, skillId)
		unitSkill.isExtra = false
		unit:useCounterattack(unitSkill, targetUid)
	end
end

-- 协同攻击
function BattleController.checkUnitAssist(target)
	for _, unit in pairs(self.units) do
		if unit:isAlive() and unit.group == target.group and unit.uid ~= target.uid then
			local buff = BuffController.getAssistBuff(unit.uid)
			if buff then
				-- 协同几率
				local chance = random:random()
				if chance <= buff.funcParameter[1] then

					local skill = unit.skills[c.SkillType.NORMAL][1]
					if skill then
						local skillId = skill.attr.Id
						local unitSkill = TeamController.newUnitSkill(unit, skillId)
						unit:useAssist(unitSkill)
					end

				end
			end
		end
	end
end

-- 每回合触发技能
function BattleController.unitRoundBeginSkill(unit)
	local buff = BuffController.getRoundBeginSkillBuff(unit.uid)

	if not buff then
		return
	end
	--noSkill不触发
	local noAttack,noSkill = BuffController.getControlState(unit.uid)
	if noSkill then
		return
	end
	local skillId = buff.funcParameter[1]
	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unit:useRoundBeginSkill(unitSkill)
end

-- 暴击触发技能
function BattleController.unitEachCritToSkill(target)
	for _, unit in pairs(self.units) do
		if unit:isAlive() and unit.group == target.group and unit.uid ~= target.uid then
			local buff = BuffController.getEachCritToSkillBuff(unit.uid)

			if buff then
				local skillId = buff.funcParameter[1]
				local chance = random:random()
				if chance <= buff.funcParameter[2] then
					local unitSkill = TeamController.newUnitSkill(unit, skillId)
					unit:useEachCritToSkill(unitSkill)
				end
			end
		end
	end
end

-- 命中触发神器技能
function BattleController.unitEachHitToSkill(target, isExtra)
	local unit = self.getUnitByUid(target.uid)

	if not isExtra and unit.artifactSkill and unit.artifactSkill.skillFunc == "hitTrigger" then
		local chance = random:random()
		if chance <= unit.artifactSkill.parameter then
			local unitSkill = TeamController.newUnitSkill(unit, unit.artifactSkill.skillId)
			unit:useArtifactSkill(unitSkill)
		end
	end
end

-- 闪避触发技能
function BattleController.unitDodgeToSkill(unit)
	local buff = BuffController.getDodgeToSkillBuff(unit.uid)

	if not buff then
		return
	end

	if unit.dodgeCnt < buff.funcParameter[1] then
		return
	end

	local skillId = buff.funcParameter[2]
	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unit:useDodgeToSkill(unitSkill)
end

-- 重复buff触发技能
function BattleController.unitRepeatToAttack(unit)
	local skill = unit.skills[c.SkillType.NORMAL][1]

	if skill then
		local skillId = skill.attr.Id
		local unitSkill = TeamController.newUnitSkill(unit, skillId)
		unit:useRepeatToAttack(unitSkill)
	end
end

-- 死亡触发技能
function BattleController.unitDeathSkill(unit)
	local buff = BuffController.getDeathSkillBuff(unit.uid)

	if not buff then
		return false
	end

	local skillId = buff.funcParameter[1]
	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unit:useDeathSkill(unitSkill)

	return true
end

function BattleController.unitChoiceSkill(unit, skillId)
	local unitSkill = TeamController.newUnitSkill(unit, skillId)
	unit:useChoiceSkill(unitSkill)
end

-- 变身
function BattleController.transfrom(target, params)
	if not target:isAlive() then
		return
	end

	local unit = TeamController.getTransfromUnit(target, params[1], params[2])

	self.addUnit(unit)

	BuffController.inheritBuff(target.uid, unit)

	unit:attack()

	target:transfrom()

	for group, value in pairs(self.startUnit or {}) do
        for heroId, uid in pairs(value) do
            if uid == target.uid then
                self.startUnit[group][heroId] = unit.uid
                break
            end
        end
    end
end

function BattleController.transfromTurnBack(target)
	local unit = TeamController.getTransfromTurnBackUnit(target)
	self.addUnit(unit)

	BuffController.inheritBuff(target.uid, unit)
	
 	unit:attack()
 
	for group, value in pairs(self.startUnit or {}) do
        for heroId, uid in pairs(value) do
            if uid == target.uid then
                self.startUnit[group][heroId] = unit.uid
                break
            end
        end
    end
end

-- 获取伤害分摊目标
function BattleController.getUnitsByShareBuff(buff)
	local units = {}
	for _, unit in pairs(self.units) do
		if unit:isAlive() and unit.group == buff.owner.group then
			local b = BuffController.getShareBuff(unit.uid)
			if b and b.id == buff.id then
				units[#units + 1] = unit
			end
		end
	end

	return units
end

function BattleController.getGroupMateUnits(unit)
	local units = {}
	for _, u in pairs(self.units) do
		if u:isAlive() and u.group == unit.group and u.uid ~= unit.uid then
			units[#units + 1] = u
		end
	end
	return units
end

function BattleController.kamiSkill(group)	
	local kami = self.kamis[group]

	if kami then
		kami:usePowermaxSkill()
	end
end

function BattleController.refreshNameColor(defenders)
	if self.fightStatus == c.FightStatus.ordinary then
		local monsterConf = require "app.configs.monster"
		local MonsterColorConf = require "app.configs.MonsterColor"
		local monsterIds = {}
		local level = 0
		for i,v in ipairs(defenders) do
			table.insert(monsterIds, v.heroId)
			level = v.level
		end
		local colors = MonsterColorConf[level] and MonsterColorConf[level].colorArray or {}
		table.sort(colors, function(a, b)
			return a > b
		end)
		table.sort(monsterIds, function(a, b)
			local data_a, data_b = monsterConf[a], monsterConf[b]
			if data_a.color ~=  data_b.color then
				return data_a.color > data_b.color
			else
				return data_a.Id > data_b.Id
			end
		end)

		for i,id in ipairs(monsterIds) do
			self.monsterColor[id] = colors[i] or 1
		end
	end
end

function BattleController.checkSendEvent()
	if self.sendEventView and not tolua.isnull(self.sendEventView) then
		return true
	end
	return false
end

function BattleController.sendFightEvent(params)
	if self.sendEventView and not tolua.isnull(self.sendEventView) then
		self.sendEventView:sendEvent(params.event, params)
	end
end

return BattleController
