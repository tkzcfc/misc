
local c = require "app.configs.constants"

local battleConf = require "app.configs.battle"
local wantedConf = require "app.configs.wanted"
local heroConf = require "app.configs.hero"
local monsterConf = require "app.configs.monster"
local monsterPowerConf = require "app.configs.monsterPower"
local towerConf = require "app.configs.tower"
local towerEliteConf = require "app.configs.towerElite"
local dungeonConf = require "app.configs.dungeon"
local huntSoulConf = require "app.configs.huntSoul"
local arenaBotConf = require "app.configs.arenaBot"
local attributeConf = require "app.configs.attribute"
local skinConf = require "app.configs.skin"

local TeamController = {}
local self = TeamController

local attributes = {
    "attack", -- 攻击
    "defense", -- 防御
    "maxLife", -- 生命上限
    "energy", -- 能量上限
    "crit", -- 暴击
    "critDamage", -- 暴击伤害
    "hit", -- 命中
    "dodge", -- 闪避
    "speed", -- 速度
    "lifePerHit", -- 吸血
    "lifePerRound", -- 生命回复
    "energyPerRound", -- 能量回复
    "addCure", -- 附加治疗
    "cureRatio", -- 治疗加成
    "damageRatio", -- 伤害减免
    "healingRatio", -- 治疗减免
    "effectHit", -- 效果命中
    "effectDodge", -- 效果抵抗
    "critOdds", -- 暴击率
    "calmOdds", -- 抗暴
    "damageUpRatio", --伤害加深
}

local default_attr = {a = 0, b = 0, c = 0}

function TeamController.ctor()
	local UnitFactory = require "app.battle.controllers.UnitFactory"
	self.factory = UnitFactory.new()
end

function TeamController.getHeroRuneSkillsFromModel(heroId)
	local init = require "app.models.init"
	local RuneModel = init.RuneModel
	local skillIds = {}
	local runes = RuneModel:getHeroRunes(heroId)
	for _,rune in pairs(runes) do
		for _,skillId in pairs(rune.skill or {}) do
			table.insert(skillIds, skillId)
		end
	end
	return skillIds
end

-- 从本地HeroModel获取英雄数据
function TeamController.getDataFromHeroModel(heroIds, atkFactor)
	local init = require "app.models.init"
	local HeroModel = init.HeroModel
	local PlayerModel = init.PlayerModel
	local data = {}
	atkFactor = atkFactor or 1

	for idx, heroId in pairs(heroIds) do
		assert(heroConf[heroId] ~= nil, "TeamController.getDataFromHeroModel heroConf[" .. heroId .. "] is nil")

		local hero = HeroModel:getHero(heroId)

		data[idx] = {
			id = heroId,
			level = hero.level,
			star = hero.star,
			cls = hero.cls,
			aoyi = hero.aoyi,
			props = {},
			armors = {},
			atkFactor = atkFactor,
			curHp = nil,
			curMp = nil,
			skin = skinConf[hero.curSkin].spineName,
			artifactSkill = HeroModel:getHeroArtifactSkill(heroId),
			titleStore = PlayerModel.info.titleStore,
			runeSkills = self.getHeroRuneSkillsFromModel(heroId)
		}
		-- armors
		for _, armor in pairs(hero.armorBox) do
			table.insert(data[idx].armors, armor.id)
		end

		-- attributes
		for _, attr in pairs(attributes) do
			local value = hero[attr] or default_attr
			data[idx].props[attr] = {a = value.a, b = value.b, c = value.c}
		end
	end
	return data
end

-- 从配置表获取英雄数据
function TeamController.getDataFromConfig(heroIds, level, cls, star, aoyi, artifactSkill)
	level = level or 1
	cls = cls or 0
	star = star or 0 --怪物星级影响释放技能 3
	aoyi = aoyi or false
	local data = {}
	for order, id in pairs(heroIds) do
		assert(monsterConf[id] ~= nil or heroConf[id] ~= nil, "TeamController.getDataFromConfig invalid id : " .. id)
		local artifactSkillInfo = nil
		if heroConf[id] and artifactSkill then
			artifactSkillInfo = heroConf[id].artifactSkill[1]
		end
		data[order] = {
			id = id,
			level = level,
			cls = cls,
			star = star,
			aoyi = aoyi,
			props = {},
			armors = {},
			atkFactor = 1,
			curHp = nil,
			curMp = nil,
			artifactSkill = artifactSkillInfo,
			titleStore = {},
			runeSkills = {},
		}

		-- attributes
		for _, attr in pairs(attributes) do
			local value = 0

			if monsterConf[id] then
				value = (monsterConf[id][attr] or 0) * (monsterPowerConf[level][attr] or 0)
			else
				value = heroConf[id][attr] or 0
			end

			data[order].props[attr] = {a = value, b = 0, c = 0}
		end
	end

	return data
end

-- 从服务器返回战报中获取数据
function TeamController.getDataFromServer(teams)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {},
	}

	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
			if data.attacker[1][order] then
				data.attacker[1][order].curHp = info.Hp
			end
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end

			if info.DecHp and info.DecHp ~= 0 then
				local maxLifeData = data.attacker[1][order].props.maxLife
				local maxLife = (maxLifeData.a * (1 + maxLifeData.b) + maxLifeData.c)
				local localCurHp = maxLife*((1000000-info.DecHp)/1000000)
				data.attacker[1][order].curHp = localCurHp
			end
		end
		if data.attacker[1][order] then
			local skinId = info.CurSkin or 1
			data.attacker[1][order].skin = skinConf[skinId].spineName
		end
	end

	data.defender[1] = {}
	for order, info in pairs(teams[2].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.defender[1][order] = value[order]
			if data.defender[1][order] then
				data.defender[1][order].curHp = info.Hp
			end
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.defender[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[2].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.defender[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.defender[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end

			if info.DecHp and info.DecHp ~= 0 then
				local maxLifeData = data.defender[1][order].props.maxLife
				local maxLife = (maxLifeData.a * (1 + maxLifeData.b) + maxLifeData.c)
				local localCurHp = maxLife*((1000000-info.DecHp)/1000000)
				data.defender[1][order].curHp = localCurHp
			end
		end
		if data.defender[1][order] then
			local skinId = info.CurSkin or 1
			data.defender[1][order].skin = skinConf[skinId].spineName
		end
	end

	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[2].Ghost then
		local val = {}
		val.id = math.floor(teams[2].Ghost / 100)
		val.skin = teams[2].GhostSkin
		val.astSkill = teams[2].GhostAstSkill
		data.kami[c.UnitGroup.DEFENDER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	if teams[2].Skills and #teams[2].Skills > 0 then
		data.gods[c.UnitGroup.DEFENDER] = {level = teams[2].ReinGodLv or 1, skillIds = teams[2].Skills}
	end

	data.params = {
		attackPlayerInfo = {
			name = teams[1].Name,
			head = teams[1].Head,
			hFrame = teams[1].HFrame,
			title = teams[1].Title,
			level = teams[1].Lv,
			vip = teams[1].Vip,
			ex = teams[1].Ex,
		},
		defenderPlayerInfo = {
			name = teams[2].Name,
			head = teams[2].Head,
			hFrame = teams[2].HFrame,
			title = teams[2].Title,
			level = teams[2].Lv,
			vip = teams[2].Vip,
			ex = teams[2].Ex,
		},
	}
	
	return data
end

function TeamController.createUnit(data)
	return self.factory:createUnit(data)
end

function TeamController.createKami(kamiId, skin, astSkill, group, attack, curMp)
	return self.factory:createKami(kamiId, skin, astSkill, group, attack, curMp)
end

function TeamController.createGod(level, group, skillIds)
	return self.factory:createGod(level, group, skillIds)
end

-- 推图
function TeamController.getLevelTeam(heroIds, levelId)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.ordinary,
			levelId = levelId,
			bg = battleConf[levelId].background,
			bgMusic = battleConf[levelId].battleMusic,
			battleVideo = battleConf[levelId].battleVideo,
			dialog = battleConf[levelId].dialog,
			endDialog = battleConf[levelId].endDialog,
			backgroundEffect = battleConf[levelId].backgroundEffect,
			particleEffect = battleConf[levelId].particleEffect,
			seed = math.random(1,100000000),
			rounds = (battleConf[levelId].rounds and #battleConf[levelId].rounds > 0) and battleConf[levelId].rounds or nil,
		},
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end

	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	-- 关卡怪物
	local conf = battleConf[levelId]
	local level = conf.monsterLevel
	local idx = 1
	local key = "monster"

	while true do
		local info = checktable(conf[key .. tostring(idx)])
		if #info > 0 then
			local monsterIds = {}
			for idx, monsterId in ipairs(info) do
				if monsterId ~= 0 then
					monsterIds[#monsterIds + 1] = monsterId
				end
			end

			if #monsterIds > 0 then
				table.insert(data.defender, self.getDataFromConfig(monsterIds, level))
			end

			idx = idx + 1
		else
			break
		end
	end
	return data
end

--通缉大厅
function TeamController.getWantedTeam(heroIds,monsterId,fightStatus,monsterHp)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = fightStatus,
			monsterId = monsterId,
			bg = wantedConf[monsterId].background,
			monsterHp = monsterHp,
			bgMusic = wantedConf[monsterId].battleMusic,
			backgroundEffect = wantedConf[monsterId].backgroundEffect,
			particleEffect = wantedConf[monsterId].particleEffect,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	local factor = (fightStatus == c.FightStatus.wantedComplete) and 2.5 or 1
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds, factor))

	-- 关卡怪物
	local conf = wantedConf[monsterId]
	local level = conf.level
	local order = 4
	table.insert(data.defender, self.getDataFromConfig({[order] = conf.monsterId}, level))
	data.defender[1][order].curHp = monsterHp

	return data
end

function TeamController.getGuildBossTeam(heroIds, bossId, curHp, serMaxHp)
	local guildBossConf = require "app.configs.guildBoss"
	local skinConf = require "app.configs.skin"
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.guildBoss,
			monsterId = bossId,
			bg = guildBossConf[bossId].background,
			curHp = curHp,
			serMaxHp = serMaxHp,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	local conf = guildBossConf[bossId]
	local level = conf.level
	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = bossId}, level))

	local maxLife = data.defender[1][1].props.maxLife
	local localCurHp = (curHp / serMaxHp) * (maxLife.a * (1 + maxLife.b) + maxLife.c) --将boss当前血量按百分比转换为本地配置的血量
	data.defender[1][order].curHp = localCurHp
	data.params.curHp = localCurHp
	data.defender[1][order].skin = skinConf[conf.skin].spineName
	return data
end

function TeamController.getGuildMonsterTeam(teams, monsterId, level, bg)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.guildMonster,
			monsterId = monsterId,
			bg = bg,
		}
	}
	
	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end
		end
		local skinId = info.CurSkin or 1
		data.attacker[1][order].skin = skinConf[skinId].spineName
	end
	
	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = monsterId}, level))
	
	return data
end

function TeamController.getdevilSoulSealTeam(teams, monsterId, level, bg, bgMusic)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.devilSoulSeal,
			monsterId = monsterId,
			bg = bg,
			bgMusic = {bgMusic},
		}
	}
	
	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end
		end
		local skinId = info.CurSkin or 1
		data.attacker[1][order].skin = skinConf[skinId].spineName
	end
	
	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = monsterId}, level))
	
	return data
end

function TeamController.getfamilyBossTeam(teams, monsterId, level, bg, bgMusic, backgroundEffect, decHp)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.guildBoss,
			monsterId = monsterId,
			bg = bg,
			bgMusic = {bgMusic},
			backgroundEffect = backgroundEffect,
		}
	}
	
	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end
		end
		local skinId = info.CurSkin or 1
		data.attacker[1][order].skin = skinConf[skinId].spineName
	end
	
	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = monsterId}, level))

	local maxLifeData = data.defender[1][order].props.maxLife
	local maxLife = (maxLifeData.a * (1 + maxLifeData.b) + maxLifeData.c)
	local localCurHp = maxLife - decHp
	data.defender[1][order].curHp = localCurHp
	data.params.curHp = localCurHp
	data.params.maxLife = maxLife
	return data
end

function TeamController.getWorldBossTeam(teams, monsterId, level, bg, bgMusic, backgroundEffect, decHp)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.worldBoss,
			monsterId = monsterId,
			bg = bg,
			bgMusic = {bgMusic},
			backgroundEffect = backgroundEffect,
		}
	}
	
	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end
		end
		local skinId = info.CurSkin or 1
		data.attacker[1][order].skin = skinConf[skinId].spineName
	end
	
	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = monsterId}, level))

	local maxLifeData = data.defender[1][order].props.maxLife
	local maxLife = (maxLifeData.a * (1 + maxLifeData.b) + maxLifeData.c)
	local localCurHp = maxLife*((1000000-decHp)/1000000)
	data.defender[1][order].curHp = localCurHp
	data.params.curHp = localCurHp
	data.params.maxLife = maxLife
	return data
end

-- 限时挑战bossTeam
function TeamController.getLimitChallengeBossTeam(teams, monsterId, level, bg, bgMusic, backgroundEffect, confKeyId)
	local timeChallengeSkillConf = require "app.configs.timeChallengeSkill"
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.actTimeChallenge,
			monsterId = monsterId,
			bg = bg,
			bgMusic = {bgMusic},
			backgroundEffect = backgroundEffect,
		}
	}
	
	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end
		end
		local skinId = info.CurSkin or 1
		data.attacker[1][order].skin = skinConf[skinId].spineName

		if timeChallengeSkillConf[confKeyId] then
			for k,v in ipairs(timeChallengeSkillConf[confKeyId].heroSkill or {}) do
				if v.id == info.Id then
					data.attacker[1][order].exSkills = {v.skill}
					break
				end
			end
		end
	end

	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = monsterId}, level))

	local maxLifeData = data.defender[1][order].props.maxLife
	local maxLife = (maxLifeData.a * (1 + maxLifeData.b) + maxLifeData.c)
	local localCurHp = maxLife
	data.defender[1][order].curHp = localCurHp
	data.params.curHp = localCurHp
	data.params.maxLife = maxLife
	return data
end

-- 秘术之塔
function TeamController.getTowerTeam(heroIds, floor)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.tower,
			floor = floor,
			bg = towerConf[floor].background,
			bgMusic = towerConf[floor].battleMusic,
			backgroundEffect = towerConf[floor].backgroundEffect,
			particleEffect = towerConf[floor].particleEffect,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	-- 关卡怪物
	local conf = towerConf[floor]
	local level = conf.monsterLevel

	local monsterIds = {}
	for idx, monsterId in ipairs(conf.monster) do
		if monsterId ~= 0 then 
			monsterIds[#monsterIds + 1] = monsterId
		end
	end
	table.insert(data.defender, self.getDataFromConfig(monsterIds, level))

	return data
end

-- 秘术之塔
function TeamController.getTowerEliteTeam(heroIds, floor)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.towerElite,
			floor = floor,
			bg = towerEliteConf[floor].background,
			bgMusic = towerEliteConf[floor].battleMusic,
			backgroundEffect = towerEliteConf[floor].backgroundEffect,
			particleEffect = towerEliteConf[floor].particleEffect,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	-- 关卡怪物
	local conf = towerEliteConf[floor]
	local level = conf.monsterLevel

	local monsterIds = {}
	for idx, monsterId in ipairs(conf.monster) do
		if monsterId ~= 0 then 
			monsterIds[#monsterIds + 1] = monsterId
		end
	end
	table.insert(data.defender, self.getDataFromConfig(monsterIds, level))

	return data
end

-- 地下城
function TeamController.getDungeonTeam(heroIds, dungeonId)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.dungeon,
			dungeonId = dungeonId,	
			bg = dungeonConf[dungeonId].background,
			bgMusic = dungeonConf[dungeonId].battleMusic,
			backgroundEffect = dungeonConf[dungeonId].backgroundEffect,
			particleEffect = dungeonConf[dungeonId].particleEffect,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	-- 关卡怪物
	local conf = dungeonConf[dungeonId]
	local level = conf.monsterLevel
	local idx = 1
	local key = "monster"

	while true do
		local info = checktable(conf[key .. tostring(idx)])
		if #info > 0 then
			local monsterIds = {}
			for idx, monsterId in ipairs(info) do
				if monsterId ~= 0 then
					monsterIds[#monsterIds + 1] = monsterId
				end
			end

			if #monsterIds > 0 then
				table.insert(data.defender, self.getDataFromConfig(monsterIds, level))
			end

			idx = idx + 1
		else
			break
		end
	end

	return data
end

-- 限时挑战
function TeamController.getTimeChallengeTeam(heroIds, challengeId)
	local timeChallengeConf = require "app.configs.timeChallenge"
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.timeChallenge,
			challengeId = challengeId,	
			bg = timeChallengeConf[challengeId].backgroundEffect,
			-- bgMusic = timeChallengeConf[challengeId].battleMusic,
			backgroundEffect = timeChallengeConf[challengeId].backgroundEffect,
			-- particleEffect = timeChallengeConf[challengeId].particleEffect,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	-- 关卡怪物
	local conf = timeChallengeConf[challengeId]
	local level = conf.monsterLevel
	local idx = 1
	local key = "monster"

	while true do
		local info = checktable(conf[key .. tostring(idx)])
		if #info > 0 then
			local monsterIds = {}
			for idx, monsterId in ipairs(info) do
				if monsterId ~= 0 then
					monsterIds[#monsterIds + 1] = monsterId
				end
			end

			if #monsterIds > 0 then
				table.insert(data.defender, self.getDataFromConfig(monsterIds, level))
			end

			idx = idx + 1
		else
			break
		end
	end
	return data
end

function TeamController.getGhostStepTeam(heroIds, params)
	local ghostStepConf = require "app.configs.ghostStep"
	local globalBattleConf = require "app.configs.globalBattle"

	local effectData = ghostStepConf[params.Id]
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.ghostStep,
			bg = effectData.background,
			bgMusic = effectData.battleMusic,
			backgroundEffect = effectData.backgroundEffect,
			levelId = params.Id,
		},
		kamiMp = {},
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local kamiId = math.floor(id / 100)
		local val = {}
		val.id = kamiId
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
		data.kamiMp[kamiId] = params.GHostVal
	end

	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))
	if params.HeroHp then --设置血量和能量
		for k,v in pairs(data.attacker[1]) do
			if params.HeroHp[v.id] then
				local hpData = params.HeroHp[v.id]
				local maxLife = v.props.maxLife.a * (1 +  v.props.maxLife.b) + v.props.maxLife.c
				local energy = globalBattleConf[1].energyLimit
				v.curHp = maxLife - maxLife * hpData.DecHp / 10000
				v.curMp = energy * hpData.Power / 10000
			end
		end
	end
	--关卡怪物
	table.insert(data.defender, self.getDataFromConfig(params.defender.Team, params.defender.Lv))
	if params.defender.HpPower then
		for _,hpData in ipairs(params.defender.HpPower) do
			for k,v in pairs(data.defender[1]) do
				if v.id == hpData.Id then
					if hpData.DecHp >= 10000 then
						data.defender[1][k] = nil
					else
						local maxLife = v.props.maxLife.a * (1 +  v.props.maxLife.b) + v.props.maxLife.c
						local energy = globalBattleConf[1].energyLimit
						v.curHp = maxLife - maxLife * hpData.DecHp / 10000
						v.curMp = energy * hpData.Power / 10000
					end
					break
				end
			end
		end
	end
	return data
end

function TeamController.getMapBossTeam(heroIds, params)
	local battleCallBossConf = require "app.configs.battleCallBoss"
	local globalBattleConf = require "app.configs.globalBattle"
	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel

	local tData = battleCallBossConf[params.Id]
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.mapBoss,
			bg = tData.background,
			bgMusic = tData.battleMusic,
			backgroundEffect = tData.backgroundEffect,
			levelId = params.Id,
			stepId = params.StepId,
			buffs = params.buffs,
		},
	}
	
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local kamiId = math.floor(id / 100)
		local val = {}
		val.id = kamiId
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))
	if params.HeroHp then --设置血量和能量
		for k,v in pairs(data.attacker[1]) do
			if params.HeroHp[v.id] then
				local hpData = params.HeroHp[v.id]
				local maxLife = v.props.maxLife.a * (1 +  v.props.maxLife.b) + v.props.maxLife.c
				local energy = globalBattleConf[1].energyLimit
				v.curHp = maxLife - maxLife * hpData.DecHp / 10000
				v.curMp = energy * hpData.Power / 10000
			end
		end
	end
	--关卡怪物
	table.insert(data.defender, self.getDataFromConfig(params.defender, params.level))
	if params.HpPower then
		for _,hpData in ipairs(params.HpPower) do
			for k,v in pairs(data.defender[1]) do
				if v.id == hpData.Id then
					if hpData.DecHp >= 10000 then
						data.defender[1][k] = nil
					else
						local maxLife = v.props.maxLife.a * (1 +  v.props.maxLife.b) + v.props.maxLife.c
						local energy = globalBattleConf[1].energyLimit
						v.curHp = maxLife - maxLife * hpData.DecHp / 10000
						v.curMp = energy * hpData.Power / 10000
					end
					break
				end
			end
		end
	end
	return data
end

function TeamController.getHuntSoulTeam(heroIds, huntData)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.huntSoul,
			huntId = huntData.data.Id,
			monsterIndex = huntData.data.monsterIndex,
			bg = huntData.data.background,
			bgMusic = huntData.data.bgMusic,
			backgroundEffect = huntData.data.backgroundEffect,
			particleEffect = huntData.data.particleEffect,
		}
	}

	local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id
	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = PlayerModel.info.kami.CurSkin
		val.astSkill = PlayerModel:getKamiAstSkill()
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if Helper.getOpenState(48,true) then
		local reinGodLevel = PlayerModel.info.reinGod.Lv
		local reinGodSkill = PlayerModel.info.reinGod.Skills
		data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	end
	table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	-- 关卡怪物
	local monsterIds = {}
	for i=1,5 do
		monsterIds[i] = huntData.data.monsterId
	end
	table.insert(data.defender, self.getDataFromConfig(monsterIds, huntData.data.Lv))

	return data
end

function TeamController.getKingSwordTeam(teams, monsterId, level, bg)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.KingSwordBoss,
			monsterId = monsterId,
			bg = bg,
		}
	}
	
	data.attacker[1] = {}
	for order, info in pairs(teams[1].Fighters) do
		if info.Props == nil then
			local value = TeamController.getDataFromConfig({[order] = info.Id}, info.Lv)
			data.attacker[1][order] = value[order]
		else
			local artifactSkillInfo = nil
			if heroConf[info.Id] and info.RuneGrp then
				artifactSkillInfo = heroConf[info.Id].artifactSkill[1]
			end

			data.attacker[1][order] = {
				id = info.Id,
				level = info.Lv,
				star = info.Star,
				cls = info.Cls,
				aoyi = info.AoYi or false,
				props = {},
				armors = info.Armors or {},
				curHp = info.Hp,
				atkFactor = 1,
				artifactSkill = artifactSkillInfo,
				titleStore = teams[1].TitleStore or {},
				runeSkills = info.RuneSkill or {},
			}

			-- attributes
			for _, attr in pairs(attributes) do
				data.attacker[1][order].props[attr] = {a = 0, b = 0, c = 0}
			end

			for _, v in pairs(info.Props) do
				local attr = attributeConf[v.Id].alias
				data.attacker[1][order].props[attr] = {a = v.A, b = v.B, c = v.C}
			end
		end
		local skinId = info.CurSkin or 1
		data.attacker[1][order].skin = skinConf[skinId].spineName
	end
	
	if teams[1].Ghost then
		local val = {}
		val.id = math.floor(teams[1].Ghost / 100)
		val.skin = teams[1].GhostSkin
		val.astSkill = teams[1].GhostAstSkill
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	if teams[1].Skills and #teams[1].Skills > 0 then
		data.gods[c.UnitGroup.ATTACKER] = {level = teams[1].ReinGodLv or 1, skillIds = teams[1].Skills}
	end

	local order = 1
	table.insert(data.defender, self.getDataFromConfig({[order] = monsterId}, level))
	
	return data
end

function TeamController.getTestTeam(leftHeroIds, rightHeroIds)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.debug,
			backgroundEffect = "background_9_2",
		}
	}

	table.insert(data.attacker, self.getDataFromConfig(leftHeroIds, 100, 10, 3, false, true))
	-- 关卡怪物
	table.insert(data.defender, self.getDataFromConfig(rightHeroIds, 100, 10, 3, false, true))

	return data
end

function TeamController.getSkillPreviewTeam(heroId, isAoyi)
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.debug,
			backgroundEffect = "background_9_2",
			maxSkillId = heroConf[heroId].skillUltimate,
			heroId = heroId,
		}
	}
    local level = 0
    local star = 0
    if isAoyi then
    	level = 50
    	star = 1
    else
    	level = 200
    	star = 10
    end
	table.insert(data.attacker, self.getDataFromConfig({heroId}, level, 10, star, isAoyi, false))
	-- 关卡怪物
	table.insert(data.defender, self.getDataFromConfig({20012, 20014, 20036, 20033,20040}, 1, 0, 1, false, false))

	return data
end

-- 幻化神技能预览
function TeamController.getKamiSkillPreviewTeam(skinId, isAoyi)
	local heroId = 20012
	local data = {
		attacker = {},
		defender = {},
		kami = {},
		gods = {},
		params = {
			fightStatus = c.FightStatus.debug,
			backgroundEffect = "background_9_2",
			maxSkillId = heroConf[heroId].skillUltimate,
			heroId = heroId,
		}
	}
    local level = 0
    local star = 0
    if isAoyi then
    	level = 50
    	star = 1
    else
    	level = 200
    	star = 10
    end

    local init = require "app.models.init"
	local Helper = require "app.Helper"
	local PlayerModel = init.PlayerModel
	local id = PlayerModel.info.kami.Id

	if id and Helper.getOpenState(10,true) then
		local val = {}
		val.id = math.floor(id / 100)
		val.skin = skinId
		data.kami[c.UnitGroup.ATTACKER] = val
	end

	-- if Helper.getOpenState(48,true) then
	-- 	local reinGodLevel = PlayerModel.info.reinGod.Lv
	-- 	local reinGodSkill = PlayerModel.info.reinGod.Skills
	-- 	data.gods[c.UnitGroup.ATTACKER] = {level = reinGodLevel, skillIds = reinGodSkill}
	-- end
	-- table.insert(data.attacker, self.getDataFromHeroModel(heroIds))

	table.insert(data.attacker, self.getDataFromConfig({heroId}, level, 10, star, isAoyi, false))
	-- 关卡怪物
	table.insert(data.defender, self.getDataFromConfig({20012, 20014, 20036, 20033,20040}, 1, 0, 1, false, false))

	return data
end

function TeamController.getRebornUnit(target, monsterId, hpPercent, energy)
	local conf = monsterConf[monsterId]
	local data = {
		id = monsterId,
		level = target.level,
		cls = target.cls,
		star = target.star,
		aoyi = target.aoyi,
		artifactSkill = target.artifactSkill,
		props = {},
		armors = clone(target.armorsID),
		atkFactor = target.atkFactor,
		exSkills = target.exSkills or {},
		curHp = nil,
		curMp = nil,
	}

	-- attributes
	for _, attr in pairs(attributes) do
		local factor = (conf[attr] or 0)
		local a = target.part_attr[attr].a * factor
		local b = target.part_attr[attr].b
		local c = target.part_attr[attr].c * factor
		data.props[attr] = {a = a, b = b, c = c}
	end

	local value = data.props.maxLife
	data.curHp = (value.a * (1 + value.b) + value.c) * hpPercent
	data.curMp = energy

	local unit = self.factory:createUnit(data)
	unit.order = target.order
	unit.group = target.group
	unit.originHeroId = target.originHeroId
	
	return unit
end

function TeamController.getTransfromUnit(target, monsterId, lifecycle)
	local hpPercent = target.attr.hp / target.attr.maxLife
	local unit = self.getRebornUnit(target, monsterId, hpPercent, 0)
	unit.uType = c.UnitType.TRANSFROM
	unit.lifecycle = lifecycle
	unit.lifecycleData = target.originData
	unit.originHeroId = target.originHeroId
	return unit
end

function TeamController.getTransfromTurnBackUnit(target)
	local unit = self.factory:createUnit(target.lifecycleData)
	unit.attr.hp = (target.attr.hp / target.attr.maxLife) * unit.attr.maxLife
	unit.order = target.order
	unit.group = target.group
	unit.originHeroId = target.originHeroId
	unit:setAtkFactor(target.atkFactor)

	return unit
end

function TeamController.getReviveUnit(data, percent)
	local unit = self.factory:createUnit(data)
	unit.attr.hp = unit.attr.maxLife * percent

	return unit
end

function TeamController.newUnitSkill(unit, skillId)
	return self.factory:newUnitSkill(unit, skillId)
end

return TeamController
