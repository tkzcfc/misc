
local buffConf = require "app.configs.buff"
local BuffControl = require "app.battle.models.BuffControl"
local BuffReborn = require "app.battle.models.BuffReborn"
local BuffShield = require "app.battle.models.BuffShield"
local BuffEnemyBuffToBuff = require "app.battle.models.BuffEnemyBuffToBuff"
local BuffListener = require "app.battle.models.BuffListener"
local BuffHitDamageToLife = require "app.battle.models.BuffHitDamageToLife"
local Buff = require "app.battle.models.Buff"
local attributeConf = require "app.configs.attribute"

local BuffFactory = class("BuffFactory")

function BuffFactory:ctor()
	self.uid = 1
end

function BuffFactory:createBuff(buffId, target, attacker)
	local conf = buffConf[buffId]

	assert(conf, "BuffFactory:createBuff invalid buffId:" .. buffId)

	local buff = nil

	if conf.isControl == 1 then -- 控制类buff
		buff = BuffControl.new(buffId, target, attacker.uid)
	elseif conf.func == "reborn" then -- 重生buff
		buff = BuffReborn.new(buffId, target, attacker.uid)
	elseif conf.func == "eaststarShield" then -- 东方星辰减伤盾
		buff = BuffShield.new(buffId, target, attacker.uid, conf.funcParameter[1] * attacker.attr.attack)
	elseif conf.func == "defenseToShield" then -- 防御转护盾
		buff = BuffShield.new(buffId, target, attacker.uid, conf.funcParameter[1] * attacker.attr.defense)
	elseif conf.func == "attrToShield" then -- 属性转护盾
		buff = BuffShield.new(buffId, target, attacker.uid, attacker.attr[attributeConf[conf.funcParameter[1]].alias] * conf.funcParameter[2])
	elseif conf.func == "enemyBuffToBuff" then -- 敌对buff触发buff
		buff = BuffEnemyBuffToBuff.new(buffId, target, attacker.uid)
	elseif conf.func == "listenerBuff" then --监听buff
		buff = BuffListener.new(buffId, target, attacker.uid)
	elseif conf.func == "hitDamageToLife" then --受伤回血
		buff = BuffHitDamageToLife.new(buffId, target, attacker.uid, attacker.attr.attack)
	else
		buff = Buff.new(buffId, target, attacker.uid)
	end

	buff.uid = self.uid
	self.uid = self.uid + 1

	if conf.buffCoefficient > 0 then -- 伤害
		buff.buffHp = conf.buffCoefficient * attacker.attr.attack
	elseif conf.buffCoefficient < 0 then -- 治疗
		buff.buffHp = conf.buffCoefficient * attacker.attr.attack
	end

	--能量
	if conf.energyChange ~= 0 then
		buff.buffEnergy = conf.energyChange
	end

	return buff
end

function BuffFactory:cloneBuff(sourceBuff, target)
	local buffId = sourceBuff.id
	local conf = buffConf[buffId]

	assert(conf, "BuffFactory:cloneBuff invalid buffId:" .. buffId)

	local buff = nil

	if conf.isControl == 1 then -- 控制类buff
		buff = BuffControl.new(buffId, target, sourceBuff.attackerUid)
	elseif conf.func == "reborn" then -- 重生buff
		buff = BuffReborn.new(buffId, target, sourceBuff.attackerUid)
	elseif conf.func == "eaststarShield" then -- 东方星辰减伤盾
		buff = BuffShield.new(buffId, target, sourceBuff.attackerUid)
	elseif conf.func == "defenseToShield" then -- 防御转护盾
		buff = BuffShield.new(buffId, target, sourceBuff.attackerUid)
	else
		buff = Buff.new(buffId, target, sourceBuff.attackerUid)
	end

	buff.uid = self.uid
	self.uid = self.uid + 1

	buff:copy(sourceBuff)

	return buff
end

return BuffFactory
