
local c = require "app.configs.constants"

local spineConf = require "app.configs.spine"
local globalBattleConf = require "app.configs.globalBattle"
local Bullet = require "app.battle.models.Bullet"
local KamiBullet = require "app.battle.models.KamiBullet"
local GodBullet = require "app.battle.models.GodBullet"
local BuffController = require "app.battle.controllers.BuffController"
local BattleController = require "app.battle.controllers.BattleController"

local BulletFactory = class("BulletFactory")

function BulletFactory:ctor()
	self.uid = 1
end

function BulletFactory:createGodSkillBullets(skill)
	local bullets = {}

	if skill.attr.bulletJsonName ~= "" then -- 有多个子弹特效
		for _, uid in pairs(skill.targetUids) do
			bullets[#bullets + 1] = self:createGodBullet(skill, {uid})
		end
	else
		bullets[#bullets + 1] = self:createGodBullet(skill, skill.targetUids)
	end

	return bullets
end

function BulletFactory:createGodBullet(skill, targetUids)
	local attacker = skill.owner
	local bullet = GodBullet.new(attacker)
	local skillInfo = skill.attr

	bullet.uid = self.uid
	self.uid = self.uid + 1

	bullet.skillTriggerCnt = skill.curCnt

	-- attr
	bullet.attr.attack = attacker.attr.attack
	bullet.attr.skill_coefficient = skillInfo.coefficient
	bullet.attr.skillFunc = skillInfo.skillFunc
	bullet.attr.targetValue = skillInfo.targetValue
	bullet.attr.funcParameter = skillInfo.funcParameter
	if skillInfo.isFriendly == 1 then
		bullet.attr.group = attacker.group
	else
		bullet.attr.group = (attacker.group == c.UnitGroup.ATTACKER and c.UnitGroup.DEFENDER or c.UnitGroup.ATTACKER)
	end

	-- 多段伤害
	local triggerCnt = skill.triggerCnt

	if skillInfo.releaseJsonName ~= "" then
		triggerCnt = triggerCnt * spineConf[skillInfo.releaseJsonName]["idle"].triggerCnt
	end

	if triggerCnt > 1 then
		bullet.attr.skill_coefficient = (bullet.attr.skill_coefficient / triggerCnt)
	end

	if skillInfo.buffId > 0 then
		bullet.attr.buffId = skillInfo.buffId
		bullet.attr.buffHit = skillInfo.buffHit
		-- buff命中几率额外加成
		if skillInfo.isBuffHitAdded > 0 then
			bullet.attr.buffHit = bullet.attr.buffHit + attacker.attr.effectHit
		end
	end

	-- targetUids
	for _, uid in pairs(targetUids) do
		bullet.targetUids[#bullet.targetUids + 1] = uid
	end

	-- triggers
	if skillInfo.releaseJsonName ~= "" then -- 子弹释放特效
		local conf = spineConf[skillInfo.releaseJsonName]["idle"]
		bullet.triggers = clone(conf.events) or {}

		for _, trigger in pairs(bullet.triggers) do
			if trigger.name == "trigger" then
				trigger.jsonName = skillInfo.hitJsonName
			end
		end

		table.sort(bullet.triggers, function(a, b)
			return a.time > b.time
		end)

		table.insert(bullet.triggers, {
			time = 0,
			name = "bullet_effect",
			jsonName = skillInfo.releaseJsonName,
		})
		
		bullet.totalTime = conf.totalTime
	elseif skillInfo.bulletJsonName ~= "" then -- 子弹飞行特效
		local flyTime = skillInfo.bulletFlyTime
		bullet.totalTime = flyTime
		bullet.triggers = {
			{
				time = bullet.totalTime,
				name = "trigger",
				jsonName = skillInfo.hitJsonName,
			},
			{
				time = 0,
				name = "bullet_fly",
				duration = flyTime,
				jsonName = skillInfo.bulletJsonName,
				bulletRoute = skillInfo.bulletRoute,
			},
		}
	else -- 子弹没有特效
		bullet.triggers = {
			{
				time = 0,
				name = "trigger",
				jsonName = skillInfo.hitJsonName,
			},
		}
		bullet.totalTime = 0
	end

	return bullet
end

function BulletFactory:createKamiSkillBullets(kamiSkill)
	local bullets = {}

	if kamiSkill.attr.bulletJsonName ~= "" then -- 有多个子弹特效
		for _, uid in pairs(kamiSkill.targetUids) do
			bullets[#bullets + 1] = self:createKamiBullet(kamiSkill, {uid})
		end
	else
		bullets[#bullets + 1] = self:createKamiBullet(kamiSkill, kamiSkill.targetUids)
	end

	return bullets
end

function BulletFactory:createKamiBullet(kamiSkill, targetUids)
	local attacker = kamiSkill.owner
	local bullet = KamiBullet.new(attacker)
	local skillInfo = kamiSkill.attr

	bullet.uid = self.uid
	self.uid = self.uid + 1

	bullet.kamiSkill = kamiSkill
	bullet.skillTriggerCnt = kamiSkill.curCnt
	-- attr
	bullet.attr.attack = attacker.attr.attack
	bullet.attr.skill_coefficient = skillInfo.coefficient
	bullet.attr.skillFunc = skillInfo.skillFunc
	bullet.attr.targetValue = skillInfo.targetValue
	bullet.attr.funcParameter = skillInfo.funcParameter
	
	-- 多段伤害
	local triggerCnt = kamiSkill.triggerCnt

	if skillInfo.releaseJsonName ~= "" then
		triggerCnt = triggerCnt * spineConf[skillInfo.releaseJsonName]["idle"].triggerCnt
	end

	if triggerCnt > 1 then
		bullet.attr.skill_coefficient = (bullet.attr.skill_coefficient / triggerCnt)
	end

	if skillInfo.buffId > 0 then
		bullet.attr.buffId = skillInfo.buffId
		bullet.attr.buffHit = skillInfo.buffHit
		-- buff命中几率额外加成
		if skillInfo.isBuffHitAdded > 0 then
			bullet.attr.buffHit = bullet.attr.buffHit + attacker.attr.effectHit
		end
	end

	-- targetUids
	for _, uid in pairs(targetUids) do
		bullet.targetUids[#bullet.targetUids + 1] = uid
	end

	-- triggers
	if skillInfo.releaseJsonName ~= "" then -- 子弹释放特效
		local conf = spineConf[skillInfo.releaseJsonName]["idle"]
		bullet.triggers = clone(conf.events) or {}

		for _, trigger in pairs(bullet.triggers) do
			if trigger.name == "trigger" then
				trigger.jsonName = skillInfo.hitJsonName
			end
		end

		table.sort(bullet.triggers, function(a, b)
			return a.time > b.time
		end)

		table.insert(bullet.triggers, {
			time = 0,
			name = "bullet_effect",
			jsonName = skillInfo.releaseJsonName,
		})
		
		bullet.totalTime = conf.totalTime
	elseif skillInfo.bulletJsonName ~= "" then -- 子弹飞行特效
		local flyTime = skillInfo.bulletFlyTime
		bullet.totalTime = flyTime
		bullet.triggers = {
			{
				time = bullet.totalTime,
				name = "trigger",
				jsonName = skillInfo.hitJsonName,
			},
			{
				time = 0,
				name = "bullet_fly",
				duration = flyTime,
				jsonName = skillInfo.bulletJsonName,
				bulletRoute = skillInfo.bulletRoute,
			},
		}
	else -- 子弹没有特效
		bullet.triggers = {
			{
				time = 0,
				name = "trigger",
				jsonName = skillInfo.hitJsonName,
			},
		}
		bullet.totalTime = 0
	end

	return bullet
end

function BulletFactory:createSkillBullets(unitSkill)
	local bullets = {}

	if unitSkill.attr.skillFunc == "freeBullet" then
		for idx = 1, unitSkill.attr.funcParameter[1] do
			bullets[#bullets + 1] = self:createBullet(unitSkill, BattleController.getUnitSkillTarget(unitSkill))
		end
	elseif unitSkill.attr.bulletJsonName ~= "" then -- 有多个子弹特效
		for _, uid in pairs(unitSkill.targetUids) do
			bullets[#bullets + 1] = self:createBullet(unitSkill, {uid})
		end
	else
		bullets[#bullets + 1] = self:createBullet(unitSkill, unitSkill.targetUids)
	end

	return bullets
end

function BulletFactory:createBullet(unitSkill, targetUids)
	local attacker = unitSkill.owner
	local bullet = Bullet.new(attacker)
	local skillInfo = unitSkill.attr

	bullet.uid = self.uid
	self.uid = self.uid + 1

	bullet.unitSkill = unitSkill
	bullet.skillTriggerCnt = unitSkill.curCnt

	-- attr
	bullet.attr.damageType = skillInfo.damageType
	bullet.attr.level = attacker.level
	bullet.attr.hit = attacker.attr.hit
	bullet.attr.skill_hitodds = skillInfo.hitOdds
	bullet.attr.crit = attacker.attr.crit
	bullet.attr.critodds = attacker.attr.critOdds
	bullet.attr.skill_critodds = skillInfo.critOdds
	bullet.attr.attack = attacker.attr.attack
	bullet.attr.critdamage = attacker.attr.critDamage
	bullet.attr.lifeperhit = attacker.attr.lifePerHit
	bullet.attr.cureratio = attacker.attr.cureRatio
	bullet.attr.addcure = attacker.attr.addCure
	bullet.attr.skillType = skillInfo.skillType
	bullet.attr.skillFunc = skillInfo.skillFunc
	bullet.attr.funcParameter = skillInfo.funcParameter
	bullet.attr.bounceCnt = 0 -- 弹射次数
	bullet.attr.isBuffHitAdded = skillInfo.isBuffHitAdded
	bullet.attr.damageUpRatio = attacker.attr.damageUpRatio
	bullet.attr.targetValue = skillInfo.targetValue
	if skillInfo.isFriendly == 1 then
		bullet.attr.group = attacker.group
	else
		bullet.attr.group = (attacker.group == c.UnitGroup.ATTACKER and c.UnitGroup.DEFENDER or c.UnitGroup.ATTACKER)
	end

	if skillInfo.skillFunc == "bounce" then
		bullet.attr.bounceCnt = skillInfo.funcParameter[1]
	end

	-- 多段伤害
	bullet.attr.skill_coefficient = skillInfo.coefficient
	local triggerCnt = unitSkill.triggerCnt

	if skillInfo.releaseJsonName ~= "" then
		triggerCnt = triggerCnt * spineConf[skillInfo.releaseJsonName]["idle"].triggerCnt
	end

	if triggerCnt > 1 then
		bullet.attr.skill_coefficient = (bullet.attr.skill_coefficient / triggerCnt)
	end

	-- 必暴击
	if skillInfo.skillFunc == "buffToCrit" then
		bullet.attr.mustCrit = BuffController.groupIsExist(attacker.uid, skillInfo.funcParameter[1])
	end

	if skillInfo.buffId > 0 then
		bullet.attr.buffId = skillInfo.buffId
		bullet.attr.buffHit = skillInfo.buffHit
		-- buff命中几率额外加成
		if skillInfo.isBuffHitAdded > 0 then
			bullet.attr.buffHit = bullet.attr.buffHit + attacker.attr.effectHit
		end
	end

	-- targetUids
	for _, uid in pairs(targetUids) do
		bullet.targetUids[#bullet.targetUids + 1] = uid
	end

	-- triggers
	if skillInfo.releaseJsonName ~= "" then -- 子弹释放特效
		local conf = spineConf[skillInfo.releaseJsonName]["idle"]
		bullet.triggers = clone(conf.events) or {}

		for _, trigger in pairs(bullet.triggers) do
			if trigger.name == "trigger" then
				trigger.jsonName = skillInfo.hitJsonName
			end
		end

		table.sort(bullet.triggers, function(a, b)
			return a.time > b.time
		end)

		table.insert(bullet.triggers, {
			time = 0,
			name = "bullet_effect",
			jsonName = skillInfo.releaseJsonName,
		})
		
		bullet.totalTime = conf.totalTime
	elseif skillInfo.bulletJsonName ~= "" then -- 子弹飞行特效
		local flyTime = skillInfo.bulletFlyTime
		bullet.totalTime = flyTime
		bullet.triggers = {
			{
				time = bullet.totalTime,
				name = "trigger",
				jsonName = skillInfo.hitJsonName,
			},
			{
				time = 0,
				name = "bullet_fly",
				duration = flyTime,
				jsonName = skillInfo.bulletJsonName,
				bulletRoute = skillInfo.bulletRoute,
			},
		}
	else -- 子弹没有特效
		bullet.triggers = {
			{
				time = 0,
				name = "trigger",
				jsonName = skillInfo.hitJsonName,
			},
		}
		bullet.totalTime = 0
	end

	return bullet
end

function BulletFactory:createBounceBullet(sourceBullet, targetUids, defender)
	local bullet = Bullet.new(sourceBullet.owner)

	bullet.uid = self.uid
	self.uid = self.uid + 1

	bullet.unitSkill = sourceBullet.unitSkill

	bullet.attr = clone(sourceBullet.attr)
	bullet.attr.bounceCnt = bullet.attr.bounceCnt - 1

	-- targetUids
	for _, uid in pairs(targetUids) do
		bullet.targetUids[#bullet.targetUids + 1] = uid
	end

	local skillInfo = bullet.unitSkill.attr
	local flyTime = 0.1
	bullet.totalTime = flyTime
	bullet.triggers = {
		{
			time = bullet.totalTime,
			name = "trigger",
			jsonName = skillInfo.hitJsonName,
		},
		{
			time = 0,
			name = "bullet_fly",
			duration = flyTime,
			jsonName = skillInfo.bulletJsonName,
			defenderUid = defender.uid,
		},
	}

	return bullet
end

return BulletFactory
