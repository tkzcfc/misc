
local SpineManager = require "sandglass.core.SpineManager"
local skinConf = require "app.configs.skin"

local UnitAnim = class("UnitAnim", function(jsonName,scale)
	return SpineManager.createAnimation("spine/actors/" .. jsonName, nil, true)
end)

function UnitAnim:ctor(jsonName, scale, skin)
	self:setScale(scale)
	
	self:enableNodeEvents()
	self.actions = {}
	self.jsonName = jsonName

	self.skin = skin or skinConf[1].spineName
	self:registerSkin(self.skin)
	-- self:registerSkin("upgrade2")

	-- 播放受击动作以后，循环idle动作
	self:addLuaHandler(function(eventName, animName, intValue, floatValue)
		if (animName == "hit" or animName == "appear2") and eventName == "complete" then
			self:playAnimation("idle", -1)
		end
	end)
end

function UnitAnim:setStartPosition(x, y)
	self.startPos = cc.p(x, y)
	self:setPosition(x, y)
end

function UnitAnim:updateAction(dt)
	for idx = #self.actions, 1, -1 do
		local action = self.actions[idx]
		action:step(dt)

		if action:isDone() then
			action:release()
			table.remove(self.actions, idx)
		end
	end
end

function UnitAnim:addAction(action)
	action:retain()
	action:startWithTarget(self)
	self.actions[#self.actions + 1] = action
end

function UnitAnim:clearAction()
	for _, action in pairs(self.actions) do
		action:release()
	end
	self.actions = {}
end

function UnitAnim:onCleanup()
	self:clearAction()
end

return UnitAnim