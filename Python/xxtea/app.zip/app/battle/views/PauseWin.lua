-- 战斗暂停界面

local c = require "app.configs.constants"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"

local PauseWin = class("PauseWin", WinBase)

PauseWin.RESOURCE_FILENAME = "fight/pause.csb"

function PauseWin:onCreate(fightStatus, callback)
    self.fightStatus = fightStatus
    self.callback = callback

    self:initView()
end

function PauseWin:closeSelf()
    if self.callback then
        self.callback(false)
    end
    PauseWin.super.closeSelf(self)
end

function PauseWin:initView()
    self.resourceNode_:getChildByName("txt_skip"):setString(WordDictionary[10106])
    self.resourceNode_:getChildByName("txt_continue"):setString(WordDictionary[10107])
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[10157])
    
	local tipText = WordDictionary[10150]
    if self.fightStatus == c.FightStatus.arena
        or self.fightStatus == c.FightStatus.mine then--竞技场
        tipText = WordDictionary[10151]
    end
    self.resourceNode_:getChildByName("txt_content"):setString(tipText)

    UIImageBox.new(self.resourceNode_:getChildByName("skipBtn"),function()
        if self.callback then
            self.callback(true)
        end
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("continueBtn"),function()
        self:closeSelf()
    end)
end

return PauseWin