--英雄大招卡片

local c = require "app.configs.constants"
local ShaderManager = require "sandglass.core.ShaderManager"
local SpineManager = require "sandglass.core.SpineManager"
local BattleController = require "app.battle.controllers.BattleController"
local BuffController = require "app.battle.controllers.BuffController"
local UIImageBox = require "sandglass.ui.UIImageBox"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local ViewBase = require "sandglass.core.ViewBase"

local MOVETIME = 0.3
local MOVEDIS = 70
local CARD_POS = {
    [1] = {
        {pos = cc.p(568,-28), rotation = 0},
    },
    [2] = {
        {pos = cc.p(503,-35), rotation = -3},
        {pos = cc.p(633,-35), rotation = 3},
    },
    [3] = {
        {pos = cc.p(438,-35), rotation = -5},
        {pos = cc.p(568,-28), rotation = 0},
        {pos = cc.p(698,-35), rotation = 5},
    },
    [4] = {
        {pos = cc.p(374,-49), rotation = -8},
        {pos = cc.p(503,-35), rotation = -3},
        {pos = cc.p(633,-35), rotation = 3},
        {pos = cc.p(762,-49), rotation = 8},
    },
    [5] = {     
        {pos = cc.p(309,-59), rotation = -10},
        {pos = cc.p(438,-35), rotation = -5},
        {pos = cc.p(568,-28), rotation = 0},
        {pos = cc.p(698,-35), rotation = 5},
        {pos = cc.p(827,-59), rotation = 10},
    },
}

local UnitCard = class("UnitCard", function()
    return ViewBase:createCsbNode("fight/roleNode.csb")
end)

function UnitCard:ctor(uid, total, idx, order, uiScale)
    self:setScale(uiScale)

    self.order = order

    local unit = BattleController.getUnitByUid(uid)

    --设置位置和旋转
    local posInfo = CARD_POS[total][idx]
    local p = cc.pAdd(posInfo.pos,cc.p(0,-45))

    local offsetX = display.cx > 568 and 568 or display.cx
    self:setPosition(p.x * uiScale - offsetX, p.y * uiScale)
    self:setRotation(posInfo.rotation)

    local heroCard = roleConf[unit.role].heroCard
    local card = UIImageBox.new(self:getChildByName("card"), function()
        local unit = BattleController.getUnitByGroupOrder(c.UnitGroup.ATTACKER, self.order)
        BattleController.unitPowermaxSkill(unit)
    end,{ableGLProgram = false})

    local path = "card/"..heroCard..".png"
    card:setImage(path)

    self.card = card

    self.isFullStatus = true --当前卡牌状态
    self:resetStatus()
end

function UnitCard:playUseEffect()
    self.playing = true
    local effectLight = self.card:getChildByName("effectLight")
    effectLight:addLuaHandler(function(eventName, animName, intValue, floatValue)
        if animName == "idle3" and eventName == "end" then
            self.playing = false
            self:resetStatus()
        end
    end)
    effectLight:stopAnimation()
    effectLight:playAnimation("idle3",1)
end

function UnitCard:showFullStatus()
    if not self.isFullStatus then
        self.isFullStatus = not self.isFullStatus
        
        self:setCardShader(self, ShaderManager.SHADER_NORMAL)
        self.card:setEnabled(true)
        self.card:stopAllActions()
        self.card:runAction(cc.MoveTo:create(MOVETIME,cc.p(0,MOVEDIS)))

        local effect = self.card:getChildByName("effectLight")
        if not effect then
            effect = SpineManager.createAnimation("public/ui_dazhaokeshifang")
            effect:setName("effectLight")
            local size = self.card:getContentSize()
            effect:setPosition(size.width * 0.5 - 3.5, size.height * 0.5 + 10)
            self.card:addChild(effect)
        end
        effect:playAnimation("idle1", 1)
        effect:appendNextAnimation("idle2", -1)
        effect:setVisible(true)
    end
end

function UnitCard:resetStatus()
    if self.playing then
        return
    end

    if self.isFullStatus then
        self.isFullStatus = not self.isFullStatus

        self:setCardShader(self, ShaderManager.SHADER_DARKEN)
        self.card:setEnabled(false)
        self.card:stopAllActions()
        self.card:runAction(cc.MoveTo:create(MOVETIME,cc.p(0,0)))

        --hide effect
        local effectLight = self.card:getChildByName("effectLight")
        if effectLight then
            effectLight:setVisible(false)
        end
    end
end

function UnitCard:setCardShader(obj,shaderName)
    local func = nil
    func = function(obj) --对Node设置shader 包括子节点（如果是label 记得先调用getContentSize）
        if tolua.type(obj) == "ccui.Text" then
            obj:getContentSize()
            obj:setTextColor(cc.c3b(200,200,200))
        elseif obj.setGLProgram then
            local shader = ShaderManager.loadShader(shaderName)
            obj:setGLProgram(shader)
        end

        obj = obj:getChildren()
        for m,n in pairs(obj) do
            func(n)
        end
    end
    func(obj)
end

function UnitCard:update()
    local unit = BattleController.getUnitByGroupOrder(c.UnitGroup.ATTACKER, self.order)
    local canUseSkill = false

    if unit and (unit.attr.mp >= unit.attr.energy) then
        local noAttack, noSkill = BuffController.getControlState(unit.uid)
        if not noSkill then
            canUseSkill = true
        end
    end

    if canUseSkill then
        self:showFullStatus()
    else
        self:resetStatus()
    end
end

return UnitCard