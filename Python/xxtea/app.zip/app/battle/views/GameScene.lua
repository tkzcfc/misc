
local c = require "app.configs.constants"

local skillConf = require "app.configs.skill"
local spineConf = require "app.configs.spine"
local ViewBase = require "sandglass.core.ViewBase"
local UnitAnim = require "app.battle.views.UnitAnim"
local UnitCard = require "app.battle.views.UnitCard"
local BulletAnim = require "app.battle.views.BulletAnim"
local BattleController = require "app.battle.controllers.BattleController"
local ViewController = require "app.battle.controllers.ViewController"
local BuffController = require "app.battle.controllers.BuffController"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local buffConf = require "app.configs.buff"
local monsterConf = require "app.configs.monster"
local globalBattleConf = require "app.configs.globalBattle"
local ghostUpConf = require "app.configs.ghostUp"
local ghostSkinConf = require "app.configs.ghostSkin"
local SpineManager = require "sandglass.core.SpineManager"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UIAniButton = require "sandglass.ui.UIAniButton"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local AudioManager = require "sandglass.core.AudioManager"
local GuideManager = require "app.views.guide.GuideManager"
local VideoLayer = require "app.views.scene.VideoLayer"
local openConf = require "app.configs.open"
local MoveLabel = require "sandglass.ui.MoveLabel"
local WordDictionary = require "app.configs.WordDictionary"
local StatisticsController = require "app.battle.controllers.StatisticsController"
local Helper = require "app.Helper"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local CoreColor = require "sandglass.core.CoreColor"
local guildMonsterConf = require "app.configs.guildMonster"
local globalPublicConf = require "app.configs.globalPublic"
local reinGodConf = require "app.configs.reinGod"
local wfightConf = require "app.configs.wfight"
local dungeonConf = require "app.configs.dungeon"
local battleConf = require "app.configs.battle"

local init = require "app.models.init"
local PlayerModel = init.PlayerModel
local MainLineModel = init.MainLineModel
local PayModel = init.PayModel
local SpeCardModel = init.SpeCardModel

local GameScene = class("GameScene", ViewBase)

GameScene.RESOURCE_FILENAME = "fight/fight.csb"

local fightZOrder = {
    bg = -1,
    pos_height = display.height, --英雄最高站位
    bullet = 10000, --子弹层级
    black_layer = 20000, --黑屏层级
    anim_powermax = 20001, --英雄释放大招定屏层级
    powermax_effect = 20002, --英雄释放大招水墨画层级
    kami = 20003, -- 幻化神
    god = 20004, -- 御神
}

local debuffColor = cc.c3b(255,74,74)
local buffColor = cc.c3b(81,248,0)
local specialBuffColor = cc.c3b(81,248,0)

function GameScene:ctor(app,name, data)
    SpineManager.setAutoRemove(true)

    self.hpNumberCnt = {}
    self.comboNode = {} -- 连击
    self.comboInfo = {
        [c.UnitGroup.ATTACKER] = {cnt = 0, time = 0},
        [c.UnitGroup.DEFENDER] = {cnt = 0, time = 0},
    } -- 上次连击时间
    self.anims = {}
    self.kamis = {}
    self.gods = {}
    self.bullets = {}
    self.effects = {}
    self.chargeEffect = {}
    self.buffEffects = {} -- {[buff.owner.uid .. "_" .. buff.id] = {cnt = 0, buff = anim}}
    self.cards = {}
    self.actions = {}
    self.heads = {} -- 右方攻击顺序头像
    self.bulletHitCnt = {} --受击特效次数
    self.swing = nil
    self.swingDt = 0
    self.waveIndex = 1 --第几波

    self.speed = 2
    self.freezeCnt = 0 -- 特效定帧帧数
    self.data = data.params
    self.defenderTeam = {0,0,0,0,0}
    self.team = {0,0,0,0,0}

    for order, info in pairs(data.attacker[1]) do
        self.team[order] = info.id
    end
    
    for order, info in pairs(data.defender[1]) do
        self.defenderTeam[order] = info.id
    end

    BattleController.ctor(data, self.data.seed or 1000)
    ViewController.new(self)
    for _,unit in ipairs(BattleController.attackers[1]) do
        BattleController.startUnit[c.UnitGroup.ATTACKER][unit.heroId] = unit.uid
    end
    for _,unit in ipairs(BattleController.defenders[1]) do
        BattleController.startUnit[c.UnitGroup.DEFENDER][unit.heroId] = unit.uid
    end
    --创建csb
    GameScene.super.ctor(self,app,name,data)
end

function GameScene:onCreate()
    --背景音乐
    self:updateBgMusic()

    --创建背景图
    local bgPath = "battleBackground/" .. (self.data.bg and self.data.bg .. ".png" or "background_1_1.png")
    local isExist = cc.FileUtils:getInstance():isFileExist(bgPath)
    if not isExist then
        bgPath = "battleBackground/background_1_1.png"
    end
    self.bg = display.newSprite(bgPath,display.cx,display.cy)
    self.resourceNode_:getChildByName("heroNode"):addChild(self.bg, fightZOrder.bg)

    --创建场景spine
    if self.data.backgroundEffect and self.data.backgroundEffect ~= "" then
        local sp = SpineManager.createAnimation("spine/background/" .. self.data.backgroundEffect, 1)
        sp:playAnimation("idle", -1)
        sp:setPosition(self.bg:getContentSize().width * 0.5,self.bg:getContentSize().height * 0.5)
        self.bg:addChild(sp)
    end

    --创建场景特效
    if self.data.particleEffect and self.data.particleEffect ~= "" then
        local sp = cc.ParticleSystemQuad:create("spine/background/" .. self.data.particleEffect .. ".plist")
        sp:setPosition(self.bg:getContentSize().width * 0.5,self.bg:getContentSize().height)
        self.bg:addChild(sp)
    end

    --定屏遮罩层
    self.blackLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 150))
    self.resourceNode_:getChildByName("heroNode"):addChild(self.blackLayer, fightZOrder.black_layer)
    self.blackLayer:setVisible(false)

    self.powermaxEffectLayer = cc.Layer:create()
    self.resourceNode_:getChildByName("heroNode"):addChild(self.powermaxEffectLayer, fightZOrder.powermax_effect)

    ---自动推图按钮
    local btn_pushMap = self.resourceNode_:getChildByName("node_rb"):getChildByName("btn_pushMap")
    local sp_spot = self.resourceNode_:getChildByName("node_rb"):getChildByName('sp_spot')
    local txt_auto = self.resourceNode_:getChildByName("node_rb"):getChildByName('txt_auto')
    local function updateAutoPushMapStatus()
        sp_spot:setVisible(self.data.autoPushMap)
        btn_pushMap:stopAllActions()
        if self.data.autoPushMap then
            btn_pushMap:runAction(cc.RepeatForever:create(cc.RotateBy:create(2,360)))
        end
    end
    UIImageBox.new(btn_pushMap, function()
        self.data.autoPushMap = not self.data.autoPushMap
        updateAutoPushMapStatus()
    end)

    local level = PlayerModel and PlayerModel.info and PlayerModel.info.level or 0
    local vip = PlayerModel and PlayerModel.info and PlayerModel.info.vip or 0

    if (level >= globalPublicConf[1].aotoBattleLv) and self.data.fightStatus == c.FightStatus.ordinary then 
        btn_pushMap:setVisible(true)
        txt_auto:setVisible(true)
        updateAutoPushMapStatus()
    else
        self.data.autoPushMap = false
        btn_pushMap:setVisible(false)
        txt_auto:setVisible(false)
        sp_spot:setVisible(false)
    end
    -- 暂停按钮
    UIImageBox.new(self.resourceNode_:getChildByName("node_lt"):getChildByName("pauseBtn"), function()
        self:closeSelf()
    end)
    -- 势力克制
    UIImageBox.new(self.resourceNode_:getChildByName("node_lt"):getChildByName("restrainBtn"), function()
        self:openWin("BattleRestrainWin")
    end)
    --- 跳过按钮
    local canSkip = false
    local skipBtn =  self.resourceNode_:getChildByName("node_lt"):getChildByName("skipBtn")

    -- 加速
    local maxSpeed = 1
    -- local isBuyWeek1 = PayModel:getCardBuyState(21)
    local isSpeedTwo = false
    if PlayerModel.info.level and globalPublicConf[1].battleSpeedOpen <= PlayerModel.info.level then
        isSpeedTwo = true
    end
    local isBuyWeek2 = SpeCardModel:hasCardEffect("honor")

    maxSpeed = isSpeedTwo and maxSpeed *2 or maxSpeed
    -- maxSpeed = isBuyWeek2 and maxSpeed *2 or maxSpeed
    if not isSpeedTwo then
        maxSpeed = isBuyWeek2 and maxSpeed *4 or maxSpeed
    else
        maxSpeed = isBuyWeek2 and maxSpeed *2 or maxSpeed
    end
    local speedUpBtn = self.resourceNode_:getChildByName("node_lt"):getChildByName("speedUpBtn")

    local curSpeed = 1
    if PlayerModel.info.userId then
        curSpeed = PlayerConfig.getSetting(PlayerModel.info.userId .. "speed", 1)
        if not isBuyWeek2 and curSpeed == 4 then
            curSpeed = 2
        end
        self:setBattleSpeed(curSpeed*2)
        speedUpBtn:loadTexture("fight/zhandou-x"..curSpeed..".png",ccui.TextureResType.plistType)
    end

    self.speedUpBtn = UIImageBox.new(speedUpBtn, function()
        local buyWeek = SpeCardModel:hasCardEffect("honor")
        if not buyWeek then
            if not isSpeedTwo then
                MoveLabel.new(string.format(WordDictionary[10162], globalPublicConf[1].battleSpeedOpen))
            else
                curSpeed = curSpeed * 2
                if curSpeed > maxSpeed then
                    curSpeed = 1
                end
                self:setBattleSpeed(curSpeed*2)
                PlayerConfig.setSetting(PlayerModel.info.userId .. "speed", curSpeed)
                speedUpBtn:loadTexture("fight/zhandou-x"..curSpeed..".png",ccui.TextureResType.plistType)
            end
        else
            curSpeed = curSpeed * 2
            if curSpeed > maxSpeed then
                curSpeed = 1
            end
            self:setBattleSpeed(curSpeed*2)
            PlayerConfig.setSetting(PlayerModel.info.userId .. "speed", curSpeed)
            speedUpBtn:loadTexture("fight/zhandou-x"..curSpeed..".png",ccui.TextureResType.plistType)
        end
    end)

    local isBuyMonthCard = SpeCardModel:hasCardEffect("extreme")
    -- if (level >= globalPublicConf[1].pvpSkip[1].level) or (vip >= globalPublicConf[1].pvpSkip[1].vip) then
    if isBuyMonthCard then
        canSkip = true
    else
        Helper.greyFunc(skipBtn)
    end

    local btn_skipBtn = UIImageBox.new(skipBtn, function(me)
        local skip = SpeCardModel:hasCardEffect("extreme")
        if not skip then
            return MoveLabel.new(WordDictionary[10161])
        end

        if self.data.fightStatus == c.FightStatus.guildMonster then
            BattleController.pause()
            self:openWin("ResultBossWin",{rewards = {},defenderTeam = self.defenderTeam,team = self.team, damage = self.data.damage + self.data.curMonsterDamage, fightStatus = c.FightStatus.guildMonster, stage = self.data.stage, allDamageData =self.data.allDamageData })
        elseif self.data.fightStatus == c.FightStatus.worldBoss then
            BattleController.pause()
            self:openWin("ResultBossWin", {rewards = {}, defenderTeam = self.defenderTeam, team = self.team, damage = self.data.curMonsterDamage,fightStatus = c.FightStatus.worldBoss, allDamageData =self.data.allDamageData, bossCurHp = self.data.curHp, bossMaxLife = self.data.maxLife })
        elseif self.data.fightStatus == c.FightStatus.actTimeChallenge then
            BattleController.pause()
            self:openWin("ResultBossWin", {rewards = self.data.rewards, defenderTeam = self.defenderTeam, team = self.team, damage = self.data.curMonsterDamage,fightStatus = c.FightStatus.actTimeChallenge, allDamageData =self.data.allDamageData, bossCurHp = self.data.curHp, bossMaxLife = self.data.maxLife})
        elseif self.data.fightStatus == c.FightStatus.worldFight then
            BattleController.pause()
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, showRewards = true, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.KingSwordBoss
            or self.data.fightStatus == c.FightStatus.KingSwordFightOther then
            BattleController.pause()
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, showRewards = true, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.hallFight
            or self.data.fightStatus == c.FightStatus.hallSpecialFight then
            BattleController.pause()
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.rewardPalace then
            BattleController.pause()
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.arena
            or self.data.fightStatus == c.FightStatus.familyCompeteFight then
            BattleController.pause()
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
                    
                if self.data.hisRankMax and self.data.hisMaxRwds and self.data.myIdx < self.data.hisRankMax then
                    self:openWin("ArenaMaxRankWin",self.data)
                end
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        else
            self:skipBattle()
            me:setTouchEnabled(false)
        end
    end)

    if self.data.fightStatus == c.FightStatus.ordinary then
        self.resourceNode_:getChildByName("node_lt"):getChildByName("node_expAdd"):setVisible(true)
    else
        self.resourceNode_:getChildByName("node_lt"):getChildByName("node_expAdd"):setVisible(false)
    end

    if self.data.fightStatus == c.FightStatus.worldBoss 
        or self.data.fightStatus == c.FightStatus.KingSwordBoss
        or self.data.fightStatus == c.FightStatus.guildBoss
        or self.data.fightStatus == c.FightStatus.KingSwordFightOther 
        or self.data.fightStatus == c.FightStatus.hallFight
        or self.data.fightStatus == c.FightStatus.hallSpecialFight
        or (self.data.fightStatus == c.FightStatus.worldFight and wfightConf[1].skip == 1)
        or self.data.fightStatus == c.FightStatus.rewardPalace
        or self.data.fightStatus == c.FightStatus.ordinary
        or self.data.fightStatus == c.FightStatus.actTimeChallenge then
        btn_skipBtn:setVisible(true)
        btn_skipBtn:setEnabled(false)
        local size = btn_skipBtn:getContentSize()
        local waitTime = 30
        if self.data.fightStatus == c.FightStatus.hallFight
            or self.data.fightStatus == c.FightStatus.hallSpecialFight
            or self.data.fightStatus == c.FightStatus.rewardPalace
            or self.data.fightStatus == c.FightStatus.worldBoss
            or self.data.fightStatus == c.FightStatus.actTimeChallenge
            or self.data.fightStatus == c.FightStatus.guildBoss
            or self.data.fightStatus == c.FightStatus.ordinary then
            waitTime = 0
        end
        local timeLabel = UILabel.new({
            text = waitTime,
            color = CoreColor.WHITE,
            back = cc.c3b(0,0,0),
            size = 25,
        })
        btn_skipBtn:addChild(timeLabel)
        display.align(timeLabel, display.CENTER_BOTTOM, size.width/2, 10)
        if canSkip then
            if waitTime <= 0 then
                timeLabel:setVisible(false)
                btn_skipBtn:setEnabled(true)
            end
            timeLabel:actionScheduleInterval(function()
                waitTime = waitTime - 1
                if waitTime >= 0 then
                    timeLabel:setString(waitTime)
                else
                    timeLabel:stopAllActions()
                    timeLabel:setVisible(false)
                    btn_skipBtn:setEnabled(true)
                end
            end, 1)
        else
            timeLabel:setVisible(false)
            btn_skipBtn:setEnabled(true)
            Helper.greyFunc(btn_skipBtn)
        end
    end

    self.resourceNode_:getChildByName("node_lt"):getChildByName("restrainBtn"):setVisible(false)--隐藏势力克制

    if self.data.fightStatus == c.FightStatus.arena or ---隐藏暂停按钮
        self.data.fightStatus == c.FightStatus.mineWar or 
        self.data.fightStatus == c.FightStatus.worldBoss or 
        self.data.fightStatus == c.FightStatus.guildBoss or 
        self.data.fightStatus == c.FightStatus.rewardPalace or
        self.data.fightStatus == c.FightStatus.hallFight or
        self.data.fightStatus == c.FightStatus.phantomTower or
        self.data.fightStatus == c.FightStatus.kfbsLadder or
        self.data.fightStatus == c.FightStatus.kfbsChampion or
        self.data.fightStatus == c.FightStatus.tower or
        self.data.fightStatus == c.FightStatus.towerElite or
        self.data.fightStatus == c.FightStatus.ninjaMaster or
        self.data.fightStatus == c.FightStatus.ninjaLegend or
        self.data.fightStatus == c.FightStatus.patrol or
        self.data.fightStatus == c.FightStatus.runePlay or
        self.data.fightStatus == c.FightStatus.actTimeChallenge or
        self.data.fightStatus == c.FightStatus.plotStep or
        self.data.fightStatus == c.FightStatus.plotBoss then
        self.resourceNode_:getChildByName("node_lt"):getChildByName("pauseBtn"):setVisible(false)
    end

    self:createTopNode()

    if self.data.fightStatus == c.FightStatus.arena 
        or self.data.fightStatus == c.FightStatus.mineWar
        or self.data.fightStatus == c.FightStatus.land
        or self.data.fightStatus == c.FightStatus.kingFight
        or self.data.fightStatus == c.FightStatus.worldFight
        or self.data.fightStatus == c.FightStatus.guildMonster 
        or self.data.fightStatus == c.FightStatus.worldBoss 
        or self.data.fightStatus == c.FightStatus.devilSoulSeal
        or self.data.fightStatus == c.FightStatus.hallFight 
        or self.data.fightStatus == c.FightStatus.hallSpecialFight
        or self.data.fightStatus == c.FightStatus.txwsPVP
        or self.data.fightStatus == c.FightStatus.forceLeader
        or self.data.fightStatus == c.FightStatus.phantomTower
        or self.data.fightStatus == c.FightStatus.rewardPalace 
        or self.data.fightStatus == c.FightStatus.ghostStep
        or self.data.fightStatus == c.FightStatus.mapBoss
        or self.data.fightStatus == c.FightStatus.familyCompeteFight
        or self.data.fightStatus == c.FightStatus.guildBoss
        or self.data.fightStatus == c.FightStatus.tower
        or self.data.fightStatus == c.FightStatus.towerElite
        or self.data.fightStatus == c.FightStatus.ninjaExp
        or self.data.fightStatus == c.FightStatus.kfbsLadder
        or self.data.fightStatus == c.FightStatus.kfbsChampion
        or self.data.fightStatus == c.FightStatus.ninjaMaster
        or self.data.fightStatus == c.FightStatus.patrol
        or self.data.fightStatus == c.FightStatus.actTimeChallenge 
        or self.data.fightStatus == c.FightStatus.plotStep
        or self.data.fightStatus == c.FightStatus.plotBoss then

        BattleController.autoFight[c.UnitGroup.ATTACKER] = true
        BattleController.autoFight[c.UnitGroup.DEFENDER] = true
        BattleController.canFreezing[c.UnitGroup.ATTACKER] = true
        BattleController.canFreezing[c.UnitGroup.DEFENDER] = true
    elseif self.data.fightStatus == c.FightStatus.KingSwordBoss
        or self.data.fightStatus == c.FightStatus.ninjaLegend
        or self.data.fightStatus == c.FightStatus.runePlay
        or self.data.fightStatus == c.FightStatus.KingSwordFightOther then

        BattleController.autoFight[c.UnitGroup.ATTACKER] = true
        BattleController.autoFight[c.UnitGroup.DEFENDER] = true
    elseif self.data.fightStatus == c.FightStatus.ordinary or 
            self.data.fightStatus == c.FightStatus.tower or
            self.data.fightStatus == c.FightStatus.towerElite or
            self.data.fightStatus == c.FightStatus.dungeon or
            self.data.fightStatus == c.FightStatus.wantedOrdinary or
            self.data.fightStatus == c.FightStatus.wantedComplete or
            self.data.fightStatus == c.FightStatus.huntSoul or 
            self.data.fightStatus == c.FightStatus.timeChallenge then--推图、爬塔、地下城通缉Boss（普通）、通缉Boss（2.5被攻击）限时挑战
        --是否自动
        if PlayerModel.info.userId then
            BattleController.autoFight[c.UnitGroup.ATTACKER] = PlayerConfig.getSetting(PlayerModel.info.userId .. "autoFight", false)
        else
            BattleController.autoFight[c.UnitGroup.ATTACKER] = false
        end
    end

    self.autoBtn = UIImageBox.new(self.resourceNode_:getChildByName("node_rb"):getChildByName("autoBtn"), handler(self, self.clickAutoBtn))
    self:changeAutoStatus()

    -- 幻化神
    self.resourceNode_:getChildByName("kamiNode"):getChildByName("sp_icon"):runAction(cc.RepeatForever:create(cc.RotateBy:create(1, -60)))

    local kami = BattleController.kamis[c.UnitGroup.ATTACKER]
    local path = kami and "spine/actors/" .. roleConf[kami.role].spine or "spine/actors/kamione1"
    local button = UIAniButton.new(path,function(eventType,me,point)
        if eventType == "ended" then
            BattleController.kamiSkill(c.UnitGroup.ATTACKER)
        end
    end)
    button:setScale(1.3)
    button:setPosition(113, 0)
    button:setEnabled(false)
    button:setGray()
    self.kamiButton = button
    self.resourceNode_:getChildByName("kamiNode"):addChild(button, -1)
    self.resourceNode_:getChildByName("kamiNode"):setVisible(kami ~= nil and Helper.getOpenState(10,true))
    if kami ~= nil then
        self:updateKamiEnergy(kami.group, kami.attr.mp, kami.attr.energy)
    end

    self:updateRound(1, globalBattleConf[1].roundLimit)

    -- 幻化神
    for _, group in pairs({[1] = c.UnitGroup.ATTACKER, [2] = c.UnitGroup.DEFENDER}) do
        local kami = BattleController.kamis[group]
        if kami then
            local anim = UnitAnim.new(roleConf[kami.role].spine, 2.5 * self.uiScale)
            anim:playAnimation("idle", -1)
            anim:setVisible(false)
            
            if kami.group == c.UnitGroup.DEFENDER then
                anim:setScaleX(-1 * anim:getScaleX())
            end

            local name = (group == c.UnitGroup.ATTACKER) and "kamiLeft" or "kamiRight"
            local node = self.resourceNode_:getChildByName("heroNode"):getChildByName(name)
            anim:setPosition(node:getPosition())
            self.resourceNode_:getChildByName("heroNode"):addChild(anim, fightZOrder.kami)

            self.kamis[kami.uid] = anim
        end
    end

    --御神
    for _, group in pairs({[1] = c.UnitGroup.ATTACKER, [2] = c.UnitGroup.DEFENDER}) do
        local god = BattleController.gods[group]
        if god then
            local anim = UnitAnim.new(roleConf[god.role].spine, 1 * self.uiScale)
            anim:setVisible(false)
            anim:setPosition(display.cx, display.cy)
            anim:addChildFollowSlot("item_point",display.newSprite("kami/" .. reinGodConf[god.level].spine .. ".png"))
            self.resourceNode_:getChildByName("heroNode"):addChild(anim, fightZOrder.god)

            self.gods[god.uid] = anim
        end
    end

    -- 攻击顺序头像
    local bg = display.newSprite("#fight/fight_slat_27.png")
        :align(display.TOP_CENTER, 0, 0)
        :addTo(self.resourceNode_:getChildByName("node_rt"):getChildByName("speedBarNode"))
    self.sequenceBg = bg

    local curFightBg = display.newSprite("#fight/fight_slat_31.png")
    local anim = SpineManager.createAnimation("public/ui_shunxutiao", 1)
    anim:playAnimation("idle3", -1)
    anim:setPosition(curFightBg:getContentSize().width/2, curFightBg:getContentSize().height/2)
    curFightBg:addChild(anim)

    local size = bg:getContentSize()
    local cellHeight = curFightBg:getContentSize().height
    local startY = size.height - cellHeight / 2
    local startX = size.width / 2

    bg.startX = startX
    bg.startY = startY
    bg.cellHeight = cellHeight

    curFightBg:align(display.CENTER, startX, startY)
        :addTo(bg)

    self.heads["line"] = display.newSprite("#fight/fight_slat_30.png")
        :align(display.TOP_CENTER, startX, startY - cellHeight / 2)
        :addTo(bg)
    
    ----通用翻牌
    network.addListener(self, {msgids.GS_FlopRewardsNew}, handler(self, function(self, op, data)
        self.TrunCardData = data
    end))
    
    --战斗如果有月卡体验直接扣除体验次数
    if SpeCardModel:getExprienceId() ~= 0 then
        network.tcpSend(msgids.C_SpeCardTrial)
    end

    if self.data.fightStatus == c.FightStatus.ordinary then
        self:showExpAddView()
        network.addListener(self, {msgids.GS_SpeCardCharge}, handler(self, function(self, op, data)
            self.resourceNode_:getChildByName("node_lt"):getChildByName("skipBtn"):setEnabled(SpeCardModel:isBuyExtremeCard())
            self:showExpAddView()
        end))
    end

    if self.data.fightStatus == c.FightStatus.mapBoss and self.data.buffs then----英魂boss添加buff图标
        local node = self.resourceNode_:getChildByName("node_rt")
        for i,id in ipairs(self.data.buffs or {}) do
            local buffIcon = Helper.createBuffIcon({id = id, scale = 0.8})
            node:addChild(buffIcon)
            buffIcon:setPosition(-(i-1)*50 - 35, -30)
        end
    end

    if self.data.fightStatus == c.FightStatus.ninjaExp then
        self.resourceNode_:getChildByName("node_lt"):setVisible(false)
        self:setBattleSpeed(4)
    end

    if self.data.fightStatus == c.FightStatus.kfbsChampion then ---设置直接退出按钮
        local btn = UIImageBox.new(self.resourceNode_:getChildByName("node_lt"):getChildByName("skipBtn"), function()
            BattleController.pause()
            self:exitScene()
        end)
        btn:setVisible(true)
        Helper.greyFunc(btn, true)
        btn:getChildByName("txt_word"):setString(WordDictionary[10172])
    end

    if self.data.fightStatus == c.FightStatus.kfbsLadder---隐藏跳过按钮
    or self.data.fightStatus == c.FightStatus.ninjaMaster
    or self.data.fightStatus == c.FightStatus.ninjaLegend
    or self.data.fightStatus == c.FightStatus.runePlay
    or self.data.fightStatus == c.FightStatus.patrol then
        self.resourceNode_:getChildByName("node_lt"):getChildByName("skipBtn"):setVisible(false)
    end

     -----设置左上角按钮位置
    local btnNames = {"pauseBtn", "skipBtn", "speedUpBtn", "restrainBtn"}---从左向右
    local startX = 42
    local spacing = 70
    local cnt = 0
    for i,name in ipairs(btnNames) do
        local btn = self.resourceNode_:getChildByName("node_lt"):getChildByName(name)
        if btn and btn:isVisible() then
            cnt = cnt + 1
            btn:setPositionX(startX + (cnt - 1) * spacing)
        end
    end

end

function GameScene:showExpAddView()
    if not SpeCardModel:getTrial()  and (not SpeCardModel:isBuyHonorCard() and not SpeCardModel:isBuyExtremeCard()) then
        return
    end
    local exprienceId = SpeCardModel:getExprienceId()
    local node = self.resourceNode_:getChildByName("node_lt"):getChildByName("node_expAdd")
    node:removeAllChildren()
    local img_di = self.resourceNode_:getChildByName("node_lt"):getChildByName("img_di")
    
    if not SpeCardModel:isBuyHonorCard() and not SpeCardModel:isBuyExtremeCard() then--没有激活任何月卡
        local img = ccui.ImageView:create("fight/zhandou-exp".. (exprienceId ~= 2 and 5 or 15) ..".png", ccui.TextureResType.plistType)
            :addTo(node)
        local path = "fight/zhandou-exp5.png"
        img_di:getChildByName("img_expadd"):loadTexture("fight/zhandou-exp".. (exprienceId ~= 2 and 5 or 15) ..".png",ccui.TextureResType.plistType)
        img_di:getChildByName("txt_use"):setString(WordDictionary[10166] .. (exprienceId ~= 2 and 5 or 15) .."%")
        img_di:getChildByName("txt_laiyuan"):setString(WordDictionary[10167] .. WordDictionary[10168])

        UIImageBox.new(img, function(me, event)
            if event.name == "began" then
                img_di:setVisible(true)
            elseif event.name == "ended" or event.name == "cancelled" then
                img_di:setVisible(false)
            elseif event.name == "moved" then
                if event.dis >= 8 then
                    img_di:setVisible(false)
                end
            end
        end, {touchEvent = true, ableGLProgram = false})

        if exprienceId == 0 then
            Helper.greyFunc(img, false)
        end
    elseif SpeCardModel:isBuyHonorCard() and not SpeCardModel:isBuyExtremeCard() then--只激活小月卡
        local img = ccui.ImageView:create("fight/zhandou-exp".. (exprienceId ~= 2 and 5 or 15) ..".png", ccui.TextureResType.plistType)
            :addTo(node)
        img_di:getChildByName("img_expadd"):loadTexture("fight/zhandou-exp".. (exprienceId ~= 2 and 5 or 15) ..".png",ccui.TextureResType.plistType)
        img_di:getChildByName("txt_use"):setString(WordDictionary[10166] .. (exprienceId ~= 2 and 5 or 15) .."%")
        img_di:getChildByName("txt_laiyuan"):setString(WordDictionary[10167] .. WordDictionary[10169])
        UIImageBox.new(img, function(me, event)
            if event.name == "began" then
                img_di:setVisible(true)
            elseif event.name == "ended" or event.name == "cancelled" then
                img_di:setVisible(false)
            elseif event.name == "moved" then
                if event.dis >= 8 then
                    img_di:setVisible(false)
                end
            end
        end, {touchEvent = true, ableGLProgram = false})

        if exprienceId == 0 and not SpeCardModel:isBuyHonorCard() then
            Helper.greyFunc(img, false)
        end
    elseif not SpeCardModel:isBuyHonorCard() and SpeCardModel:isBuyExtremeCard() then--只激活大月卡
        local img = ccui.ImageView:create("fight/zhandou-exp15.png", ccui.TextureResType.plistType)
            :addTo(node)
        img_di:getChildByName("img_expadd"):loadTexture("fight/zhandou-exp15.png",ccui.TextureResType.plistType)
        img_di:getChildByName("txt_use"):setString(WordDictionary[10166] .. "15%")
        img_di:getChildByName("txt_laiyuan"):setString(WordDictionary[10167] .. WordDictionary[10169])
        UIImageBox.new(img, function(me, event)
            if event.name == "began" then
                img_di:setVisible(true)
            elseif event.name == "ended" or event.name == "cancelled" then
                img_di:setVisible(false)
            elseif event.name == "moved" then
                if event.dis >= 8 then
                    img_di:setVisible(false)
                end
            end
        end, {touchEvent = true, ableGLProgram = false})

        -- if exprienceId == 0 then
        --     Helper.greyFunc(img, false)
        -- end
    else--两种卡都激活了
        local img = ccui.ImageView:create("fight/zhandou-exp15.png", ccui.TextureResType.plistType)
            :addTo(node)

        img_di:getChildByName("img_expadd"):loadTexture("fight/zhandou-exp15.png",ccui.TextureResType.plistType)
        img_di:getChildByName("txt_use"):setString(WordDictionary[10166] .. "15%")
        img_di:getChildByName("txt_laiyuan"):setString(WordDictionary[10167] .. WordDictionary[10169])

        UIImageBox.new(img, function(me, event)
            if event.name == "began" then
                img_di:setVisible(true)
            elseif event.name == "ended" or event.name == "cancelled" then
                img_di:setVisible(false)
            elseif event.name == "moved" then
                if event.dis >= 8 then
                    img_di:setVisible(false)
                end
            end
        end, {touchEvent = true, ableGLProgram = false})
    end
end


function GameScene:closeSelf()
    BattleController.pause()
    local function callback(isSkip)
        if isSkip then
            self:exitScene()
        else--继续
            BattleController.pause()
        end
    end
    self:openWin("PauseWin",self.data.fightStatus, callback)
end

function GameScene:refreshFightSequenceHead()
    local uids = {}
    local waitAtk = {}
    for _, unit in pairs(BattleController.units) do
        if unit:isAlive() then
            uids[#uids + 1] = unit.uid
        end
    end

    for idx, unit in pairs(BattleController.waitAtkUnits["wait"] or {}) do
        waitAtk[unit.uid] = idx
    end

    table.sort(uids, function(a, b)
        if waitAtk[a] and waitAtk[b] then
            return waitAtk[a] > waitAtk[b]
        elseif waitAtk[a] then
            return true
        elseif waitAtk[b] then
            return false
        else
            local unitA = BattleController.getUnitByUid(a)
            local unitB = BattleController.getUnitByUid(b)

            if unitA.attr.speed ~= unitB.attr.speed then
                return unitA.attr.speed > unitB.attr.speed
            elseif unitA.group ~= unitB.group then
                return unitA.group == c.UnitGroup.ATTACKER
            else
                return unitA.order < unitB.order
            end
        end
    end)


    local bg = self.sequenceBg
    local x = bg.startX
    local y = bg.startY
    local cellHeight = bg.cellHeight
    local needSplitLine = true
    local moveTime = 0.5

    for _, uid in ipairs(uids) do
        if not waitAtk[uid] and needSplitLine == true then
            local line = self.heads["line"]
            if _ == 1  then
                y = y - cellHeight
            end

            line:stopAllActions()
            line:runAction(cc.MoveTo:create(moveTime, cc.p(line:getPositionX(), y + cellHeight / 2)))

            y = y - line:getContentSize().height
            needSplitLine = false
        end

        local head = self.heads[uid]
        if not head then
            local unit = BattleController.getUnitByUid(uid)
            local path = unit.group == c.UnitGroup.ATTACKER and "#fight/fight_slat_28.png" or "#fight/fight_slat_29.png"

            head = display.newSprite(path)
                :align(display.CENTER, x, y)
                :addTo(bg)

            local path = "icon/head/" .. (roleConf[unit.role].head) .. ".png"
            local icon = display.newSprite(path)
                :align(display.CENTER, head:getContentSize().width/2, head:getContentSize().height/2)
                :addTo(head)
            icon:setScale(head:getContentSize().width * 0.8 / icon:getContentSize().width)

            self.heads[uid] = head
        else
            head:stopAllActions()
            head:runAction(cc.MoveTo:create(moveTime, cc.p(head:getPositionX(), y)))
        end

        y = y - cellHeight
    end

    if needSplitLine then
        local line = self.heads["line"]
        line:stopAllActions()
        line:runAction(cc.MoveTo:create(moveTime, cc.p(line:getPositionX(), y + cellHeight / 2)))
    end

    for _, uid in pairs(table.keys(self.heads)) do
        if uid ~= "line" then
            local unit = BattleController.getUnitByUid(uid)
            if not unit or not unit:isAlive() then
                self.heads[uid]:removeFromParent()
                self.heads[uid] = nil
            end
        end
    end
end

function GameScene:updateBgMusic()
    if not self.data.bgMusic or not self.data.bgMusic[self.waveIndex] or self.data.bgMusic[self.waveIndex] == "" then
        return
    end
    local path = "music/" .. self.data.bgMusic[self.waveIndex]
    AudioManager.playMusic(path)
end

function GameScene:createTopNode()
    --顶部信息栏(普通、BOSS)
    if self.topNode then
        self.topNode:removeFromParent()
        self.topNode = nil
    end
    local topNode = nil
    if self.data.fightStatus == c.FightStatus.wantedOrdinary or
        self.data.fightStatus == c.FightStatus.wantedComplete or 
        self.data.fightStatus == c.FightStatus.guildBoss or
        self.data.fightStatus == c.FightStatus.worldBoss or
        self.data.fightStatus == c.FightStatus.plotBoss or
        (self.data.monsterId and self.data.fightStatus == c.FightStatus.actTimeChallenge) or
        self.bossTop then
        
        topNode = self:createCsbNode("fight/bossTopNode.csb")
        topNode:getChildByName("node_normal"):setVisible(true)
        topNode:getChildByName("node_guildMonster"):setVisible(false)
        --boss头像
        local frame = topNode:getChildByName("node_normal"):getChildByName("headFrame")
        local roleId = monsterConf[self.data.monsterId].role
        local headPath = roleConf[roleId].head
        local imgName = "icon/head/" .. headPath .. ".png"
        local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png")
        headImg:setScale(0.45)
        headImg:setFlippedX(true)
        display.align(headImg,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(headImg)

        local bloodCount = monsterConf[self.data.monsterId].bloodCount
        --print("+++++++++++",bloodCount)
        topNode:getChildByName("node_normal"):getChildByName("bloodCntText"):setString("x"..bloodCount)

        if (self.data.fightStatus == c.FightStatus.ordinary and self.data.levelId) or self.data.fightStatus == c.FightStatus.plotBoss then
            local buffs = battleConf[self.data.levelId] and battleConf[self.data.levelId].battleBuff or (self.data.buffs or {})
            for i,id in ipairs(buffs) do
                local icon = Helper.createBuffIcon({id = id, scale = 0.6, haveTip = true})
                icon:setPositionX((i-1)*40)
                topNode:getChildByName("node_normal"):getChildByName("node_buff"):addChild(icon)
            end
        end
    elseif self.data.fightStatus == c.FightStatus.arena
        or self.data.fightStatus == c.FightStatus.mineWar
        or self.data.fightStatus == c.FightStatus.kingFight
        or self.data.fightStatus == c.FightStatus.worldFight
        or self.data.fightStatus == c.FightStatus.KingSwordFightOther
        or self.data.fightStatus == c.FightStatus.familyCompeteFight 
        or self.data.fightStatus == c.FightStatus.kfbsLadder 
        or self.data.fightStatus == c.FightStatus.kfbsChampion 
        or self.data.fightStatus == c.FightStatus.ninjaExp then
        topNode = self:createCsbNode("fight/pvpTopNode.csb")
        local attackPlayerInfo = self.data.attackPlayerInfo
        local defenderPlayerInfo = self.data.defenderPlayerInfo
        topNode:getChildByName("node"):getChildByName("Text_1"):setString(attackPlayerInfo.name or "")
        topNode:getChildByName("node"):getChildByName("Text_2"):setString(defenderPlayerInfo.name or "")
        local headL = {
            frame = topNode:getChildByName("node"):getChildByName("left"),
            headId = attackPlayerInfo.head,
            frameId = attackPlayerInfo.hFrame,
            title = attackPlayerInfo.title,
        }
        local headR = {
            frame = topNode:getChildByName("node"):getChildByName("right"),
            headId = defenderPlayerInfo.head,
            frameId = defenderPlayerInfo.hFrame,
            title = defenderPlayerInfo.title,
        }
        Helper.createPlayerHead(headL)
        Helper.createPlayerHead(headR)
        -- topNode = self:createCsbNode("fight/topNode.csb")
    elseif self.data.fightStatus == c.FightStatus.guildMonster then
        topNode = self:createCsbNode("fight/bossTopNode.csb")
        topNode:getChildByName("node_normal"):setVisible(false)
        topNode:getChildByName("node_guildMonster"):setVisible(true)

        local guildMonsterData = guildMonsterConf[self.data.stage]
        local barMyDamage = topNode:getChildByName("node_guildMonster"):getChildByName("bar_myDamage")
        local damageSize = barMyDamage:getContentSize()
        for k,v in ipairs(guildMonsterData.attackLevel) do
            local x = (v / guildMonsterData.attackLevelLimit) * damageSize.width
            barMyDamage:getChildByName("stage"..k):setPositionX(x)
        end

        self:updateGuildMonsterBar(barMyDamage, 0)

    else
        topNode = self:createCsbNode("fight/topNode.csb")
    end

    self.resourceNode_:addChild(topNode)
    self.topNode = topNode

    -------------------------- 调试界面 --------------------------
    UIImageBox.new(self.topNode:getChildByName("node"):getChildByName("roundBg"), function()
        if DEBUG ~= 0 then
            self:openWin("BattleInfoWin")
        end
    end)

    if self.topNode:getChildByName("node"):getChildByName("turnBg") then
        UIImageBox.new(self.topNode:getChildByName("node"):getChildByName("turnBg"), function()
            if DEBUG ~= 0 then
                BattleController.manualLogic = not BattleController.manualLogic
            end
        end)
    end
    ------------------------------------------------------------
end

function GameScene:updateGuildMonsterBar(bar, damage)
    local allDamage = self.data.damage + damage
    local guildMonsterData = guildMonsterConf[self.data.stage]
    bar:getChildByName("txt_damage"):setString(math.ceil(allDamage))
    bar:setPercent(math.min(allDamage/guildMonsterData.attackLevelLimit, 1) * 100)
    for k,v in ipairs (guildMonsterData.attackLevel) do
        local txt = bar:getChildByName("stage"..k):getChildByName("txt_stage")
        if allDamage >= v then
            txt:setTextColor(c.ITEM_COLOR[k+1])
        else
            txt:setTextColor(cc.c3b(200,200,200))
        end
    end
end

function GameScene:updateDamage(uid)
    if self.data.fightStatus == c.FightStatus.guildMonster then
        local unit = BattleController.getUnitByUid(uid)
        if unit.group == c.UnitGroup.ATTACKER then
            local damage = StatisticsController.getGroupDamage(c.UnitGroup.ATTACKER, true)
            local bossBar = self.topNode:getChildByName("node_guildMonster"):getChildByName("bar_myDamage")
            self:updateGuildMonsterBar(bossBar, damage)
        end
    end
end

function GameScene:updateKamiDamage(group)
    if self.data.fightStatus == c.FightStatus.guildMonster then
        if group == c.UnitGroup.ATTACKER then
            local damage = StatisticsController.getGroupDamage(c.UnitGroup.ATTACKER, true)
            local bossBar = self.topNode:getChildByName("node_guildMonster"):getChildByName("bar_myDamage")
            self:updateGuildMonsterBar(bossBar, damage)
        end
    end
end

function GameScene:updateTopNode(uidGroups)
    local bossId = nil
    self.bossTop = false
    for k,v in pairs(uidGroups or {}) do
        local unit = BattleController.getUnitByUid(v)
        if unit.heroId >= 50000 and unit.heroId <=70000  then
            self.bossTop = true
            self.data.monsterId = unit.heroId
        end
    end
end

function GameScene:changeAutoStatus()
    local isOpen = Helper.getOpenState(7,true)
    if self.data.fightStatus == c.FightStatus.KingSwordBoss
    or self.data.fightStatus == c.FightStatus.ninjaMaster
    or self.data.fightStatus == c.FightStatus.ninjaLegend
    or self.data.fightStatus == c.FightStatus.patrol
    or self.data.fightStatus == c.FightStatus.runePlay
    or self.data.fightStatus == c.FightStatus.KingSwordFightOther then
        isOpen = true
    end
    local isAuto = BattleController.autoFight[c.UnitGroup.ATTACKER] and isOpen

    self.resourceNode_:getChildByName("node_rb"):getChildByName("autoLight"):setVisible(isAuto)
	
    if isAuto then
        self.autoBtn:runAction(cc.RepeatForever:create(cc.RotateBy:create(2,-360)))
    else    
        self.autoBtn:stopAllActions()
    end
end

function GameScene:clickAutoBtn()
    if self.data.fightStatus == c.FightStatus.arena
        or self.data.fightStatus == c.FightStatus.mineWar
        or self.data.fightStatus == c.FightStatus.land
        or self.data.fightStatus == c.FightStatus.kingFight
        or self.data.fightStatus == c.FightStatus.worldFight 
        or self.data.fightStatus == c.FightStatus.worldBoss
        or self.data.fightStatus == c.FightStatus.guildMonster
        or self.data.fightStatus == c.FightStatus.kfbsLadder
        or self.data.fightStatus == c.FightStatus.kfbsChampion
        or self.data.fightStatus == c.FightStatus.devilSoulSeal
        or self.data.fightStatus == c.FightStatus.KingSwordBoss
        or self.data.fightStatus == c.FightStatus.KingSwordFightOther
        or self.data.fightStatus == c.FightStatus.hallFight 
        or self.data.fightStatus == c.FightStatus.hallSpecialFight
        or self.data.fightStatus == c.FightStatus.txwsPVP
        or self.data.fightStatus == c.FightStatus.forceLeader 
        or self.data.fightStatus == c.FightStatus.phantomTower
        or self.data.fightStatus == c.FightStatus.rewardPalace
        or self.data.fightStatus == c.FightStatus.mapBoss
        or self.data.fightStatus == c.FightStatus.familyCompeteFight
        or self.data.fightStatus == c.FightStatus.tower
        or self.data.fightStatus == c.FightStatus.towerElite
        or self.data.fightStatus == c.FightStatus.guildBoss
        or self.data.fightStatus == c.FightStatus.actTimeChallenge
        or self.data.fightStatus == c.FightStatus.ninjaMaster
        or self.data.fightStatus == c.FightStatus.ninjaLegend
        or self.data.fightStatus == c.FightStatus.patrol
        or self.data.fightStatus == c.FightStatus.runePlay
        or self.data.fightStatus == c.FightStatus.plotStep
        or self.data.fightStatus == c.FightStatus.plotBoss
        or self.data.fightStatus == c.FightStatus.ninjaExp then
        return
    end

    local isOpen = Helper.getOpenState(7)
    if isOpen then
        BattleController.autoFight[c.UnitGroup.ATTACKER] = not BattleController.autoFight[c.UnitGroup.ATTACKER]

        if PlayerModel.info.userId then
            PlayerConfig.setSetting(PlayerModel.info.userId .. "autoFight", BattleController.autoFight[c.UnitGroup.ATTACKER])
        end
        self:changeAutoStatus()
    end
end

function GameScene:exitScene(isWin)
    AudioManager.effectStatus = true
    local data = {afterLoading = self.data.afterLoading or c.AfterLoading.outsideScene, curScene = c.AfterLoading.gameScene}
    data.fromScene = self.data.fromScene
    if self.data.fightStatus == c.FightStatus.ordinary and isWin then
        data.levelId = self.data.levelId
    elseif self.data.fightStatus == c.FightStatus.tower then
        data.win = "TowerWin"
    elseif self.data.fightStatus == c.FightStatus.towerElite then--返回秘术之塔
        data.win = "TowerEliteWin"
    elseif self.data.fightStatus == c.FightStatus.arena then--返回竞技场
        data.win = "ArenaWin"
    elseif self.data.fightStatus == c.FightStatus.mineWar then--返回矿战
        data.afterLoading = self.data.afterLoading
    elseif self.data.fightStatus == c.FightStatus.dungeon then--返回地下城
        data.dungeonId = self.data.dungeonId
        data.win = "DungeonWin"
    elseif self.data.fightStatus == c.FightStatus.timeChallenge then--返回限时挑战
        data.challengeId = self.data.challengeId
        data.win = "ActTimeChallengeWin"
    elseif self.data.fightStatus == c.FightStatus.actTimeChallenge then--返回限时挑战
        data.challengeId = self.data.challengeId
        data.win = "ActLimitChallengeWin"
    elseif self.data.fightStatus == c.FightStatus.wantedOrdinary or
            self.data.fightStatus == c.FightStatus.wantedComplete then--返回通缉BOSS
        data.win = "WantedWin"
    elseif self.data.fightStatus == c.FightStatus.guildBoss then
        data.afterLoading = c.AfterLoading.mainScene
        data.win = "FamilyLandWin"
    elseif self.data.fightStatus == c.FightStatus.worldBoss then
        data.afterLoading = c.AfterLoading.mainScene
        data.win = "WorldBossWin"
    elseif self.data.fightStatus == c.FightStatus.kfbsLadder or self.data.fightStatus == c.FightStatus.kfbsChampion then
        data.win = "CrossServerWin"
    elseif self.data.fightStatus == c.FightStatus.devilSoulSeal then
        data.win = "SealInfoWin"
    elseif self.data.fightStatus == c.FightStatus.kingFight then
        data.afterLoading = c.AfterLoading.kingFightScene
        data.fromScene = Helper.getFromScene(g_lastScene)
        if self.data.win == "KingFightInWin" then
            data.win = "KingFightInWin"
        end
        -- data.fromScene = 
    elseif self.data.fightStatus == c.FightStatus.huntSoul then
        data.win = "HuntSoulWin"
        data.selectPage = self.data.huntId
        if isWin then
            data.monsterIndex = self.data.monsterIndex
        end
    elseif self.data.fightStatus == c.FightStatus.KingSwordBoss
        or self.data.fightStatus == c.FightStatus.KingSwordFightOther then
        data.win = "KingSwordWin"
    elseif self.data.fightStatus == c.FightStatus.hallFight 
        or self.data.fightStatus == c.FightStatus.hallSpecialFight then
        data.win = "HallDetailWin"
        data.stageType = self.data.stageType
        data.showStage = self.data.showStage
        data.isWin = self.data.isWin
        data.isFirst = self.data.isFirst or false
    elseif self.data.fightStatus == c.FightStatus.txwsPVP then
        data.win = "TxwsPlusWin"
    elseif self.data.fightStatus == c.FightStatus.forceLeader then
        data.win = "LeaderWin"
    elseif self.data.fightStatus == c.FightStatus.phantomTower then
        data.win = "ChaseTraitorWin"
        --data.openTowerWin = true
    elseif self.data.fightStatus == c.FightStatus.ghostStep and isWin then
        data.levelId = self.data.levelId
    elseif self.data.fightStatus == c.FightStatus.rewardPalace then
        data.win = "RewardPalaceWin"
    elseif self.data.fightStatus == c.FightStatus.familyCompeteFight then--返回家族
        data.win = "FamilyLandWin"
    elseif self.data.fightStatus == c.FightStatus.ninjaMaster then
        data.win = "NinjaMasterWin"
    elseif self.data.fightStatus == c.FightStatus.ninjaLegend then
        data.win = "NinjaLegendWin"
    elseif self.data.fightStatus == c.FightStatus.patrol then
        data.win = "PatrolWin"
        data.id = self.data.id
    elseif self.data.fightStatus == c.FightStatus.mapBoss then
        data.levelId = self.data.stepId
        data.click = true
    elseif self.data.fightStatus == c.FightStatus.ninjaExp then
        data.afterLoading = c.AfterLoading.mainScene
        data.win = "NinjaExpWin"
    elseif self.data.fightStatus == c.FightStatus.runePlay then
        data.levelId = self.data.levelId
    elseif self.data.fightStatus == c.FightStatus.plotStep then
        data.win = "PlotStepWin"
        data.isWin = self.data.isWin
    elseif self.data.fightStatus == c.FightStatus.plotBoss then
        data.win = "PlotBossWin"
    end

    --最后一次体验获取最终奖励之后去除
    local inLastTrial = SpeCardModel:getInLastTrial()
    if inLastTrial then
        SpeCardModel:setInLastTrial(false)
    end
    self:getApp():enterScene("LoadingScene", data)
end

function GameScene:skipBattle()
    ViewController.new(nil)
    BattleController.autoFight[c.UnitGroup.ATTACKER] = true
    BattleController.autoFight[c.UnitGroup.DEFENDER] = true
    BattleController.canFreezing[c.UnitGroup.ATTACKER] = true
    BattleController.canFreezing[c.UnitGroup.DEFENDER] = true
    while true do
        BattleController.update(c.FRAME_TIME)
        local state = BattleController.state
        if state == c.GameState.NONE then
            BattleController.start()
        elseif state == c.GameState.NEXT_WAVE then
            BattleController.updateNextWave()
            BattleController.start()
        elseif state == c.GameState.ATTACK_WIN or state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
            self:setGameState(state)
            break
        end
    end
end

function GameScene:setBattleSpeed(speed)
    self.speed = speed

    if self.speed > 2 then
        AudioManager.effectStatus = false
    else
        AudioManager.effectStatus = true
    end
end

function GameScene:updateRoleCards()
    local roleNode = self.resourceNode_:getChildByName("node_cb"):getChildByName("roleNode")
    roleNode:removeAllChildren()

    -- 卡牌按钮
    local idx = 0
    self.cards = {}
    for _, unit in pairs(BattleController.units) do
        if unit.group == c.UnitGroup.ATTACKER then
            idx = idx + 1
            local card = UnitCard.new(unit.uid, BattleController.atkCnt, idx, unit.order, self.uiScale)
            roleNode:addChild(card)
            self.cards[unit.order] = card

            if self.data.fightStatus == c.FightStatus.ninjaExp then
                card:setVisible(false)
            end
        end
    end
end

function GameScene:startGame()
    self.time = 0
    BattleController.initializeUnits()

    self:refreshFightSequenceHead()

    self:updateRoleCards()

    self:onUpdate(function(dt)
        if self.freezeCnt > 0 then
            self.freezeCnt = self.freezeCnt - 1
            return
        end
        for idx = 1, self.speed do
            if self.data.isReplay then
                self.time = self.time + dt
                while self.time >= 0.016 do
                    BattleController.update(0.016)
                    self.time = self.time - 0.016
                end
            else
                BattleController.update(dt)
            end
        end
    end)

    local uidGroups = {[c.UnitGroup.ATTACKER] = {},[c.UnitGroup.DEFENDER] = {}}
    for _, unit in pairs(BattleController.units) do
        table.insert(uidGroups[unit.group],unit.uid)
    end

    self:playBattleVideo(function()
        self:showAppear(uidGroups,function()
            BattleController.start()
        end)
        self:updateTurn()
    end)
end

-- function GameScene:initialView()
function GameScene:showWithScene()
    GameScene.super.showWithScene(self)
    local level = PlayerModel and PlayerModel.info and PlayerModel.info.level or 0
    local rect = self.bg:getBoundingBox()
    if rect.width < display.width then
        self.bg:setScale(display.width/rect.width)
    end

    if self.data.dialog and self.data.dialog ~= 0 then
        for _,child in pairs(self.resourceNode_:getChildren()) do
            if child:getName() ~= "heroNode" then
                child:setVisible(false)
            end
        end
        self:openWin("DuplicateDialogWin",self.data.dialog,function()
            for _,child in pairs(self.resourceNode_:getChildren()) do
                if child:getName() == "kamiNode" then
                    if level >= openConf[10].p2 then
                        child:setVisible(true)
                    end
                else
                    child:setVisible(true)
                end
            end
            self:startGame()
        end)
    else
        self:startGame()
    end
    if self.data.fightStatus and self.data.fightStatus ~= c.FightStatus.debug then---技能预览不开启新手
        if self.data.fightStatus ~= c.FightStatus.specialLevel then
            -----2倍加速引导
            local doubleSpeedup = PlayerConfig.getSetting(PlayerModel.info.userId .. "doubleSpeedup", nil)
            if not doubleSpeedup and (level >= 12) then 
                GuideManager.newbieStep = 10001
            end
            -----4倍加速引导
            local buyWeek = SpeCardModel:hasCardEffect("honor")
            local firstFightSpeedup = PlayerConfig.getSetting(PlayerModel.info.userId .. "firstFightSpeedup", nil)
            if not firstFightSpeedup and buyWeek then
                GuideManager.newbieStep = 8001
            end
            ---自动战斗引导
            if Helper.getOpenState(7, true) then
                local autoFightStep = PlayerConfig.getSetting(PlayerModel.info.userId .. "autoFightStep",nil)
                if not autoFightStep or tonumber(autoFightStep) < 4004 then
                    GuideManager.newbieStep = 4001
                end
            else
                local tColor = cc.c3b(171,171,171)
                self.resourceNode_:getChildByName("node_rb"):getChildByName("autoLight"):setColor(tColor)
                self.resourceNode_:getChildByName("node_rb"):getChildByName("autoBtn"):setColor(tColor)
                self.resourceNode_:getChildByName("node_rb"):getChildByName("autoText"):setColor(tColor)
            end
        end

        GuideManager.startGuide(self)
    end
end

function GameScene:showCombo(group, time)
    local preTime = self.comboInfo[group].time
    local cnt = self.comboInfo[group].cnt

    if math.abs(time - preTime) > globalBattleConf[1].caromSec then
        self.comboInfo[group].cnt = 1
    else
        cnt = cnt + 1
        self.comboInfo[group].cnt = cnt

        if cnt > 1 then
            self:updateComboSprite(group, cnt)
        end
    end

    self.comboInfo[group].time = time
end

function GameScene:updateComboSprite(group, cnt)
    local sprite = nil

    if not self.comboNode[group] then
        sprite = display.newSprite("fight/fight_slat_17.png")

        if group == c.UnitGroup.ATTACKER then
            sprite:setPosition(80, display.height * 0.7)
        else
            sprite:setPosition(display.width - 35, display.height * 0.7)
        end

        self:addChild(sprite)
        self.comboNode[group] = sprite

        if group == c.UnitGroup.DEFENDER then
            sprite:setVisible(false)
        end
    else
        sprite = self.comboNode[group]
    end

    sprite:stopAllActions()
    sprite:removeAllChildren()
    local png = string.format("fight/fight_slat_%d.png", math.random(17, 20))
    sprite:setTexture(png)

    local size = sprite:getContentSize()

    local number = self:createNumber(cnt, "crit")
    local y = 35
    local scale = 1
    if cnt >= 100 then
        scale = 1.3
    elseif cnt >= 30 then
        scale = 1.15
    end

    local combo = nil

    if group == c.UnitGroup.ATTACKER then
        number:align(display.LEFT_BOTTOM, 65, y)
            :addTo(sprite, 1)
            :setScale(0.8 * scale)

        combo = display.newSprite("fightNum/fightnum_combo_01.png")
        combo:align(display.LEFT_BOTTOM, number:getPositionX() + number:getContentSize().width * number:getScale(), y)
            :addTo(sprite, 1)
            :setScale(0.7 * scale)
    else
        combo = display.newSprite("fightNum/fightnum_combo_01.png")
        combo:align(display.RIGHT_BOTTOM, sprite:getContentSize().width - 110, y)
            :addTo(sprite, 1)
            :setScale(0.7 * scale)

        number:align(display.RIGHT_BOTTOM, combo:getPositionX() - combo:getContentSize().width * combo:getScale(), y)
            :addTo(sprite, 1)
            :setScale(0.8 * scale)
    end

    local rect = number:getBoundingBox()
    local w = rect.width + combo:getBoundingBox().width
    local pos = cc.p(rect.x + w * 0.5, rect.y + rect.height/2)

    if cnt >= 100 then
        local anim = SpineManager.createAnimation("public/ui_lianji_huo", 1)
        anim:playAnimation("idle", -1)
        anim:setPosition(pos)
        anim:setScale(scale)
        sprite:addChild(anim)
    end

    if cnt >= 30 then
        local anim = SpineManager.createAnimation("public/ui_lianji_dian", 1)
        anim:playAnimation("idle", -1)
        anim:setPosition(pos)
        sprite:addChild(anim, 2)
    end

    sprite:setCascadeOpacityEnabled(true)

    local scale_a = 1
    local scale_b = 1.3
    sprite:setScale(scale_a)
    sprite:setOpacity(255)
    sprite:runAction(
        cc.Sequence:create(
            cc.ScaleTo:create(0.1, scale_b),
            cc.ScaleTo:create(0.1, scale_a),
            cc.DelayTime:create(1),
            cc.FadeOut:create(0.5)
        )
    )
end

function GameScene:createNumber(number, nType, isSuck)
    local node = cc.Node:create()
    local format = "fightNum/fightnum_%s_%02d.png"

    local digits = {}

    while number > 0 do
        digits[#digits + 1] = number % 10
        number = math.floor(number / 10)
    end

    if #digits == 0 then
        digits[#digits + 1] = 0
    end

    local x, y = 0, 0
    local offset = 8

    if isSuck then
        local sprite = display.newSprite("fightNum/fightnum_vampire_01.png")
        display.align(sprite, display.LEFT_BOTTOM, x, 0)
        node:addChild(sprite)

        local size = sprite:getContentSize()
        x = x + size.width
        y = size.height
    end

    for idx = #digits, 1, -1 do
        local sprite = display.newSprite(string.format(format, nType, digits[idx]))
        display.align(sprite, display.LEFT_BOTTOM, x, 0)
        node:addChild(sprite)

        local size = sprite:getContentSize()
        x = x + size.width - offset
        if size.height > y then
            y = size.height
        end
    end

    node:setContentSize(cc.size(x, y))

    node:setCascadeOpacityEnabled(true)

    return node
end

function GameScene:createNumberAction(obj, uid, cr)

    if self.hpNumberCnt[uid] and self.hpNumberCnt[uid] > 0 then
        local x = obj:getPositionX()
        local y = obj:getPositionY()
        x = x + math.random(-30, 30)
        y = y + math.random(0, 40)
        obj:setPosition(x, y)
    end

    self.hpNumberCnt[uid] = self.hpNumberCnt[uid] and self.hpNumberCnt[uid] + 1 or 1


    local scale_a = cr and 0.7 or 0.5
    local scale_b = cr and 1.2 or 0.7
    obj:setScale(scale_a)
    self:addAction(
        cc.Sequence:create(
            cc.ScaleTo:create(0.1, scale_b),
            cc.ScaleTo:create(0.1, scale_a),
            cc.DelayTime:create(0.5),
            cc.FadeOut:create(0.5),
            cc.CallFunc:create(function()
                self.hpNumberCnt[uid] = self.hpNumberCnt[uid] - 1
            end),
            cc.RemoveSelf:create()
        )
    ,obj)

end

function GameScene:createActionFlash(obj,cr)
    local scale_a = cr and 1.3 or 1
    local scale_b = 3
    local time_a = 0.3
    local time_b = 1
    obj:setScale(scale_a)
    self:addAction(
        cc.Spawn:create(
            cc.MoveBy:create(time_a * 2 + time_b, cc.p(0, 70)),
            cc.Sequence:create(
                cc.ScaleTo:create(time_a, scale_b),
                cc.ScaleTo:create(time_a, scale_a),
                cc.FadeOut:create(time_b),
                cc.RemoveSelf:create()
            )
        )
    ,obj)

end

function GameScene:playBattleVideo(callback)
    local videoPath = nil
    for k,v in ipairs(self.data.battleVideo or {}) do
        if v.wave == self.waveIndex then
            videoPath = v.path
            break
        end
    end
    if videoPath then
        videoPath = "video/"..videoPath

        local layer = VideoLayer.new(videoPath,function()
            callback()
        end)
        self:addChild(layer)
    else
        callback()
    end
end

function GameScene:showAppear(uidGroups,callback)
    callback = callback or function() end
    local maxTime = 0
    local offsetTime = 0.4    

    for _,group in ipairs(uidGroups) do
        local time = 0
        for _,uid in ipairs(group) do
            local anim = self.anims[uid]
            anim:setVisible(false)
            local unit = BattleController.getUnitByUid(uid)
            local appearEffect = roleConf[unit.role].appearEffect ~= "" and (roleConf[unit.role].appearEffect) or "common_heroappear"
            local info = spineConf[anim.jsonName]
            local animName = info["appear2"] and "appear2" or "idle"

            self:addAction(
                cc.Sequence:create(
                    cc.DelayTime:create(time),
                    cc.CallFunc:create(function()
                        if animName == "appear2" then
                            anim:playAnimation(animName, 1)
                        else
                            anim:playAnimation("idle", -1)
                        end

                        -- 出场特效
                        local commonAnim = SpineManager.createAnimation("spine/effect/" .. appearEffect,nil , true)
                        commonAnim:playAnimation("idle", 1)
                        commonAnim:setPosition(anim:getPosition())
                        self.resourceNode_:getChildByName("heroNode"):addChild(commonAnim, fightZOrder.anim_powermax)

                        commonAnim:addLuaHandler(function(eventName, animName, intValue, floatValue)
                            if eventName == "trigger" then
                                anim:setVisible(true)
                            elseif eventName == "duang_start" then
                                if intValue then
                                    self:startShake(intValue)
                                end
                            elseif eventName == "duang_end" then
                                self:stopShake()
                            end
                        end)

                        local visible = true
                        for _, value in pairs(spineConf[appearEffect]["idle"].events) do
                            if value.name == "trigger" then
                                visible = false
                                break
                            end
                        end
                        anim:setVisible(visible)

                        self.effects[#self.effects + 1] = commonAnim
                    end)
                )
            ,self)
            
            local t = time + math.max(info[animName].totalTime, spineConf[appearEffect]["idle"].totalTime or 0)
            if t > maxTime then
                maxTime = t
            end

            time = time + offsetTime
        end
    end

    self:addAction(
        cc.Sequence:create(
            cc.DelayTime:create(maxTime),
            cc.CallFunc:create(callback)
        )
    ,self)

end

function GameScene:updateHpDelta(uid, delta, cr, updateType, state)

    -- 暴击定屏4帧，受击定屏2帧
    if cr then
        self.freezeCnt = math.max(self.freezeCnt, 4)
    else
        self.freezeCnt = math.max(self.freezeCnt, 4)
    end

    local nType = nil
    local anim = self.anims[uid]
    if delta > 0 then
        nType = "life"
    elseif delta < 0 then
        if cr then
            nType = "crit"
        else
            nType = "damage"
        end

        local unit = BattleController.getUnitByUid(uid)
        if unit:isAlive() then
            anim:registerAnimation("hit",1)
        end
    else
        return
    end

    local isSuck = (updateType == c.UpdateHpType.SUCK_MARKER or updateType == c.UpdateHpType.LIFE_PER_HIT)
    local label = self:createNumber(math.ceil(math.abs(delta)), nType, isSuck)

    local pos = anim:getBonePosition("hp_point")
    pos.y = pos.y + 20
    if self.data.fightStatus == c.FightStatus.worldBoss then
        local unit = BattleController.getUnitByUid(uid)
        if unit and unit.group == c.UnitGroup.DEFENDER then
            pos.y = pos.y - 100
        end
    end
    label:setAnchorPoint(cc.p(0.5, 0.5))
    label:setPosition(pos)
    self.resourceNode_:getChildByName("heroNode"):addChild(label, fightZOrder.bullet)


    self:createNumberAction(label, uid, cr)

end

function GameScene:updateRound(round, maxRound)
    local node = self.topNode:getChildByName("node")
    if node:getChildByName("leftText") and node:getChildByName("rightText") then
        if maxRound - round <= 5 then
            node:getChildByName("leftText"):runAction(cc.Sequence:create(
                cc.ScaleTo:create(0.1,2)
            ))
            node:getChildByName("leftText"):setColor(cc.c3b(255,0,0))
        else
            node:getChildByName("leftText"):setColor(cc.c3b(255,255,255))
        end
        node:getChildByName("leftText"):setString(round)
        node:getChildByName("rightText"):setString("/" .. maxRound)

        node:getChildByName("leftText"):runAction(cc.Sequence:create(
            cc.DelayTime:create(0.1),
            cc.ScaleTo:create(0.2,1)
        ))
    end
end

function GameScene:updateTurn()
    -- 更新第几波
    local curTurn = BattleController.defWaveCnt
    local maxTurn = #BattleController.defenders

    local anim = SpineManager.createAnimation("public/ui_battle_huihe", 1)
    anim:playAnimation("idle", 1)
    anim:setAutoRemove(true)
    self:addChild(anim)

    anim:addChildFollowSlot("point_1", display.newSprite("fight/fight_num_0" .. maxTurn .. ".png"))
    anim:addChildFollowSlot("point_2", display.newSprite("fight/fight_num_0" .. curTurn .. ".png"))

    local text = self.topNode:getChildByName("node"):getChildByName("turnText")
    if text then
        text:setString(curTurn .. "/" .. maxTurn)
    end
end

function GameScene:updateHp(uid, curHp, totalHp)
    local anim = self.anims[uid]
    local hpNode = anim:getChildFollowBone("hp_point")
    hpNode:getChildByName("hpBar"):setPercent((curHp / totalHp) * 100.0)

    --BOSS  更新顶部血条
    if self.data.fightStatus == c.FightStatus.wantedOrdinary or
        self.data.fightStatus == c.FightStatus.wantedComplete or
        self.data.fightStatus == c.FightStatus.guildBoss or 
        self.data.fightStatus == c.FightStatus.worldBoss or
        self.data.fightStatus == c.FightStatus.plotBoss or
        (self.data.monsterId and self.data.fightStatus == c.FightStatus.actTimeChallenge) or
        self.bossTop then
        
        local unit = BattleController.getUnitByUid(uid)
        if unit.group == c.UnitGroup.DEFENDER then
            local bossBar = self.topNode:getChildByName("node_normal"):getChildByName("bossBar")

            local bloodCount = monsterConf[self.data.monsterId].bloodCount
            local perTotalHp = totalHp / bloodCount
            --print("++++++updateHp+++++++",totalHp,bloodCount)
            local curBloodIdx = math.ceil(curHp / perTotalHp)
            if curHp <= 0 or curBloodIdx == 0 then
                curBloodIdx = 1
            elseif curBloodIdx > bloodCount then
                curBloodIdx = bloodCount
            end

            local cntStr = ""
            local nextBossBar = self.topNode:getChildByName("node_normal"):getChildByName("nextBossBar")
            nextBossBar:setVisible(false)
            if curBloodIdx > 1 then
                cntStr = "x"..curBloodIdx
                nextBossBar:setVisible(true)
                nextBossBar:setSpriteFrame(Helper.getBossBarPath(curBloodIdx - 1))
            end

            self.topNode:getChildByName("node_normal"):getChildByName("bloodCntText"):setString(cntStr)
            
            local path = Helper.getBossBarPath(curBloodIdx)
            bossBar:loadTexture(path,ccui.TextureResType.plistType)    

            local percent = 100 * (curHp - (curBloodIdx - 1) * perTotalHp) / perTotalHp
            bossBar:setPercent(percent)

            local barLightX = bossBar:getPositionX()
            if percent > 0 then
                local width = bossBar:getContentSize().width
                barLightX = barLightX - width * percent / 100 - 3
            end
            self.topNode:getChildByName("node_normal"):getChildByName("barLight"):setPositionX(barLightX)
        end
    end
end

function GameScene:updateKamiEnergy(group, curEnergy, totalEnergy)
    if group == c.UnitGroup.ATTACKER then
        local progress = self.resourceNode_:getChildByName("kamiNode"):getChildByName("loadingBar")
        progress:setPercent((curEnergy / totalEnergy) * 100.0)

        local enable = curEnergy >= totalEnergy

        if enable ~= self.kamiButton.enabled then
            self.kamiButton:setEnabled(enable)

            if enable then
                self.kamiButton:setNormal()
            else
                self.kamiButton:setGray()
            end
        end
    end
end

function GameScene:updateEnergy(uid, curEnergy, totalEnergy)
    local anim = self.anims[uid]
    
    if not anim then
        return
    end

    local hpNode = anim:getChildFollowBone("hp_point")
    hpNode:getChildByName("energyBar"):setPercent((curEnergy / totalEnergy) * 100.0)
end

function GameScene:autoUsePowermaxSkill(unit)
    if unit.order == 6 then--幻化神
        return
    end

    local unitCard = self.cards[unit.order]
    if unitCard and unitCard then
        unitCard:playUseEffect()
    end
end

function GameScene:updateAnim(uid, dt)
    local anim = self.anims[uid] or self.kamis[uid] or self.gods[uid]
    anim:update(dt)
    anim:updateAction(dt)
end

function GameScene:setUnitState(uid, state)
    local anim = self.anims[uid]
    anim:clearAction()
    local unit = BattleController.getUnitByUid(uid)
    local zOrder = fightZOrder.pos_height - anim:getPositionY()
    -- anim:setLocalZOrder(unit.order) 

    if state == c.UnitState.IDLE then
        local animName = BuffController.getIdleAction(uid)
        anim:playAnimation(animName, -1)

        anim:setPosition(anim.startPos)
    elseif state == c.UnitState.DIE then
        anim:getChildFollowBone("hp_point"):setVisible(false)
        anim:playAnimation("die", 1)
        if roleConf[unit.role].deathEffect ~= "" then
            local deathAnim = SpineManager.createAnimation("spine/effect/" .. roleConf[unit.role].deathEffect)
            deathAnim:playAnimation("idle", 1)
            anim:addChild(deathAnim)
            --self.effects[#self.effects + 1] = deathAnim --死亡特效没有加速
        end
    elseif state == c.UnitState.REMOVED then
        anim:getChildFollowBone("hp_point"):setVisible(false)
        anim:addAction(
            cc.Sequence:create(
                cc.FadeOut:create(0.5),
                cc.CallFunc:create(function(sender)
                    sender:setVisible(false)
                end)
            )
        )
    elseif state == c.UnitState.REBORN then
        -- 隐藏血条
        anim:getChildFollowBone("hp_point"):setVisible(false)
        anim:playAnimation("idle", 1) --skill_b
    end

    anim:setLocalZOrder(zOrder)
end

--反击飘字
function GameScene:counterattack(uid)
    local label = UILabel.new({
        text = WordDictionary[10004],
        color = specialBuffColor,
        back = cc.c3b(0,0,0),
        size = 25,
    })

    local anim = self.anims[uid]
    local pos = anim:getBonePosition("hp_point")
    pos.y = pos.y - 80
    label:setAnchorPoint(cc.p(0.5, 0.5))
    label:setPosition(pos)
    self.resourceNode_:getChildByName("heroNode"):addChild(label, fightZOrder.bullet)

    self:createActionFlash(label)
end

function GameScene:kamiVideo(fileName, kamiId)
    if not ccexp.VideoPlayer then
        return
    end

    local fightVideo = PlayerConfig.getSetting("fightVideo",1)
    if fightVideo ~= 1 then
        return
    end

    -- local layer = cc.LayerColor:create(cc.c4b(0, 0, 0, 255))
    local file = "video/" .. (fileName ~= "" and fileName or "kami_skill_light") .. ".mp4"
    local layer = VideoLayer.new(file,function()
        local kami = BattleController.getKamiByUid(kamiId)
        kami:completeVideo()
    end)

    if Helper.getOpenState(7, true) then
        layer:showTips(WordDictionary[21320])
    end

    self:addChild(layer)
    self.videoLayer = layer

    layer:setOpacity(0)
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(true)
    listener:registerScriptHandler(function() end, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(function() end, cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(function() end, cc.Handler.EVENT_TOUCH_ENDED)
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, layer)

    layer:runAction(cc.FadeIn:create(0.5))

    return true
end

function GameScene:kamiUseSkill(uid, skillId)
    local anim = self.kamis[uid]
    local name = skillConf[skillId].skillAnim
    anim:playAnimation(name, 1)

    -- 蓄力特效
    local effectName = skillConf[skillId].chargeJsonName
    if effectName ~= "" then
        effectName = "spine/effect/"..effectName
        assert(cc.FileUtils:getInstance():isFileExist(effectName .. "/skeleton.json"), "skillId : " .. skillId .. ", chargeJsonName : " .. effectName .. " not exist")

        local effect = SpineManager.createAnimation(effectName, nil, true)
        anim:addChild(effect,-1)
        -- effect:setPosition(anim:getPosition())
        -- self.resourceNode_:getChildByName("heroNode"):addChild(effect,display.height+1)
        effect:playAnimation("idle", 1)

        self.effects[#self.effects + 1] = effect
    end
end

function GameScene:setKamiState(uid, state)
    local kami = self.kamis[uid]
    if not self.starrySkys then
        self.starrySkys = {}
    end
    if state == c.UnitState.IDLE then
        kami:setVisible(false)
        kami:playAnimation("idle", -1)
    elseif state == c.UnitState.KAMI_APPEAR then
        kami:stopAnimation()
        kami:setVisible(true)
        kami:setOpacity(255)
        kami:playAnimation("appear", 1)

        -- 星空背景淡入
        local kami = BattleController.getKamiByUid(uid)
        local bg = ghostSkinConf[kami.skin].ghostBack
        local bgPath = "battleBackground/" .. bg .. ".png"
        local isExist = cc.FileUtils:getInstance():isFileExist(bgPath)
        if not isExist then
            bgPath = "battleBackground/ghostBack_01.png"
        end
        local background = display.newSprite(bgPath)
        background:setScale(self.bgScale)
        display.align(background, display.CENTER, display.cx, display.cy)
        -- self.resourceNode_:getChildByName("heroNode"):addChild(background, fightZOrder.kami - 1)
        self.resourceNode_:getChildByName("heroNode"):addChild(background, fightZOrder.bg + 1)
        self.starrySkys[uid] = background

        local sp = SpineManager.createAnimation("spine/background/" .. ghostSkinConf[kami.skin].backgroundEffect, 1)
        sp:playAnimation("idle", -1)
        sp:setPosition(background:getContentSize().width * 0.5,background:getContentSize().height * 0.5)
        background:addChild(sp)
        background:setCascadeOpacityEnabled(true)

        background:setOpacity(0)
        self:addAction(cc.FadeIn:create(1.5), background)

        for _, unit in pairs(BattleController.units) do
            if unit:isAlive() and unit.group ~= kami.group then
                local anim = self.anims[unit.uid]
                anim:setLocalZOrder(fightZOrder.kami + fightZOrder.pos_height - anim:getPositionY())
            end
        end
        AudioManager.playEffect("music/".. kami.skill.attr.kamiSound ..".mp3")
    elseif state == c.UnitState.DIE then
        kami:playAnimation("die", 1)

        self:addAction(cc.Sequence:create(
            cc.FadeOut:create(1),
            cc.RemoveSelf:create()
        ), self.starrySkys[uid])

        for _, unit in pairs(BattleController.units) do
            if unit.group ~= kami.group then
                local anim = self.anims[unit.uid]
                if anim then
                    anim:setLocalZOrder(fightZOrder.pos_height - anim:getPositionY())
                end
            end
        end
    end
end

function GameScene:hideKami(uid)
    local kami = self.kamis[uid]
    kami:playAnimation("die", 1)
    kami:runAction(cc.FadeOut:create(0.2))
    if self.starrySkys[uid] then
        self.starrySkys[uid]:runAction(cc.FadeOut:create(0.2))
    end

    for _, unit in pairs(BattleController.units) do
        if unit.group ~= kami.group then
            local anim = self.anims[unit.uid]
            if anim then
                anim:setLocalZOrder(fightZOrder.pos_height - anim:getPositionY())
            end
        end
    end
end

function GameScene:godSkillReviveMissed(uid, group)
    local pos = nil
    if group == c.UnitGroup.ATTACKER then
        pos = cc.p(display.width/4, (display.height/4)*3)
    else
        pos = cc.p((display.width/4)*3, (display.height/4)*3)
    end
    MoveLabel.new(WordDictionary[10155], {pos = pos})
end

function GameScene:godUseSkill(uid, skillId)
    local anim = self.gods[uid]
    local name = skillConf[skillId].skillAnim
    local god = BattleController.getGodByUid(uid)
    local factor = (god.group == c.UnitGroup.DEFENDER) and -1 or 1
    anim:setScaleX(factor * math.abs(anim:getScaleX()))
    anim:setVisible(true)
    anim:playAnimation(name, 1)

    -- 蓄力特效
    local effectName = skillConf[skillId].chargeJsonName
    if effectName ~= "" then
        effectName = "spine/effect/"..effectName
        assert(cc.FileUtils:getInstance():isFileExist(effectName .. "/skeleton.json"), "skillId : " .. skillId .. ", chargeJsonName : " .. effectName .. " not exist")

        local effect = SpineManager.createAnimation(effectName, nil, true)
        anim:addChild(effect,-1)
        -- effect:setPosition(anim:getPosition())
        -- self.resourceNode_:getChildByName("heroNode"):addChild(effect,display.height+1)
        effect:playAnimation("idle", 1)

        self.effects[#self.effects + 1] = effect
    end
end

function GameScene:setGodState(uid, state)
    local god = self.gods[uid]

    if state == c.UnitState.IDLE then
        god:setVisible(false)
    end
end

function GameScene:unitUseSkill(uid, skillId)
    local anim = self.anims[uid]
    local name = skillConf[skillId].skillAnim
    anim:playAnimation(name, 1)

    -- 蓄力特效
    local effectName = skillConf[skillId].chargeJsonName
    if effectName ~= "" then
        effectName = "spine/effect/"..effectName
        assert(cc.FileUtils:getInstance():isFileExist(effectName .. "/skeleton.json"), "skillId : " .. skillId .. ", chargeJsonName : " .. effectName .. " not exist")

        local effect = SpineManager.createAnimation(effectName, nil, true)
        anim:addChild(effect)
        -- effect:setPosition(anim:getPosition())
        -- self.resourceNode_:getChildByName("heroNode"):addChild(effect,display.height+1)
        effect:playAnimation("idle", 1)

        self.effects[#self.effects + 1] = effect
    end

    -- 大招特效
    if skillConf[skillId].skillType == c.SkillType.POWERMAX then
        local effect = SpineManager.createAnimation("spine/effect/common_manualskill", nil, true)
        effect:setScaleX(anim:getScaleX())
        effect:setPosition(anim:getBonePosition("hit_point"))
        self.resourceNode_:getChildByName("heroNode"):addChild(effect, fightZOrder.anim_powermax)
        effect:playAnimation("idle", 1)

        self.effects[#self.effects + 1] = effect
    end
end

function GameScene:unitMoveBack(uid, duration)
    local anim = self.anims[uid]
    local action = cc.MoveTo:create(duration, anim.startPos)
    local unit = BattleController.getUnitByUid(uid)
    local jsonName = roleConf[unit.role].spine
    if spineConf[jsonName].jump then
        -- anim:setPlayBackwardsEnabled(true)
        anim:playAnimation("jump")

    end
    anim:addAction(action)
end

function GameScene:unitMoveTowards(uid, skillId, targetUids, duration)
    local conf = skillConf[skillId]
    local anim = self.anims[uid]
    local x, y
    local offset
    local targetGroup
    for _, uid in pairs(targetUids) do
        targetGroup = BattleController.getUnitByUid(uid).group
        break
    end

    if conf.distance == 1 then -- 远程
        return
    elseif conf.distance == 2 then -- 近程单体
        local targetAnim = self.anims[targetUids[1]]
        x, y = targetAnim:getPosition()

        offset = 130
    elseif conf.distance == 3 then -- 近程群体
        local minX, maxX, minY, maxY
        for _, uid in pairs(targetUids) do
            local px, py = self.anims[uid].startPos.x,self.anims[uid].startPos.y
            if minX == nil or minX > px then
                minX = px
            end

            if maxX == nil or maxX < px then
                maxX = px
            end

            if minY == nil or minY > py then
                minY = py
            end

            if maxY == nil or maxY < py then
                maxY = py
            end
        end

        x = (targetGroup == c.UnitGroup.DEFENDER) and minX or maxX
        y = (minY + maxY) / 2

        offset = 190
    elseif conf.distance == 4 then -- 屏幕中间
        x = display.cx
        y = 278
        offset = 0
    end

    if targetGroup == c.UnitGroup.DEFENDER then
        offset = -1 * offset
    end

    local action = cc.MoveTo:create(duration, cc.p(x + offset, y))
    anim:addAction(action)

    local unit = BattleController.getUnitByUid(uid)
    local jsonName = roleConf[unit.role].spine
    if spineConf[jsonName].jump then
        anim:playAnimation("jump")
    end
end

function GameScene:bulletFly(bulletUid, attackUid, targetUids, trigger)
    if trigger.jsonName == nil or trigger.jsonName == "" or #targetUids <= 0 then
        return
    end

    local anim = self.anims[attackUid]
    local bullet = BulletAnim.new(trigger.jsonName)

    local pos = nil

    if trigger.defenderUid then
        local defender = self.anims[trigger.defenderUid]
        if defender then
            pos = defender:getBonePosition("bullet")
        end
    end

    if pos == nil then
        pos = anim:getBonePosition("bullet")
    end

    bullet:setPosition(pos)
    bullet:setScaleX(anim:getScaleX())
    self.resourceNode_:getChildByName("heroNode"):addChild(bullet, fightZOrder.bullet)

    local targetAnim = self.anims[targetUids[1]]
    local targetPos = targetAnim:getBonePosition("hit_point")

    local action = nil

    if trigger.bulletRoute == "missile" then
        local x = bullet:getPositionX() + math.random(-80, 80)
        local y = bullet:getPositionY() + math.random(0, 120)
        bullet:setPosition(x, y)

        action = cc.Sequence:create(
            cc.DelayTime:create(trigger.duration * 2 / 3.0),
            cc.MoveTo:create(trigger.duration / 3.0, targetPos)
        )
    elseif trigger.bulletRoute == "parabola" then
        local y = bullet:getPositionY()
        if targetPos.y > y then
            y = targetPos.y
        end

        --[[
        local bezier2 = ccBezierConfig()
        bezier2.controlPoint_1 = cc.p(100, size.height / 2)
        bezier2.controlPoint_2 = cc.p(200, - size.height / 2)
        bezier2.endPosition = cc.p(240, 160)
        ]]--
        local bezier ={
            cc.p(bullet:getPositionX(), y + 100),
            cc.p(targetPos.x, y + 50),
            cc.p(targetPos.x, targetPos.y),
        }

        action = cc.BezierTo:create(trigger.duration, bezier)
    else
        action = cc.MoveTo:create(trigger.duration, targetPos)
    end
    
    bullet:addAction(action)

    self.bullets[bulletUid] = bullet
end

function GameScene:bulletEffect(bulletUid, attackUid, jsonName)
    if jsonName == nil or jsonName == "" then
        return
    end

    local anim = self.anims[attackUid] or self.kamis[attackUid]
    local bullet = BulletAnim.new(jsonName)
    bullet:setPosition(anim:getPosition())
    bullet:setScaleX(anim:getScaleX())
    self.resourceNode_:getChildByName("heroNode"):addChild(bullet, fightZOrder.bullet)

    self.bullets[bulletUid] = bullet
end

function GameScene:bulletHit(uid, targetUids, jsonName)
    if jsonName == nil or jsonName == "" then
        return
    end

    for _, id in pairs(targetUids) do
        local anim = self.anims[id]
        local hit = SpineManager.createAnimation("spine/effect/"..jsonName, nil , true)
        local pos = anim:getBoneLocation("hit_point")

        if self.bulletHitCnt[id] then
            self.bulletHitCnt[id] = self.bulletHitCnt[id] + 1
        else
            self.bulletHitCnt[id] = 1
        end
        hit.uid = id
        local offset = 60
        local _pos = nil
        if self.bulletHitCnt[id] == 1 then
            _pos = pos
        else
            _pos = cc.p(math.random(pos.x - offset,pos.x + offset),math.random(pos.y - offset,pos.y + offset))
        end
        hit:setPosition(_pos)
        anim:addChild(hit)
        hit:playAnimation("idle", 1)
        self.effects[#self.effects + 1] = hit

        hit:addLuaHandler(function(eventName, animName, intValue, floatValue)
            if eventName == "duang_start" then
                if intValue then
                    self:startShake(intValue)
                end
            elseif eventName == "duang_end" then
                self:stopShake()
            end
        end)
    end
end

function GameScene:updateBullet(bulletUid, dt)
    local bullet = self.bullets[bulletUid]
    if bullet then
        bullet:updateAnim(dt)
    end
end

function GameScene:removeBullet(bulletUid)
    local bullet = self.bullets[bulletUid]
    if bullet then
        bullet:removeFromParent()
        self.bullets[bulletUid] = nil
    end
end

function GameScene:updateEffects(dt)
    for idx = #self.effects, 1, -1 do
        local effect = self.effects[idx]

        if tolua.isnull(effect) then
            table.remove(self.effects, idx)
        else
            effect:update(dt)
            local uid = effect.uid
            -- boss appearEffect
            if effect.spineEvents then
                effect.dt = effect.dt + dt

                for i = #effect.spineEvents, 1, -1 do
                    local event = effect.spineEvents[i]
                    if event.time <= effect.dt then
                        if effect.onEvent then
                            effect.onEvent(event)
                        end
                        table.remove(effect.spineEvents, i)
                    else
                        break
                    end
                end
            end

            if effect:isComplete() then
                if uid and self.bulletHitCnt[uid] then
                    self.bulletHitCnt[uid] = self.bulletHitCnt[uid] - 1
                end
                effect:removeFromParent()
                table.remove(self.effects, idx)
            end
        end
    end

    for _, info in pairs(self.buffEffects) do
        local buff = info.effect
        -- if buff.uid then
            buff:update(dt)
            local anim = self.anims[buff.uid]
            if anim then
                buff:setPosition(anim:getBoneLocation(buff.boneName))
            end
        -- end
    end

    -- actions
    for idx = #self.actions, 1, -1 do
        local action = self.actions[idx]
        if action:getTarget() and not tolua.isnull(action:getTarget()) then
            action:step(dt)
            if action:isDone() then
                action:release()
                table.remove(self.actions, idx)
            end
        else
            action:release()
            table.remove(self.actions, idx)
        end
    end

    -- 震屏
    if self.swing then
        local shakeDt = (1.0 / 30)
        self.swingDt = self.swingDt + dt

        if self.swingDt >= shakeDt then
            self.swingDt = self.swingDt - shakeDt
            local gameLayer = self.resourceNode_:getChildByName("heroNode")
            local y = gameLayer:getPositionY()
            if y < 0 then
                y = 0
            else
                y = self.swing
            end
            gameLayer:setPositionY(y)
        end
    end

    for _, card in pairs(self.cards) do
        card:update()
    end
end

function GameScene:startShake(swing)
    self.swing =  -1 * (3 * swing)
end

function GameScene:stopShake()
    self.swing = nil
    self.swingDt = 0
    self.resourceNode_:getChildByName("heroNode"):setPositionY(0)
end

function GameScene:addBuff(buff)
    local buffData = buffConf[buff.id]
    local jsonName = buffData.continuedJson
    local boneName = buffData.position

    if jsonName ~= "" and boneName ~= "" then
        -- 英雄身上多个相同的buff只显示一个特效
        local key = buff.owner.uid .. "_" .. buff.id

        if self.buffEffects[key] == nil then
            local anim = self.anims[buff.owner.uid]

            local effect = SpineManager.createAnimation("spine/effect/"..jsonName, nil, true)
            effect:setPosition(anim:getBoneLocation(boneName))
            effect:playAnimation("idle", -1)
            if boneName == "hp_point" then
                effect:setPositionY(effect:getPositionY() - 20)
            end

            anim:addChild(effect)

            effect.uid = buff.owner.uid
            effect.boneName = boneName
            self.buffEffects[key] = {cnt = 1, effect = effect}
        else
            self.buffEffects[key].cnt = self.buffEffects[key].cnt + 1
        end
    end

    local anim = self.anims[buff.owner.uid]
    local pos = anim:getBonePosition("hp_point")
    pos.y = pos.y -80
    local color = nil
    if buffData.buffType == 1 then
        color = buffColor
    else
        color = debuffColor
    end
    if buffData.name and buffData.name ~= "" then
        local label = UILabel.new({
            text = buffData.name,
            color = color,
            back = cc.c3b(0,0,0),
            size = 25,
        })

        label:setAnchorPoint(cc.p(0.5, 0.5))
        label:setName("buffLabel")
        if self.resourceNode_:getChildByName("heroNode"):getChildByName("buffLabel") then
            pos.y = pos.y - 25
        end
        label:setPosition(pos)
        self.resourceNode_:getChildByName("heroNode"):addChild(label, fightZOrder.bullet)

        self:createActionFlash(label)
    end

    if buffData.showLayer ~= "" then
        local buffCnt = UILabel.new({
            text = string.format(buffData.showLayer, BuffController.getBuffCnt(buff.owner.uid, buffData.Id)),
            color = color,
            back = cc.c3b(0,0,0),
            size = 20,
        })

        buffCnt:setAnchorPoint(cc.p(0.5, 0.5))
        buffCnt:setName("buffLabel")
        if self.resourceNode_:getChildByName("heroNode"):getChildByName("buffLabel") then
            pos.y = pos.y - 25
        end
        buffCnt:setPosition(pos)
        self.resourceNode_:getChildByName("heroNode"):addChild(buffCnt, fightZOrder.bullet)
        self:createActionFlash(buffCnt)
    end

end

function GameScene:removeBuff(buff)
    local key = buff.owner.uid .. "_" .. buff.id
    local info = self.buffEffects[key]

    if info and info.cnt > 0 then
        local cnt = info.cnt - 1
        self.buffEffects[key].cnt = cnt

        if cnt == 0 then
            if not tolua.isnull(info.effect) then
                info.effect:removeFromParent()
            end
            self.buffEffects[key] = nil
        end
    end
end

function GameScene:updateControlBuff(uid)
    local unit = BattleController.getUnitByUid(uid)
    if unit:isAlive() then
        local anim = self.anims[uid]
        local animName = BuffController.getIdleAction(uid)
        anim:playAnimation(animName, -1)
    end
end

function GameScene:unitHitEffect(uids,animName)
    for _, uid in pairs(uids) do
        local unit = BattleController.getUnitByUid(uid)
        
        local unitState = unit.state
        local isNotAttack = unitState ~= c.UnitState.ATTACK and unitState ~= c.UnitState.EXTRA_ATTACK and unitState ~= c.UnitState.DEATH_ATTACK
        if unit:isAlive() and isNotAttack then
            local anim = self.anims[uid]
            anim:registerAnimation(animName, 1)
        end
    end 
end

function GameScene:setGameState(state)
    if state == c.GameState.NEXT_WAVE then
        self:nextWave()

    elseif state == c.GameState.ATTACK_WIN or state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
        if self.data.fightStatus == c.FightStatus.ordinary then
            local data = {
                LevelId = self.data.levelId,
                Team = self.team,
                Result = state,
            }
            network.tcpSend(msgids.C_WLevelFightNormal, data)

            local openResultWin = function(self, op, data)
                local func = function()
                    if op == msgids.GS_WLevelFightNormal_R then
                        if state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
                            self:openWin("ResultLoseWin",{team = self.team,levelId = self.data.levelId, afterLoading = self.data.afterLoading})
                        elseif state == c.GameState.ATTACK_WIN then
                            self:openWin("ResultVictoryWin",{rewards = data.Rewards, team = self.team, levelUp = self.levelUp, autoPushMap = self.data.autoPushMap, fightStatus = c.FightStatus.ordinary})
                        end
                        AudioManager.stopMusic()

                    elseif op == msgids.GS_PlayerUpdate_Lv and data.Level ~= -1 then
                        self.levelUp = true
                        self:runAction(cc.Sequence:create(
                            cc.DelayTime:create(3),
                            cc.CallFunc:create(function()
                                self:openWin("LevelUpWin",self.data.levelId, false)
                            end)
                        ))
                    end
                end

                if self.data.endDialog and self.data.endDialog ~= 0 and (state == c.GameState.ATTACK_WIN or state == c.GameState.COMPLETE) then
                    BattleController.pause()
                    self:openWin("DuplicateDialogWin",self.data.endDialog,function()
                        func()
                        BattleController.pause()
                    end)
                else
                    func()
                end
            end
            network.addListener(self, {msgids.GS_WLevelFightNormal_R,msgids.GS_PlayerUpdate_Lv}, handler(self, openResultWin))
        elseif self.data.fightStatus == c.FightStatus.wantedOrdinary or self.data.fightStatus == c.FightStatus.wantedComplete then
            local damage = 0

            for _, unit in pairs(BattleController.units) do
                if unit.group == c.UnitGroup.DEFENDER then
                    damage = self.data.monsterHp - unit.attr.hp
                    break
                end
            end
            if damage < 0 then
                damage = 0
            end
            damage = math.ceil(damage)
            local seed = math.random(1, 2^30)
            local key = "wasdpoqwepmmscaNiuUgASksddKsduyo"
            local sign = Crypto:MD5(seed..damage..key)
            local data = {
                FightType = self.data.fightStatus,
                Id = self.data.monsterId,
                Team = self.team,
                Dmg = damage,
                Seed = seed,
                Sign = sign,
            }
            network.tcpSend(msgids.C_WantedFight, data)

            local openResultWin = function(self, op, data)
                self:openWin("ResultBossWin",{rewards = data.Rewards,defenderTeam = self.defenderTeam,team = self.team, damage = damage})
            end
            AudioManager.stopMusic()
            network.addListener(self, {msgids.GS_WantedFight_R}, handler(self, openResultWin))
        elseif self.data.fightStatus == c.FightStatus.tower then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam, fightStatus = c.FightStatus.tower, afterLoading = self.data.afterLoading})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.towerElite then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team, afterLoading = self.data.afterLoading, star = self.data.Star})
                AudioManager.stopMusic()
            else
                self:openWin("ResultLoseWin",{team = self.team, afterLoading = self.data.afterLoading})
            end
        elseif self.data.fightStatus == c.FightStatus.dungeon then
            if state == c.GameState.ATTACK_WIN then
                local star_ = 1--胜利 最低1星
                local dieCnt = 0
                for k,v in pairs(StatisticsController.hp or {}) do
                    if k <= 5 and v <= 0 then
                        dieCnt = dieCnt + 1
                    end
                end
                local dData = dungeonConf[self.data.dungeonId] and dungeonConf[self.data.dungeonId].starTerm or nil
                for i,v in ipairs(dData or {}) do
                    if dieCnt <= v.n then
                        star_ = v.star
                        break
                    end
                end

                local data = {
                    DgId = self.data.dungeonId,
                    Team = self.team,
                    Result = star_ + 1,--发给服务器 2代表1星 依此类推
                }
                network.tcpSend(msgids.C_WLevelFightDungeon, data)

                local openResultWin = function(self, op, data)
                    self:openWin("ResultVictoryWin",{rewards = data.Rewards, team = self.team, star = star_, fightStatus = c.FightStatus.dungeon, afterLoading = self.data.afterLoading})
                    AudioManager.stopMusic()
                end
                network.addListener(self, {msgids.GS_WLevelFightDungeon_R}, handler(self, openResultWin))
            else
                self:openWin("ResultLoseWin",{team = self.team,levelId = self.data.levelId, afterLoading = self.data.afterLoading})
                AudioManager.stopMusic()
            end
            
        elseif self.data.fightStatus == c.FightStatus.timeChallenge then --- timeChallenge
            if state == c.GameState.ATTACK_WIN then
                local dieCnt = 0
                for k,v in pairs(StatisticsController.hp or {}) do
                    if k <= 5 and v <= 0 then
                        dieCnt = dieCnt + 1
                    end
                end

                local data = {
                    Id = self.data.challengeId,
                    Team = self.team,
                }
                network.tcpSend(msgids.C_TimeChallengeFight, data)

                local openResultWin = function(self, op, data)
                    self:openWin("ResultVictoryWin",{team = self.team, fightStatus = c.FightStatus.timeChallenge})
                    AudioManager.stopMusic()
                end
                network.addListener(self, {msgids.GS_TimeChallengeFight_R}, handler(self, openResultWin))
            else
                self:openWin("ResultLoseWin",{team = self.team,levelId = self.data.levelId, afterLoading = self.data.afterLoading})
                AudioManager.stopMusic()
            end
        elseif self.data.fightStatus == c.FightStatus.arena then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
                    
                if self.data.hisRankMax and self.data.hisMaxRwds and self.data.myIdx < self.data.hisRankMax then
                    self:openWin("ArenaMaxRankWin",self.data)
                end
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.mineWar then
            self:openWin("MineWarFightResultWin", {rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam , fighters = self.data.replayFighters})
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.land then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam })
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.forceLeader then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam })
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, showRewards = true, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
           elseif self.data.fightStatus == c.FightStatus.kingFight then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam })
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.guildBoss then
            self:openWin("ResultBossWin", {rewards = self.data.rewards, defenderTeam = self.defenderTeam, team = self.team, damage = self.data.curMonsterDamage,fightStatus = c.FightStatus.guildBoss, allDamageData =self.data.allDamageData, bossCurHp = self.data.curHp, bossMaxLife = self.data.maxLife })
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.actTimeChallenge then
            -- local damage = StatisticsController.getGroupDamage(c.UnitGroup.ATTACKER, true)
            -- local allDamage = damage
            self:openWin("ResultBossWin",{rewards = self.data.rewards,defenderTeam = self.defenderTeam,team = self.team, damage = self.data.curMonsterDamage, fightStatus = c.FightStatus.actTimeChallenge, allDamageData =self.data.allDamageData, bossCurHp = self.data.curHp, bossMaxLife = self.data.maxLife })
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.guildMonster then
            local damage = StatisticsController.getGroupDamage(c.UnitGroup.ATTACKER, true)
            local allDamage = self.data.damage + damage
            self:openWin("ResultBossWin",{rewards = {},defenderTeam = self.defenderTeam,team = self.team, damage = allDamage, fightStatus = c.FightStatus.guildMonster, stage = self.data.stage})
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.worldBoss then
            -- local damage = StatisticsController.getGroupDamage(c.UnitGroup.ATTACKER, true)
            self:openWin("ResultBossWin", {rewards = {}, defenderTeam = self.defenderTeam, team = self.team, damage = self.data.curMonsterDamage,fightStatus = c.FightStatus.worldBoss, allDamageData =self.data.allDamageData, bossCurHp = self.data.curHp, bossMaxLife = self.data.maxLife })
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.kfbsLadder or self.data.fightStatus == c.FightStatus.kfbsChampion then
            self:openWin("KfbsResultWin",{rewards = self.data.Rewards, team = self.team, defenderTeam = self.defenderTeam, isWin = self.data.isWin})
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.devilSoulSeal then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.Rewards, team = self.team, defenderTeam = self.defenderTeam })
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, fightStatus = c.FightStatus.devilSoulSeal, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.runePlay then
            if state == c.GameState.ATTACK_WIN then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam })
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.ghostStep then
            local emyDecHp = {}
            local selfDecHp = {}
            local ghostVal = 0

            for group, value in pairs(BattleController.startUnit or {}) do
                for heroId, uid in pairs(value) do
                    local decHp = 0
                    local unit = BattleController.getUnitByUid(uid)

                    --如果达到回合上限，则认为双方都死亡
                    if state == c.GameState.COMPLETE or not unit or not unit:isAlive() then
                        decHp = 10000
                    else
                        decHp = math.ceil( (1-(unit.attr.hp/unit.attr.maxLife)) * 10000) --损失血量百分比,只计算本次战斗损失血量（10000 = 100%）
                    end

                    local phantomAttr = {
                        Id = heroId,
                        DecHp = decHp,
                        Power = math.ceil((unit.attr.mp / unit.attr.energy) * 10000), --剩余能量值百分比（10000 = 100%）
                    }
                    if unit.group == c.UnitGroup.ATTACKER then
                        table.insert(selfDecHp, phantomAttr)
                    elseif unit.group == c.UnitGroup.DEFENDER then
                        table.insert(emyDecHp, phantomAttr)
                    end
                end
            end
            
            local kami = BattleController.kamis[c.UnitGroup.ATTACKER]
            if kami ~= nil then
                ghostVal = math.ceil(kami.attr.mp)
            end
            if state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
                local data = {
                    IsWin = false,
                    EmyDecHp = emyDecHp,
                    SelfDecHp = selfDecHp,
                    GHostVal = ghostVal,
                }
                network.tcpSend(msgids.C_GhostStepFight, data)
                local openLoseWin = function(self, op, data)
                    self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
                    AudioManager.stopMusic()
                end
                network.addListener(self, {msgids.GS_GhostStepFight_R}, handler(self, openLoseWin))
            elseif state == c.GameState.ATTACK_WIN then
                local data_ = {
                    IsWin = true,
                    EmyDecHp = emyDecHp,
                    SelfDecHp = selfDecHp,
                    GHostVal = ghostVal,
                }           
                network.tcpSend(msgids.C_GhostStepFight, data_)
                local openResultWin = function(self, op, data)
                    self:openWin("ResultVictoryWin",{ rewards = data.Rewards, team = self.team})
                    if self.TrunCardData then
                        local win = display.getRunningScene().winManager:findWinByName("TurnCardRewardWin")
                        if not win then
                            self:openWin("TurnCardRewardWin", self.TrunCardData)
                        end
                    end
                    AudioManager.stopMusic()
                end
                network.addListener(self, {msgids.GS_GhostStepFight_R}, handler(self, openResultWin))
            end
        elseif self.data.fightStatus == c.FightStatus.mapBoss then
            local emyDecHp = {}
            local selfDecHp = {}
            for group, value in pairs(BattleController.startUnit) do
                for heroId, uid in pairs(value) do
                    local decHp = 0
                    local unit = BattleController.getUnitByUid(uid)
                    --如果达到回合上限，则认为双方都死亡
                    if not unit or (not unit:isAlive()) or (state == c.GameState.COMPLETE and unit.group == c.UnitGroup.ATTACKER) then
                        decHp = 10000
                    else
                        decHp = math.ceil( (1-(unit.attr.hp/unit.attr.maxLife)) * 10000) --损失血量百分比,只计算本次战斗损失血量（10000 = 100%）
                    end
                    local monHpData = {
                        Id = heroId,
                        DecHp = decHp,
                        Power = math.ceil((unit.attr.mp / unit.attr.energy) * 10000), --剩余能量值百分比（10000 = 100%）
                    }
                    if unit.group == c.UnitGroup.ATTACKER then
                        table.insert(selfDecHp, monHpData)
                    elseif unit.group == c.UnitGroup.DEFENDER then
                        table.insert(emyDecHp, monHpData)
                    end
                end
            end
            local sData = {
                StepId = self.data.stepId,
                EmyDecHp = emyDecHp,
                SelfDecHp = selfDecHp,
            }
            if state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
                sData.IsWin = false
                network.tcpSend(msgids.C_CBossFight, sData)
                local openLoseWin = function(self, op, data)
                    self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
                    AudioManager.stopMusic()
                end
                network.addListener(self, {msgids.GS_CBossFight_R}, handler(self, openLoseWin))
            elseif state == c.GameState.ATTACK_WIN then
                sData.IsWin = true       
                network.tcpSend(msgids.C_CBossFight, sData)
                local openResultWin = function(self, op, data)
                    self:openWin("ResultVictoryWin",{ rewards = {}, team = self.team})
                    AudioManager.stopMusic()
                    if data.Idx and data.Idx > 0 then
                        self:openWin("MapBossBoxWin", data.Idx, self.data.levelId)
                    end
                end
                network.addListener(self, {msgids.GS_CBossFight_R}, handler(self, openResultWin))
            end
        elseif self.data.fightStatus == c.FightStatus.huntSoul then
            local openResultWin = function(self, op, data)
                if state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
                    self:openWin("ResultLoseWin",{team = self.team,levelId = self.data.levelId, afterLoading = self.data.afterLoading})
                elseif state == c.GameState.ATTACK_WIN then
                    self:openWin("ResultVictoryWin",{ rewards = data.Rewards, team = self.team})
                end
                AudioManager.stopMusic()
            end

            if state == c.GameState.ATTACK_WIN then
                local data = {
                    Fid = self.data.huntId,
                    Index = self.data.monsterIndex,
                    Team = self.team,
                }
                network.addListener(self, {msgids.GS_HuntSoulFight_R}, handler(self, openResultWin))
                network.tcpSend(msgids.C_HuntSoulFight, data)
            else
                openResultWin(self)
            end
        elseif self.data.fightStatus == c.FightStatus.worldFight then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, showRewards = true, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
           elseif self.data.fightStatus == c.FightStatus.KingSwordBoss
            or self.data.fightStatus == c.FightStatus.KingSwordFightOther then
            BattleController.pause()
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam, levelId = self.data.levelId, showRewards = true, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.hallFight
             or self.data.fightStatus == c.FightStatus.hallSpecialFight then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.txwsPVP then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.phantomTower then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team, defenderTeam = self.defenderTeam })
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.rewardPalace then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.ninjaMaster then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.ninjaLegend then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.patrol then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.familyCompeteFight then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.ninjaExp then
            self:openWin("NinjaExpResultWin", {state = self.data.state, rewards = self.data.rewards, defenderTeam = self.defenderTeam, team = self.team})
        elseif self.data.fightStatus == c.FightStatus.plotStep then
            if self.data.isWin then
                self:openWin("ResultVictoryWin",{rewards = self.data.rewards, team = self.team , defenderTeam = self.defenderTeam, allDamageData =self.data.allDamageData})
            else
                self:openWin("ResultLoseWin",{team = self.team, defenderTeam = self.defenderTeam, afterLoading = self.data.afterLoading, allDamageData =self.data.allDamageData})
            end
            AudioManager.stopMusic()
        elseif self.data.fightStatus == c.FightStatus.plotBoss then
            local damage = StatisticsController.getGroupDamage(c.UnitGroup.ATTACKER, true)
            self:openWin("ResultBossWin",{rewards = self.data.rewards,defenderTeam = self.defenderTeam,team = self.team, damage = damage, fightStatus = c.FightStatus.plotBoss, allDamageData =self.data.allDamageData})
            AudioManager.stopMusic()
        end
    end
end

function GameScene:nextWave()
    self.waveIndex = self.waveIndex + 1
    --背景音乐
    self:updateBgMusic()

    BattleController.updateNextWave()

    -- 清除死亡单位spine
    local uids = table.keys(self.anims)
    for _, uid in pairs(uids) do
        if BattleController.units[uid] == nil then
            self.anims[uid]:removeFromParent()
            self.anims[uid] = nil
        end
    end

    -- 添加新上阵英雄
    local uidGroups = {[c.UnitGroup.ATTACKER] = {},[c.UnitGroup.DEFENDER] = {}}
    for _, unit in pairs(BattleController.units) do
        if unit:isAlive() and unit.group == c.UnitGroup.DEFENDER then
            table.insert(uidGroups[unit.group],unit.uid)
        end
    end


    self:playBattleVideo(function()
        self:showAppear(uidGroups,function()
            BattleController.start()
        end)

        self:updateTopNode(uidGroups[c.UnitGroup.DEFENDER])
        if self.waveIndex >= 2 then
            self:createTopNode()
        end
        self:updateTurn()
        --更新顶部

        self:updateRound(BattleController.curRound, BattleController.maxRound)
    end)
end

function GameScene:addAction(action, target)
    action:retain()
    action:startWithTarget(target)
    self.actions[#self.actions + 1] = action
end

function GameScene:onCleanup()
    for _, action in pairs(self.actions) do
        action:release()
    end
    self.actions = {}

    ViewController.new(nil)

    SpineManager.clean()
end

function GameScene:breakEffect()
    local sp = display.newSprite("fight/ninsover_a.png")
    display.align(sp,display.CENTER,0,0)
    self:addChild(sp)
    sp:setScale(2)
    sp:runAction(
        cc.Sequence:create(
            cc.FadeOut:create(2),
            cc.RemoveSelf:create()
        )
    )
end

function GameScene:freezingStart(uid)
    local anim = self.anims[uid]
    local zorder = fightZOrder.anim_powermax
    anim:setLocalZOrder(zorder)
    self.blackLayer:setVisible(BattleController.isFreezing())

    self:showAnimation(uid)
end

function GameScene:freezingEnd(uid)
    local anim = self.anims[uid]
    local zorder = fightZOrder.pos_height - anim.startPos.y
    anim:setLocalZOrder(zorder)
    self.blackLayer:setVisible(BattleController.isFreezing())
end

function GameScene:updateBlackLayer()
    self.blackLayer:setVisible(BattleController.isFreezing())
end

function GameScene:showAnimation(uid)
    self.powermaxEffectLayer:removeAllChildren()

    local scale = 1
    local unit = BattleController.getUnitByUid(uid)
    if unit.group == c.UnitGroup.DEFENDER then
        scale = -1
    end

    self.powermaxEffectLayer:setScaleX(scale)

    local x, y = 300, display.cy

    local anim = SpineManager.createAnimation("public/ui_dazhaotexie_di", 1 , true)
    anim:setPosition(x, y)
    self.powermaxEffectLayer:addChild(anim)

    anim:playAnimation("idle", 1)
    self.effects[#self.effects + 1] = anim


    local mask = SpineManager.createAnimation("public/ui_dazhaotexie_mask", 1 , true)
    mask:setPosition(x, y)
    mask:playAnimation("idle", 1)
    self.effects[#self.effects + 1] = mask
    
    local node = cc.ClippingNode:create(mask)
    node:setAlphaThreshold(0.5)
    self.powermaxEffectLayer:addChild(node)


    local anim = SpineManager.createAnimation("public/ui_dazhaotexie_card", 1 , true)
    anim:setPosition(x, y)
    node:addChild(anim)

    local sprite = display.newSprite("skillCard/" .. roleConf[unit.role].skillCard .. ".png")
    anim:addChildFollowSlot("card_point", sprite)

    anim:playAnimation("idle", 1)
    self.effects[#self.effects + 1] = anim
end

-- 战斗中新单位（重生、变身、召唤）
function GameScene:addUnit(unit, revive)
    local name = (unit.group == c.UnitGroup.ATTACKER) and "left" or "right"
    local node = self.resourceNode_:getChildByName("heroNode"):getChildByName(name .. "_" .. unit.order)
    local jsonName = roleConf[unit.role].spine
    local anim = UnitAnim.new(jsonName, unit.fightBodyScale * self.uiScale, unit.skin)

    if unit.group == c.UnitGroup.DEFENDER then
        anim:setScaleX(-1 * anim:getScaleX())
    end

    local x, y = node:getPosition()
    local zorder = fightZOrder.pos_height - y
    anim:setStartPosition(x, y)
    self.resourceNode_:getChildByName("heroNode"):addChild(anim, zorder)
    anim:playAnimation("idle", -1) 
    if unit.originData and unit.originData.star and unit.originData.star > 0 then 
        if Helper.checkHeroIsDemon(unit.heroId, unit.originData.star) then ----魔化光圈
            local auraAnim = SpineManager.createAnimation("public/"..heroConf[unit.heroId].auraSpine, 1)
            auraAnim:playAnimation("idle", -1)
            auraAnim:setPosition(3, 10)
            anim:addChild(auraAnim)
        end
    end
    self.anims[unit.uid] = anim

    local hpNode = self:createCsbNode("fight/hpNode.csb")
    local heroName = hpNode:getChildByName("txt_name")
    anim:addChildFollowBone("hp_point", hpNode)

    if self.data.fightStatus == c.FightStatus.guildMonster and unit.group == c.UnitGroup.DEFENDER then --家族monster不显示血条
        hpNode:setVisible(false)
    else
        if unit.heroId then
            local heroData = heroConf[unit.heroId] or monsterConf[unit.heroId] or {}
            local name_ = heroData.heroName or heroData.name or ""
            local cls = unit.originData and unit.originData.cls or 0
            local color = c.ITEM_QUALITY_COLOR[heroData.color or 401]
            if cls > 0  then
                name_ = name_.." +"..cls
            end
            if heroConf[unit.heroId] then--英雄
                name_, color = Helper.getHeroNameAndColor(unit.heroId, cls)
            end
            heroName:setString(name_)
            heroName:setTextColor(color)
            if unit.group == c.UnitGroup.DEFENDER then
                heroName:setScaleX(-1)
                if self.data.fightStatus == c.FightStatus.ordinary then
                    color = BattleController.monsterColor[unit.heroId] or 1
                    heroName:setTextColor(c.ITEM_COLOR[color])
                end
            end
        end
    end
    
    if roleConf[unit.role].idleEffect and roleConf[unit.role].idleEffect ~= "" then
        local idleEffect = SpineManager.createAnimation("spine/effect/"..roleConf[unit.role].idleEffect, 1)
        anim:addChild(idleEffect)
        idleEffect:playAnimation("idle", -1)
    end

    self:updateHp(unit.uid, unit.attr.hp, unit.attr.maxLife)
    self:updateEnergy(unit.uid, unit.attr.mp, unit.attr.energy)

    if revive then
        local effect = SpineManager.createAnimation("spine/effect/buff_fuhuo", nil, true)
        anim:addChild(effect)
        effect:playAnimation("idle", 1)

        self.effects[#self.effects + 1] = effect
    end

    return anim
end

-- 未命中
function GameScene:hitMiss(uid)
    local anim = self.anims[uid]
    
    local sprite = display.newSprite("fightNum/fightnum_dodge_01.png")

    local pos = anim:getBonePosition("hp_point")
    pos.y = pos.y + 20
    sprite:setPosition(pos)
    self.resourceNode_:getChildByName("heroNode"):addChild(sprite, fightZOrder.bullet)

    self:createNumberAction(sprite, uid)
end

-- 无敌
function GameScene:invincible(uid)
    local anim = self.anims[uid]
    
    local label = UILabel.new({
        text = WordDictionary[10002],
        color = specialBuffColor,
        back = cc.c3b(0,0,0),
        size = 25,
    })

    local pos = anim:getBonePosition("hp_point")
    pos.y = pos.y + 20
    label:setAnchorPoint(cc.p(0.5, 0.5))
    label:setPosition(pos)
    self.resourceNode_:getChildByName("heroNode"):addChild(label, fightZOrder.bullet)

    self:createActionFlash(label)
end

-- 护盾吸收所有伤害
function GameScene:shield(uid)
    local anim = self.anims[uid]
    
    local label = UILabel.new({
        text = WordDictionary[10003],
        color = specialBuffColor,
        back = cc.c3b(0,0,0),
        size = 25,
    })

    local pos = anim:getBonePosition("hp_point")
    pos.y = pos.y + 20
    label:setAnchorPoint(cc.p(0.5, 0.5))
    label:setPosition(pos)
    self.resourceNode_:getChildByName("heroNode"):addChild(label, fightZOrder.bullet)

    self:createActionFlash(label)
end

return GameScene
