
local SpineManager = require "sandglass.core.SpineManager"

local BulletAnim = class("BulletAnim", function(jsonName)
	return SpineManager.createAnimation("spine/effect/"..jsonName, nil , true)
end)

function BulletAnim:ctor(jsonName)
	self:enableNodeEvents()
	self.actions = {}
	self:playAnimation("idle", -1)
end

function BulletAnim:updateAnim(dt)
	self:update(dt)

	for idx = #self.actions, 1, -1 do
		local action = self.actions[idx]

		action:step(dt)

		if action:isDone() then
			action:release()
			table.remove(self.actions, idx)
		end
	end
end

function BulletAnim:addAction(action)
	action:retain()
	action:startWithTarget(self)
	self.actions[#self.actions + 1] = action
end

function BulletAnim:onCleanup()
	for _, action in pairs(self.actions) do
		action:release()
	end
	self.actions = {}
end

return BulletAnim
