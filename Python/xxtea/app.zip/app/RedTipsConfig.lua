--RedTipsConfig.lua
local RedTipsConfig = {}
local self = RedTipsConfig

function RedTipsConfig.new()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local userId = PlayerModel:getInfo().userId

    local configFileName = userId..".lua"
    local writablePath = cc.FileUtils:getInstance():getWritablePath()

    self.configFileName = configFileName
    self.writablePath = writablePath

    self.setting = {}
    if cc.FileUtils:getInstance():isFileExist(writablePath .. configFileName) then
        local file = dofile(writablePath .. configFileName)
        if file then
            for key, var in pairs(file) do
            	self.setting[key] = var
            end
        end
    end
end

local serialize = serialize
if not serialize then
    serialize = function (o)  
        local str_serialize = ""  
        if o == nil then  
            return "nil"
        end  
        if type(o) == "number" then  
            str_serialize = str_serialize..o  
        elseif type(o) == "string" then  
            str_serialize = str_serialize..string.format("%q", o)  
        elseif type(o) == "table" then  
            str_serialize = str_serialize.."{"  
            for k,v in pairs(o) do  
                str_serialize = str_serialize.." ["  
                str_serialize = str_serialize .. serialize(k)
                str_serialize = str_serialize.."] = "  
                str_serialize = str_serialize .. serialize(v)  
                str_serialize = str_serialize..","  
            end  
            str_serialize = str_serialize.."}"  
        elseif type(o) == "boolean" then  
            str_serialize = str_serialize..(o and "true" or "false")  
        elseif type(o) == "function" then  
            str_serialize = str_serialize.."function"  
        else  
            error("cannot serialize a " .. type(o))  
        end  
        return str_serialize
    end
end

function RedTipsConfig.writeFile()
    local file = io.open(self.writablePath .. self.configFileName, "w+")
    if file then
        local content = "return " .. serialize(self.setting)
        file:write(content)
        file:close()
    end
end

function RedTipsConfig.setSetting(name, value)
    self.setting[name] = value
    self:writeFile()
end

function RedTipsConfig.getSetting(name,default)
    local data = self.setting[name]
    if data == nil or data == "" then data = default end
    return data
end

return RedTipsConfig