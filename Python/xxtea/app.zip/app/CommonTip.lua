--CommonTip.lua
local c = require "app.configs.constants"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local skillConf = require "app.configs.skill"
local zsdforeverbuffConf = require "app.configs.zsdforeverbuff"
local attributeConf = require "app.configs.attribute"
local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local CoreColor = require "sandglass.core.CoreColor"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local RichLabel = require "sandglass.ui.RichLabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local sqMinerConf = require "app.configs.sqMiner"
local buffConf = require "app.configs.buff"
local playerTitleConf = require "app.configs.playerTitle"

local PlayerModel = init.PlayerModel
local ItemModel = init.ItemModel
local MinerModel = init.MinerModel
local RuneModel = init.RuneModel

local HERO_CLS_TO_COLOR = {
    2,
    2,
    2,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    5,
    6,
    6,
    6,
    6,
    6,
    6,
}

local CommonTip = class("CommonTip", function ()
	return cc.Node:create()
end)

function CommonTip.create(point, offsetSize, params)
	return CommonTip.new(point, offsetSize, params)
end 


function CommonTip:ctor(point, offsetSize, params)
	self.origin = point
	self.offsetSize = offsetSize
	self.params = params or {}
    self.type = self.params.type or 1  --1.物品Tips 2.技能Tips 3.战神殿战神意志Tips 5.符文
    self.id = self.params.id or 0
    self.showNum = self.params.showNum ~= false and true or false
    self.isAoyi = self.params.aoyi or false
    self:dacorate()
end

function CommonTip:dacorate()
    if self.id == 0 and self.tid == 0 and not self.params.data then
        return 
    end
	if self.type == c.TipsType.goods then
		local tip = self:createItemTip()
        self:tipsLayer(tip)
    elseif self.type == c.TipsType.skill then
    	local tip = self:createSkillTip()
        self:tipsLayer(tip)
    elseif self.type == c.TipsType.mars then
        local tip = self:createMarsTip()
        self:tipsLayer(tip)
    elseif self.type == c.TipsType.miner then
        local tip = self:createMinerTip()
        self:tipsLayer(tip)
    elseif self.type == c.TipsType.rune then
        local tip = self:createRuneTip()
        self:tipsLayer(tip)
    elseif self.type == c.TipsType.buff then
        local tip = self:createBuffTip()
        self:tipsLayer(tip)
    elseif self.type == c.TipsType.gem then
        local tip = self:createGemTip()
        self:tipsLayer(tip)
     elseif self.type == c.TipsType.title then
        local tip = self:createTitleTip()
        self:tipsLayer(tip)
	end
end

function CommonTip:createGemTip()
    local width = 240
    local height = 120
    local data = itemConf[self.id] 
    local attr = data.basicProperty[1]
    local bg = display.newSprite("#public/tongyong-di11.png", 0, 0, {scale9 = true, size = cc.size(width, height)})

    local iconImg = display.newSprite("icon/item/"..data.icon..".png")
    iconImg:setScale(0.7)
    display.align(iconImg, display.LEFT_CENTER, 15, height - 40)
    bg:addChild(iconImg)

    local nameStr = UILabel.new({
        text = data.name,
        color = c.ITEM_COLOR[data.color],
        size = 24,
        back = CoreColor.BLACK,
    })
    display.align(nameStr, display.LEFT_CENTER, 80, height - 40)
    bg:addChild(nameStr)

    local LineImg = display.newSprite("#public/tongyong-fengexian.png", 0, 0, {scale9 = true, size = cc.size(width - 20, 5)})
    display.align(LineImg, display.CENTER, width/2, height/2)
    bg:addChild(LineImg)

    local attrStr = UILabel.new({
        text = Helper.getAttriName(attributeConf[attr.id].alias).."+"..Helper.getAttriValue(attr.id, attr.val, true),
        color = CoreColor.GREEN,
        size = 20,
        back = CoreColor.BLACK,
    })
    display.align(attrStr, display.LEFT_CENTER, 20, 30)
    bg:addChild(attrStr)

    return bg
end

function CommonTip:createMinerTip()
    cc.SpriteFrameCache:getInstance():addSpriteFrames("public/public.plist")
    local width = 316
    local height = 123
    local num = 0
    for k,v in pairs(MinerModel:getCanDismissMiners()) do
        if self.id == v.Id then
            num = v.N
            break
        end
    end
    local data = sqMinerConf[self.id]

    local iconImg = Helper.createMinerHead({scale = 0.8,id = self.id,haveTip = false})
    local nameStr = UILabel.new({
        text = data.name,
        color = c.ITEM_COLOR[data.stage],
        size = 25,
        back = CoreColor.BLACK,
    })
    local haveLabel = UILabel.new({
        text = WordDictionary[20317],
        color = cc.c3b(236,225,204),
        size = 20,
        back = CoreColor.BLACK,
    })
    local numLabel = UILabel.new({
        text = num,
        color = cc.c3b(255,183,29),
        size = 20,
        back = CoreColor.BLACK,
    })
    display.align(numLabel,display.BOTTOM_LEFT,haveLabel:getContentSize().width + 5,0)
    haveLabel:addChild(numLabel)

    local ggImg = display.newSprite("#public/tongyong-fengexian.png", 0, 0, {scale9 = true, size = cc.size(286,2)})

    local desLabel = RichLabel.new({
        fontSize = 20,
        maxWidth = 294,
        fontColor = cc.c3b(236,225,204),
    })
    desLabel:setString(data.minerDes)
    height = height + desLabel:getContentSize().height

    local bg = display.newSprite("#public/tongyong-di11.png", 0, 0, {scale9 = true, size = cc.size(width,height)})
    display.align(iconImg,display.CENTER,55,height - 55)
    display.align(nameStr,display.BOTTOM_LEFT,104,height - 48)
    display.align(haveLabel,display.BOTTOM_LEFT,104,height - 83)
    display.align(desLabel,display.LEFT_TOP,15,height - 107)
    display.align(ggImg,display.CENTER,width * 0.5,height - 99)
    bg:addChild(iconImg)
    bg:addChild(nameStr)
    bg:addChild(haveLabel)
    bg:addChild(desLabel)
    bg:addChild(ggImg)
    
    return bg
end

function CommonTip:createMarsTip()
    cc.SpriteFrameCache:getInstance():addSpriteFrames("public/public.plist")
    local width = 260
    local height = 25
    local zsdforeverbuffConfData = zsdforeverbuffConf[self.id]
    local nextZsdforeverbuffConfData = nil

    local nameStr = UILabel.new({
        text = zsdforeverbuffConfData.name,
        color = cc.c3b(254,149,74),
        size = 25,
        back = CoreColor.BLACK,
    })
    height = height + nameStr:getContentSize().height
    local curLabel = nil
    local curAttr = nil
    if not self.params.notOpen then
        nextZsdforeverbuffConfData = zsdforeverbuffConf[self.id+5]
        local curStr = ""
        for _, attr in pairs(zsdforeverbuffConfData.buff) do
            curStr = curStr .. attributeConf[attr.id].name .. "+" .. Helper.getAttriValue(attr.id,attr.val) .. "\r\n"
        end
        curStr = string.sub(curStr,1,-3)
        curLabel = UILabel.new({
            text = WordDictionary[24410],
            color = cc.c3b(236,225,204),
            size = 20,
            back = CoreColor.BLACK,
        })
        curAttr = UILabel.new({
            text = curStr,
            color = cc.c3b(255,183,29),
            size = 20,
            back = CoreColor.BLACK,
            dimensions = cc.size(250,0)
        })
        height = height + curLabel:getContentSize().height + curAttr:getContentSize().height + 10
    else
        nextZsdforeverbuffConfData = zsdforeverbuffConf[self.id]
      
    end
    local ggImg = nil
    local nextLabel = nil
    local nextAttr = nil
    if nextZsdforeverbuffConfData then
        ggImg = display.newSprite("#public/tongyong-fengexian.png", 0, 0, {scale9 = true, size = cc.size(240,2)})
        local nextStr = ""
        for _, attr in pairs(nextZsdforeverbuffConfData.buff) do
            nextStr = nextStr .. attributeConf[attr.id].name .. "+" .. Helper.getAttriValue(attr.id,attr.val) .. "\r\n"
        end
        nextStr = string.sub(nextStr,1,-3)
        nextLabel = UILabel.new({
            text = WordDictionary[24411],
            color = cc.c3b(236,225,204),
            size = 18,
            back = CoreColor.BLACK,
        })
        nextAttr = UILabel.new({
            text = nextStr,
            color = cc.c3b(255,255,255),
            size = 18,
            back = CoreColor.BLACK,
            dimensions = cc.size(250,0)
        })
        height = height + ggImg:getContentSize().height + nextLabel:getContentSize().height + nextAttr:getContentSize().height + 10 
    end
    local bg = display.newSprite("#public/tongyong-di11.png", 0, 0, {scale9 = true, size = cc.size(width,height)})
    bg:addChild(nameStr)
    local curHeight = 10
    display.align(nameStr,display.BOTTOM_LEFT,15,height - curHeight - nameStr:getContentSize().height)
    curHeight = curHeight + nameStr:getContentSize().height + 5
    if curLabel then
        bg:addChild(curLabel)
        display.align(curLabel,display.BOTTOM_LEFT,15,height - curHeight - curLabel:getContentSize().height)
        curHeight = curHeight + curLabel:getContentSize().height + 5
    end
    if curAttr then
        bg:addChild(curAttr)
        display.align(curAttr,display.BOTTOM_LEFT,15,height - curHeight - curAttr:getContentSize().height)
        curHeight = curHeight + curAttr:getContentSize().height + 5
    end
    if ggImg then
        bg:addChild(ggImg)
        display.align(ggImg,display.CENTER,width * 0.5,height - curHeight - ggImg:getContentSize().height)
        curHeight = curHeight + ggImg:getContentSize().height + 5
    end
    if nextLabel then
        bg:addChild(nextLabel)
        display.align(nextLabel,display.BOTTOM_LEFT,15,height - curHeight - nextLabel:getContentSize().height)
        curHeight = curHeight + nextLabel:getContentSize().height + 5
    end
    if nextAttr then
        bg:addChild(nextAttr)
        display.align(nextAttr,display.BOTTOM_LEFT,15,height - curHeight - nextAttr:getContentSize().height)
    end
    return bg
end

function CommonTip:createRuneTip()
    cc.SpriteFrameCache:getInstance():addSpriteFrames("rune/rune.plist")
    local width = 308
    local topHeight = 80
    local attrHeight = 70
    local skillHeight = 180

    local runeConf = require "app.configs.rune"
    local rune = RuneModel:getRune(self.params.seq) or {}
    local conf = itemConf[self.id]
    
    local bg_name = display.newSprite("#rune/fuwen-di-2.png", 0, 0, {scale9 = true, size = cc.size(281,67)})
    local sp_icon = display.newSprite("icon/item/" .. conf.icon .. ".png")
    sp_icon:setScale(0.76)
    display.align(sp_icon,display.CENTER, 36, 34)
    bg_name:addChild(sp_icon)    

    local txt_name = UILabel.new({
        text = conf.name,
        color = c.ITEM_COLOR[conf.color],
        size = 18,
        back = CoreColor.BLACK,
    })
    display.align(txt_name,display.LEFT_CENTER, 77, 49)
    bg_name:addChild(txt_name) 

    local lv = runeConf[conf.type].level
    local txt_lv = UILabel.new({
        text = "Lv."..lv,
        color = c.ITEM_COLOR[conf.color],
        size = 18,
        back = CoreColor.BLACK,
    })
    display.align(txt_lv,display.LEFT_CENTER, 77, 20)
    bg_name:addChild(txt_lv)

    local bg_attr = display.newSprite("#rune/fuwen-di5.png")
    local txt_attr_title = UILabel.new({
        text = WordDictionary[50111],
        color = cc.c3b(175,149,112),
        size = 16,
        back = CoreColor.BLACK,
    })
    display.align(txt_attr_title,display.LEFT_CENTER, 10, 11)
    bg_attr:addChild(txt_attr_title)

    if rune.RProp then
        for k,attr in pairs(rune.RProp) do
            local val = Helper.getAttriValue(attr.id, attr.val)
            local desc = attributeConf[attr.id].des1
            local str = string.format(desc, val)

            local txt_attr = UILabel.new({
                text = str,
                color = cc.c3b(132,253,50),
                size = 16,
            })

            display.align(txt_attr,display.LEFT_CENTER, 10 + (k-1) % 2 * 130, 5 - 25 * math.ceil(k/2))
            bg_attr:addChild(txt_attr)
        end

        if table.nums(rune.RProp) > 2 then
            attrHeight = 85
        end
    else
        local txt_attr = UILabel.new({
            text = WordDictionary[50121],
            color = cc.c3b(132,253,50),
            size = 16,
        })

        display.align(txt_attr,display.LEFT_CENTER, 10, -25)
        bg_attr:addChild(txt_attr)
    end

    local bg_skill = display.newSprite("#rune/fuwen-di5.png")
    local txt_skill_title = UILabel.new({
        text = WordDictionary[50097],
        color = cc.c3b(175,149,112),
        size = 16,
        back = CoreColor.BLACK,
    })
    display.align(txt_skill_title,display.LEFT_CENTER, 10, 11)
    bg_skill:addChild(txt_skill_title)

    if not rune.skill then
        skillHeight = 200
        local txt_skill_tip1 = UILabel.new({
            text = WordDictionary[50122],
            color = cc.c3b(132,253,50),
            size = 16,
            back = CoreColor.BLACK,
        })
        display.align(txt_skill_tip1,display.LEFT_TOP, 10, -5)
        bg_skill:addChild(txt_skill_tip1)
    elseif #rune.skill == 0 then
        skillHeight = 70

        local txt_skill_null = UILabel.new({
            text = WordDictionary[50113],
            color = cc.c3b(175,149,112),
            size = 16,
            back = CoreColor.BLACK,
        })
        display.align(txt_skill_null,display.LEFT_TOP, 10, -15)
        bg_skill:addChild(txt_skill_null)
    else
        local skillC = skillConf[rune.skill[1]]
        local skillItem = Helper.createSkillIcon({
            id = skillC.Id,
            ableGLProgram = false,
            cls = 0,
            aoyi = false,
        })
        display.align(skillItem,display.LEFT_CENTER, 6, -35)
        bg_skill:addChild(skillItem)

        local txt_skill_name = UILabel.new({
            text = skillC.name,
            color = CoreColor[RuneModel:getRuneSkillColor(skillC.Id)],
            size = 16,
            back = CoreColor.BLACK,
        })
        display.align(txt_skill_name,display.LEFT_CENTER, 70, -20)
        bg_skill:addChild(txt_skill_name)

        local desc = skillC.des
        while true do
            local middel = string.match(desc, "%b[]")
            if middel then
                middel = string.sub(middel,2,string.len(middel) - 1)
                local cont = skillC[middel] or 0
                desc = string.gsub(desc, "%["..middel.."%]" , math.floor(cont * 100) .. "%%")
            else
                break
            end
        end

        --描述
        local txt_desc = UILabel.new({
            text = desc,
            color = CoreColor.TIPS_DESC,
            back = CoreColor.BLACK_191,
            dimensions = cc.size(212,0),
            backWidth = 1,
            size = 16,
        })
        display.align(txt_desc,display.LEFT_TOP, 70, -38)
        bg_skill:addChild(txt_desc)

        print("txt_desc:getContentSize().height== ", txt_desc:getContentSize().height)
        skillHeight = skillHeight - (100 - txt_desc:getContentSize().height)
    end
    
    local height = topHeight + attrHeight + skillHeight + 13
    local bg = display.newSprite("#rune/fuwen-di2.png", 0, 0, {scale9 = true, size = cc.size(width,height)})
    display.align(bg_name,display.LEFT_TOP, 13, height - 13)
    bg:addChild(bg_name)

    display.align(bg_attr,display.LEFT_TOP, 13, height - topHeight - 2)
    bg:addChild(bg_attr)

    display.align(bg_skill,display.LEFT_TOP, 13, height - topHeight - attrHeight - 4)
    bg:addChild(bg_skill)

    return bg
end

function CommonTip:createItemTip()
	cc.SpriteFrameCache:getInstance():addSpriteFrames("public/public.plist")
	local width = 316
	local height = 123
	if self.id == 10201 or self.id == 10202 or self.id == 10203 then
		self.id = 10200
	end
	local data = itemConf[self.id] or currencyConf[self.id]
	local num = 0
	if PlayerModel:getCurrencyByID(self.id) and PlayerModel:getCurrencyByID(self.id) ~= 0 then
		num = PlayerModel:getCurrencyByID(self.id)
	elseif ItemModel:getItem(self.id) and ItemModel:getItem(self.id) ~= 0 then
		num = ItemModel:getItem(self.id).number
	end

	local iconImg = Helper.createGoodsItem({scale = 0.8,id = self.id,haveTip = false})
	local nameStr = UILabel.new({
		text = data.name,
		color = c.ITEM_COLOR[data.color],
		size = 25,
		back = CoreColor.BLACK,
	})
	local yyLabel = UILabel.new({
		text = WordDictionary[20317],
		color = cc.c3b(236,225,204),
		size = 20,
		back = CoreColor.BLACK,
	})
	local numLabel = UILabel.new({
		text = num,
		color = cc.c3b(255,183,29),
		size = 20,
		back = CoreColor.BLACK,
	})
	display.align(numLabel,display.BOTTOM_LEFT,yyLabel:getContentSize().width + 1,0)
	yyLabel:addChild(numLabel)

	local ggImg = display.newSprite("#public/tongyong-fengexian.png", 0, 0, {scale9 = true, size = cc.size(286,2)})

	local desLabel = RichLabel.new({
		fontColor = cc.c3b(236,225,204),
		fontSize = 20,
		maxWidth = 294
	})
    desLabel:setString(data.des)

	height = height + desLabel:getContentSize().height

    local bg = display.newSprite("#public/tongyong-di11.png", 0, 0, {scale9 = true, size = cc.size(width,height)})
    display.align(iconImg,display.CENTER,55,height - 55)
    display.align(nameStr,display.BOTTOM_LEFT,104,height - 48)
    display.align(yyLabel,display.BOTTOM_LEFT,104,height - 83)
    display.align(desLabel,display.LEFT_TOP,15,height - 107)
    display.align(ggImg,display.CENTER,width * 0.5,height - 99)
    bg:addChild(iconImg)
    bg:addChild(nameStr)
    if self.showNum then
    	bg:addChild(yyLabel)
    end
    bg:addChild(desLabel)
    bg:addChild(ggImg)
    
    return bg
end

function CommonTip:createTitleTip()
    cc.SpriteFrameCache:getInstance():addSpriteFrames("public/public.plist")
    local width = 316
    local height = 123
    
    local data = playerTitleConf[self.id]

    local iconImg = ccui.ImageView:create("public/"..data.icon..".png", ccui.TextureResType.plistType)

    local ggImg = display.newSprite("#public/tongyong-fengexian.png", 0, 0, {scale9 = true, size = cc.size(286,2)})

    local desLabel = RichLabel.new({
        fontColor = cc.c3b(236,225,204),
        fontSize = 20,
        maxWidth = 294
    })
    desLabel:setString(data.des)

    height = height + desLabel:getContentSize().height

    local bg = display.newSprite("#public/tongyong-di11.png", 0, 0, {scale9 = true, size = cc.size(width,height)})
    display.align(iconImg,display.CENTER,width * 0.5,height - 50)
    display.align(desLabel,display.LEFT_TOP,15,height - 107)
    display.align(ggImg,display.CENTER,width * 0.5,height - 99)
    bg:addChild(iconImg)
    bg:addChild(desLabel)
    bg:addChild(ggImg)
    
    return bg
end

function CommonTip:createSkillTip()
    local heroCls = self.params.cls or 1
    local showStatus = true
    if self.params.showStatus == false then
        showStatus = false
    end

    local width = 330
    local path = "public/tips_di.png"
    local skillTip = UIImageBox.new(path, function()
        
    end, {isPlist = true, ableGLProgram = false})
    skillTip:setScale9Enabled(true)
    skillTip:setAnchorPoint(cc.p(0, 0.5))
    skillTip:setName("skillTipNode")

    local height = 15
    local conf = skillConf[self.id]
    local desc = conf.des

    while true do
        local middel = string.match(desc, "%b[]")
        if middel then
            middel = string.sub(middel,2,string.len(middel) - 1)
            local cont = conf[middel] or 0
            desc = string.gsub(desc, "%["..middel.."%]" , math.floor(cont * 100) .. "%%")
        else
            break
        end
    end

    --描述
    local txt_desc = UILabel.new({
        text = desc,
        color = CoreColor.TIPS_DESC,
        back = CoreColor.BLACK_191,
        dimensions = cc.size(305,0),
        backWidth = 1,
        size = 18,
    })

    height = height + 5--下边距
    display.align(txt_desc, display.LEFT_BOTTOM, 15, height)
    skillTip:addChild(txt_desc, 1)
    local txtHeight = txt_desc:getContentSize().height
    height = height + txtHeight + 2

    --line
    local line = display.newSprite("#public/biaoti_di.png")--, 0, 0, {scale9 = true, size = cc.size(width - 48, 3)}
    local lineHeight = line:getContentSize().height
    display.align(line, display.CENTER, width * 0.5, height + lineHeight * 0.5)
    skillTip:addChild(line, 1)
    --技能属性
    local txt_attr_title = UILabel.new({
        text = WordDictionary[24203],
        color = CoreColor.TIPS_DESC,
        back = CoreColor.BLACK_191,
        backWidth = 1,
        size = 18,
    })
    display.align(txt_attr_title, display.CENTER, width * 0.5, height + lineHeight * 0.5 + 2)
    skillTip:addChild(txt_attr_title, 1)

    height = height + lineHeight + 10

    --icon
    local skillIcon = display.newSprite("icon/skill/" .. conf.icon .. ".png")
    skillTip:addChild(skillIcon, 1)
    display.align(skillIcon, display.LEFT_BOTTOM, 15 , height)

    --name
    local txt_name = UILabel.new({
        text = conf.name,
        color = CoreColor.RED,
        back = CoreColor.BLACK_191,
        backWidth = 2,
        size = 22,
    })
    display.align(txt_name, display.LEFT_BOTTOM, 85, height + 28)
    skillTip:addChild(txt_name, 1)

    --unlock
    if (conf.talentUnlock and conf.talentUnlock > 0 and conf.talentUnlock > heroCls) and (not self.params.notShowUnlock) then
        local txt_unlock_title = UILabel.new({
            text = WordDictionary[50045],
            color = CoreColor.TIPS_DESC,
            back = CoreColor.BLACK_191,
            backWidth = 1,
            size = 18,
        })
        display.align(txt_unlock_title, display.LEFT_BOTTOM, 85, height)
        skillTip:addChild(txt_unlock_title, 1)

        local talentUnlock = Helper.getHeroClsName(conf.talentUnlock)
        local txt_unlock = UILabel.new({
            text = talentUnlock, --string.format(WordDictionary[50046], talentUnlock),
            color = CoreColor.TIPS_VAL,
            back = CoreColor.BLACK_191,
            backWidth = 1,
            size = 18,
        })
        local colors = {
            [2] = CoreColor.GREEN,
            [3] = CoreColor.BLUE,
            [4] = CoreColor.PURPLE,
            [5] = CoreColor.ORANGE,
            [6] = CoreColor.RED,
        }
        for k,v in ipairs(HERO_CLS_TO_COLOR) do
            if conf.talentUnlock == k then
                txt_unlock:setTextColor(colors[v])
            end
        end
        display.align(txt_unlock, display.LEFT_BOTTOM, txt_unlock_title:getPositionX() + txt_unlock_title:getContentSize().width + 1, height)
        skillTip:addChild(txt_unlock, 1)
    end

    height = height + 70
    skillTip:setContentSize(cc.size(width, height))
    return skillTip
end

function CommonTip:createBuffTip()
    local width = 330
    local path = "public/tips_di.png"
    local buffTip = UIImageBox.new(path, function()
        
    end, {isPlist = true, ableGLProgram = false})
    buffTip:setScale9Enabled(true)
    buffTip:setAnchorPoint(cc.p(0, 0.5))
    buffTip:setName("buffTipNode")

    local height = 15
    local conf = buffConf[self.id]
    local desc = conf.beizhu

    --描述
    local txt_desc = UILabel.new({
        text = desc,
        color = CoreColor.TIPS_DESC,
        back = CoreColor.BLACK_191,
        dimensions = cc.size(305,0),
        backWidth = 1,
        size = 18,
    })
    height = height + 5--下边距
    display.align(txt_desc, display.LEFT_BOTTOM, 15, height)
    buffTip:addChild(txt_desc, 1)
    local txtHeight = txt_desc:getContentSize().height
    height = height + txtHeight + 2

    --line
    local line = display.newSprite("#public/biaoti_di.png")--, 0, 0, {scale9 = true, size = cc.size(width - 48, 3)}
    local lineHeight = line:getContentSize().height
    display.align(line, display.CENTER, width * 0.5, height + lineHeight * 0.5)
    buffTip:addChild(line, 1)
    --技能属性
    local txt_attr_title = UILabel.new({
        text = WordDictionary[24206],
        color = CoreColor.TIPS_DESC,
        back = CoreColor.BLACK_191,
        backWidth = 1,
        size = 18,
    })
    display.align(txt_attr_title, display.CENTER, width * 0.5, height + lineHeight * 0.5 + 2)
    buffTip:addChild(txt_attr_title, 1)

    height = height + lineHeight + 10

    --icon
    local skillIcon = display.newSprite("icon/skill/" .. conf.icon .. ".png")
    buffTip:addChild(skillIcon, 1)
    display.align(skillIcon, display.LEFT_BOTTOM, 15 , height)

    --name
    local txt_name = UILabel.new({
        text = conf.name,
        color = CoreColor.RED,
        back = CoreColor.BLACK_191,
        backWidth = 2,
        size = 22,
    })
    display.align(txt_name, display.LEFT_BOTTOM, 85, height + 28)
    buffTip:addChild(txt_name, 1)
    height = height + 70
    buffTip:setContentSize(cc.size(width, height))
    return buffTip
end


function CommonTip:tipsLayer(tip)
    display.align(tip,display.BOTTOM_LEFT, 0, 0)
    self:addChild(tip)

    local per = 10
    local xs , ys = 1, 1
    local sz = tip:getContentSize()
    local originPos = cc.p(self.origin.x / xs, self.origin.y / ys)
    local _x,_y = 0, sz.height * 0.5
    if originPos.x < display.width * 0.5 then
        _x = originPos.x * xs
        local y = originPos.y + self.offsetSize.height + per
        if y + sz.height > display.height then 
            y = display.height - sz.height
        elseif y < 0 then 
            y = 0
        end

        _y = y * ys
        display.align(self,display.CENTER,_x,_y)
    else
        _x = (originPos.x - sz.width) * xs
        local y = originPos.y + self.offsetSize.height + per
        if y + sz.height > display.height then 
            y = display.height - sz.height
        elseif y < 0 then 
            y = 0
        end

        _y = y * ys
        display.align(self,display.CENTER,_x,_y)
    end
end

return CommonTip