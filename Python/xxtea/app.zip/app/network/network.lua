
local msgPack = require "app.network.MessagePack"
local Helper = require "app.Helper"
local msgids = require "app.network.msgids"
local Scheduler = require "sandglass.core.Scheduler"

local SOCKET_STATE = {
    Connecting = 0,
    ConnectTimeOut = 1,
    Connected = 2,
    SocketError = 3,
}

local network = {}
network._socket_state = SOCKET_STATE.SocketError
network.tcpListeners = {}

cc.exports.socket = GameSocket:createInstance()
local socket = cc.exports.socket

-- http
function network.httpGet(url, callback)
    local xhr = cc.XMLHttpRequest:new()
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    xhr:open("GET", url)

    local function onReadyStateChanged()
        callback(xhr)
        xhr:unregisterScriptHandler()
    end

    xhr:registerScriptHandler(onReadyStateChanged)
    xhr:send()
end

function network.httpPost(url, data, callback)
    local xhr = cc.XMLHttpRequest:new()
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    xhr:open("POST", url)

    local function onReadyStateChanged()
        callback(xhr)
        xhr:unregisterScriptHandler()
    end

    xhr:registerScriptHandler(onReadyStateChanged)
    xhr:send(data)
end

-- tcp
function network.tcpConnect(ip, port, callback)
    network.connectCallback = callback
    if not network.sendConnect then
        socket:asynConnect(tostring(ip), tonumber(port))
        network.sendConnect = true
    end
end

--[[
params = {
    lockScreen = true,
    view = nil,
    ops = {},
    callback = function()end,
}
]]
function network.tcpSend(op, data, params)
    if network._socket_state == SOCKET_STATE.SocketError then
        local scene = display.getRunningScene()
        if scene.winManager:findWinByName("ErrorCodeWin") == nil then
            scene:getChildByName("ViewBase"):openWin("ErrorCodeWin",-1)
        end
        return
    end
    local data = msgPack.pack(data)
    socket:send(op, data)

    params = params or {}
    network.tcpListeners[#network.tcpListeners + 1] = {view = params.view, ops = params.ops, callback = params.callback, type = "once"}

    if params.lockScreen ~= false then
        Helper.lockWindow()
    end
end

function network.tcpClose()
    network.tcpListeners = {}
    socket:close()
end

function network.addListener(view, ops, callback, tp)
    tp = tp or "persist"
    network.tcpListeners[#network.tcpListeners + 1] = {view = view, ops = ops, callback = callback, type = tp}
end

function network.dispatch(op, data)
    if op ~= msgids.GS_TimeSync_R then
        Helper.unlockWindow()
    end
    local success = (not data.ErrorCode or data.ErrorCode == 0)

    if success then
        -- 先发给model
        local DataMgr = require "app.models.init"
        DataMgr.handleMsg(op, data)
    else
        print("errorCode :", data.ErrorCode)
    end

    local needRemove = {}
    local count = #network.tcpListeners
    for idx = 1, count do
        local info = network.tcpListeners[idx]

        if info.view ~= nil and tolua.isnull(info.view) then
            needRemove[#needRemove + 1] = idx
        else
            if not info.ops then
                needRemove[#needRemove + 1] = idx
            else
                for _, v in pairs(info.ops) do
                    if v == op then

                        if success then
                            info.callback(op, data)
                        end

                        if info.type == "once" then
                            needRemove[#needRemove + 1] = idx
                        end

                        break
                    end
                end
            end
        end
    end

    for idx = #needRemove, 1, -1 do
        table.remove(network.tcpListeners, needRemove[idx])
    end

    if not success then
        local tips = nil
        if data.ErrorCode == 302 or data.ErrorCode == 411 or data.ErrorCode == 1003 or data.ErrorCode == 1103 then
            tips = true
        end
        Helper.errorCodeHandle(data.ErrorCode, tips)
    end
end

function network.purge()
    socket:close()
    socket:release()
    Scheduler.unscheduleGlobal(network.commonScheduler)
end

local function str_read_int32(str, idx)
    local b1, b2, b3, b4 = string.byte(str, idx, idx + 3)
    return b1 * (2 ^ 24) + b2 * (2 ^ 16) + b3 * (2 ^ 8) + b4
end

local function extract(msg)
    local op = str_read_int32(msg, 1)
    local data = msgPack.unpack(string.sub(msg, 5))
    return op, data
end

-- global function
 cc.exports.g_socket_dispatch = function(msgs)
    for _, msg in ipairs(msgs) do
        local op, data = extract(msg)
        network.dispatch(op, data)
    end
end

cc.exports.g_socket_event = function(state)
    network._socket_state = state
    if state == SOCKET_STATE.Connecting then

    else
        local reason = ""
        if state == SOCKET_STATE.ConnectTimeOut then
            reason = "ConnectTimeOut"
            network.sendConnect = false
        elseif state == SOCKET_STATE.Connected then
            reason = "Connected"
        elseif state == SOCKET_STATE.SocketError then
            reason = "SocketError"
            network.sendConnect = false
        end

        if network.connectCallback then
            network.connectCallback(reason)
            network.connectCallback = nil
        elseif state == SOCKET_STATE.SocketError then
            Helper.unlockWindow()
            --打开网络错误窗口
            local scene = display.getRunningScene()
            scene:getChildByName("ViewBase"):openWin("ErrorCodeWin",-1)
        end
    end
end

network.commonScheduler = Scheduler.scheduleGlobal(function()
    if network._socket_state == SOCKET_STATE.Connected then
        network.tcpSend(msgids.C_TimeSync, {}, {lockScreen=false})
    end
end, 6)

return network
