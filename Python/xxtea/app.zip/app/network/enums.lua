
local C = {}

---------------------------------------

--// 对象类型

C.ObjType_Currency = 1
C.ObjType_Hero     = 2
C.ObjType_Item     = 3
C.ObjType_Armor    = 4

function C.ObjectType(id)
    return math.floor(id / 10000)
end

--// 特殊货币

C.Diamond_Type = 102

C.Diamond_BaseId = C.Diamond_Type * 100
C.Diamond_MaxId  = C.Diamond_BaseId + 3
C.Gold           = 10100
C.PlayerExp      = 10300
C.AchvPoint      = 10303
C.Talent         = 10304
C.ArmorExp       = 10305
C.GldCoin        = 10501
C.ActivityScore  = 10600
C.ActMsShopScore = 10601
C.JbsCoin        = 10511
C.SoulCoin       = 30125

function C.IsDiamond(id)
    return math.floor(id/100) == C.Diamond_Type
end

--// 玩家计数器 (属于货币)

C.Cnt_WLevel_Dungeon            = 1000001
C.Cnt_WLevel_BuyDungeonPotion   = 1000002
C.Cnt_Arena_Pvp                 = 1000003
C.Cnt_Arena_BuyPvpPotion        = 1000004
C.Cnt_Tower_EliteChallenge      = 1000005
C.Cnt_Tower_BuyEliteChallenge   = 1000006
C.Cnt_BuyGold_Counter           = 1000007
C.Cnt_Act_RemainderCardPickCnt  = 1000011
C.Cnt_Act_BuyCardPickCnt        = 1000012
C.Cnt_Awake_ResetCnt            = 1000017
C.Cnt_Awake_BuyResetCnt         = 1000021
C.Cnt_GuildBoss_FightCnt        = 1000022
C.Cnt_WorldBoss_FightCnt        = 1000023
C.Cnt_WantedBoss_ChallengePoint = 1000024
C.Cnt_WantedBoss_DailyKillCnt   = 1000025
C.Cnt_HuntSoul_StrengthPoint    = 1000026
C.Cnt_HuntSoul_StrengthBuyCnt   = 1000027
C.Cnt_SummonSoul_BuyCnt         = 1000028
C.Cnt_WantedBossBuyCnt          = 1000029
C.Cnt_ZsdConsecrateCnt          = 1000030
C.Cnt_DevilSealFreshCnt         = 1000034
C.Cnt_DevilSealFightCnt         = 1000035
C.Cnt_Hhssl_StrengthPoint       = 1000036
C.Cnt_Hhssl_StrengthPointBuyCnt = 1000037
C.Cnt_Txws_BossNormalFightCnt   = 1000040
C.Cnt_Txws_BossDoubleFightCnt   = 1000041
C.Cnt_Sllx_Worship              = 1000042
C.Cnt_Txws_PvpBossFight         = 1000043
C.Cnt_Txws_PvpBossFightLeft     = 1000044
C.Cnt_GhostStep_ResetCnt        = 1000048
C.Cnt_GhostStep_BuyResetCnt     = 1000049
C.Cnt_OfferToken_Gold           = 1000050
C.Cnt_OfferToken_Gold_Buy       = 1000051
C.Cnt_OfferToken_SP             = 1000052
C.Cnt_OfferToken_SP_Buy         = 1000053
C.Cnt_OfferToken_XHS            = 1000054
C.Cnt_OfferToken_XHS_Buy        = 1000055
C.Cnt_BuyStrength_Counter       = 1000056
C.Cnt_FreeBuyGold_Counter       = 1000057
C.Cnt_FreeBuyStrength_Counter   = 1000058
C.Cnt_MineFF_ExchCount          = 1000059
C.Cnt_Tower_NormalSweepCnt      = 1000060
C.Cnt_ExploreBoxBuyCnt          = 1000061
C.Cnt_GuildHelp_GiveCnt         = 1000062



--// vip功能上限
C.Max_Vip_Cnt_DungeonCount                    = 2000001
C.Max_Vip_Cnt_BuyDungeonCount                 = 2000002
C.Max_Vip_Cnt_TowerEliteChallengeCount        = 2000004
C.Max_Vip_Cnt_BuyTowerEliteChallengeCount     = 2000005
C.Max_Vip_Cnt_PvpBasicCount                   = 2000006
C.Max_Vip_Cnt_BuyPvpCount                     = 2000007
C.Max_Vip_Cnt_BuyGoldCount                    = 2000008
C.Max_Vip_Cnt_BuyGoldCrit                     = 2000009
C.Max_Vip_Cnt_GJLootMaxTime                   = 2000010
C.Max_Vip_Cnt_ShopRefreshCount                = 2000011
C.Max_Vip_Cnt_WLevelAccRateCount              = 2000012
C.Max_Vip_Cnt_Act_BuyCardPickCnt              = 2000016
C.Max_Vip_Cnt_Awake_ResetCnt                  = 2000020
C.Max_Vip_Cnt_Awake_BuyResetCnt               = 2000023
C.Max_Vip_Cnt_GuildBoss_FightCnt              = 2000024
C.Max_Vip_Cnt_WorldBoss_FightCnt              = 2000025
C.Max_Vip_Cnt_WantedBoss_ChallengePoint       = 2000026
C.Max_Vip_Cnt_WantedBoss_DailyKillCnt         = 2000027
C.Max_Vip_Cnt_HuntSoul_StrengthPoint          = 2000028
C.Max_Vip_Cnt_HuntSoul_StrengthBuyCnt         = 2000029
C.Max_Vip_Cnt_SummonSoul_BuyCnt               = 2000030
C.Max_Vip_Cnt_WantedBossBuyCnt                = 2000031
C.Max_Vip_Cnt_Hhssl_StrengthPoint             = 2000032
C.Max_Vip_Cnt_Txws_BossNormalFightCnt         = 2000035
C.Max_Vip_Cnt_Txws_BossDoubleFightCnt         = 2000036
C.Max_Vip_Cnt_Sllx_Worship                    = 2000037
C.Max_Vip_Cnt_Txws_PvpBossFight               = 2000038
C.Max_Vip_Cnt_GhostStep_ResetCnt              = 2000042
C.Max_Vip_Cnt_GhostStep_BuyResetCnt           = 2000043
C.Max_Vip_Cnt_OfferToken_Gold                 = 2000044
C.Max_Vip_Cnt_OfferToken_Gold_Buy             = 2000045
C.Max_Vip_Cnt_OfferToken_SP                   = 2000046
C.Max_Vip_Cnt_OfferToken_SP_Buy               = 2000047
C.Max_Vip_Cnt_OfferToken_XHS                  = 2000048
C.Max_Vip_Cnt_OfferToken_XHS_Buy              = 2000049
C.Max_Vip_Cnt_GhostStep_SweepStep             = 2000050
C.Max_Vip_Cnt_ShopFreeRefreshCount            = 2000051
C.Max_Vip_Cnt_BuyStrengthCount                = 2000052
C.Max_Vip_Cnt_BuyStrengthCrit                 = 2000053
C.Max_Vip_Cnt_MineFF_ExchCount                = 2000054
C.Max_Vip_Cnt_Tower_NormalSweepCnt            = 2000055
C.Max_Vip_Cnt_ExploreBoxBuyCnt                = 2000056
C.Max_Vip_Cnt_GuildHelp_GiveCnt               = 2000057

      
C.Max_Rzzx_Cnt_EscortRefreshCar               = 2010001
C.Max_Rzzx_Cnt_EscortCar                      = 2010002
C.Max_Rzzx_Cnt_EscortRob                      = 2010003
C.Max_Rzzx_Cnt_DevilSealFreshCnt              = 2010004
C.Max_Rzzx_Cnt_DevilSealFightCnt              = 2010005


--// 道具类型

C.ItemType_SoulStone = 1
C.ItemType_Mat       = 2
C.ItemType_Usable    = 3
C.ItemType_Armor     = 4

function C.ItemType(t)
    return math.floor(t / 10)
end

function C.ArmorSlot(t)
    return t % 10
end

--// 关卡

C.WLevelType_Normal   = 1
C.WLevelType_Dungeon  = 2
C.WLevelType_Building = 3

C.DungeonStatus_Unlocked = 1
C.DungeonStatus_Passed   = 2

--// 通缉战斗类型

C.WantedFight_Normal    = 1
C.WantedFight_DoubleHit = 2

--// 排行榜类型

C.Rank_Level          = 101
C.Rank_BattleVal      = 102
C.Rank_Occupy         = 103
C.Rank_GuildLevel     = 104
C.Rank_GuildBattleVal = 105
C.Rank_Arena          = 107
C.Rank_WantedKill     = 108
C.Rank_WantedDamage   = 109
C.Rank_Tower          = 110
C.Rank_Achievement    = 111

-- // 公会

C.Guild_AMode_Lv    = 1
C.Guild_AMode_Apply = 2
C.Guild_AMode_Deny  = 3

C.Guild_LR_Leave   = 1
C.Guild_LR_Kick    = 2
C.Guild_LR_Destroy = 3

C.RK_Owner  = 1
C.RK_Vice1  = 2
C.RK_Vice2  = 3
C.RK_Mid1   = 4
C.RK_Mid2   = 5
C.RK_Low1   = 6
C.RK_Low2   = 7
C.RK_Member = 8

C.RKMode_Owner = 1 -- 独裁
C.RKMode_Ft    = 2 -- 竞争

-- // 聊天

C.ChatType_World   = 0
C.ChatType_Guild   = 1
C.ChatType_Private = 2

-- // 觉醒

C.Awake_Battle_Box_Power = 1 -- // 势力材料掉落
C.Awake_Battle_Box_Job   = 2 -- // 职业材料掉落

-- // 大富翁-摇骰子

C.Monopoly_DiceTypeNormal = 1 -- // 普通摇骰子
C.Monopoly_DiceTypeMagic  = 2 -- // 魔法骰子

-- // 活动排行
C.Act7DayRank_HeroRec    = 201
C.Act7DayRank_HeroTalent = 202
C.Act7DayRank_HeroStar   = 203
C.Act7DayRank_HeroAwake  = 204
C.Act7DayRank_Tower      = 205
C.Act7DayRank_WantedDmg  = 206
C.Act7DayRank_Power      = 207



---------------------------------------

return C
