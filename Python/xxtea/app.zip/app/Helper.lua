--Helper.lua

local Helper = {}
local self = Helper

local LOCK_ODER = 10000 --消息锁屏层级
local LOCK_MAX_TIME = 20 --锁屏最大时间
local ITEM_COLOR_IMAGE = {
    [1] = "public/public_frame_01.png",
    [2] = "public/public_frame_02.png",
    [3] = "public/public_frame_03.png",
    [4] = "public/public_frame_04.png",
    [5] = "public/public_frame_05.png",
    [6] = "public/public_frame_06.png",
    [7] = "public/public_frame_07.png",
}

local ITEM_COLOR_IMAGE_FRAGMENT = {
    [1] = "public/public_item_01.png",
    [2] = "public/public_item_02.png",
    [3] = "public/public_item_03.png",
    [4] = "public/public_item_04.png",
    [5] = "public/public_item_05.png",
    [6] = "public/public_item_06.png",
    [8] = "public/public_item_08.png",
}

local ARMORS_COLOR_IMAGE_FRAGMENT = {
    [1] = "public/public_stage_01.png",
    [2] = "public/public_stage_02.png",
    [3] = "public/public_stage_03.png",
    [4] = "public/public_stage_04.png",
    [5] = "public/public_stage_05.png",
    [6] = "public/public_stage_06.png",
}

local ARMORS_COLOR_LIGHT_FRAGMENT = {
    [1] = "public/public_quality_01.png",
    [2] = "public/public_quality_02.png",
    [3] = "public/public_quality_03.png",
    [4] = "public/public_quality_04.png",
    [5] = "public/public_quality_05.png",
    [6] = "public/public_quality_06.png",
}

local SOUL_COLOR_IMAGE_FRAGMENT = {
    [1] = "public/shouhuling-kuang1.png",
    [2] = "public/shouhuling-kuang2.png",
    [3] = "public/shouhuling-kuang3.png",
    [4] = "public/shouhuling-kuang4.png",
    [5] = "public/shouhuling-kuang5.png",
    [6] = "public/shouhuling-kuang6.png",
}


local HEAD_TITLE_PATH = {
    [1] = "#public/chenghao_shouzuo.png",
    [2] = "#public/chenghao_zunzhe.png",
    [3] = "#public/chenghao_yushou.png",
    [4] = "#public/chenghao_guishou.png",
}

local SSR = {
    ["R"] = "public/tongyong-s.png",
    ["SR"] = "public/tongyong-ss.png",
    ["SSR"] = "public/tongyong-sss.png",
    ["KKK"] = "public/tongyong-kkk.png",
}

local BOSS_HP_BAR_PATH = {
    "fight/zhandou-tiao2.png",-- 第一条血：红色；
    "fight/zhandou-tiao9.png",-- 第二条血：橙色；
    "fight/zhandou-tiao4.png",-- 第三条血：黄色；
    "fight/zhandou-tiao3.png",-- 第四条血：绿色；
    "fight/zhandou-tiao5.png",-- 第五条血：蓝色；
    "fight/zhandou-tiao6.png",-- 第六条血：紫色；
}

local HERO_CLS_TO_NAME = {
    "",
    "+1",
    "+2",
    "",
    "+1",
    "+2",
    "",
    "+1",
    "+2",
    "+3",
    "",
    "+1",
    "+2",
    "+3",
    "+4",
    "",
    "+1",
    "+2",
    "+3",
    "+4",
    "+5",
}

--错误消息处理
function Helper.errorCodeHandle(errorCode,tips)
    local scene = display.getRunningScene()
    scene:getChildByName("ViewBase"):openWin("ErrorCodeWin",errorCode)
end

--消息锁屏
function Helper.lockWindow(dontShowSpine, dontUnlockByMsg)
    if not self.dontUnlockByMsg then
        self.dontUnlockByMsg = dontUnlockByMsg
    end
    if self.isLockWin then
        return
    end
    local scene = display.getRunningScene()
    if not scene then return end
    --拓展参数
    local params = params or {}
    self.unlockWindow()
    self.isLockWin = true
    local SpineManager = require "sandglass.core.SpineManager"
    self.lockLayer = display.newLayer():addTo(scene,LOCK_ODER)
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(true)
    listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(handler(self, function() end), cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(handler(self, function() end), cc.Handler.EVENT_TOUCH_ENDED)
    
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.lockLayer)

    if not dontShowSpine and not self.dontUnlockByMsg then
        self.lockLayer:runAction(
            cc.Sequence:create(
                cc.DelayTime:create(2),
                cc.CallFunc:create(function()
                    local load_ = SpineManager.createAnimation("public/load",1)
                    display.align(load_,display.CENTER,display.cx,display.cy)
                    load_:playAnimation("idle", -1)
                    cc.LayerColor:create(cc.c4b(0,0,0,200)):align(display.LEFT_BOTTOM, 0, 0):addTo(self.lockLayer, -1)
                    self.lockLayer:addChild(load_)

                    self.lockLayer:actionScheduleInterval(function()
                        self.unlockWindow(true)
                        --打开网络错误窗口
                        local scene = display.getRunningScene()
                        scene:getChildByName("ViewBase"):openWin("ErrorCodeWin",-1)
                    end,LOCK_MAX_TIME)
                end)
            )
        )
    end

end

function Helper.unlockWindow(isError, force)
    if self.dontUnlockByMsg and not force then
        return
    else
        self.dontUnlockByMsg = false
    end
    if not isError then
        self.isLockWin = false
    end
    if not tolua.isnull(self.lockLayer) then
        self.lockLayer:stopAllActions()
        self.lockLayer:removeFromParent()
        self.lockLayer = nil
    end
end

function Helper.getTimeString(second,long,showDay)
    local WordDictionary = require "app.configs.WordDictionary"
    local allSecond = second

    local hour = math.modf(second / 3600)
    second = math.mod(second, 3600)
    local minute = math.modf(second / 60)
    second = math.mod(second, 60)

    local timeStr = ""

    local day = math.modf(hour / 24)
    if day >= 1 and showDay then
        if day > 41 then
            timeStr = WordDictionary[21531]
        else
            timeStr = timeStr .. day .. WordDictionary[21529]
            local sec = math.mod(allSecond, 3600*24)
            hour = math.modf(sec / 3600)
            timeStr = timeStr .. string.format("%02d", hour) .. WordDictionary[21530]
        end
        return timeStr
    end

    if hour ~= 0 or long then
        if long then
            timeStr = timeStr .. string.format("%02d", hour) .. ":"
        else
            timeStr = timeStr .. hour .. ":"
        end
    end

    if minute ~= 0 or long then
        local str = nil

        if hour ~= 0 or long then
            str = string.format("%02d", minute)
        else
            str = tostring(minute)
        end

        timeStr = timeStr .. str .. ":"
    end

    local str = nil

    if minute ~= 0 or long then
        str = string.format("%02d", second)
    else
        str = tostring(second)
    end

    timeStr = timeStr .. str

    return timeStr
end

function Helper.getTimeShortString(second)
    local allSecond = second

    second = math.mod(second, 3600)
    local minute = math.modf(second / 60)
    second = math.mod(second, 60)

    return string.format("%02d:%02d", minute, second)
end

function Helper.getHeroRarePath(rare)
    return SSR[string.upper(rare)]
end

function Helper.getBossBarPath(idx)
    local len = #BOSS_HP_BAR_PATH
    local _idx = idx % len
    if _idx == 0 then
        _idx = len
    end
    return BOSS_HP_BAR_PATH[_idx]
end

function Helper.greyFunc(obj,normal)
    local ShaderManager = require "sandglass.core.ShaderManager"
    local greyFunc = nil
    greyFunc = function(obj,normal) --灰化Node 包括子节点（如果是label 记得先调用getContentSize）
        if tolua.type(obj) == "ccui.Text" then
            if not obj.originColor then
                obj.originColor = obj:getTextColor()
                obj.originOutline = obj:getEffectColor()
                obj.getOutlineSize = obj:getOutlineSize()
            end
            if not normal then
                obj:getContentSize()
                obj:setTextColor(cc.c3b(200,200,200))
                -- obj:disableEffect()
                obj:enableOutline(cc.c3b(0,0,0), 1)
            elseif obj.originColor then
                obj:setTextColor(obj.originColor)
                obj:enableOutline(obj.originOutline, obj.getOutlineSize)
            end
        elseif obj.setGLProgram then
            local shaderName = ShaderManager.SHADER_GRAY
            if normal then
                shaderName = ShaderManager.SHADER_NORMAL
            end
            local shader = ShaderManager.loadShader(shaderName)
            obj:setGLProgram(shader)
        end

        obj = obj:getChildren()
        for m,n in pairs(obj) do
            greyFunc(n,normal)
        end
    end
    greyFunc(obj,normal)
end

function Helper.createClipSprite(bgPath, maskPath, bgScale,maskScale)
    --特殊处理下英雄头像来做玩家头像的情况？
    local bg = display.newSprite(bgPath)
    bg:setScale(bgScale or 1)
    bg:setScaleY(bg:getScaleY() * -1)
    local  mask = display.newSprite(maskPath)
    if maskScale then
        mask:setScale(maskScale)
    end
    mask:setScaleY(mask:getScaleY() * -1)
    
    local size = mask:getContentSize()
    mask:setPosition(cc.p(size.width/2, size.height/2))
    bg:setPosition(cc.p(size.width/2, size.height/2))

    bg:setBlendFunc({src = gl.DST_COLOR, dst = gl.ONE_MINUS_DST_COLOR})
    local render = cc.RenderTexture:create(size.width, size.height)
      
    local sprite = render:getSprite()
    sprite:setOpacityModifyRGB(false)
    local texture = sprite:getTexture()
    texture:setAntiAliasTexParameters()
    
    render:beginWithClear(0, 0, 0, 0)
    mask:visit()
    bg:visit()
    render:endToLua()
    
    local newSprite = cc.Sprite:createWithTexture(sprite:getTexture())
    newSprite:setOpacityModifyRGB(false)
 
    newSprite:setBlendFunc({src = gl.ONE, dst = gl.ONE_MINUS_SRC_ALPHA})
    return newSprite
end

function Helper.createGoodsNumLabel(obj,params)
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local numLabel = nil
    local params = params or {}
    local str = params.num or 1
    local goodsNumLabel = UILabel.new({
        text = tostring(str),
        font = params.font or "fonts/HYh3gj.ttf",
        color = params.color or CoreColor.WHITE,
        back = params.back or CoreColor.BLACK_191,
        size = params.size or 20,
    })
    goodsNumLabel:setName("goodsNumLabel")
    local numBg = display.newSprite("#public/bag-kuang-di.png")
    obj:addChild(numBg)
    display.align(numBg,display.BOTTOM_RIGHT,obj:getContentSize().width - 8,9)

    numBg:addChild(goodsNumLabel)
    if numBg:getContentSize().width >= goodsNumLabel:getContentSize().width then
        display.align(goodsNumLabel,display.CENTER,numBg:getContentSize().width / 2,numBg:getContentSize().height / 2)
    else
        display.align(goodsNumLabel,display.RIGHT_CENTER,numBg:getContentSize().width,numBg:getContentSize().height / 2)
    end

    return numLabel
end

function Helper.createEquipLevelLabel(obj,params)
    local level = params.level or 0
    local size = params.size or 20
    if level <= 0 then return end
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local numLabel = nil
    local params = params or {}
    local eLevelLabel = UILabel.new({
        text = level,
        color = cc.c3b(146,253,32),
        back = CoreColor.BLACK,
        size = size,
        backWidth = 2,
    })
    eLevelLabel:setName("eLevelLabel")

    display.align(eLevelLabel,display.TOP_LEFT,2, obj:getContentSize().height)
    obj:addChild(eLevelLabel,1)

    return eLevelLabel
end

function Helper.createEquipSmeltLabel(obj,params)
    local smeltLv = params.smeltLv or 0
    if smeltLv <= 0 then return end
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local numLabel = nil
    local params = params or {}
    local eLevelLabel = UILabel.new({
        text = smeltLv,
        color = cc.c3b(80, 149, 214),
        back = CoreColor.BLACK,
        size = 20,
        backWidth = 2,
    })
    eLevelLabel:setName("eSmeltLvLabel")

    display.align(eLevelLabel,display.TOP_RIGHT,obj:getContentSize().width - 2, obj:getContentSize().height)
    obj:addChild(eLevelLabel,1)

    return eLevelLabel
end

--获取货币或者道具资源路径
function Helper.getPathById(id)
    local currencyConf = require "app.configs.currency"
    if currencyConf[id] then
        return "icon/currency/" .. currencyConf[id].icon .. ".png"
    end

    local itemConf = require "app.configs.item"
    if itemConf[id] then
        return "icon/item/" .. itemConf[id].icon .. ".png"
    end

    return nil
end

function Helper.createGoldItem(params)
    local itemConf = require "app.configs.item"
    local currencyConf = require "app.configs.currency"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local id = params.id
    local scale = params.scale or 1
    local data = currencyConf[id]
    local values = {isPlist = true,swallowTouches = false} 
    values.tipsProto = require "app.CommonTip"
    values.tipsParam = {type = 1, id = id}
    values.isPlist = params.isPlist

    local frame = UIImageBox.new(self.getPathById(id),nil,values)
    frame:setScale(scale)

    return frame
end

--创建道具图标
function Helper.createGoodsItem(params)
    local itemConf = require "app.configs.item"
    local currencyConf = require "app.configs.currency"
    local heroConf = require "app.configs.hero"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local SpineManager = require "sandglass.core.SpineManager"
    local roleConf = require "app.configs.role"

    local onClick = params.onClick
    local id = params.id
    local num = params.num
    local shortNum = (num ~= nil) and Helper.getShortNum(num) or nil

    if not params.showOne then
        if num == 1 then num = nil end
    end
    local level = params.level
    local scale = params.scale or 1
    local alreadyEquipped = params.already
    local locked = params.locked
    local buyNum = params.buyNum or 0
    local data = itemConf[id] or currencyConf[id]

    local haveTip = true
    if params.haveTip == false then 
        haveTip = false
    end
    local isHero = false
    if not data then
        if id > 2 ^ 32 then
            local heroId = id % (2 ^ 32)
            local cData = heroConf[heroId]
            if cData then
                id = cData.soulShardID
                shortNum = cData.fragmentDecompose
                data = itemConf[id]
            else
                print("error:can't find id : " .. id .. "in itemConf,currencyConf,heroConf")
            end
        else
            if heroConf[id] then
                data = heroConf[id]
                data.icon = roleConf[data.role].head
                isHero = true
                haveTip = false
                shortNum = nil
            else
                print("error:can't find id : " .. id .. "in itemConf,currencyConf,heroConf")
            end
        end
    end

    if not data then return nil end
    local color = params.color or data.color or 1
    local decorate = params.decorate or data.decorate or nil

    local imgFrameName = "icon/item/" .. data.icon .. ".png"
    local colorImage = ITEM_COLOR_IMAGE[color]
    local shadePath = params.shadePath or "#public/public_shade_01.png"
    local showSource = params.showSource


    if not data.type then
        data.type = 0
    end
    if data.type == 10 then
        shadePath = "#public/public_item_07.png"
        imgFrameName = "icon/head/" .. data.icon .. ".png"
        colorImage = ITEM_COLOR_IMAGE_FRAGMENT[color]
    elseif data.type == 70 then--魂器碎片
        shadePath = "#public/public_item_07.png"
        imgFrameName = "icon/head/" .. data.icon .. ".png"
        colorImage = ITEM_COLOR_IMAGE_FRAGMENT[color]
    elseif data.type == 0 then
        imgFrameName = "icon/currency/" .. data.icon .. ".png"
    elseif data.type >= 41 and data.type <= 47 then
        shadePath = "#public/public_stage_07.png"
        colorImage = ARMORS_COLOR_IMAGE_FRAGMENT[color]
    elseif data.type == 100 then --英雄
        imgFrameName = "icon/head/" .. data.icon .. ".png"
        colorImage = ITEM_COLOR_IMAGE[params.color or data.color - 398]
    elseif data.type >= 501 and data.type <= 511 then --守护灵
        imgFrameName = "icon/soul/" .. data.icon .. ".png"
        colorImage = ITEM_COLOR_IMAGE[color]
        shadePath = "#public/shouhuling-zhezhao.png"
    elseif data.type >= 1000 and data.type <= 1200 then --宝石
        colorImage = "list/baoshi-baoshidi.png"
        shadePath = "#public/public_stage_07.png"
        decorate = 2
    end

    local values = {isPlist = true,swallowTouches = params.swallowTouches or false, ableGLProgram = params.ableGLProgram or true}
    values.ableGLProgram = params.ableGLProgram
    if haveTip then 
        values.tipsProto = require "app.CommonTip"
        if data.type > 80 and data.type <= 84  then --符文
            values.tipsParam = {type = 5, id = id, seq = params.seq}
        else
            values.tipsParam = {type = 1, id = id, showNum = params.showTipsNum}
        end
    end
    if showSource then
        onClick = function()
            display.getRunningScene():getChildByName("ViewBase"):openWin("SourceWin",id,buyNum)
        end
    end

    if isHero then
        onClick = function()
            display.getRunningScene():getChildByName("ViewBase"):openWin("HeroDetailWin",id)
        end
    end

    if itemConf[id] and (itemConf[id].func == "itemChoose" or itemConf[id].func == "heroSkin") and not onClick and not params.notShowSelWin then
        onClick = function()
            local win = display.getRunningScene().winManager:findWinByName("ItemSelectWin")
            if not win then
                display.getRunningScene():getChildByName("ViewBase"):openWin("ItemSelectWin",id)
            end
        end
    end

    local frame = nil
    if data.type >= 41 and data.type <= 47 then
        values.swallowTouches = false
        frame = UIImageBox.new("public/public_frame_07.png",onClick,values)
        frame:setScale(scale)

        local perF = display.newSprite("#" .. colorImage)
        perF:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(perF)

        imgFrameName = "icon/rune/" .. data.icon .. ".png"
        local cf = Helper.createClipSprite("#" .. ARMORS_COLOR_LIGHT_FRAGMENT[color], shadePath,0.9)
        -- local cf = display.newSprite("#" .. ARMORS_COLOR_LIGHT_FRAGMENT[color] )
        cf:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(cf)

        local perF = display.newSprite("#public/public_frame_07.png")
        perF:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(perF,-1)

        --装备角标
        if data.type ~= 47 then
            cc.SpriteFrameCache:getInstance():addSpriteFrames("heroList/heroList.plist")
            local path = string.format("#heroList/yingxiong-jiantou-0%d.png",(data.type-40) )
            local corner = display.newSprite(path)
            corner:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
            frame:addChild(corner)
        end
    else
        frame = UIImageBox.new(colorImage,onClick,values)
        frame:setScale(scale)
    end

    local itemImage = Helper.createClipSprite(imgFrameName, shadePath,1)
    display.align(itemImage,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(itemImage)

    if data.type >= 41 and data.type <= 47 then
        if level then
            if level > 0 then
                Helper.createEquipLevelLabel(itemImage,{level = level})
            end
            if shortNum then
                Helper.createGoodsNumLabel(itemImage,{num = shortNum})
            end
        elseif shortNum then
            Helper.createEquipLevelLabel(itemImage,{level = shortNum})
        end

        if params.smeltLv and params.smeltLv > 0 then
            Helper.createEquipSmeltLabel(itemImage, {smeltLv = params.smeltLv})
        end

        if params.star then
            Helper.createEquipStar(itemImage, {star = params.star, offsetY = 15, id = id})
        end

        if locked then
            local lockImg = display.newSprite("#public/public_slat_30.png")
            display.align(lockImg,display.LEFT_TOP,0,frame:getContentSize().height)
            lockImg:setName("lockImg")
            frame:addChild(lockImg)
        end

        if alreadyEquipped then --如果是已装备，使用遮罩
            local yzbBack = display.newSprite(shadePath)
            yzbBack:setColor(cc.c4b(0,0,0))
            yzbBack:setOpacity(127)
            yzbBack:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
            frame:addChild(yzbBack)

            local yzbLabelImg = display.newSprite("#public/public_state_02.png")
            yzbLabelImg:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
            frame:addChild(yzbLabelImg)
        end
    elseif data.type >= 1000 and data.type <= 1200 then
        if level and level > 0 then
            Helper.createGemLevelLabel(itemImage,{level = level})
        end
        if shortNum and shortNum > 1 then
            Helper.createGoodsNumLabel(itemImage,{num = shortNum})
        end
    elseif shortNum then
        Helper.createGoodsNumLabel(frame,{num = shortNum})
    end

    if data.type == 10 then
        local soulImg = display.newSprite("#public/public_soul_01.png")
        frame:addChild(soulImg)
        soulImg:setPosition(frame:getContentSize().width - 15,frame:getContentSize().height - 15)
    end

    --流光特效
    if decorate and decorate ~= 0 then
        local effectNums = {1,2,4,8,16}
        local useAnim = {}
        for k,v in ipairs(effectNums) do
            if bit.band(decorate,v) > 0 then
                table.insert(useAnim,"idle" .. k)
            end
        end
        for k,v in ipairs(useAnim) do
            local anim = SpineManager.createAnimation("public/ui_wupinguang",1)  
            frame:addChild(anim)
            anim:setPosition(frame:getContentSize().width * 0.5,frame:getContentSize().height * 0.5)
            anim:playAnimation(v, -1)
        end

    end

    --加成角标
    if params.additional then
        local c = require "app.configs.constants"
        local WordDictionary = require "app.configs.WordDictionary"
        display.loadSpriteFrames("embattle/embattle.plist", "embattle/embattle.png")

        frame.ableGLProgram = false
        Helper.greyFunc(frame, params.additional ~= c.ADDITIONAL_TYPE.onlyShow)

        local path = "#embattle/zhandou-di6.png"
        local wordStr = 10171
        local outlineColor = cc.c3b(159, 106, 12)
        if params.cardType == 1 then
            path = "#embattle/zhandou-di5.png"
            wordStr = 10170
            outlineColor = cc.c3b(106, 9, 111)
        end

        local sp = display.newSprite(path)
            :align(display.RIGHT_TOP, frame:getContentSize().width+10, frame:getContentSize().height+10)
            :addTo(frame)
            :setScale(1.1)
        local txt = ccui.Text:create(WordDictionary[wordStr], "fonts/HYh3gj.ttf", 17)
            :align(display.CENTER, 28, 28)
            :addTo(sp)
            :setRotation(40)
            :setTextColor(cc.c3b(255, 255, 255))
            :enableOutline(outlineColor, 2)
    end

    return frame
end

function Helper.createRuneItem(params)
    local itemConf = require "app.configs.item"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local id = params.id
    local seq = params.seq
    local swallowTouches = true
    local iData = itemConf[id]
    local imgFrameName = "icon/item/" .. iData.icon .. ".png"
    if params.swallowTouches == false then
        swallowTouches = false
    end

    local values = {swallowTouches = swallowTouches, ableGLProgram = params.ableGLProgram or true}

    local haveTip = true
    if params.haveTip == false then 
        haveTip = false
    end
    if haveTip then
        values.tipsProto = require "app.CommonTip"
        values.tipsParam = {type = 5, id = id, seq = seq}
    end

    local frame = UIImageBox.new(imgFrameName, function()
        if params.callback then
            params.callback()
        end
    end, values)
    frame:setScale(params.scale or 1)
    return frame
end

--创建英雄养成装备图标
function Helper.createArmorItem(armorData, params)
    local itemConf = require "app.configs.item"
    local suitConf = require "app.configs.suit"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local globalPublicConf = require "app.configs.globalPublic"

    local scale =  1
    if params and params.scale then
        scale = params.scale
    end
    local id = armorData.id
    local level = armorData.level
    local data = itemConf[id]
    local imgFrameName = "icon/rune/" .. data.icon .. ".png"
    local shadePath = "#public/public_stage_07.png"

    local colorImage = ARMORS_COLOR_IMAGE_FRAGMENT[data.color]
    local values = {isPlist = true,swallowTouches = false}
    local frame = UIImageBox.new(colorImage,nil,values)
    frame:setScale(scale)

    local cf = Helper.createClipSprite("#" .. ARMORS_COLOR_LIGHT_FRAGMENT[data.color], shadePath,1)
    cf:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(cf)

    local itemImage = Helper.createClipSprite(imgFrameName, shadePath,1)
    display.align(itemImage,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(itemImage)

    self.createEquipLevelLabel(frame,{level = level})
    self.createEquipSmeltLabel(frame,{smeltLv = armorData.smtLv})
    --装备角标
    if data.type and data.type >= 41 and data.type <= 46 then
        cc.SpriteFrameCache:getInstance():addSpriteFrames("heroList/heroList.plist")
        local path = string.format("#heroList/yingxiong-jiantou-0%d.png",data.type - 40)
        local corner = display.newSprite(path)
        corner:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(corner)
    end

    if params and params.showStar then
        if data.color >= globalPublicConf[1].equipStarLimit[1].down and data.color <= globalPublicConf[1].equipStarLimit[1].up then
            self.createEquipStar(frame, {star = armorData.star, id = id})
        end
    end

    return frame
end

function Helper.createEquipStar(frame, params)
    if not params.star or params.star == 0 then
        return
    end

    local itemConf = require "app.configs.item"
    local globalPublicConf = require "app.configs.globalPublic"
    local id = params.id
    if itemConf[id].color >= globalPublicConf[1].equipStarLimit[1].down and itemConf[id].color <= globalPublicConf[1].equipStarLimit[1].up then
        local starLv = params.star
        local width = frame:getContentSize().width / 5
        local offsetY = params.offsetY or 0
        local offsetX = {4,2,0,-2,-4}

        local paths = {
            "#public/zhuangbei-xing2.png",--1-5亮
            "#public/zhuangbei-xing3.png",--6-10亮
            "#public/zhuangbei-xing1.png",--暗
        }

        local temp_1,temp_2
        temp_1,temp_2 =  math.modf(starLv / 5)
        local starLight,starNormal
        if temp_1 > 0 then
            starLight = temp_2 * 5
            if temp_2 == 0 and temp_1 > 1 then
                starLight = 5
            end
            starNormal = 5 - starLight
        else
            starLight = 0
            starNormal = starLv
        end
        --local stage = math.ceil(starLv / 5)
        --local stageLv = (starLv - 1) % 5 + 1
        for i = 1, 5 do
            local spStar = nil
            if starLight > 0 then 
                if i < starLight + 1 then
                    spStar = display.newSprite(paths[2])
                else
                    spStar = display.newSprite(paths[1])
                end
            else
                if i <= starNormal then 
                    spStar = display.newSprite(paths[1])
                else
                    spStar = display.newSprite(paths[3])
                end
            end
            -- if i <= stageLv then
            --     spStar = display.newSprite(paths[stage] or paths[#paths])
            -- else
            --     if
            --     spStar = display.newSprite(paths[#paths])
            -- end

            spStar:setScale(width/spStar:getContentSize().width)
            frame:addChild(spStar)
            display.align(spStar, display.LEFT_TOP, (i-1)*width + offsetX[i], offsetY)
        end
    end
end

--适用于界面已拼星(sprite) 刷新星级状态
function Helper.updateEquipStar(parent, prefix, star, id)
    local paths = {
        -- "public/zhuangbei-xing1.png",--暗
        "public/zhuangbei-xing2.png",--1-5亮
        "public/zhuangbei-xing3.png",--6-10亮

        "public/zhuangbei-xing1.png",--暗
    }

    local stage = 1
    local stageLv = 0
    if star > 0 then
        stage = math.ceil(star / 5)--阶段
        stageLv = (star - 1) % 5 + 1--阶段等级
    end

    --是否有星级
    local itemConf = require "app.configs.item"
    local globalPublicConf = require "app.configs.globalPublic"
    local noStar = itemConf[id].color < globalPublicConf[1].equipStarLimit[1].down or itemConf[id].color > globalPublicConf[1].equipStarLimit[1].up

    for i=1,5 do
        local sp_star = parent:getChildByName(prefix .. i)
        if noStar then
            sp_star:setVisible(false)
        else
            local path = ""
            if i <= stageLv then
                path = paths[stage]
            else
                -- path = paths[#paths]
                local stage = stage-1 > 0 and stage-1 or #paths
                path = paths[stage]
            end
            sp_star:setVisible(true)
            sp_star:setSpriteFrame(path)
        end
    end
end

--计算装备评分
function Helper.armorScore(armorData)
    return armorData.atkPwr
    -- local score = 0
    -- local itemConf = require "app.configs.item"
    -- local attributeConf = require "app.configs.attribute"
    -- local armorDataId = armorData.id or armorData.Id
    -- local cData = itemConf[armorDataId]

    -- for k,v in pairs(cData.basicProperty) do
    --     local defaultAttri = attributeConf[v.id]
    --     score = score + defaultAttri.equipPower * (armorData.basicVal or v.val)
    -- end
    
    -- for k,v in pairs(armorData.RProps or {}) do
    --     local defaultAttri = attributeConf[v.id]
    --     score = score + defaultAttri.equipPower * v.val
    -- end

    -- for k,v in pairs(cData.attachAttrId or {}) do
    --     local defaultAttri = attributeConf[v.id]
    --     score = score + defaultAttri.equipPower * v.val
    -- end

    -- return math.floor(score)
end

--创建英雄技能图标  以及tips
function Helper.createSkillIcon(params)
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local skillConf = require "app.configs.skill"
    local params = params or {}
    local id = params.id or 0
    local scale = params.scale or 1
    local onClick = params.onClick
    local inScrollView = params.inScrollView or false
    local touchEvent = params.touchEvent or false
    local haveTip = true
    local isAoyi = params.aoyi
    if params.haveTip == false then 
        haveTip = false
    end
    local showStatus = true
    if params.showStatus == false then
        showStatus = false
    end
    local values = {swallowTouches = inScrollView, touchEvent = touchEvent}
    values.ableGLProgram = params.ableGLProgram
    if haveTip then 
        values.tipsProto = require "app.CommonTip"
        values.tipsParam = {type = 2, id = id, cls = params.cls or 1, showStatus = showStatus, aoyi = isAoyi, notShowUnlock = params.notShowUnlock}
    end

    local imgName = "icon/skill/" .. skillConf[id].icon .. ".png"

    local icon = UIImageBox.new(imgName,onClick, values)
    icon:setScale(scale)
    return icon
end

--英雄列表排序
function Helper.sortHeroList(tData)
    if table.nums(tData) <= 1 then return end
    local init = require "app.models.init"
    local ItemModel = init.ItemModel
    table.sort(tData,function(a,b)
        if a.useData and b.useData then
            if a.useData.level ~= b.useData.level then
                return a.useData.level > b.useData.level
            else
                if a.useData.star ~= b.useData.star then
                    return a.useData.star > b.useData.star
                else
                    if a.useData.cls ~= b.useData.cls then
                        return a.useData.cls > b.useData.cls
                    else
                        return a.sequence > b.sequence
                    end
                end
            end
        elseif a.useData and not b.useData then
            return true
        elseif not a.useData and b.useData then
            return false
        elseif not a.useData and not b.useData then
            local af,bf = a.fragmentSummon,b.fragmentSummon
            local as,bs = ItemModel:getItem(a.soulShardID),ItemModel:getItem(b.soulShardID)
            local au,bu = as and as.number or 0 , bs and bs.number or 0
            local ac,bc = au >= af , bu >= bf
            if (ac and bc) or (au == bu) then
                return a.sequence > b.sequence
            else
                return au > bu
            end
        end
    end)
end

--获取装备属性值
function Helper.getArmorAttri(armorData)
    local c = require "app.configs.constants"
    local itemConf = require "app.configs.item"
    local attributeConf = require "app.configs.attribute"
    local strList = {}
    local cData = itemConf[armorData.id]

    local dFunc = function(basicProperty)
        local defaultAttri = attributeConf[basicProperty.id]
        local valueType = defaultAttri.valueType
        local val = basicProperty.val
        if valueType == c.ArmorAttribute.integers then
            val = math.floor(val)
        elseif valueType == c.ArmorAttribute.percentages then
            val = math.floor(val * 100)
        elseif valueType == c.ArmorAttribute.decimalOne then
            val = math.floor(val * 10) / 10
        end
        if not strList[defaultAttri.attributeId] then
            strList[defaultAttri.attributeId] = val
        else
            strList[defaultAttri.attributeId] = strList[defaultAttri.attributeId] + val
        end
    end

    dFunc({id = cData.basicProperty[1].id, val = armorData.basicVal})
    for k,v in ipairs(armorData.RProps or {}) do
        dFunc(v)
    end
    for k,v in ipairs(cData.attachAttrId or {}) do
        dFunc(v)
    end
    for k,v in ipairs(cData.smeltAttrId or {}) do
        dFunc({id = v.id, val = v.val * armorData.smtLv})
    end
    if cData.equipStarAttrId[armorData.star] then
        dFunc({id = cData.equipStarAttrId[armorData.star].id, val = cData.equipStarAttrId[armorData.star].val})
    end

    return strList
end

--属性文字
function Helper.showAttriLabel(armorData)
    local c = require "app.configs.constants"

    local itemConf = require "app.configs.item"
    local attributeConf = require "app.configs.attribute"
    local strList = {}
    local cData = itemConf[armorData.id]

    local dFunc = function(basicProperty)
        local defaultAttri = attributeConf[basicProperty.id]
        local valueType = defaultAttri.valueType
        local val = basicProperty.val
        if valueType == c.ArmorAttribute.integers then
            val = math.floor(val)
        elseif valueType == c.ArmorAttribute.percentages then
            val = math.floor(val * 100) .. "%"
        elseif valueType == c.ArmorAttribute.decimalOne then
            val = math.floor(val * 10) / 10
        end

        table.insert(strList,string.format(defaultAttri.des1,val))
        -- strList[1] = string.format(defaultAttri.des1,val)
    end
    -- dFunc(cData.basicProperty[1])
    dFunc({id = cData.basicProperty[1].id, val = armorData.basicVal})
    for k,v in ipairs(cData.attachAttrId or {}) do
        dFunc(v)
    end
    for k,v in ipairs(armorData.RProps or {}) do
        dFunc(v)
    end
    return strList
end

--获取属性值
function Helper.getAttriValue(id,val,showDecimal)
    local c = require "app.configs.constants"

    local attributeConf = require "app.configs.attribute"
    local defaultAttri = attributeConf[id]
    local valueType = defaultAttri.valueType
    local val = val + 0.000001
    if valueType == c.ArmorAttribute.integers then
        if showDecimal then
            val = math.floor(val * 1000)
            val = val/1000
        else
            val = math.floor(val)
        end
    elseif valueType == c.ArmorAttribute.percentages then
        if showDecimal then
            val = math.floor(val * 10000)
            val = val/100 .. "%"
        else
            val = math.floor(val * 100) .. "%"
        end
    elseif valueType == c.ArmorAttribute.decimalOne then
        val = math.floor(val * 10) / 10
    end

    return val
end


--套装属性文字
function Helper.showSuitLabel(armorCData, hasColor)
    local suitConf = require "app.configs.suit"
    local WordDictionary = require "app.configs.WordDictionary"
    local c = require "app.configs.constants"
    local suit = armorCData.suit
    local strList = {}
    if hasColor then
        strList[1] = string.format(WordDictionary[20138], suitConf[suit].name, c.ITEM_COLOR_16[suitConf[suit].color], suitConf[suit].twoSuit)
        strList[2] = string.format(WordDictionary[20139], suitConf[suit].name, c.ITEM_COLOR_16[suitConf[suit].color], suitConf[suit].fourSuit)
    else
        strList[1] = suitConf[suit].name .. "（2）:" .. suitConf[suit].twoSuit
        strList[2] = suitConf[suit].name .. "（4）:" .. suitConf[suit].fourSuit
    end

    return strList
end

--属性数值取整或百分比或保留小数点1位
function Helper.arrangementAttrNumber(number,valueType,showDecimal)
    local c = require "app.configs.constants"

    local mt = math.floor
    if number < 0 then
        mt = math.ceil
    end
    local nos = nil
    if valueType == c.ValueType.integer then
        if showDecimal then
            nos = mt(number * 100)
            nos = nos/100
        else
            nos = mt(number)
        end
    elseif valueType == c.ValueType.percentage then
        if showDecimal then
            nos = mt(number * 10000)
            nos = nos/100 .. "%"
        else
            nos = mt(number * 100) .. "%"
        end
    elseif valueType == c.ValueType.pointOne then
        nos = mt(number * 10) / 10
    end
    return nos
end

--获取装备套装技能ID
function Helper.getHeroArmorSkillID(armorsID)
    local itemConf = require "app.configs.item"
    local suitConf = require "app.configs.suit"
    local skillID = {}

    local groupList = {}
    for _,id in pairs(armorsID or {}) do
        local suit = itemConf[id].suit
        if not groupList[suit] then
            groupList[suit] = {cData = suitConf[suit], index = 1}
        else
            groupList[suit].index = groupList[suit].index + 1
        end
    end

    for k,v in pairs(groupList) do
        for m,n in pairs(v.cData.skill or {}) do
            if v.index >= n.n then
                table.insert(skillID,n.skill)
            end
        end
    end

    return skillID
end

--创建进度条光标
function Helper.createLoadingBarCursor(loadingBar,nextPercent,isFlip)
    local _nextPercent = nil
    if nextPercent then
        _nextPercent = nextPercent > 100 and 100 or nextPercent
    end
    if tolua.isnull(loadingBar) then return end
    local percent = loadingBar:getPercent()
    if not loadingBar:getChildByName("cursor") then
        local lSize = loadingBar:getContentSize()
        local cursor = display.newSprite("#public/public_effect_01.png")

        local cSize = cursor:getContentSize()
        local cScale = lSize.height / cSize.height
        cursor:setName("cursor")
        cursor:setScaleY(cScale)
        if isFlip then
            cursor:setFlippedX(true)
            display.align(cursor,display.BOTTOM_LEFT,lSize.width - (percent / 100) * lSize.width - 2,0 )
        else
            display.align(cursor,display.BOTTOM_RIGHT,(percent / 100) * lSize.width + 2,0 )
        end
        loadingBar:addChild(cursor)
    end
    if _nextPercent then
        self.updateLoadingBarCursor(loadingBar,_nextPercent,isFlip)
    end
end

--更新进度条光标位置（平滑滚动）
function Helper.updateLoadingBarCursor(loadingBar,nextPercent,isFlip)
    if tolua.isnull(loadingBar) or not nextPercent then return end
    local cursor = loadingBar:getChildByName("cursor")
    if not cursor then return end
    local percent = loadingBar:getPercent()
    local time = 20
    local perP = (nextPercent - percent) / time
    if perP == 0 then return end
    loadingBar:stopAllActions()
    local lSize = loadingBar:getContentSize()
    loadingBar:actionScheduleInterval(function()
        percent = percent + perP
        if perP >= 0 then
            if percent >= nextPercent then
                percent = nextPercent
                loadingBar:stopAllActions()
            end
        else
            if percent <= nextPercent then
                percent = nextPercent
                loadingBar:stopAllActions()
            end
        end
        loadingBar:setPercent(percent)
        if isFlip then
            cursor:setPosition(lSize.width - (percent / 100) * lSize.width - 2,0)
        else
            cursor:setPosition((percent / 100) * lSize.width + 2,0)
        end
        -- cursor:setPosition((percent / 100) * lSize.width,0)
    end,0.01)

end

--创建玩家头像
function Helper.createPlayerHead(params, callback)
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local playerTitleConf = require "app.configs.playerTitle"
    local frame = params.frame
    local headId = params.headId
    local frameId = params.frameId
    local level = params.level
    local title = params.title
    
    if tolua.type(frame) == "ccui.ImageView" and callback then
        UIImageBox.new(frame,function()
            if callback then
                callback()
            end
        end, {ableGLProgram = false})
    end
    local width = frame:getContentSize().width
    local height = frame:getContentSize().height

    frame:removeAllChildren()
    if headId then
        local playerHeadConf = require "app.configs.playerHead"
        local headData = playerHeadConf[headId]
        local confPath = headData.icon
        local imgName = "icon/head/" .. confPath .. ".png"
        local isExist = cc.FileUtils:getInstance():isFileExist(imgName)
        if not isExist then
            imgName = "icon/item/" .. confPath .. ".png"
        end
        -- local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png")
        local headImg = display.newSprite(imgName)
        headImg:setScale(0.83)
        display.align(headImg,display.CENTER, width * 0.5 , height * 0.5)
        frame:addChild(headImg, -1)

        if headData.res and headData.res ~= "" then
            local SpineManager = require "sandglass.core.SpineManager"
            local resArr = string.split(headData.res,"|")
            for _, path in pairs(resArr) do
                local anim = SpineManager.createAnimation("public/"..path,1)
                anim:playAnimation("idle",-1)
                frame:addChild(anim)
                display.align(anim,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
            end
        end
    end

    if frameId then
        local playerFrameConf = require "app.configs.playerFrame"
        local conf = playerFrameConf[frameId]
        local confPath = conf.icon
        local imgName = "icon/frame/" .. confPath .. ".png"
        if conf.res and conf.res ~= "" then
            local SpineManager = require "sandglass.core.SpineManager"
            local resArr = string.split(conf.res,"|")
            for _, path in pairs(resArr) do
                local anim = SpineManager.createAnimation("public/"..path,1)
                anim:playAnimation("idle",-1)
                frame:addChild(anim)
                display.align(anim,display.CENTER, width * 0.5 , height * 0.5+5)
            end

            imgName = "icon/frame/frame_initial_01.png"
            if tolua.type(frame) == "cc.Sprite" then
                frame:setTexture(imgName)
            elseif frame.setImage then
                frame:setImage(imgName)
            elseif frame.loadTexture then
                frame:loadTexture(imgName,ccui.TextureResType.localType)
            end
        else
            if tolua.type(frame) == "cc.Sprite" then
                frame:setTexture(imgName)
            elseif frame.setImage then
                frame:setImage(imgName)
            elseif frame.loadTexture then
                frame:loadTexture(imgName,ccui.TextureResType.localType)
            end
        end
    end
    
    if level then
        local levelImg = display.newSprite("#public/list_slat_04.png")
        display.align(levelImg,display.CENTER, width * 0.2 , height * 0.8)
        frame:addChild(levelImg)
        
        local lvImgSize = levelImg:getContentSize()
        local lvStr = UILabel.new({
            text = level,
            size = 20,
            back = CoreColor.BLACK,
        })
        display.align(lvStr,display.CENTER, lvImgSize.width/2 , lvImgSize.height/2)
        levelImg:addChild(lvStr)
    end
    if title and (HEAD_TITLE_PATH[title] or playerTitleConf[title]) then
        print(HEAD_TITLE_PATH[title],"#public/"..playerTitleConf[title].icon..".png",playerTitleConf[title].icon)
         local titleImg = display.newSprite(HEAD_TITLE_PATH[title] or "#public/"..playerTitleConf[title].icon..".png")
        display.align(titleImg, display.CENTER, width * 0.5 , height * 0.2)
        titleImg:setScale(0.5)
        frame:addChild(titleImg)
    end

end

--dontShowLabel == true  就不显示label
function Helper.getOpenState(openID,dontShowLabel)
    local openConf = require "app.configs.open"
    local init = require "app.models.init"
    local c = require "app.configs.constants"
    local MoveLabel = require "sandglass.ui.MoveLabel"
    local WordDictionary = require "app.configs.WordDictionary"
    local PlayerModel = init.PlayerModel
    local LevelModel = init.LevelModel
    local desStr = ""
    local isOpen = false
    local data = openConf[openID]
    local scene = display.getRunningScene()

    if not data then
        return true
    end

    if data.unOpen == 1 then
        if not dontShowLabel then
            MoveLabel.new(WordDictionary[21535])
        end
        return false
    end

    if data.p1 and data.p1 ~= 0 then
        local levelStatus = LevelModel:getLevel(data.p1)
        if data.cond == 110 then
            if levelStatus == c.LevelStatus.PASSED or levelStatus == c.LevelStatus.EXPLORE then
                isOpen = true
            else
                desStr = data.cannotTips or ""
            end
        else
            if levelStatus == c.LevelStatus.PASSED or levelStatus == c.LevelStatus.EXPLORE or levelStatus == c.LevelStatus.CURRENT then
                isOpen = true
            else
                desStr = data.cannotTips or ""
            end
        end
    elseif data.p1 then
        local needLevel = data.p2
        local lv = PlayerModel.info.level or 0
        if lv >= needLevel then
            isOpen = true
        else
            desStr = data.cannotTips or ""
        end
    end

    if desStr and desStr ~= "" and not dontShowLabel then
        if data.unlocked == "" then
            MoveLabel.new(desStr)
        else
            local scene = display.getRunningScene()
            scene:getChildByName("ViewBase"):openWin("NewFunWin",data)
        end
    end

    return isOpen
end

function Helper.getOpenData(openID)
    local openConf = require "app.configs.open"
    return openConf[openID]
end

function Helper.getAttriName(name)
    local WordDictionary = require "app.configs.WordDictionary"
    local attrWordName = {
        ["attack"] = WordDictionary[21900],
        ["defense"] = WordDictionary[21901],
        ["maxLife"] = WordDictionary[21902],
        ["energy"] = WordDictionary[21903],
        ["attackCoef"] = WordDictionary[21904],
        ["defenseCoef"] = WordDictionary[21905],
        ["maxLifeCoef"] = WordDictionary[21906],
        ["attackLvIncr"] = WordDictionary[21907],
        ["defenseLvIncr"] = WordDictionary[21908],
        ["maxLifeLvIncr"] = WordDictionary[21909],
        ["crit"] = WordDictionary[21910],
        ["critDamage"] = WordDictionary[21911],
        ["hit"] = WordDictionary[21912],
        ["dodge"] = WordDictionary[21913],
        ["speed"] = WordDictionary[21914],
        ["lifePerHit"] = WordDictionary[21915],
        ["lifePerRound"] = WordDictionary[21916],
        ["energyPerRound"] = WordDictionary[21917],
        ["addCure"] = WordDictionary[21918],
        ["cureRatio"] = WordDictionary[21919],
        ["damageRatio"] = WordDictionary[21920],
        ["healingRatio"] = WordDictionary[21921],
        ["effectHit"] = WordDictionary[21922],
        ["effectDodge"] = WordDictionary[21923],
        ["critOdds"] = WordDictionary[21924],
        ["calmOdds"] = WordDictionary[21925],
        ["critCoef"] = WordDictionary[21926],
        ["hitCoef"] = WordDictionary[21927],
        ["dodgeCoef"] = WordDictionary[21928],
        ["speedCoef"] = WordDictionary[21929],
        ["lifePerHitCoef"] = WordDictionary[21930],
        ["damageUpRatio"] = WordDictionary[21931],
        ["attackLvExtra"] = WordDictionary[21932], --额外攻击,
        ["defenseLvExtra"] = WordDictionary[21933], --额外防御
        ["maxLifeLvExtra"] = WordDictionary[21934], --额外生命
    }
    return attrWordName[name]
end

--战斗力播放特效
function Helper.playAtkAnimation()
    
    local NUMBER = {
        [0] = "public/zhanlizeng-shuzi-00.png",
        [1] = "public/zhanlizeng-shuzi-01.png",
        [2] = "public/zhanlizeng-shuzi-02.png",
        [3] = "public/zhanlizeng-shuzi-03.png",
        [4] = "public/zhanlizeng-shuzi-04.png",
        [5] = "public/zhanlizeng-shuzi-05.png",
        [6] = "public/zhanlizeng-shuzi-06.png",
        [7] = "public/zhanlizeng-shuzi-07.png",
        [8] = "public/zhanlizeng-shuzi-08.png",
        [9] = "public/zhanlizeng-shuzi-09.png",
    }
    local NUMBER_GREEN = {
        [0] = "public/zhanlizeng-shuzilv-00.png",
        [1] = "public/zhanlizeng-shuzilv-01.png",
        [2] = "public/zhanlizeng-shuzilv-02.png",
        [3] = "public/zhanlizeng-shuzilv-03.png",
        [4] = "public/zhanlizeng-shuzilv-04.png",
        [5] = "public/zhanlizeng-shuzilv-05.png",
        [6] = "public/zhanlizeng-shuzilv-06.png",
        [7] = "public/zhanlizeng-shuzilv-07.png",
        [8] = "public/zhanlizeng-shuzilv-08.png",
        [9] = "public/zhanlizeng-shuzilv-09.png",
    }

    local init = require "app.models.init"
    local SpineManager = require "sandglass.core.SpineManager"
    local UILabel = require "sandglass.ui.UILabel"

    local PlayerModel = init.PlayerModel
    local atkPwr=PlayerModel.info.atkPwr
    local scene = display.getRunningScene()
    local atkNode = scene:getChildByName("atkNode")
    local zhanliNode=nil
    local numberNode=nil

    if atkNode then
        zhanliNode = atkNode:getChildFollowBone("item_point")
        numberNode = zhanliNode:getChildByName("numberNode")
        atkNode:stopAllActions()
        zhanliNode:stopAllActions()
        numberNode:stopAllActions()
        numberNode.perAtk = numberNode.str
        if not numberNode.perAtk then
            numberNode.perAtk = PlayerModel.info.perAtkPwr
        end
    else
        
        zhanliNode= display.newNode()
        numberNode= display.newNode()
        numberNode:setName("numberNode")
        atkNode = SpineManager.createAnimation("public/ui_zengjiazhanli",1)
        atkNode:setName("atkNode")
        display.align(atkNode,display.CENTER,display.cx,display.height * 0.84)
        scene:addChild(atkNode,10)
        numberNode.perAtk = PlayerModel.info.perAtkPwr
        atkNode:addChildFollowBone("item_point",zhanliNode)
        atkNode:playAnimation("idle1", 1)
        atkNode:appendNextAnimation("idle2", -1)

        local img_zhanli=display.newSprite("public/zhanlizeng-zongzhanli.png")
        display.align(img_zhanli,display.CENTER,0,atkNode:getContentSize().height/2)
        img_zhanli:setScale(0.6)
        zhanliNode:addChild(img_zhanli)
        zhanliNode:addChild(numberNode)
        zhanliNode:setCascadeOpacityEnabled(true)
    end

    numberNode:stopAllActions()
    numberNode:setCascadeOpacityEnabled(true)
    atkNode.index = 1
    local maxIndex = 50
    local difference = atkPwr - numberNode.perAtk
    -- 数字按帧跳动
    local img_numer=nil
    local count = 0
    numberNode:actionScheduleInterval(function()
        numberNode.str = numberNode.perAtk + math.floor(difference * (atkNode.index / maxIndex))
        if atkNode.index > maxIndex then
            numberNode:stopAllActions()
        else
            numberNode:removeAllChildren()
            for i=1, #tostring(numberNode.str) do
                img_numer=display.newSprite(NUMBER[tonumber(string.sub(tostring(numberNode.str), i, i))])  
                img_numer:setScale(0.5)             
                display.align(img_numer,display.CENTER,70+i*20,atkNode:getContentSize().height/2)
                numberNode:addChild(img_numer)
                count = i + 2
            end
            img_numer=display.newSprite("public/zhanlizeng-add.png")  
            img_numer:setScale(0.5)             
            display.align(img_numer,display.CENTER,70+count*20,atkNode:getContentSize().height/2)
            numberNode:addChild(img_numer)
            count = count + 1
            for i = 1, #tostring(difference) do
                img_numer=display.newSprite(NUMBER_GREEN[tonumber(string.sub(tostring(difference), i, i))])  
                img_numer:setScale(0.5)             
                display.align(img_numer,display.CENTER,70+count*20,atkNode:getContentSize().height/2)
                numberNode:addChild(img_numer)
                count = count + 1
            end
        end
        atkNode.index = atkNode.index + 1
    end,0.02)

    atkNode:setOpacity(255)
    atkNode:runAction(cc.Sequence:create(
        cc.DelayTime:create(1),
        cc.FadeOut:create(2),
        cc.RemoveSelf:create()
    ))
    zhanliNode:setOpacity(255)
    zhanliNode:runAction(cc.Sequence:create(
        cc.DelayTime:create(1),
        cc.FadeOut:create(2)
    ))
end

function Helper.createComboNumber(number)
    local node = cc.Node:create();
    local format = "public/stage_num_%02d.png"

    local digits = {}
    local scale = 1
    if number < 10 then

    elseif number < 100 then
        scale = 0.7
    else
        scale = 0.5
    end

    while number > 0 do
        digits[#digits + 1] = number % 10
        number = math.floor(number / 10)
    end

    if #digits == 0 then
        digits[#digits + 1] = 0
    end

    local x, y = 0, 0
    local offset = 8

    for idx = #digits, 1, -1 do
        local sprite = display.newSprite(string.format(format, digits[idx]))
        display.align(sprite, display.LEFT_BOTTOM, x, (#digits - idx) * 10)
        node:addChild(sprite)
        local size = sprite:getContentSize()
        x = x + size.width - offset

        if size.height + (#digits - idx) * 10 > y then
            y = size.height
        end
    end

    node:setContentSize(cc.size(x, y))
    node:setScale(scale)
    node:setCascadeOpacityEnabled(true)
    return node;
end


function Helper.updateComboSprite(number, node, scale)
    local sprite = nil
    local scale = scale or 1
    if not node:getChildByName("ComboSprite") then
        sprite = display.newSprite("#public/stage_slat_11.png")
        sprite:setPosition(60, 0)
        sprite:setName("ComboSprite")
        node:addChild(sprite, 999)
    else
        sprite = node:getChildByName("ComboSprite")
    end

    local anim = nil
    local SpineManager = require "sandglass.core.SpineManager"
    if number - math.floor(number / 20) * 20 == 0  then
        anim = SpineManager.createAnimation("public/ui_tansuolianji",1)
        anim:playAnimation("idle",1)
        anim:setPosition(60, 0)
        node:addChild(anim,1)
    else
        sprite:stopAllActions()
        sprite:removeAllChildren()
    end

    local combo = display.newSprite("#public/stage_slat_12.png")
    combo:align(display.RIGHT_BOTTOM, combo:getContentSize().width + 20, 5)
        :addTo(sprite, 1)

    local numberNode = Helper.createComboNumber(number)
    sprite:addChild(numberNode)
    numberNode:align(display.LEFT_BOTTOM, combo:getContentSize().width + 25, 35)
    sprite:setCascadeOpacityEnabled(true)
    sprite:setScale(scale)
    sprite:runAction(
        cc.Sequence:create(
            cc.ScaleTo:create(0.05, 1.3 * scale),
            cc.ScaleTo:create(0.05, 1.0 * scale),
            cc.DelayTime:create(1),
            cc.FadeOut:create(0.5)
        )
    )
end

--召唤英雄获得英雄动画
function Helper.showHero(node,rewards,params)
    local heroConf = require "app.configs.hero"
    local WordDictionary = require "app.configs.WordDictionary"
    local UIAniButton = require "sandglass.ui.UIAniButton"
    local SpineManager = require "sandglass.core.SpineManager"
    local roleConf = require "app.configs.role"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local c = require "app.configs.constants"
    local UILabel = require "sandglass.ui.UILabel"
    local jobConf = require "app.configs.job"
    local CoreColor = require "sandglass.core.CoreColor"
    local init = require "app.models.init"
    local AudioManager = require "sandglass.core.AudioManager"

    local ItemModel = init.ItemModel
    local params = params or {}
    local showOther = params.showOther

    local btnCallBack_1 = params.btnCallBack_1
    local btnCallBack_2 = params.btnCallBack_2
    local tp = params.tp
    local reRecruit = params.reRecruit or false
    local bgNode = node
    local baseNode = cc.Node:create();
    local getHeroID = nil
    local isAlready = false
    local heroID = nil
    local cData = nil
    local choukakapai = nil
    local card = nil 

    local bg = display.newSprite("summon/zhaohuanBG.png")
    bgNode:addChild(bg)
    bg:setPosition(cc.p(display.width / 2, display.height / 2))
    bgNode:addChild(baseNode)
    baseNode:setName("baseNode")
    local renderFunc = function()
        -- local render = cc.RenderTexture:create(display.width, display.height)
        -- render:setPosition(display.cx, display.cy)
        -- baseNode:addChild(display.newLayer(cc.c4b(0,0,0,255)))

    end

    local createChoukadi = function()
    --ui_choukadi
        local choukadi = SpineManager.createAnimation("public/ui_choukadi",1)
        choukadi:setPosition(568,320)
        baseNode:addChild(choukadi,1)
        local name = "idle1"
        if cData.rare == "R" then
            name = "idle1"
        elseif cData.rare == "SR" then
            name = "idle2"
        elseif cData.rare == "SSR" then
            name = "idle3"
        end
        choukadi:playAnimation(name, -1)
    end

    local showCard = function()
        local coverLayer = display.newLayer():addTo(baseNode)
        local listener = cc.EventListenerTouchOneByOne:create()
        listener:setSwallowTouches(true)
        listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
        listener:registerScriptHandler(handler(self, function() end), cc.Handler.EVENT_TOUCH_MOVED)
        listener:registerScriptHandler(handler(self, function() end), cc.Handler.EVENT_TOUCH_ENDED)
        local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, coverLayer)
        card:getChildByName("Node_3"):setVisible(false)
        card:setVisible(true)
        baseNode.cardFram = nil
        baseNode.cardNode3 = nil

        local moveAction = cc.CSLoader:createTimeline("layer/summon/card.csb")
        baseNode:runAction(moveAction)
        moveAction:play("animation0", false)

        if isAlready then --已经有这个英雄了，显示碎片
            card:getChildByName("Node_1"):setVisible(false)
            local fragmentDecompose = cData.fragmentDecompose
            local soulShardID = cData.soulShardID
            local shadePath = "#public/public_item_07.png"
            local k = 1
            card:actionScheduleInterval(function()
                if k <= fragmentDecompose then
                    local item = Helper.createGoodsItem({scale = 1,id = soulShardID,num = 1,shadePath = shadePath})        
                    local img = SpineManager.createAnimation("public/ui_tansuowupintanchu",1)
                    img:addChildFollowBone("item_point",item)
                    img:playAnimation("idle", 1)
                    card:getChildByName("Node_2"):getChildByName("headNode"):addChild(img)
                    local rx,ry = math.random(-60,60),math.random(0,50)
                    while math.abs(rx) <= 10 and math.abs(ry) <= 10 do
                        rx,ry = math.random(-60,60),math.random(0,50)
                    end
                    img:runAction(cc.MoveBy:create(0.66, cc.p(rx,ry)))
                    Helper.updateComboSprite(k, card:getChildByName("Node_2"):getChildByName("headNode"))
                    k = k + 1
                else
                    card:stopAllActions()
                end
            end, 0.1)
            card:getChildByName("Node_2"):getChildByName("ssr"):loadTexture(Helper.getHeroRarePath(cData.rare),ccui.TextureResType.plistType)
            card:getChildByName("Node_2"):getChildByName("Text_1"):setString(string.format(WordDictionary[20103],fragmentDecompose))
            card:getChildByName("Node_3"):runAction(cc.Sequence:create(
                cc.DelayTime:create(1),
                cc.CallFunc:create(function()
                    card:getChildByName("Node_3"):setVisible(true)
                end)
            ))
        else
            card:getChildByName("Node_2"):setVisible(false)
            local heroCard = "card/" .. roleConf[cData.role].heroCard .. ".png"
            card:getChildByName("Node_1"):getChildByName("cardFram"):getChildByName("card"):loadTexture(heroCard, ccui.TextureResType.localType)
            card:getChildByName("Node_1"):getChildByName("ssr"):loadTexture(Helper.getHeroRarePath(cData.rare),ccui.TextureResType.plistType)

            card:getChildByName("Node_1"):getChildByName("heroNameBack"):getChildByName("name"):setString(cData.heroName)

            card:getChildByName("Node_1"):getChildByName("heroNameBack_2"):getChildByName("name"):setString(cData.heroName)
            local HERO_COLOR = {
                ["R"] = CoreColor.BLUE,
                ["SR"] = CoreColor.PURPLE,
                ["SSR"] = CoreColor.ORANGE,
            }
            local color = HERO_COLOR[cData.rare] or CoreColor.BLUE
            card:getChildByName("Node_1"):getChildByName("heroNameBack"):getChildByName("name"):setTextColor(color)
            card:getChildByName("Node_1"):getChildByName("heroNameBack_2"):getChildByName("name"):setTextColor(color)
            card:getChildByName("Node_1"):getChildByName("heroNameBack"):getChildByName("jobImage"):loadTexture("public/" .. jobConf[cData.jobId].icon .. ".png",ccui.TextureResType.plistType)
            card:getChildByName("Node_1"):getChildByName("heroNameBack_2"):getChildByName("jobImage"):loadTexture("public/" .. jobConf[cData.jobId].icon .. ".png",ccui.TextureResType.plistType)
            card:getChildByName("Node_1"):getChildByName("heroNameBack_2"):setVisible(false)
            card:getChildByName("Node_1"):getChildByName("heroNameBack"):runAction(cc.FadeIn:create(0.5))

            local node_star = card:getChildByName("Node_1"):getChildByName("cardFram"):getChildByName("node_star")
            for i=1,cData.initialStar do
                node_star:getChildByName("star_"..i):loadTexture("public/public_star_01.png", ccui.TextureResType.plistType)
            end
            baseNode.cardFram = card:getChildByName("Node_1"):getChildByName("cardFram")
            baseNode.cardNode3 = card:getChildByName("Node_3")
            baseNode.cardNode3:setVisible(false)
        end


        local gPath = "summon/summon_prop_01.png"
        local num = 0
        local needNum = 0
        if params.tpIndex == 1 then
            gPath = "summon/summon_prop_01.png"
            num = ItemModel:getItem(30102) and ItemModel:getItem(30102).number or 0
            needNum = 1
        elseif params.tpIndex == 2 then
            gPath = "summon/summon_prop_02.png"
            num = ItemModel:getItem(30103) and ItemModel:getItem(30103).number or 0
            needNum = 1
        end
        card:getChildByName("Node_3"):getChildByName("goodsImage"):loadTexture(gPath,ccui.TextureResType.plistType)
        card:getChildByName("Node_3"):getChildByName("Text_1"):setString(WordDictionary[20104])
        card:getChildByName("Node_3"):getChildByName("Text_2"):setString(WordDictionary[20101])
        card:getChildByName("Node_3"):getChildByName("Text_3"):setString(WordDictionary[20102])
        card:getChildByName("Node_3"):getChildByName("Text_4"):setString(num.."/"..needNum)

        if num < needNum then
            card:getChildByName("Node_3"):getChildByName("Text_4"):setTextColor(CoreColor.RED)
        else
            card:getChildByName("Node_3"):getChildByName("Text_4"):setTextColor(CoreColor.GREEN)
        end

        if not isAlready then
            baseNode.touchLayer = display.newLayer():addTo(baseNode,1)
            local listener = cc.EventListenerTouchOneByOne:create()
            listener:setSwallowTouches(true)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
            listener:registerScriptHandler(handler(self, function() end), cc.Handler.EVENT_TOUCH_MOVED)
            listener:registerScriptHandler(handler(self, function()
                baseNode.firstClick()
            end), cc.Handler.EVENT_TOUCH_ENDED)
            
            local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener, baseNode.touchLayer)
        end
    end

    baseNode.firstClick = function()
        if baseNode:getChildByName("choukakapai") then
            baseNode:getChildByName("choukakapai"):playAnimation("idle4", 1)
            -- choukakapai:playAnimation("idle2", 1)
        end
        if baseNode.touchLayer then
            baseNode.touchLayer:removeSelf()
            baseNode.touchLayer = nil
        end
        if not isAlready then
            local skillConf = require "app.configs.skill"
            if not baseNode:getChildByName("heroSpineAnim") then
                local path = "spine/actors/".. roleConf[cData.role].spine
                local heroSpine = UIAniButton.new(path)
                heroSpine:setPosition(568,263)
                heroSpine:setScale(1.2)
                heroSpine:playAnimation("appear", 1)
                baseNode:addChild(heroSpine,1)
                heroSpine:setName("heroSpineAnim")
                heroSpine:addLuaHandler(function (eventName, animName, intValue, floatValue)
                    if eventName == "complete" and animName == "appear" then
                        heroSpine:playAnimation("idle", -1)
                    end
                end)

                -- local skillPicData = {
                --     [1] = skillConf[cData.skillUltimate],
                --     [2] = skillConf[cData.skill1],
                --     [3] = skillConf[cData.skill2],
                -- }
                
                -- local perX = 120.5
                -- for k,v in ipairs(skillPicData) do
                --     local skillItem = Helper.createSkillIcon({id = v.Id, ableGLProgram = false})
                --     skillItem:setScale(0.9)
                --     local x = (k -  (#skillPicData + 1) / 2)  * perX
                --     local y = k % 2 * 20
                --     display.align(skillItem,display.CENTER,x,y)
                --     local skillNode = baseNode:getChildByName("card"):getChildByName("Node_1"):getChildByName("skillNode")
                --     skillNode:addChild(skillItem)
                -- end
                baseNode:getChildByName("card"):getChildByName("Node_3"):getChildByName("img_detail"):setVisible(true)
                UIImageBox.new(baseNode:getChildByName("card"):getChildByName("Node_3"):getChildByName("img_detail"),function(me)
                    display.getRunningScene():getChildByName("ViewBase"):openWin("HeroDetailWin", cData.heroID)
                end)

                baseNode:getChildByName("card"):getChildByName("Node_1"):getChildByName("heroNameBack_2"):setVisible(true)
                baseNode:getChildByName("card"):getChildByName("Node_1"):getChildByName("heroNameBack"):setVisible(false)
                baseNode:getChildByName("card"):getChildByName("Node_1"):getChildByName("ssr"):setPosition(cc.p(568, 480))
            end

            if not tolua.isnull(baseNode.cardFram) then
                baseNode.cardFram:setVisible(false)
            end
            if baseNode.cardNode3 then
                baseNode.cardNode3:runAction(cc.Sequence:create(
                cc.DelayTime:create(1),
                cc.CallFunc:create(function()
                    baseNode.cardNode3:setVisible(true)
                end)
            ))
            end
        end
    end

    local initFresh = nil
    initFresh = function()
        getHeroID = rewards[1]
        table.remove(rewards, 1)
        isAlready = false
        if getHeroID > 2 ^ 32 then
            isAlready = true
        end
        heroID = getHeroID % (2 ^ 32)
        cData = heroConf[heroID]

        baseNode:removeAllChildren()

        choukakapai = SpineManager.createAnimation("public/ui_choukakapai",1)
        choukakapai:setPosition(585,363)

        card = cc.CSLoader:createNode("layer/summon/card.csb")
        baseNode:addChild(card,2)
        card:setName("card")
        card:setVisible(false)

        local an = "idle1"
        local musicEffect = "ui_getrcard.mp3"
        if cData.rare == "R" then
            an = "idle1"
            musicEffect = "ui_getrcard.mp3"
        elseif cData.rare == "SR" then
            an = "idle2"
            musicEffect = "ui_getsrcard.mp3"
        elseif cData.rare == "SSR" then
            an = "idle3"
            musicEffect = "ui_getssrcard.mp3"
            cc.Device:vibrate(3)
        end
        -- an = "idle3"
        baseNode:addChild(choukakapai,2)
        choukakapai:setName("choukakapai")
        choukakapai:addLuaHandler(function (eventName, animName, intValue, floatValue)
            if eventName == "trigger" and (animName == "idle1" or animName == "idle2" or animName == "idle3")then
                createChoukadi()
                showCard()
            end
        end)
        choukakapai:playAnimation(an, 1)
        AudioManager.playEffect("music/" .. musicEffect)
        renderFunc()

        if #rewards > 0 or not reRecruit then
            card:getChildByName("Node_3"):getChildByName("btn_1"):setPositionX(568)
            local nText_1 = card:getChildByName("Node_3"):getChildByName("Text_1")
            nText_1:setPositionX(nText_1:getPositionX() + 130)
            card:getChildByName("Node_3"):getChildByName("Text_2"):setVisible(false)
            card:getChildByName("Node_3"):getChildByName("Text_3"):setVisible(false)
            card:getChildByName("Node_3"):getChildByName("Text_4"):setVisible(false)
            card:getChildByName("Node_3"):getChildByName("goodsImage"):setVisible(false)
            card:getChildByName("Node_3"):getChildByName("btn_2"):setVisible(false)
        end

        UIImageBox.new(baseNode:getChildByName("card"):getChildByName("Node_3"):getChildByName("btn_1"),function()
            if #rewards > 0 then
                initFresh()
            else
                if btnCallBack_1 then
                    btnCallBack_1()
                end
            end
        end)

        UIImageBox.new(baseNode:getChildByName("card"):getChildByName("Node_3"):getChildByName("btn_2"),function()
        -- self:refresh()
            if btnCallBack_2 then
                btnCallBack_2()
            end
        end)
    end
    initFresh()

end

--卷轴界面的UI动画
function Helper.reelActions(contentNode,callback)
    local AudioManager = require "sandglass.core.AudioManager"
    local panel = contentNode:getChildByName("panel")
    local left = contentNode:getChildByName("left")
    local right = contentNode:getChildByName("right")
    local back = panel:getChildByName("back")
    local lw = left:getContentSize().width
    local rw = right:getContentSize().width
    local wd = lw * 0.5
    local size = panel:getContentSize()
    local md = size.width
    local time = 0.3
    local perTime = 0.01666
    panel:setContentSize(wd,size.height)
    --left:setAnchorPoint(display.CENTER)
    right:setAnchorPoint(display.CENTER)
    panel:setAnchorPoint(display.CENTER)
    back:setAnchorPoint(display.CENTER)

    local back_x = wd * 0.5
    local left_x = panel:getPositionX() - panel:getContentSize().width * 0.5
    local right_x = panel:getPositionX() + panel:getContentSize().width * 0.5

    back:setPositionX(back_x)
    left:setPositionX(left_x)
    right:setPositionX(right_x)

    local func = function()
        panel:actionScheduleInterval(function()
            wd = wd + md / time * perTime
            back_x = wd * 0.5
            left_x = panel:getPositionX() - panel:getContentSize().width * 0.5
            right_x = panel:getPositionX() + panel:getContentSize().width * 0.5

            if wd >= md then
                wd = md
                back_x = wd * 0.5
                left_x = panel:getPositionX() - panel:getContentSize().width * 0.5
                right_x = panel:getPositionX() + panel:getContentSize().width * 0.5
                panel:setContentSize(wd,size.height)
                back:setPositionX(back_x)
                left:setPositionX(left_x)
                right:setPositionX(right_x)
                if callback then
                    callback()
                end
                panel:stopAllActions()
            else
                panel:setContentSize(wd,size.height)
                back:setPositionX(back_x)
                left:setPositionX(left_x)
                right:setPositionX(right_x)
            end
        end,perTime)
    end

    local action_1 = cc.Sequence:create(
        cc.ScaleTo:create(0.07, 1.2),
        cc.ScaleTo:create(0.07, 1)
    )
    local action_2 = cc.Sequence:create(
        cc.ScaleTo:create(0.07, 1.2),
        cc.ScaleTo:create(0.07, 1),
        cc.CallFunc:create(function()
            func()
        end)
    )
    left:runAction(action_1)
    right:runAction(action_2)
    AudioManager.playEffect("music/ui_openpaper.mp3")
end

function Helper.getFixedTime()
    local init = require "app.models.init"
    local HeartbeatModel = init.HeartbeatModel
    return HeartbeatModel:getFixedTime()
end

function Helper.sendEvent(event, param)
    local event = cc.EventCustom:new(event)
    event._usedata = param
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
end

function Helper.filterString(str)
    local fd = "[~!@#%$%^&%*()_%+`%-=%[%]\\;',/{}|\"%?:<>%%]"
    local filter = false
    if not str or str == "" then return false end
    if string.find(str,fd) then
        filter = true
    end
    return filter
end

function Helper.createCostNumLabel(hasNum,needNum,size)
    local UILabel = require "sandglass.ui.UILabel"
    local color = cc.c3b(146,253,32)
    if hasNum < needNum then
        color = cc.c3b(245,70,66)
    end
    local fontSize = size or 20
    local str = UILabel.new({
        text = Helper.getShortNum(hasNum).."/"..Helper.getShortNum(needNum),
        size = fontSize,
        back = cc.c3b(0,0,0),
        color = color,
    })
    return str
end

function Helper.convertStringToExpression(str,color,size,scale)
    local scale = scale or 0.8
    color = color or "#ffffff"
    local size = size or 20
    local emotionConf = require "app.configs.emotion"
    local c = require "app.configs.constants"
    local resultStr = str
    if not Helper.emotionMap then
        Helper.emotionMap = {}
        for _, conf in pairs(emotionConf) do
            Helper.emotionMap[conf.code] = conf
        end 
    end
    for k, v in string.gfind(str, "#%d%d%d%d") do
        if Helper.emotionMap[k] then
            resultStr = string.gsub(resultStr,k,"<spine src='public/ui_biaoqingcangshu' anim='" .. Helper.emotionMap[k].idle .."' scale="..scale.." visible=true />")
        end
    end
    resultStr = string.format("<div fontname='%s' fontsize=%s fontcolor=%s #000000>%s</div>",c.NORMALFONT,size,color,resultStr)
    return resultStr
end

function Helper.getShortNum(num, decimal)
    if num < 100000 then
        return num
    else
        local shortNum = math.floor(num / 10000)
        if decimal then
            shortNum = math.floor(num / 1000)
            shortNum = shortNum / 10
        end
        local WordDictionary = require "app.configs.WordDictionary"
        return shortNum .. WordDictionary[51032]
    end

    -- if num < 10000 then
    --     return num
    -- end
    -- if num >= 10000 and num < 10000000 then
    --     local shortNum = math.floor(num/1000)
    --     if decimal then
    --         shortNum = num/1000
    --     end
    --     return shortNum.."K"
    -- end
    -- if num >= 10000000 then
    --     local shortNum = math.floor(num/1000000)
    --     if decimal then
    --         shortNum = num/1000000
    --     end
    --     return shortNum.."M"
    -- end
end

function Helper.getSmallShortNum(num, decimal)
    if num < 10000 then
        return num
    else
        local shortNum = math.floor(num / 10000)
        if decimal then
            shortNum = math.floor(num / 1000)
            shortNum = shortNum / 10
        end
        local WordDictionary = require "app.configs.WordDictionary"
        return shortNum .. WordDictionary[51032]
    end

    -- if num < 10000 then
    --     return num
    -- end
    -- if num >= 10000 and num < 10000000 then
    --     local shortNum = math.floor(num/1000)
    --     if decimal then
    --         shortNum = num/1000
    --     end
    --     return shortNum.."K"
    -- end
    -- if num >= 10000000 then
    --     local shortNum = math.floor(num/1000000)
    --     if decimal then
    --         shortNum = num/1000000
    --     end
    --     return shortNum.."M"
    -- end
end

function Helper.checkArmorCountLimit()
    local init = require "app.models.init"
    local initialConf = require "app.configs.initial"
    local ArmorModel = init.ArmorModel
    local SoulModel = init.SoulModel
    return ArmorModel:getArmorCount() < initialConf[1].bagLimit and SoulModel:getSoulCount() < initialConf[1].bagLimit
end

function Helper.receiveReward(params)
    local MoveRewardItem = require "app.views.MoveRewardItem"
    local init = require "app.models.init"
    local itemConf = require "app.configs.item"
    local currencyConf = require "app.configs.currency"
    local heroConf = require "app.configs.hero"
    local c = require "app.configs.constants"
    local ArmorModel = init.ArmorModel
    local RuneModel = init.RuneModel
    local result = {}
    local item = params.rewards.Items or {}
    local ccy = params.rewards.Ccy or {}
    local armors = params.rewards.Armors or {}
    local heros = params.rewards.Heroes or {}
    local runes = params.rewards.Runes or {}
    local noEffect = params.noEffect or false
    local time=0.3
    for k,v in ipairs(ccy) do
        table.insert(result,v)
    end
    for k,v in ipairs(item) do
        table.insert(result,v)
    end
    for i,v in ipairs(runes) do
        local id  = RuneModel:getRune(v).id
        table.insert(result,{id = id, Num = 1, haveTip = true, seq = v})
    end
    for k,v in ipairs(armors) do
        local id = ArmorModel:getArmor(v).id
        table.insert(result,{seq = v,id = id, level = 0})
    end
    for k,v in ipairs(result) do
        display.getRunningScene():runAction(cc.Sequence:create(
        cc.DelayTime:create(time*(k-1)),
        cc.CallFunc:create(function() 
            local tData = itemConf[v.Id or v.id] or currencyConf[v.Id or v.id]
            local data_ = {name = tData.name, nameColor = c.ITEM_COLOR[tData.color], numStr = "x"..(v.Num or v.Val or 1), id = tData.Id}
            MoveRewardItem.new(data_)
        end)))
    end
    ----如果有英雄的话弹出英雄获得
    for k,v in ipairs(heros) do
        if v < 2 ^ 32 and heroConf[v] then
            display.getRunningScene():runAction(cc.Sequence:create(
            cc.DelayTime:create(time * (#result + k)),
            cc.CallFunc:create(function()
                display.getRunningScene():getChildByName('ViewBase'):openWin("DrawSSSHeroWin", v)
            end)))
        end
    end

end

function Helper.getExchangeItemCurrencyAndPirce(itemId)
    local itemExchangeConf = require "app.configs.itemExchange"
    local c = require "app.configs.constants"
    local itemConf = require "app.configs.item"
    if not itemExchangeConf[itemId] then
        return 0
    end

    local exchangeData = itemExchangeConf[itemId]
    local price = 0
    -- if exchangeData.currency == c.CurrencyName.gold then
    --     price = itemConf[itemId].buyGold
    -- elseif exchangeData.currency == c.CurrencyName.diamond then
    --     price = itemConf[itemId].buyDiamond
    -- elseif exchangeData.currency == c.CurrencyName.arenaGold then
    --     price = itemConf[itemId].buyArena
    -- elseif exchangeData.currency == c.CurrencyName.guildGold then
    --     price = itemConf[itemId].buyGuild
    -- elseif exchangeData.currency == c.CurrencyName.activityScore then
    --     price = itemConf[itemId].buyActivity
    -- elseif exchangeData.currency == c.CurrencyName.stoneCrash then
    --     price = itemConf[itemId].buyDust
    -- end

    price = exchangeData.cost[1].n

    return exchangeData.cost[1].id, price
end

function Helper.updateHeroStar(parentNode,star,prefix)
    local SpineManager = require "sandglass.core.SpineManager"

    local prefix = prefix or "xx_"
    local isSprite = false
    if tolua.type(parentNode:getChildByName(prefix .. "1")) == "cc.Sprite" then
        isSprite = true
    end
    local loadImage = function(item,path) 
        if isSprite then
            item:setSpriteFrame(path)
        else
            item:loadTexture(path, ccui.TextureResType.plistType)
        end
    end

    for i = 1, 5 do
        local starItem = parentNode:getChildByName(prefix .. i)
        if starItem:getChildByName("starEffect") then
            starItem:removeChildByName("starEffect")
        end
    end

    if star > 10 then
        for i = 1, 5 do
            local starItem = parentNode:getChildByName(prefix .. i)
            if star - 10 >= i then
                loadImage(starItem,"public/public_star_03.png")
                local effect = SpineManager.createAnimation("public/ui_yingxiongxingji_gouyu")
                effect:playAnimation("idle", -1)
                local itemSize = starItem:getContentSize()
                effect:setPosition(itemSize.width/2, itemSize.height/2)
                starItem:addChild(effect)
                effect:setName("starEffect")
            else
                loadImage(starItem,"public/public_star_02.png")
            end
        end
    elseif star > 5 then
        for i = 1, 5 do
            local starItem = parentNode:getChildByName(prefix .. i)
            if star - 5 >= i then
                loadImage(starItem,"public/public_star_04.png")
            else
                loadImage(starItem,"public/public_star_02.png")
            end
        end
    else
        for i = 1, 5 do
            local starItem = parentNode:getChildByName(prefix .. i)
            if star >= i then
                loadImage(starItem,"public/public_star_01.png")
            else
                loadImage(starItem,"public/public_star_02.png")
            end
        end
    end
end

function Helper.getFromScene(sceneName)
    local name = sceneName or display.getRunningScene():getChildByName("ViewBase"):getName()
    local c = require "app.configs.constants"
    if name == "MainScene" then
        return c.AfterLoading.mainScene
    end
    if name == "OutsideScene" then
        return c.AfterLoading.outsideScene
    end
    if name == "GhostStepScene" then
        return c.AfterLoading.ghostStepScene
    end
    if name == "LandScene" then
        return c.AfterLoading.landScene
    end
    if name == "WorldFightScene" then
        return c.AfterLoading.worldFightScene
    end
    if name == "WorldBossScene" then
        return c.AfterLoading.worldBossScene
    end
    if name == "KingFightScene" then
        return c.AfterLoading.kingFightScene
    end
    if name == "ValleyScene" or name == "TxwsPlusScene" then
        return c.AfterLoading.valleyScene
    end
    if name == "MineWarScene" then
        return c.AfterLoading.mineWarScene
    end
    if name == "RunePlayScene" then
        return c.AfterLoading.runePlayScene
    end

    return c.AfterLoading.mainScene
end

function Helper.createSoulTips(soul, params)
    local c = require "app.configs.constants"
    local itemConf = require "app.configs.item"
    local attributeConf = require "app.configs.attribute"
    local UILabel = require "sandglass.ui.UILabel"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local CoreColor = require "sandglass.core.CoreColor"
    local WordDictionary = require "app.configs.WordDictionary"

    local width, height = 320, 430
    local cData = itemConf[soul.id]

    local soulTip = UIImageBox.new("public/public_slat_34.png", function()
        -- body
    end, {isPlist = true, ableGLProgram = false})
    soulTip:setScale9Enabled(true)
    soulTip:setAnchorPoint(cc.p(1, 1))
    soulTip:setName("soulTipNode")
    soulTip.soul = soul
    local height = 25
    local already = params and params.already or false --显示是否已装备

    local btnList = {}
    if params and params.btnList then
        btnList = params.btnList
    end
    local soulTipsBtn = {
        ["btnDress"] = 1,
        ["btnChange"] = 2,
        ["btnEnter"] = 3,
    }
    for k,v in ipairs(btnList) do
        local btn = nil
        if v == "btnChange" then
            btn = UIImageBox.new("public/public_button_02.png", function(me)
                soulTip:removeFromParent()
                if params.onClick then
                    params.onClick()
                end   
            end, {isPlist = true,textParams = {text = WordDictionary[20045], size = 26}})
            soulTip.btnChange = btn
        elseif v == "btnDress" then
            btn = UIImageBox.new("public/public_button_01.png", function(me)
                soulTip:removeFromParent()
                if params.onClick then
                    params.onClick()
                end 
            end, {isPlist = true,textParams = {text = WordDictionary[20046], size = 26}})
            soulTip.btnDress = btn
        elseif v == "btnEnter" then
            btn = UIImageBox.new("public/public_button_01.png", function(me)
                soulTip:removeFromParent()
                if params.onClick then
                    params.onClick()
                end
            end, {isPlist = true,textParams = {text = WordDictionary[23822], size = 26}})
            soulTip.btnEnter = btn
        elseif v == "btnAdd" then
            btn = UIImageBox.new("public/public_button_01.png", function(me)
                soulTip:removeFromParent()
                if params.onClick then
                    params.onClick()
                end
            end, {isPlist = true,textParams = {text = WordDictionary[23826], size = 26}})
            soulTip.btnAdd = btn
        end

        btn:setScale(0.8)
        soulTip:addChild(btn)

        local perW = (width - 48) / #params.btnList
        display.align(btn, display.CENTER_BOTTOM, 24 + (k - 1) * perW + perW / 2, height)
    end

    if #btnList >= 1 then
        height = height + 55
    end

    local bgHStart = height
    height = height + 30

    local getAttrStr = function(basicProperty)
        local defaultAttri = attributeConf[basicProperty.id]
        local valueType = defaultAttri.valueType
        local val = basicProperty.val
        if valueType == c.ArmorAttribute.integers then
            val = math.floor(val)
        elseif valueType == c.ArmorAttribute.percentages then
            val = math.floor(val * 100) .. "%"
        elseif valueType == c.ArmorAttribute.decimalOne then
            val = math.floor(val * 10) / 10
        end
        return string.format(defaultAttri.des1,val)
    end

    local attr = {}
    local attrStr = {}

    for k,v in ipairs(cData.basicProperty) do
        table.insert(attr, {id = v.id, val = v.val + cData.attrLvIncr * soul.level})
    end

    for k,v in ipairs(attr) do
        table.insert(attrStr, getAttrStr(v))
    end
    for k,v in ipairs(attrStr) do
        local str = UILabel.new({
            text = v,
            color = cc.c3b(146,253,32),
            size = 22,
            back = CoreColor.BLACK,
        })
        soulTip:addChild(str, 1)
        display.align(str,display.LEFT_CENTER, 44 , height + (#attrStr - 1) * 30 - (k-1) * 30)
    end

    height = height + (#attrStr - 1) * 30 + 30

    local attrBg = display.newSprite("#public/public_slat_04.png", 0, 0, {scale9 = true, size = cc.size(width - 48, height - bgHStart)})
    soulTip:addChild(attrBg)
    display.align(attrBg, display.LEFT_TOP, 24, height)

    --已装备
    if already then
        local yzbLabelImg = display.newSprite("#public/public_state_02.png")
        display.align(yzbLabelImg,display.BOTTOM_RIGHT,width - 15,height + 30)
        soulTip:addChild(yzbLabelImg, 2)
    end


    local itemImg = Helper.createSoulItems({id = soul.id, scale = 0.7}) --Helper.createGoodsItem({haveTip = false,scale = 0.7,id = soul.id})
    display.align(itemImg,display.LEFT_BOTTOM, 24, height)
    soulTip:addChild(itemImg)

    local strName = UILabel.new({
        text = itemConf[soul.id].name,
        color = c.ITEM_COLOR[itemConf[soul.id].color],
        size = 24,
        back = CoreColor.BLACK,
    })
    display.align(strName,display.LEFT_CENTER, 104, height + 57)
    soulTip:addChild(strName)


    local strLevelLabel = UILabel.new({
        text = WordDictionary[23801],
        color = cc.c3b(47,43,40),
        size = 22,
    })
    display.align(strLevelLabel,display.LEFT_CENTER, 104, height + 20)
    soulTip:addChild(strLevelLabel)

    local strLevel = UILabel.new({
        text = "Lv."..soul.level,
        color = CoreColor.WHITE,
        size = 22,
        back = CoreColor.BLACK,
    })
    display.align(strLevel,display.LEFT_CENTER, 164, height + 20)
    soulTip:addChild(strLevel)

    height = height + 100
    soulTip:setContentSize(cc.size(width, height))

    local anchor = display.RIGHT_TOP

    local contains = function(point)
        local pos = cc.p(soulTip:getPosition())
        local size = soulTip:getContentSize()
        local rect = cc.rect(pos.x - anchor.x * size.width,pos.y - anchor.y * size.height,size.width,size.height)
        return cc.rectContainsPoint(rect, point)
    end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(false)
    listener:registerScriptHandler(handler(soulTip, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(handler(soulTip, function() return true end), cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(handler(soulTip, function(soulTip,touch)
        local point = touch:getLocation()
        if contains(point) then
            listener:setSwallowTouches(true)
        else
            listener:setSwallowTouches(false)
            soulTip:removeFromParent()
        end
    end), cc.Handler.EVENT_TOUCH_ENDED)
    
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, soulTip)
    return soulTip
end

function Helper.createSoulItems(params)
    local itemConf = require "app.configs.item"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local RichLabel = require "sandglass.ui.RichLabel"
    local attributeConf = require "app.configs.attribute"
    local c = require "app.configs.constants"
    local WordDictionary = require "app.configs.WordDictionary"

    local onClick = params.onClick
    local id = params.id
    local num = params.num
    local level = params.level
    local scale = params.scale or 1
    local data = itemConf[id]
    local showAttri = params.showAttri

    local imgFrameName = "icon/soul/" .. data.icon .. ".png"
    local colorImage = SOUL_COLOR_IMAGE_FRAGMENT[data.color]
    local shadePath = "#public/shouhuling-zhezhao.png"

    local values = {isPlist = true,swallowTouches = params.swallowTouches or false, ableGLProgram = params.ableGLProgram or true}

    local frame = UIImageBox.new(colorImage,onClick,values)
    frame:setScale(scale)

    local itemImage = Helper.createClipSprite(imgFrameName, shadePath,1)
    display.align(itemImage,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(itemImage)

    if showAttri then 
        local nameLvStr = RichLabel.new {
            fontSize = 15,
        }
        nameLvStr:setString(string.format(WordDictionary[23807], c.ITEM_COLOR_16[data.color], data.name, level))
        nameLvStr:setPosition(cc.p(frame:getContentSize().width*0.5- nameLvStr:getContentSize().width*0.5, frame:getContentSize().height/4))
        frame:addChild(nameLvStr)
       
        local attriData = attributeConf[data.basicProperty[1].id]
        local num = data.basicProperty[1].val + data.attrLvIncr * level
        local val = Helper.getAttriValue(data.basicProperty[1].id, num)
        local attriStr = RichLabel.new {
            fontSize = 15,
        }
        attriStr:setString(string.format(WordDictionary[23808], attriData.name.."+"..val))
        attriStr:setPosition(cc.p(frame:getContentSize().width*0.5- attriStr:getContentSize().width*0.5, frame:getContentSize().height/4-nameLvStr:getContentSize().height*0.8))
        frame:addChild(attriStr)
    end

    return frame
end


function Helper.createGuildHead(id, scale, badge)
    local guildHeadConf = require "app.configs.guildHead"
    local UIImageBox = require "sandglass.ui.UIImageBox"

    local scale = scale or 1
    local iconIndex = id%10000
    local flagIndex = id - iconIndex
    if flagIndex <= 0 or not guildHeadConf[flagIndex] then
        flagIndex = 10000
    end
    if not guildHeadConf[iconIndex] then
        iconIndex = 1
    end

    local flagPath = "icon/head/".. guildHeadConf[flagIndex].icon..".png"
    local path = "icon/head/" .. guildHeadConf[iconIndex].icon .. ".png"

    local frame = nil
    
    if badge then
        frame = UIImageBox.new(path,nil)
    else
        frame = UIImageBox.new(flagPath,nil)
        local icon = display.newSprite(path)
        display.align(icon,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(icon)
    end
    frame:setScale(scale)

    return frame
    
end

function Helper.checkDivide(index)
    if RESOURCE_PARAMS and RESOURCE_PARAMS.divide then
        local progress = cc.UserDefault:getInstance():getStringForKey("divideProgress")
        if not progress or progress == "" then
            progress = 1--默认从1号包开始
        end
        progress = tonumber(progress)

        if index >= progress then
            display.getRunningScene():getChildByName("ViewBase"):openWin("DivideLoadWin")
            return false
        else
            return true
        end
    else
        return true
    end
end

--范围随机，用于从数组中随机选择多个
function Helper.randomIndex(tabNum,indexNum)
    indexNum = indexNum or tabNum
    local t = {}
    local rt = {}
    for i = 1,indexNum do
        local ri = math.random(1,tabNum + 1 - i)
        local v = ri
        for j = 1,tabNum do
            if not t[j] then
                ri = ri - 1
                if ri == 0 then
                    table.insert(rt,j)
                    t[j] = true
                end
            end
        end
    end
    return rt
end

function Helper.createRichLable(ccUiText,outline,shadow,lineSpace,charSpace)
    local RichLabel = require "sandglass.ui.RichLabel"
    local CoreColor = require "sandglass.core.CoreColor"
    ccUiText:setVisible(false)
    local params = {
            fontName = ccUiText:getFontName(),
            fontSize = ccUiText:getFontSize(),
            fontColor = ccUiText:getTextColor(),
            maxWidth= ccUiText:getContentSize().width,
            lineSpace= lineSpace or 0,
            charSpace= charSpace or 0,
        }
    if outline then
        params.outline = true
        params.outline_params = {color=CoreColor.BLACK,size=1}
    end
    if shadow then
        params.shadow = true
        params.shadow_params = {color=CoreColor.BLACK,offset=cc.size(1,-2),blurradius=0}
    end
    local richLabel = RichLabel.new(params)
    richLabel:setPosition(ccUiText:getPosition())
    richLabel:setAnchorPoint(ccUiText:getAnchorPoint())
    ccUiText:getParent():addChild(richLabel)
    return richLabel
end

function Helper.isNight()
    local date =  os.date("*t", Helper.getFixedTime())

    if date.hour > 6 and date.hour < 18 then 
        return false
    else
        return true
    end 
end

function Helper.createMinerHead(params)
    local sqMinerConf = require "app.configs.sqMiner"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local SpineManager = require "sandglass.core.SpineManager"

    local onClick = params.onClick
    local id = params.id
    local num = params.num or 1
    local scale = params.scale or 1
    local data = sqMinerConf[id]
    local haveTip = true
    if params.haveTip == false then 
        haveTip = false
    end
    if not data then return nil end

    local imgHead = "icon/head/" .. data.icon .. ".png"
    local imgframe = ITEM_COLOR_IMAGE[data.stage]
    local shadePath = "#public/public_shade_01.png"

    local values = {isPlist = true, swallowTouches =false, ableGLProgram = false}
    if haveTip then 
        values.tipsProto = require "app.CommonTip"
        values.tipsParam = {type = 4, id = id}
    end

    local frame = UIImageBox.new(imgframe,onClick,values)
    frame:setScale(scale)

    local itemImage = Helper.createClipSprite(imgHead, shadePath,1)
    display.align(itemImage,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(itemImage)
    if num > 1 then
        Helper.createGoodsNumLabel(frame,{num = num})
    end
    --流光特效
    local effectNums = {1,2,4}
    local useAnim = {}
    for k,v in ipairs(effectNums) do
        if bit.band(data.stageSpine,v) > 0 then
            table.insert(useAnim,"idle" .. k)
        end
    end
    for k,v in ipairs(useAnim) do
        local anim = SpineManager.createAnimation("public/ui_wupinguang",1)  
        frame:addChild(anim)
        anim:setPosition(frame:getContentSize().width * 0.5,frame:getContentSize().height * 0.5)
        anim:playAnimation(v, -1)
    end

    return frame
end

function Helper.createShopItem(params)
    local itemConf = require "app.configs.item"
    local currencyConf = require "app.configs.currency"
    local heroConf = require "app.configs.hero"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local SpineManager = require "sandglass.core.SpineManager"
    local roleConf = require "app.configs.role"

    local onClick = params.onClick
    local id = params.id
    local num = params.num
    if num == 1 then num = nil end
    local scale = params.scale or 1
    local data = itemConf[id] or currencyConf[id]

    local isHero = false
    if not data then
        if id > 2 ^ 32 then
            local heroId = id % (2 ^ 32)
            local cData = heroConf[heroId]
            if cData then
                id = cData.soulShardID
                num = cData.fragmentDecompose
                data = itemConf[id]
            else
                print("error:can't find id : " .. id .. "in itemConf,currencyConf,heroConf")
            end
        else
            if heroConf[id] then
                data = heroConf[id]
                data.icon = roleConf[data.role].head
                isHero = true
                num = nil
            else
                print("error:can't find id : " .. id .. "in itemConf,currencyConf,heroConf")
            end
        end
    end

    if not data then return nil end
    local color = params.color or data.color or 1
    local decorate = params.decorate or data.decorate or nil

    local goodsIcon = "icon/item/" .. data.icon .. ".png"
    
    if not data.type then
        data.type = 0
    end
    if data.type == 10 then
        goodsIcon = "icon/head/" .. data.icon .. ".png"
    elseif data.type == 0 then
        goodsIcon = "icon/currency/" .. data.icon .. ".png"
    elseif data.type == 100 then --英雄
        goodsIcon = "icon/head/" .. data.icon .. ".png"
    elseif data.type >= 501 and data.type <= 511 then --守护灵
        goodsIcon = "icon/soul/" .. data.icon .. ".png"
    end

    local frame = nil
    if data.type >= 41 and data.type <= 47 then
        local color = params.color or data.color or 1

        frame = display.newSprite("#" .. ARMORS_COLOR_IMAGE_FRAGMENT[color])
       
        local cf = Helper.createClipSprite("#" .. ARMORS_COLOR_LIGHT_FRAGMENT[color], "#public/public_stage_07.png",0.9)
        cf:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(cf)

        --装备角标
        if data.type ~= 47 then
            cc.SpriteFrameCache:getInstance():addSpriteFrames("heroList/heroList.plist")
            local path = string.format("#heroList/yingxiong-jiantou-0%d.png",data.type - 40)
            local corner = display.newSprite(path)
            corner:setPosition(frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
            frame:addChild(corner)
        end

        local itemImage = Helper.createClipSprite("icon/rune/" .. data.icon .. ".png", "#public/public_stage_07.png",1)
        display.align(itemImage,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
        frame:addChild(itemImage)
        if num then
            Helper.createEquipLevelLabel(itemImage,{level = num})
        end
    else
        frame = UIImageBox.new(goodsIcon)
        if num then
            Helper.createGoodsNumLabel(frame,{num = num})
        end
    end

    frame:setScale(scale)
    
    --流光特效
    if decorate and decorate ~= 0 then
        local effectNums = {1,2,4}
        local useAnim = {}
        
        for k,v in ipairs(effectNums) do
            if bit.band(decorate,v) > 0 then
                table.insert(useAnim,"idle" .. k)
            end
        end

        for k,v in ipairs(useAnim) do
            local anim = SpineManager.createAnimation("public/ui_wupinguang",1)  
            frame:addChild(anim)
            anim:setPosition(frame:getContentSize().width * 0.5,frame:getContentSize().height * 0.5)
            anim:playAnimation(v, -1)
        end

    end

    return frame
end


function Helper.createGemTips(params)
    local c = require "app.configs.constants"
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local WordDictionary = require "app.configs.WordDictionary"
    local msgids = require "app.network.msgids"
    local network = require "app.network.network"
    local MoveLabel = require "sandglass.ui.MoveLabel"
    local gemComPoseConf = require "app.configs.gemCompose"
    local itemConf = require "app.configs.item"
    local attributeConf = require "app.configs.attribute"
    local init = require "app.models.init"
    local GemModel = init.GemModel

    local width, height, margin = 330, 270, 24

    local btnList = params.btnList
    local id = params.id
    local onClick = params.onClick
    local seq = params.seq 
    local heroId = params.heroId
    local holeId = params.holeId
    local itemData = itemConf[id]
    local locked = GemModel:getGem(seq) and GemModel:getGem(seq).locked or nil
    if not itemData then return end

    local bgImg = UIImageBox.new("public/public_slat_34.png", function()
    end, {isPlist = true, ableGLProgram = false, swallowTouches = false})
    bgImg:setScale9Enabled(true)
    bgImg:setAnchorPoint(cc.p(1, 1))

    local height = 25

    local btnHeight = nil
    for k,v in ipairs(btnList) do
        local spacing = (width - margin*2)/#btnList
        local btn = nil
        if v == "merge" then ---合成
            btn = UIImageBox.new("public/public_button_02.png", function(me)
                if gemComPoseConf[id].denominator > 0 then
                    display.getRunningScene():getChildByName("ViewBase"):openWin("GemComposeWin", {seq = seq, heroId = heroId, holeId = holeId})
                    bgImg:removeFromParent()
                else
                    MoveLabel.new(WordDictionary[25418])
                end
            end, {isPlist = true,textParams = {text = WordDictionary[25407], size = 26}})
        elseif v == "replace" then ---替换
            btn = UIImageBox.new("public/public_button_02.png", function(me)
                display.getRunningScene():getChildByName("ViewBase"):openWin("GemReplaceWin", holeId, heroId)
                bgImg:removeFromParent()
            end, {isPlist = true,textParams = {text = WordDictionary[25408], size = 26}})
        elseif v == "unload" then ---卸下
            btn = UIImageBox.new("public/public_button_02.png", function(me)
                network.tcpSend(msgids.C_GemUnequip, {Seq = seq})
                bgImg:removeFromParent()
            end, {isPlist = true,textParams = {text = WordDictionary[25409], size = 26}})
        elseif v == "inlay" then ---镶嵌
            btn = UIImageBox.new("public/public_button_02.png", function(me)
                bgImg:removeFromParent()
                if onClick then onClick() end
            end, {isPlist = true,textParams = {text = WordDictionary[25404], size = 26}})
        end
        if #btnList > 2 then
            btn:setScale(0.65)
        else
            btn:setScale(0.8)
        end
        display.align(btn, display.BOTTOM_CENTER, margin + (k-1)*spacing + spacing/2, height)
        bgImg:addChild(btn)
        btnHeight = btn:getContentSize().height*btn:getScale()
    end
    if btnHeight then
        height = height + btnHeight
    end
    
    height = height + 40
    
    local attrData = GemModel:getGemAttriStrs({id})
    local attrSpacing = 30
    local attrLastY = height + (#attrData - 1)*attrSpacing
    for i,v in ipairs(attrData) do
        local str = UILabel.new({
            text = v.name.."+"..v.val,
            color = cc.c3b(255,106,0),
            size = 22,
            back = CoreColor.BLACK,
        })
        bgImg:addChild(str, 1)
        display.align(str,display.CENTER, width/2, attrLastY - (i-1) * attrSpacing)
    end

    height = attrLastY + 20
    local attrBgY = (#attrData - 1)*attrSpacing + 40
    local attrBg = display.newSprite("#public/public_slat_04.png", 0, 0, {scale9 = true, size = cc.size(width - margin*2, attrBgY)})
    bgImg:addChild(attrBg)
    display.align(attrBg, display.LEFT_TOP, margin, height)
    
    height = height + 10

    local itemImg = Helper.createGoodsItem({scale = 0.8, id = id}) 
    display.align(itemImg,display.LEFT_BOTTOM, margin, height)
    bgImg:addChild(itemImg)

    local nameStr = UILabel.new({
        text = itemData.name,
        color = CoreColor.WHITE,
        size = 24,
        back = CoreColor.BLACK,
    })
    display.align(nameStr,display.LEFT_CENTER, 110, height + 57)
    bgImg:addChild(nameStr)

    local levelStr = UILabel.new({
        text = WordDictionary[25410],
        color = cc.c3b(47,43,40),
        size = 22,
    })
    display.align(levelStr,display.LEFT_CENTER, 110, height + 20)
    bgImg:addChild(levelStr)

    local levelNumStr = UILabel.new({
        text = "Lv."..id%100,
        color = CoreColor.WHITE,
        size = 22,
        back = CoreColor.BLACK,
    })
    display.align(levelNumStr,display.LEFT_CENTER, 164, height + 20)
    bgImg:addChild(levelNumStr)
    ------上锁-----
    local lockImg = "public/public_slat_31.png"
    local lockStr = WordDictionary[25421]
    if locked then
        lockImg = "public/public_slat_32.png"
        lockStr = WordDictionary[25420]
    end
    local lockBtn = UIImageBox.new(lockImg, function(me)
        bgImg:removeFromParent()
        network.tcpSend(msgids.C_GemLock, {Seq = seq, B = not locked})
    end, {isPlist = true})
    display.align(lockBtn, display.BOTTOM_CENTER, width-60, height + 40)
    lockBtn:setScale(1.3)
    bgImg:addChild(lockBtn)
    local lockLabel = UILabel.new({
        text = lockStr,
        color = cc.c3b(47,43,40),
        size = 18,
    })
    display.align(lockLabel,display.BOTTOM_CENTER, width-60, height + 20)
    bgImg:addChild(lockLabel)


    height = height + 100
    bgImg:setContentSize(cc.size(width, height))

    local anchor = display.RIGHT_TOP

    local contains = function(point)
        local pos = cc.p(bgImg:getPosition())
        local size = bgImg:getContentSize()
        local rect = cc.rect(pos.x - anchor.x * size.width,pos.y - anchor.y * size.height,size.width,size.height)
        return cc.rectContainsPoint(rect, point)
    end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(false)
    listener:registerScriptHandler(handler(bgImg, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(handler(bgImg, function() return true end), cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(handler(bgImg, function(bgImg,touch)
        local point = touch:getLocation()
        if contains(point) then
            listener:setSwallowTouches(true)
        else
            listener:setSwallowTouches(false)
            bgImg:removeFromParent()
        end
    end), cc.Handler.EVENT_TOUCH_ENDED)
    
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, bgImg)
    return bgImg
end

function Helper.createGemLevelLabel(obj,params)
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local level = params.level or 0
    local size = params.size or 16
    if level <= 0 then return end

    local lvBg = display.newSprite("#public/yangcheng-qianghua-di.png")
    local bgSize = lvBg:getContentSize()
    local lvLabel = UILabel.new({
        text = level,
        color = cc.c3b(255,255,255),
        back = CoreColor.BLACK,
        size = size,
        backWidth = 2,
    })
    display.align(lvLabel,display.CENTER, bgSize.width/2, bgSize.height/2)
    lvBg:addChild(lvLabel)
    lvBg:setScale(1.2)
    
    obj:addChild(lvBg)
    display.align(lvBg, display.CENTER, obj:getContentSize().width/2, 10)

end

function Helper.getCurrencySign()
    local c = require "app.configs.constants"
    if RESOURCE_PARAMS and RESOURCE_PARAMS.isKorea then
        return c.CURRENCY_TYPE.KRW
    elseif RESOURCE_PARAMS and RESOURCE_PARAMS.isSEA then
        return c.CURRENCY_TYPE.USD
    else
        return c.CURRENCY_TYPE.CNY
    end
end

function Helper.checkHeroIsDemon(heroId, star)
    local heroConf = require "app.configs.hero"
    local globalPublicConf = require "app.configs.globalPublic"
    if heroConf[heroId] and (heroConf[heroId].demon == 1) then
        if star > globalPublicConf[1].heroStarLimit then
            return true
        end
    end
    return false
end

function Helper.getBanInfo(banTable)
    local banTeamConf = require "app.configs.banTeam"
    local forceConf = require "app.configs.force"
    local jobConf = require "app.configs.job"
    local heroConf = require "app.configs.hero"
    local c = require "app.configs.constants"
    local WordDictionary = require "app.configs.WordDictionary"

    local curTime = Helper.getFixedTime()
    local curTimeTs = os.date("*t", curTime)
    local curWeek = (curTimeTs.wday-1 == 0) and 7 or (curTimeTs.wday-1)

    local banInfo = {}
    for k,banId in ipairs(banTable) do
        local banData = banTeamConf[banId]
        if banData then
            if banData.weekDay == 0 or banData.weekDay == curWeek then
                local data = {}
                if banData.type == 1 then --势力
                    data.icon = "public/"..forceConf[banData.subject].icon..".png"
                elseif banData.type == 2 then --性别
                    data.icon = c.HERO_GENDER_ICON[banData.subject]
                elseif banData.type == 3 then --职业
                    data.icon = "public/"..jobConf[banData.subject].icon..".png"
                    data.scale = 0.8
                elseif banData.type == 4 then --英雄
                    data.str = heroConf[banData.subject].heroName
                end
                table.insert(banInfo, data)
            end
        end
    end

    if #banInfo == 0 then
        local data = {str = WordDictionary[23327]}
        table.insert(banInfo, data)
    end

    return banInfo
end

function Helper.isBanHero(heroId, banTable)
    local heroConf = require "app.configs.hero"
    local banTeamConf = require "app.configs.banTeam"

    local curTime = Helper.getFixedTime()
    local curTimeTs = os.date("*t", curTime)
    local curWeek = (curTimeTs.wday-1 == 0) and 7 or (curTimeTs.wday-1)

    local heroData = heroConf[heroId]
    for k,banId in ipairs(banTable) do
        local banData = banTeamConf[banId]
        if banData then
            if banData.weekDay == 0 or banData.weekDay == curWeek then
                if banData.type == 1 and heroData.feature[3] == banData.subject then
                    return true
                elseif banData.type == 2 and heroData.feature[2] == banData.subject then
                    return true
                elseif banData.type == 3 and heroData.feature[1] == banData.subject then
                    return true
                elseif banData.type == 4 and heroData.heroID == banData.subject then
                    return true
                end
            end
        end
    end

    return false
end

function Helper.getParseTime(str)
    if str == "" then
        return
    end
    -- 取@
    local at = string.sub(str, 1,1)

    if at == "@" then
        -- 距离开服时间
        local data = string.split(str, "@")

        local init = require "app.models.init"
        local PlayerModel = init.PlayerModel
        local svrOpenTs = PlayerModel.info.svrOpenTs

        local day = tonumber(data[1]) or 0
        local hour = tonumber(data[2]) or 0
        local min = tonumber(data[3]) or 0

        local time = svrOpenTs + day *24 * 60 * 60 + hour * 60 *60 + min * 60
        return time
    else
        -- 年月日时间
        local function getTimeByDate(str)
            local a = string.split(str, " ")
            local b = string.split(a[1], "-")
            local c = string.split(a[2], ":")
            local t = os.time({year=b[1],month=b[2],day=b[3],hour=c[1],min=c[2],sec=c[3]})
            return t
        end

        local time = getTimeByDate(str)
        return time
    end
end



function Helper.checkBubbleTips(tipType, node, pos, size)
    local promptBubbleConf = require "app.configs.promptBubble"
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local globalPublicConf = require "app.configs.globalPublic"
    local init = require "app.models.init"
    local RedTipsModel = init.RedTipsModel
    local PlayerModel = init.PlayerModel
    local MainLineModel = init.MainLineModel
    local HeroModel = init.HeroModel

    if not node then return end
    local data = {}
    local textData = {}
    local txtType = nil
    local myLv = PlayerModel.info.level or 0
    for i,v in pairs(promptBubbleConf) do
        for _,k in ipairs(v.place) do
            if k == tipType then
                if not v.lvFixedRegion[1] or (myLv >= v.lvFixedRegion[1].low and myLv <= v.lvFixedRegion[1].higt) then
                    table.insert(data, v)
                end
            end
        end
    end
    table.sort(data, function(a, b)
        return a.textType < b.textType
    end)
    for i,v in ipairs(data) do
        if not txtType or (txtType == v.textType) then
            local state = false
            if v.termType == 1 then --妖兽
                if Helper.getOpenState(155, true) then
                    local mythAnimalData = RedTipsModel:getMythAnimalData()
                    for _,data in ipairs(mythAnimalData) do
                        if not TakeFree and data.Lv == 0 then
                            state = true
                            break
                        end
                    end
                end
            elseif v.termType == 2 then --主线成就
                local curNum = MainLineModel:getNowCpt()
                if curNum <= v.termParameter[1] then
                    state = true
                end
            elseif v.termType == 3 then --英雄
                local useData = HeroModel:getHero(v.termParameter[1])
                if not useData then
                    state = true
                end
            elseif v.termType == 4 then --等级
                if myLv < v.termParameter[1] then
                    state = true
                end
            elseif v.termType == 5 then --功能
                if not Helper.getOpenState(v.termParameter[1], true) then
                    state = true
                end
            else
                state = true
            end

            if state then
                txtType = v.textType
                table.insert(textData, v.text)
            end
        end
    end
    
    local tipNode = node:getChildByName("tipNode")
    if #textData > 0 then
        if not tipNode then
            tipNode = cc.Node:create()
            local strSize = size or 16
            local width = 250
            local height = 120
            local textStr = UILabel.new({
                text = "",
                size = strSize,
                back = CoreColor.BLACK,
                dimensions = cc.size(width-50, height-50)
            })
            local txtBg = display.newSprite("#public/zhujiemian-tishidi2.png", 45, 37, {scale9 = true, size = cc.size(width, height)})
            display.align(txtBg,display.LEFT_BOTTOM, -60, -15)
            tipNode:addChild(txtBg)
            display.align(textStr,display.LEFT_BOTTOM, -33, 15)
            textStr:setName("textLabel")
            tipNode:addChild(textStr)
            local tipImg = display.newSprite("#public/zhujiemian-tishidi3.png")
            display.align(tipImg,display.CENTER, 0, 0)
            tipNode:addChild(tipImg)
            tipNode:setName("tipNode")
            node:addChild(tipNode)
        end
        tipNode:stopAllActions()
        tipNode:setPosition(pos.x, pos.y)
        tipNode:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.MoveBy:create(1, cc.p(0, -20)), cc.MoveBy:create(1, cc.p(0,20)))))
        local index = 1
        tipNode:getChildByName("textLabel"):setString(textData[index])
        tipNode:actionScheduleInterval(function()
            index = index + 1 
            if index > #textData then
                index = 1
            end
            tipNode:getChildByName("textLabel"):setString(textData[index])
        end, globalPublicConf[1].promptBubbleCd)
    elseif tipNode then
        tipNode:stopAllActions()
        node:removeChildByName("tipNode")
    end

end

function Helper.createEquipStarItem(star)
    cc.SpriteFrameCache:getInstance():addSpriteFrames("equip/equip.plist")
    local node = cc.Node:create();
    local format = "#equip/zhuangbei-%s.png"
    local starNum = star

    local digits = {}
    local scale = 1

    while starNum > 0 do
        digits[#digits + 1] = starNum % 10
        starNum = math.floor(starNum / 10)
    end

    if #digits == 0 then
        digits[#digits + 1] = 0
    end

    local x, y = 0, 0
    local offset = 0

    local spStar = display.newSprite("#public/zhuangbei-xing2.png")
    local size = spStar:getContentSize()
    display.align(spStar, display.LEFT_CENTER, x, 1)
    x = x + size.width - 2
    node:addChild(spStar)
    local spX = display.newSprite("#equip/zhuangbei-x.png")
    local sizeX = spX:getContentSize()
    display.align(spX, display.LEFT_CENTER, x, 0)
    x = x + sizeX.width
    node:addChild(spX)
    y = math.max(size.height, sizeX.height)

    for idx = #digits, 1, -1 do
        local sprite = display.newSprite(string.format(format, digits[idx]))
        display.align(sprite, display.LEFT_CENTER, x, 0)
        node:addChild(sprite)
        local size = sprite:getContentSize()
        x = x + size.width - offset

        if size.height > y then
            y = size.height
        end
    end

    node:setContentSize(cc.size(x, y))
    node:setCascadeOpacityEnabled(true)
    return node;
end

-- 获取当月天数
function Helper.getCurrentMonthDays()
    local time = Helper.getFixedTime()
    local year,month = os.date("%Y", time), os.date("%m", time)+1
    local dayAmount = os.date("%d", os.time({year=year, month=month, day=0}))
    return tonumber(dayAmount)
end


function Helper.getItemOrCurrencyData(id, isGetCount)
    local itemConf = require "app.configs.item"
    local init = require "app.models.init"
    local ItemModel = init.ItemModel
    local PlayerModel = init.PlayerModel
    local data = {}
    if itemConf[id] then
        data.name = itemConf[id].name
        data.num = ItemModel:getItem(id) and ItemModel:getItem(id).number or 0
        data.color = itemConf[id].color
    else
        local currencyConf = require "app.configs.currency"
        data.name = currencyConf[id].name
        data.num = PlayerModel:getCurrencyByID(id)
        data.color = currencyConf[id].color
    end
    if isGetCount then
        return data.num
    end
    return data
end

--获取道具或者货币数量
function Helper.getItemOrCurrencyCnt(id, short, decimal)
    local init = require "app.models.init"
    local currencyConf = require "app.configs.currency"
    local itemConf = require "app.configs.item"
    local num = 0

    if currencyConf[id] then
        local PlayerModel = init.PlayerModel
        num = PlayerModel:getCurrencyByID(id)
    else
        local ItemModel = init.ItemModel
        num = ItemModel:getItemCntById(id)
    end
    if short then
        num = Helper.getSmallShortNum(num, decimal)
    end
    return num
end

function Helper.getQualityImgPath(colorId)
    -- bag-kuang-
    local path = "list/bag-kuang-lan.png"
    if colorId == 401 then
        path = "list/bag-kuang-lan.png"
    elseif colorId == 402 then
        path = "list/bag-kuang-zi.png"
    elseif colorId == 403 then
        path = "list/bag-kuang-cheng.png"
    elseif colorId == 404 then
        path = "list/bag-kuang-hong.png"
    end
    return path
end
-- 默认显示cls
function Helper.getHeroNameAndColor(heroId, cls, isNotShowCls)
    local CoreColor = require "sandglass.core.CoreColor"
    local talentConf = require "app.configs.talent"
    local heroConf = require "app.configs.hero"
    local idx = talentConf[heroId].talentColor[cls] or 1
    local name = heroConf[heroId].heroName
    if cls > 0 then
        if not isNotShowCls then
            name = name .. "+" ..(cls or "")
        end
    end
    
    local colors = {
        [1] = CoreColor.WHITE,
        [2] = CoreColor.GREEN,
        [3] = CoreColor.BLUE,
        [4] = CoreColor.PURPLE,
        [5] = CoreColor.ORANGE,
        [6] = CoreColor.RED,
        [7] = CoreColor.GOLD,
    }

    return name, colors[idx]
end

function Helper.getHeroClsName(cls)
    local WordDictionary = require "app.configs.WordDictionary"
    local nameTab = {
        WordDictionary[20070],
        WordDictionary[20071],
        WordDictionary[20072],
        WordDictionary[20073],
        WordDictionary[21632],
    }

    local colorNameIdx = 0
    for i = 1, cls do
        if HERO_CLS_TO_NAME[i] == "" then
            colorNameIdx = colorNameIdx + 1
        end
    end

    return WordDictionary[50090] .. "+" .. cls or ""
end

function Helper.getHeroFrame(heroId, cls)
    local talentConf = require "app.configs.talent"
    local idx = talentConf[heroId].talentColor[cls] or 0

    local frames = {
        [0] = "public/public_frame_01.png",
        [2] = "public/public_frame_02.png",
        [3] = "public/public_frame_03.png",
        [4] = "public/public_frame_04.png",
        [5] = "public/public_frame_05.png",
        [6] = "public/public_frame_06.png",
    }

    return frames[idx]
end


function Helper.CreateMonsterHead(params) 
    local monsterConf = require "app.configs.monster"
    local heroConf = require "app.configs.hero"
    local roleConf = require "app.configs.role"
    local monsterId = params.id 
    local scale = params.scale or 1
    local path = params.frame or "icon/frame/frame_initial_01.png"

    local frame = ccui.ImageView:create(path, ccui.TextureResType.localType)
    local roleId = monsterConf[monsterId] and monsterConf[monsterId].role or heroConf[monsterId].role
    local headPath = roleConf[roleId].head
    local imgName = "icon/head/" .. headPath .. ".png"
    local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png")
    headImg:setName("headImg")
    display.align(headImg,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(headImg)
    frame:setScale(scale)

    return frame
end

function Helper.CreateHeroHead(params) 
    local heroConf = require "app.configs.hero"
    local roleConf = require "app.configs.role"
    local heroId = params.id 
    local scale = params.scale or 1

    local frame = ccui.ImageView:create("icon/frame/frame_initial_01.png", ccui.TextureResType.localType)
    local roleId = heroConf[heroId].role
    local headPath = roleConf[roleId].head
    local imgName = "icon/head/" .. headPath .. ".png"
    local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png")
    headImg:setName("headImg")
    display.align(headImg,display.CENTER, frame:getContentSize().width * 0.5 , frame:getContentSize().height * 0.5)
    frame:addChild(headImg)
    frame:setScale(scale)

    return frame
end

function Helper.getRewards(rewards, rmArmors)
    local init = require "app.models.init"
    local ArmorModel = init.ArmorModel
    local SoulModel = init.SoulModel
    local GemModel = init.GemModel
    local RuneModel = init.RuneModel

    local result = {}
    local item = rewards.Items or {}
    local ccy = rewards.Ccy or {}
    local armors = rewards.Armors or {}
    local souls = rewards.Souls or {}
    local gems = rewards.Gems or {}
    local runes = rewards.Runes or {}
    local heros = rewards.Heroes or {}

    for k,v in ipairs(ccy) do
        table.insert(result, {id = v.Id, num = v.Num or v.N or v.Val})
    end
    for k,v in ipairs(item) do
        table.insert(result, {id = v.Id, num = v.Num or v.N or v.Val})
    end
    if not rmArmors then
        for k,v in ipairs(armors) do
            local id = ArmorModel:getArmor(v).id
            table.insert(result,{seq = v,id = id})
        end
    end
    for i,v in ipairs(souls) do
        local id  = SoulModel:getSoul(v).id
        table.insert(result,{seq = v,id = id})
    end
    for i,v in ipairs(gems) do
        local id  = GemModel:getGem(v).id
        table.insert(result,{seq = v,id = id, level = id%100})
    end
    for i,v in ipairs(runes) do
        local id = RuneModel:getRune(v).id
        table.insert(result,{id = id, num = 1, haveTip = true, seq = v})
    end
    for k,v in ipairs(heros) do
        if v < 2 ^ 32 then
            table.insert(result, {id = v, haveTip = true})
        end
    end

    return result
end
--loading完成时需要在win中主动设置resinfowin可见
function Helper.loadingToWin(win)
    local SpineManager = require "sandglass.core.SpineManager"
    local loadingTipsConf = require "app.configs.loadingTips"
    local UILabel = require "sandglass.ui.UILabel"
    local CoreColor = require "sandglass.core.CoreColor"
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    self.SetResInfoWinVisible(win, false)
    local node = cc.Node:create()
    
    local bg = ccui.Layout:create()
    bg:setContentSize(cc.size(display.width, display.height))
    bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    bg:setBackGroundColor(CoreColor.BLACK)
    bg:setSwallowTouches(true)
    bg:setPosition(cc.p(-display.cx, -display.cy))
    node:addChild(bg, 100)

    local anim = SpineManager.createAnimation("loading/ui_loadclipa",1)
    anim:playAnimation("idle", -1)
    anim:setPosition(0,-display.cy * 0.4)
    node:addChild(anim, 101)

    local loadAnim = SpineManager.createAnimation("loading/ui_loading",1)
    loadAnim:playAnimation("idle", -1)
    loadAnim:setPosition(anim:getPositionX(), anim:getPositionY() - 25)
    node:addChild(loadAnim, 101)

    local strList = {}
    local level = PlayerModel.info.level or 1
    for k,v in pairs(loadingTipsConf) do
        if level >= v.lvldown and level <= v.lvlup then
            table.insert(strList,v.name)
        end
    end

    local str = ""
    if #strList > 1 then
        str = strList[math.random(1,#strList)]
    else
        str = strList[1] or ""
    end

    local des = UILabel.new({
        text = str,
        size = 18,
    })
    des:setPosition(0,-display.cy+40)
    node:addChild(des, 103)
    
    win.loadingNode_ = node
    node:setScale(win.bgScale)
    win:addChild(node)
end


function Helper.SetResInfoWinVisible(win, active)
    if win then
        win.resourceNode_:setVisible(active)
        if active and win.loadingNode_ then
            win.loadingNode_:removeSelf()
            win.loadingNode_ = nil
        end
    end
    
end

function Helper.setStringFitSize(txt, str)
    txt:getVirtualRenderer():setDimensions(txt:getContentSize().width,0)
    txt:setString(str)
    local size = txt:getVirtualRendererSize()
    txt:setContentSize(size)
end

function Helper.arrangeTxts(txts)
    for i=1,#txts do
        if txts[i + 1] then
            txts[i + 1]:setPositionX(txts[i]:getPositionX() + txts[i]:getContentSize().width)
        end
    end
end


function Helper.clickRecommand()
    local battleConf = require "app.configs.battle"
    local init = require "app.models.init"
    local c = require "app.configs.constants"
    local LevelModel = init.LevelModel
    local PlayerModel = init.PlayerModel
    -- 推荐关卡
    local minPower = nil  --推荐关卡的战斗力
    local recommand = nil  --推荐关卡
    local myLv = PlayerModel.info.level
    for levelId, status in pairs(LevelModel.levels) do
        if battleConf[levelId] and battleConf[levelId].type == 1 and status == c.LevelStatus.CURRENT then
            if minPower == nil or minPower > battleConf[levelId].battlePower then
                if battleConf[levelId].stageType == 0 or battleConf[levelId].stageType == 3 and myLv >= battleConf[levelId].playerLevel then
                    recommand = levelId
                    minPower = battleConf[levelId].battlePower
                end
            end
        end
    end
    return recommand
end
function Helper.gotoWinBySourceId(id, curWin, levelId)
    local sourceConf = require "app.configs.source"
    local c = require "app.configs.constants"
    local MoveLabel = require "sandglass.ui.MoveLabel"
    local WordDictionary = require "app.configs.WordDictionary"

    local sourceData = nil
    for k,v in pairs(sourceConf) do
        if v.sourceId == id then
            sourceData = v
            break
        end
    end
    if not sourceData then return end
    if sourceData.openId and sourceData.openId > 0 then
        if not Helper.getOpenState(sourceData.openId) then
            return 
        end
    end

    local curScene = Helper.getFromScene()
    local tag = (sourceData.params and sourceData.params ~= 0) and sourceData.params or nil 
    local data = {win = (sourceData.goWin and sourceData.goWin ~= "") and sourceData.goWin or nil, fromScene = curScene}

    if sourceData.goScene == 0 then ---当前场景
        data.afterLoading = curScene
    elseif sourceData.goScene == 1 then  ---城外
        data.afterLoading = c.AfterLoading.outsideScene
    elseif sourceData.goScene == 2 then  ---城内
        data.afterLoading = c.AfterLoading.mainScene
    elseif sourceData.goScene == 100 then ---前往某关卡
        data.afterLoading = c.AfterLoading.outsideScene
        if data.afterLoading == curScene then
            local outsideScrWin = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
            if outsideScrWin and levelId then
                outsideScrWin:gotoTileByLevelId(levelId)
                if curWin then
                    curWin:closeSelf()
                    curWin = nil
                end
            end
        else
            data.levelId = levelId
            data.click = true
        end
    elseif sourceData.goScene == 200 then ---次级提示框
        display.getRunningScene():getChildByName('ViewBase'):openWin("SourceTipWin", sourceData.tipsDes)
        return
    elseif sourceData.goScene == 301 then --矿战
        data.afterLoading = c.AfterLoading.mineWarScene
    elseif sourceData.goScene == 302 then --幻神殿
        data.afterLoading = c.AfterLoading.ghostStepScene
    elseif sourceData.goScene == 303 then --符文圣地
        data.afterLoading = c.AfterLoading.runePlayScene
    end

    --家族跳转界面特殊处理
    if id == 25 then
        local init = require "app.models.init"
        local FamilyModel = init.FamilyModel
        if FamilyModel:getFamilyId() ~= "" and FamilyModel:getFamilyId() ~= nil then--没有家族打开申请界面
            data.win = "FamilyLandWin"
        else--有家族打开家族界面
            data.win = "ApplyFamilyWin"
        end
    end

    if id == 1 then --主线地图占领度关卡推荐
        levelId = Helper.clickRecommand()
        if data.afterLoading == curScene then
            local outsideScrWin = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
            if outsideScrWin and levelId then
                outsideScrWin:gotoTileByLevelId(levelId)
                if curWin then
                    curWin:closeSelf()
                    curWin = nil
                end
            end
        else
            data.levelId = levelId
            data.click = true
        end
    end
    
    if data.afterLoading and data.afterLoading ~= curScene then
        display.getRunningScene():getChildByName("ViewBase"):getApp():enterScene("LoadingScene", data)
    else
        if data.win and data.win ~= "" then
            local hasWin = display.getRunningScene().winManager:findWinByName(data.win)
            if hasWin then
                if data.win == "ChatWin" then
                    hasWin:show()
                else
                    MoveLabel.new(WordDictionary[20325])
                end
            else
                display.getRunningScene():getChildByName('ViewBase'):openWin(data.win, tag)
            end
            --不在同一场景才关闭当前界面
            if curWin then
                curWin:closeSelf()
            end
        elseif curWin then
            curWin:closeSelf()
        end
    end
end

function Helper.getAttrColor(id, n)
    local attributeConf = require "app.configs.attribute"
    if not attributeConf[id].rollColour or #attributeConf[id].rollColour == 0 then
        return 1
    else
        for _,info in ipairs(attributeConf[id].rollColour) do
            if n >= info.n then
                return info.c
            end
        end
        return 1
    end
end

--获取当前时间距离timestamp经过的天数
function Helper.getPassedDay(timestamp)
    local startDate = os.date("*t", timestamp)
    local startDayTs = os.time({year = startDate.year, month = startDate.month, day = startDate.day, hour = 0, min = 0, sec = 0})

    --local curTime = os.time()
    local curTime = Helper.getFixedTime()
    local day = math.ceil((curTime - startDayTs) / 86400)
    return day
end

function Helper.getFuncOpenTimeInterval(times)
    -- local times = {
    --     [2] = {"20:30-21:00",},
    --     [4] = {"10:30-12:00","21:30-22:00"},
    -- }-----格式----
    if table.nums(times) == 0 then return end 
    local delayTime = 0
    local opening = false

    local curTime = Helper.getFixedTime()
    local curTimeTs = os.date("*t", curTime)
    local curWeek = os.date("%w",curTime)
    curWeek = tonumber(curWeek)
    if curWeek == 0 then curWeek = 7 end
    if times[0] then
        times[7] = times[0]
        times[0] = nil
    end 
    ----------(1-7=星期一-星期天)----------
    local weeks = {}
    for week,v in pairs(times) do
        table.insert(weeks, week)
    end
    table.sort(weeks, function(a, b)
        return a < b 
    end)

    local hasToday = false
    local downDay = nil 
    for i,v in ipairs(weeks) do
        if curWeek == v then
            hasToday = true
        end
        if not downDay and v > curWeek then
            downDay = v
        end
    end
    local today = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
    local tomorrow = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day+1, hour = 0, min = 0, sec = 0})

    local getTimeSlotFunc = function(timeInfo)
        local info = string.split(timeInfo, "-")
        local openInfo = string.split(info[1], ":")
        local closeInfo = string.split(info[2], ":")
        local openH, openM = tonumber(openInfo[1]), tonumber(openInfo[2])
        local closeH, closeM = tonumber(closeInfo[1]), tonumber(closeInfo[2])
        local openTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = openH, min = openM, sec = 0})
        local closeTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = closeH, min = closeM, sec = 0})
        return openTime, closeTime
    end
    
    if hasToday then
        for i,v in ipairs(times[curWeek]) do
            local openTime, closeTime = getTimeSlotFunc(v)
            if curTime < openTime then
                delayTime = openTime - curTime
                break
            elseif curTime >= openTime and curTime < closeTime then
                opening = true
                delayTime = closeTime - curTime
                break
            elseif curTime >= closeTime then
                if i == #times[curWeek] then---取下一次开启时间
                    hasToday = false
                else---继续遍历下一个时间段
                end
            end
        end
    end
    if not hasToday then
        if downDay then
            local openTime = getTimeSlotFunc(times[downDay][1])
            delayTime =  (tomorrow - curTime) + (downDay - curWeek - 1)*60*60*24 + (openTime - today)
        else---跨周
            local openTime = getTimeSlotFunc(times[weeks[1]][1])
            delayTime =  (tomorrow - curTime) + (7 - curWeek + weeks[1] - 1)*60*60*24 + (openTime - today)
        end
    end

    return delayTime, opening
end

function Helper.buttonAddEffect(btn, effect, scale)
    local SpineManager = require "sandglass.core.SpineManager"
    if btn:getChildByName("btnEffectAnim") then
        return
    end
    local anim = SpineManager.createAnimation(effect, 1)
    anim:playAnimation("idle", -1)
    local size = btn:getContentSize()
    anim:setPosition(size.width/2, size.height/2)
    btn:addChild(anim)
    anim:setName("btnEffectAnim")
    if scale then
        anim:setScale(scale)
    end
end

function Helper.buttonRemoveEffect(btn)
    if btn and btn:getChildByName("btnEffectAnim") then
        btn:removeChildByName("btnEffectAnim")
    end
end

function Helper.checkGoToPayWin()
    local WordDictionary = require "app.configs.WordDictionary"
    display.getRunningScene():getChildByName("ViewBase"):openWin("DialogWin", WordDictionary[71011], {
        {
            handler = function ()
                display.getRunningScene():getChildByName("ViewBase"):openWin("PayWin")
            end
        },
        {
        }
    })
end

function Helper.enterWinAction2(win)
    local AudioManager = require "sandglass.core.AudioManager"
    if not win then return end
    win.resourceNode_:setPositionX(display.width)
    local closeNode = win.resourceNode_:getChildByName("closeNode")
    if closeNode then
        closeNode:setPositionX(-50)
    end
    win.resourceNode_:runAction(cc.Sequence:create(
        cc.EaseOut:create(cc.MoveTo:create(0.35, cc.p(0, 0)),1),
        cc.CallFunc:create(function()
            if closeNode then
                closeNode:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.3, cc.p(0, display.height))))
            end
        end)
    ))
    AudioManager.playEffect("music/ui_bigopen.mp3")
end

function Helper.enterWinAction1(win)
    local AudioManager = require "sandglass.core.AudioManager"
    if not win then return end
    win.resourceNode_:setPositionY(-display.height /2)
    win.resourceNode_:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.6, cc.p(0, 0))))
    AudioManager.playEffect("music/ui_popup05.mp3")
end

function Helper.outWinAction(win, callback)
    local AudioManager = require "sandglass.core.AudioManager"
    if not win then return end
    local closeNode = win.resourceNode_:getChildByName("closeNode")
    if closeNode then
        closeNode:runAction(cc.EaseBackIn:create(cc.MoveTo:create(0.3, cc.p(100, display.height))))
    end
    win.resourceNode_:runAction(cc.Sequence:create(
        cc.DelayTime:create(0.3),
        cc.CallFunc:create(function()
            AudioManager.playEffect("music/ui_bigclose.mp3")
        end),
        cc.EaseSineIn:create(cc.MoveTo:create(0.3, cc.p(display.width, 0))),
        cc.CallFunc:create(function()
            if win.closeActionFunc then
                win.closeActionFunc()
            end
            if callback then
                callback()
            end
        end)
    ))
end

function Helper.playRewardsGetAnim(params)
    local AudioManager = require "sandglass.core.AudioManager"
    local SpineManager = require "sandglass.core.SpineManager"
    local parentNode = params.node
    local rewards = params.rewards or {}
    local pos = params.pos or cc.p(0, 0)
    local time = params.time or 0.1
    local zOrder = params.zOrder or 1

    local node = cc.Node:create()
    parentNode:addChild(node, zOrder)
    node:setPosition(pos)
    local allReward = {}

    if params.split then
        for _,v in ipairs(rewards) do
            v.n = v.N or v.num or 1
            for i=1, v.n do
                table.insert(allReward, {id = v.Id or v.id, num = 1})
            end
        end
    else
        allReward = rewards
    end

    local k = 1
    if parentNode.getWardEffect then
        AudioManager.stopEffect(parentNode.getWardEffect)
    end
    parentNode.getWardEffect = AudioManager.playEffect("music/combo.mp3", true)
    node:actionScheduleInterval(function()
        local v = allReward[k]
        if not v then
            node:stopAllActions()
            if parentNode.getWardEffect then
                AudioManager.stopEffect(parentNode.getWardEffect)
                parentNode.getWardEffect = nil
            end
            parentNode:runAction(cc.Sequence:create(
                cc.DelayTime:create(0.5 + 0.2), 
                cc.CallFunc:create(function()
                    if params.callback then
                        params.callback()
                    end
                    node:removeFromParent()
                end)
            ))
            return
        end
        local item = Helper.createGoodsItem({scale = 1,id = v.Id or v.id,num = v.N or v.num or 1})
        item:setScale(0.6)
        local anim = SpineManager.createAnimation("public/ui_tansuowupintanchu",1)
        anim:addChildFollowBone("item_point",item)
        anim:playAnimation("idle", 1)
        node:addChild(anim)

        local rx,ry = math.random(-250,250),math.random(0,250)
        while math.abs(rx) <= 50 and math.abs(ry) <= 50 do
            rx,ry = math.random(-250,250),math.random(0,250)
        end
        anim:runAction(cc.MoveBy:create(0.5, cc.p(rx,ry)))

        k = k + 1
    end, time)
end

function Helper.checkOpenCardExprience()
    --玩家达到9级后，首次进入征战天下的上阵界面。弹出月卡体验。
    local init = require "app.models.init"
    local SpeCardModel = init.SpeCardModel
    local PlayerModel = init.PlayerModel
    local speCardConf = require "app.configs.speCard"
    local levelExtreme = SpeCardModel:getLeaveDay("month", "extreme")
    --没有体验过,没有买最高级的卡

    if PlayerModel:getInfo().level >= speCardConf[1].level and not SpeCardModel:getTrial() and levelExtreme <= 0 then
        display.getRunningScene():getChildByName("ViewBase"):openWin("CardExprienceWin",true,nil,true)
    end
end

function Helper.createBuffIcon(params)
    local UILabel = require "sandglass.ui.UILabel"
    local buffConf = require "app.configs.buff"
    local c = require "app.configs.constants"
    local UIImageBox = require "sandglass.ui.UIImageBox"
    local id = params.id
    local scale = params.scale or 1
    local buffData = buffConf[id]
    if not buffData then
        return
    end
    local haveTip = true
    if params.haveTip == false then 
        haveTip = false
    end

    local values = {swallowTouches = params.ableGLProgram, touchEvent = params.touchEvent}
    values.ableGLProgram = params.ableGLProgram
    if haveTip then 
        values.tipsProto = require "app.CommonTip"
        values.tipsParam = {type = c.TipsType.buff, id = id}
    end
    local imgName = "icon/skill/" .. buffData.icon .. ".png"
    local icon = UIImageBox.new(imgName, params.onClick, values)

    if params.showName then
        local nameStr = UILabel.new({
            text = buffData.name,
            size = params.size or 16,
        })
        display.align(nameStr, display.TOP_CENTER, icon:getContentSize().width/2, 0)
        icon:addChild(nameStr)
    end

    icon:setScale(scale)
    return icon
end

-----读取自然时间没有读服务器时间
function Helper.getFestivalStyle()
    local c = require "app.configs.constants"
    local curTime = os.time()
    local curStyle = 0

    for i,v in pairs(c.FESTIVAL_STYLE) do
        local info = string.split(v.startTs, "-")
        local startT = os.time({year = tonumber(info[1]), month = tonumber(info[2]), day = tonumber(info[3]), hour = 0, min = 0, sec = 0})
        local info = string.split(v.endTs, "-")
        local endT = os.time({year = tonumber(info[1]), month = tonumber(info[2]), day = tonumber(info[3]), hour = 23, min = 59, sec = 59})
        if curTime >= startT then
            if curTime < endT then
                curStyle = v.style 
                break
            end
        end
    end
   
   return curStyle
end

function Helper.checkFilterTextBySDK(text, callback)
    local network = require "app.network.network"
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    if SDK_PARAMS.checkWords then
        local data = {
            accessKey = "5a2VHw5BBAyM0oJGNLzT",
            type = "GAME",
            appId = SDK_PARAMS.checkWordsAppId,
            data = {
                text = text,
                tokenId = PlayerModel.info.userId,
                ip = PlayerModel.info.loginIP,
                channel = "DYNAMIC"
            }
        }
        network.httpPost(SDK_PARAMS.checkWords, json.encode(data), function(xhr)
            if string.find(xhr.statusText, "OK") then
                local result = string.unicode_to_utf8(xhr.response)
                local decResult = json.decode(result)
                local detail = json.decode(decResult.detail)
                if decResult.code == 1100 and decResult.riskLevel ~= 'REJECT' then
                    callback(true, text)
                else
                    callback(false)
                end
            end
        end)
    else
        callback(true, text)
    end
end

return Helper