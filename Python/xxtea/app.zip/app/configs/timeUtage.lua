return {
    [1]={
        id=1,
        startTime=12,
        lastTime=7200,
    },
    [2]={
        id=2,
        startTime=18,
        lastTime=7200,
    },
    [3]={
        id=3,
        startTime=21,
        lastTime=7200,
    },
}
