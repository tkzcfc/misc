return {
    [1]={
        id=1,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>加入了家族，欢迎新兄弟加入！</div>",
    },
    [2]={
        id=2,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>退出了家族，一路走好！</div>",
    },
    [3]={
        id=3,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>进行了</div><div fontcolor=#FFA711 outline=1,#000000>%s</div><div fontcolor=#EBD7BC>，为家族增加</div><div fontcolor=#B3EE42>%s</div><div fontcolor=#EBD7BC>点经验！</div>",
    },
    [4]={
        id=4,
        des="<div fontcolor=#EBD7BC>族长</div><div fontcolor=#FFA711 outline=1,#000000>%s</div><div fontcolor=#EBD7BC>将</div><div fontcolor=#FFA711 outline=1,#000000>%s</div><div fontcolor=#EBD7BC>任命为 %s！</div>",
    },
    [5]={
        id=5,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>击败了</div><div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>，成为了【%s】！</div>",
    },
    [6]={
        id=6,
        des="<div fontcolor=#EBD7BC>族长</div><div fontcolor=#FFA711 outline=1,#000000>%s</div><div fontcolor=#EBD7BC>被</div><div fontcolor=#FFA711 outline=1,#000000>%s</div><div fontcolor=#EBD7BC>成功弹劾，并成为新的族长！</div>",
    },
    [7]={
        id=7,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>完成家族活跃任务，为家族增加了</div><div fontcolor=#B3EE42>%s</div><div fontcolor=#FFA711 outline=1,#000000>点活跃值。</div>",
    },
    [8]={
        id=8,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>将职位模式设置为【%s】，成员们进行争夺获得更高的职位和收益吧。</div>",
    },
    [9]={
        id=9,
        des="<div fontcolor=#ffd800>%s</div>在矿战<div fontcolor=#ffd800>%s</div>中被<div fontcolor=#ffd800>%s</div>挑战,兵力损失了<div fontcolor=#eb5f06>%s</div>点",
    },
    [10]={
        id=10,
        des="<div fontcolor=#ffd800>%s</div>在矿战<div fontcolor=#ffd800>%s</div>中被<div fontcolor=#ffd800>%s</div>移出了矿场！",
    },
    [11]={
        id=11,
        des="<div fontcolor=#FFA711 outline=1,#000000>%s </div><div fontcolor=#EBD7BC>将职位模式设置为【%s】，族长大权在握，任命模式开始了。</div>",
    },
}
