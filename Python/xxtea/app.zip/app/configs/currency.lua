return {
    [10100]={
        Id=10100,
        name="金币",
        icon="currency_gold_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：通用的货币，用途广泛\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：招财喵、挂机",
        errorcode="金币不足",
        sourceId={
            9,2,
        },
    },
    [10200]={
        Id=10200,
        name="钻石",
        icon="currency_diamond_01",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：忍者世界最珍贵的货币，没有之一\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：比武场、充值",
        errorcode="钻石不足",
        sourceId={
            15,
        },
    },
    [10201]={
        Id=10201,
        name="钻石",
        icon="currency_diamond_01",
        color=5,
        decorate=7,
        des="",
        errorcode="钻石不足",
        sourceId={
            
        },
    },
    [10202]={
        Id=10202,
        name="钻石",
        icon="currency_diamond_01",
        color=5,
        decorate=7,
        des="",
        errorcode="钻石不足",
        sourceId={
            
        },
    },
    [10203]={
        Id=10203,
        name="钻石",
        icon="currency_diamond_01",
        color=5,
        decorate=7,
        des="",
        errorcode="钻石不足",
        sourceId={
            
        },
    },
    [10300]={
        Id=10300,
        name="玩家经验",
        icon="currency_exp_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可提升玩家等级\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：关卡，地下城，挂机、任务、月卡加成",
        errorcode="玩家经验不足",
        sourceId={
            2,
        },
    },
    [10302]={
        Id=10302,
        name="忍阶点数",
        icon="currency_vip_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可提升忍阶等级\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：每日任务、充值",
        errorcode="忍阶点数不足",
        sourceId={
            24,
        },
    },
    [10303]={
        Id=10303,
        name="成就点数",
        icon="currency_achv_01",
        color=4,
        decorate=0,
        des="标示性点数\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：成就",
        errorcode="成就点数不足",
        sourceId={
            
        },
    },
    [10304]={
        Id=10304,
        name="天赋神玉",
        icon="currency_talent_01",
        color=4,
        decorate=2,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可提升英雄天赋\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：地下城、关卡",
        errorcode="天赋神玉不足",
        sourceId={
            1,8,
        },
    },
    [10305]={
        Id=10305,
        name="黑铁矿石",
        icon="icon-heitiekuang",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可提升装备强化等级\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：通缉大厅、商城、挂机",
        errorcode="黑铁矿石不足",
        sourceId={
            4,3,2,
        },
    },
    [10306]={
        Id=10306,
        name="幻神能量石",
        icon="currency_ghostPwr_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：激活幻化神进阶属性点\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：幻神殿、商店",
        errorcode="幻神能量石不足",
        sourceId={
            16,3,
        },
    },
    [10307]={
        Id=10307,
        name="魂尘",
        icon="currency_soulDust_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在魂尘商店购买碎片\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：群英殿、炼魂",
        errorcode="魂尘不足",
        sourceId={
            12,17,
        },
    },
    [10308]={
        Id=10308,
        name="觉醒石",
        icon="icon-juexingshi",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可英雄觉醒\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：觉醒殿、珍藏商店、家族商店",
        errorcode="觉醒石不足",
        sourceId={
            13,3,
        },
    },
    [10309]={
        Id=10309,
        name="精炼石",
        icon="currency_soul_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可精炼装备\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：通缉大厅、珍藏商店",
        errorcode="精炼石不足",
        sourceId={
            4,3,
        },
    },
    [10310]={
        Id=10310,
        name="护灵碎片",
        icon="icon-hulingsuipian",
        color=4,
        decorate=2,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可兑换护灵\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：通灵阵",
        errorcode="护灵碎片不足",
        sourceId={
            
        },
    },
    [10311]={
        Id=10311,
        name="普通雪花酥",
        icon="icon-xuehuashu1",
        color=2,
        decorate=0,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：吃了就会上瘾的糕点,可提升英雄等级，每使用一个可获得100点经验\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：挂机、关卡",
        errorcode="普通雪花酥不足",
        sourceId={
            1,2,
        },
    },
    [10312]={
        Id=10312,
        name="优质雪花酥",
        icon="icon-xuehuashu2",
        color=3,
        decorate=2,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：吃了就会上瘾的糕点,可提升英雄等级，每使用一个可获得1000点经验\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：挂机、关卡",
        errorcode="优质雪花酥不足",
        sourceId={
            1,2,
        },
    },
    [10313]={
        Id=10313,
        name="上品雪花酥",
        icon="icon-xuehuashu3",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：吃了就会上瘾的糕点,可提升英雄等级，每使用一个可获得10000点经验\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：挂机、关卡、珍藏商店",
        errorcode="上品雪花酥不足",
        sourceId={
            1,2,3,
        },
    },
    [10314]={
        Id=10314,
        name="极品雪花酥",
        icon="icon-xuehuashu4",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：吃了就会上瘾的糕点,可提升英雄等级，每使用一个可获得50000点经验\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：挂机、关卡",
        errorcode="极品雪花酥不足",
        sourceId={
            1,2,
        },
    },
    [10500]={
        Id=10500,
        name="武斗币",
        icon="currency_arena_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在比武商店购买道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：比武场",
        errorcode="武斗币不足",
        sourceId={
            15,
        },
    },
    [10501]={
        Id=10501,
        name="家族币",
        icon="currency_guild_01",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在家族商店购买道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：家族捐献",
        errorcode="家族币不足",
        sourceId={
            25,
        },
    },
    [10505]={
        Id=10505,
        name="荣誉",
        icon="icon-wuxun",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在荣誉商店里购买珍稀道具",
        errorcode="荣誉不足",
        sourceId={
            
        },
    },
    [10506]={
        Id=10506,
        name="皇庭币",
        icon="icon-huangtinbi",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在家园皇庭商店里购买珍稀道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：领地争夺",
        errorcode="皇庭币不足",
        sourceId={
            
        },
    },
    [10507]={
        Id=10507,
        name="争霸积分",
        icon="icon_renjiezhengba",
        color=4,
        decorate=6,
        des="在忍界争霸中获得的奖励积分",
        errorcode="争霸积分不足",
        sourceId={
            
        },
    },
    [10508]={
        Id=10508,
        name="活跃积分",
        icon="icon-huangtingzhengbajifen",
        color=4,
        decorate=6,
        des="在每日限时活动时所获得的积分，可以在活跃商店内购买稀有道具",
        errorcode="活跃积分不足",
        sourceId={
            
        },
    },
    [10509]={
        Id=10509,
        name="战神币",
        icon="icon-zhanshenxunzhang",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：在忍界争霸中获得的货币，可供奉战神殿的神龛",
        errorcode="战神币不足",
        sourceId={
            
        },
    },
    [10511]={
        Id=10511,
        name="试炼币",
        icon="icon-jingcai",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可跨服试炼中参与竞猜并可在试炼商店中兑换奖励",
        errorcode="试炼币不足",
        sourceId={
            
        },
    },
    [10520]={
        Id=10520,
        name="微型铁矿石",
        icon="icon-xitukuang01",
        color=3,
        decorate=2,
        des="矿石熔炼后获得矿石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="矿石不足",
        sourceId={
            
        },
    },
    [10521]={
        Id=10521,
        name="小型铁矿石",
        icon="icon-xitukuang02",
        color=4,
        decorate=2,
        des="矿石熔炼后获得矿石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="矿石不足",
        sourceId={
            
        },
    },
    [10522]={
        Id=10522,
        name="大型铁矿石",
        icon="icon-xitukuang03",
        color=5,
        decorate=6,
        des="矿石熔炼后获得矿石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="矿石不足",
        sourceId={
            
        },
    },
    [10523]={
        Id=10523,
        name="微型铜矿石",
        icon="icon-tongkuang01",
        color=3,
        decorate=2,
        des="矿石熔炼后获得矿石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="矿石不足",
        sourceId={
            
        },
    },
    [10524]={
        Id=10524,
        name="小型铜矿石",
        icon="icon-tongkuang02",
        color=4,
        decorate=2,
        des="矿石熔炼后获得矿石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="矿石不足",
        sourceId={
            
        },
    },
    [10525]={
        Id=10525,
        name="大型铜矿石",
        icon="icon-tongkuang03",
        color=5,
        decorate=6,
        des="矿石熔炼后获得矿石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="矿石不足",
        sourceId={
            
        },
    },
    [10526]={
        Id=10526,
        name="微型红宝石",
        icon="icon-hongbaoshi01",
        color=3,
        decorate=2,
        des="矿石熔炼后获得宝石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="宝石不足",
        sourceId={
            
        },
    },
    [10527]={
        Id=10527,
        name="小型红宝石",
        icon="icon-hongbaoshi02",
        color=4,
        decorate=2,
        des="矿石熔炼后获得宝石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="宝石不足",
        sourceId={
            
        },
    },
    [10528]={
        Id=10528,
        name="大型红宝石",
        icon="icon-hongbaoshi03",
        color=5,
        decorate=6,
        des="矿石熔炼后获得宝石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="宝石不足",
        sourceId={
            
        },
    },
    [10529]={
        Id=10529,
        name="微型蓝宝石",
        icon="icon-lanbaoshi01",
        color=3,
        decorate=2,
        des="矿石熔炼后获得宝石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="宝石不足",
        sourceId={
            
        },
    },
    [10530]={
        Id=10530,
        name="小型蓝宝石",
        icon="icon-lanbaoshi02",
        color=4,
        decorate=2,
        des="矿石熔炼后获得宝石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="宝石不足",
        sourceId={
            
        },
    },
    [10531]={
        Id=10531,
        name="大型蓝宝石",
        icon="icon-lanbaoshi03",
        color=5,
        decorate=6,
        des="矿石熔炼后获得宝石徽记\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="宝石不足",
        sourceId={
            
        },
    },
    [10532]={
        Id=10532,
        name="翡翠神玉",
        icon="icon-feicuishenshi",
        color=5,
        decorate=7,
        des="神秘道具，用途未知，可能会有一些神奇的用处\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞",
        errorcode="翡翠神玉不足",
        sourceId={
            
        },
    },
    [10533]={
        Id=10533,
        name="微型七彩结晶",
        icon="icon-qicaijiejing01",
        color=3,
        decorate=2,
        des="矿石熔炼后获得神兵碎片\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞、珍藏商城",
        errorcode="七彩结晶不图纸",
        sourceId={
            
        },
    },
    [10534]={
        Id=10534,
        name="小型七彩结晶",
        icon="icon-qicaijiejing02",
        color=4,
        decorate=2,
        des="矿石熔炼后获得神兵碎片\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞、珍藏商城",
        errorcode="七彩结晶不图纸",
        sourceId={
            
        },
    },
    [10535]={
        Id=10535,
        name="大型七彩结晶",
        icon="icon-qicaijiejing03",
        color=5,
        decorate=6,
        des="矿石熔炼后获得神兵碎片\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞、珍藏商城",
        errorcode="七彩结晶不图纸",
        sourceId={
            
        },
    },
    [10536]={
        Id=10536,
        name="矿石徽记",
        icon="icon-73",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可神器升级、突破\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞-矿石熔炼、珍藏商城",
        errorcode="矿石徽记不足",
        sourceId={
            18,
        },
    },
    [10537]={
        Id=10537,
        name="宝石徽记",
        icon="icon-74",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可神器刻印\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞-矿石熔炼、珍藏商城",
        errorcode="宝石徽记不足",
        sourceId={
            19,
        },
    },
    [10538]={
        Id=10538,
        name="神兵碎片",
        icon="icon-shenbingsuipian",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可激活神器\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞-矿石熔炼、珍藏商城",
        errorcode="神兵碎片不足",
        sourceId={
            17,
        },
    },
    [10539]={
        Id=10539,
        name="熔炼积分",
        icon="icon-qicaijingceng",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在矿石商店中兑换成神兵碎片\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：翡翠矿洞-矿石熔炼、珍藏商城",
        errorcode="熔炼积分不足",
        sourceId={
            
        },
    },
    [10600]={
        Id=10600,
        name="活动积分",
        icon="currency_act_01",
        color=4,
        decorate=6,
        des="完成活动所获得的积分，可以在活动商店内兑换珍稀资源\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：活动",
        errorcode="活动积分不足",
        sourceId={
            
        },
    },
    [10601]={
        Id=10601,
        name="神秘商店积分",
        icon="icon-shenmishangdianjifen",
        color=4,
        decorate=6,
        des="在神秘商店消耗钻石所获得的积分\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：神秘商店",
        errorcode="神秘商店积分不足",
        sourceId={
            
        },
    },
    [10602]={
        Id=10602,
        name="皇庭争夺占领积分",
        icon="icon-huangtingzhengbajifen",
        color=4,
        decorate=6,
        des="皇庭争夺占领积分消耗",
        errorcode="皇庭争夺占领积分不足",
        sourceId={
            
        },
    },
    [10603]={
        Id=10603,
        name="镇魔积分",
        icon="icon-65",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在镇魔商店中兑换魔灵宝匣\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：魔灵押送",
        errorcode="镇魔积分不足",
        sourceId={
            
        },
    },
    [10604]={
        Id=10604,
        name="天下无双个人贡献值",
        icon="icon-wushuang",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在无双商店中消费\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：天下无双",
        errorcode="个人贡献值不足",
        sourceId={
            
        },
    },
    [10605]={
        Id=10605,
        name="兵力",
        icon="icon-binli",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在领地争夺战斗中消耗\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：家族兵营",
        errorcode="兵力不足",
        sourceId={
            
        },
    },
    [10606]={
        Id=10606,
        name="宝库奖券",
        icon="icon_baokuquan",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在家族宝库中进行抽奖\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：领地争夺",
        errorcode="奖券不足",
        sourceId={
            
        },
    },
    [10607]={
        Id=10607,
        name="皇庭征召令",
        icon="jiazurenwu-huangtinzhengzhaoling",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在国王争夺-皇庭征召中进行抽奖\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：国王争夺",
        errorcode="征召令不足",
        sourceId={
            
        },
    },
    [10608]={
        Id=10608,
        name="金珍珠",
        icon="icon-jinzhenzhu",
        color=4,
        decorate=6,
        des="极其珍贵的货币，可以地下城商店内兑换珍稀资源\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：地下城挑战或扫荡有几率获得",
        errorcode="金珍珠不足",
        sourceId={
            
        },
    },
    [10609]={
        Id=10609,
        name="主宰币",
        icon="jiazurenwu-huangtinzhengzhaoling",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在主宰商店购买商品\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：主宰之殿",
        errorcode="主宰币不足",
        sourceId={
            
        },
    },
    [10700]={
        Id=10700,
        name="体力",
        icon="icon-fantuan",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：忍者们最喜欢的食物，关卡等日常玩法中的消耗品\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：招财喵、挂机获得",
        errorcode="体力不足",
        sourceId={
            9,2,61,
        },
    },
    [10711]={
        Id=10711,
        name="秘术之印",
        icon="icon-mishuzhiyin",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在魂器商店兑换物品\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：秘术之塔",
        errorcode="秘术之印不足",
        sourceId={
            7,
        },
    },
    [10721]={
        Id=10721,
        name="刷新令",
        icon="icon-shuaxin",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在魂尘商店、魂器商店刷新商品\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：每日任务、活动",
        errorcode="刷新令不足",
        sourceId={
            24,
        },
    },
    [10722]={
        Id=10722,
        name="矿工皮肤券",
        icon="icon-yingshi",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在矿工商店中购买矿工皮肤\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：每日任务",
        errorcode="萤石不足",
        sourceId={
            24,
        },
    },
    [10800]={
        Id=10800,
        name="兵粮丸",
        icon="icon-junliang",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在矿战玩法中移动消耗以及兑换兵力",
        errorcode="兵粮丸不足",
        sourceId={
            
        },
    },
    [10801]={
        Id=10801,
        name="攻击令",
        icon="icon-gongjiling",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在矿战玩法中挑战其他玩家消耗",
        errorcode="攻击令不足",
        sourceId={
            
        },
    },
    [10802]={
        Id=10802,
        name="装备币",
        icon="icon-74",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在装备商店中兑换装备\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：通缉大厅、熔炼装备",
        errorcode="精铁不足",
        sourceId={
            4,11,
        },
    },
    [10803]={
        Id=10803,
        name="荣耀积分",
        icon="icon-shanjin",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在超级商店中兑换道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：活动",
        errorcode="荣耀徽记不足",
        sourceId={
            
        },
    },
    [10804]={
        Id=10804,
        name="远征积分",
        icon="icon-zhengbajifen",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在远征积分商店中兑换道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：忍界远征活动",
        errorcode="远征积分不足",
        sourceId={
            
        },
    },
    [10805]={
        Id=10805,
        name="远征积分",
        icon="icon-zhengbajifen",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在远征积分商店中兑换道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：忍界远征活动",
        errorcode="远征积分不足",
        sourceId={
            
        },
    },
    [10806]={
        Id=10806,
        name="典藏神玉",
        icon="icon-shenyu",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在典藏屋中兑换道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：召唤",
        errorcode="典藏神玉不足",
        sourceId={
            5,
        },
    },
    [10807]={
        Id=10807,
        name="兵粮丸",
        icon="icon-junliang",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在矿战玩法中移动消耗以及兑换兵力",
        errorcode="兵粮丸不足",
        sourceId={
            
        },
    },
    [10808]={
        Id=10808,
        name="攻击令",
        icon="icon-gongjiling",
        color=4,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在矿战玩法中挑战其他玩家消耗",
        errorcode="攻击令不足",
        sourceId={
            
        },
    },
    [10809]={
        Id=10809,
        name="冠军币",
        icon="icon-guanjunbi",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在杯赛商城中兑换各种道具\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：跨服杯赛活动",
        errorcode="冠军币不足",
        sourceId={
            62,
        },
    },
    [10810]={
        Id=10810,
        name="家族徽章",
        icon="icon-jiazuhuizhang",
        color=5,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可在家族秘法中升级职业秘法\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：家族BOSS",
        errorcode="家族徽章不足",
        sourceId={
            
        },
    },
    [10811]={
        Id=10811,
        name="符文粉尘",
        icon="icon-fuwenfencengg",
        color=5,
        decorate=6,
        des="<div fontcolor=#eb5f06 outline=2,#000000>用途</div>：可用于重铸符文的属性和技能\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：符文分解、符文圣地掉落、符文合成失败后返还材料",
        errorcode="粉尘不足",
        sourceId={
            63,
        },
    },
    [19997]={
        Id=19997,
        name="挂机特权",
        icon="icon-guaji",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>特权</div>：每天<div fontcolor=#fd7d01 outline=2,#000000>3次免费</div>挂机加速，<div fontcolor=#fd7d01 outline=2,#000000>8次额外</div>挂机加速购买次数\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：购买特权卡-挂机特权",
        errorcode="",
        sourceId={
            
        },
    },
    [19998]={
        Id=19998,
        name="紫色通缉特权",
        icon="icon-zesetongji",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>特权</div>：通缉大厅每日<div fontcolor=#fd7d01 outline=2,#000000>首次</div>钻石刷新必出<div fontcolor=#fd7d01 outline=2,#000000>紫色</div>首领\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：购买特权卡-紫色通缉",
        errorcode="",
        sourceId={
            
        },
    },
    [19999]={
        Id=19999,
        name="橙色通缉特权",
        icon="icon-chengsetongji",
        color=5,
        decorate=7,
        des="<div fontcolor=#eb5f06 outline=2,#000000>特权</div>：通缉大厅每日<div fontcolor=#fd7d01 outline=2,#000000>第3次</div>钻石刷新必出<div fontcolor=#fd7d01 outline=2,#000000>橙色</div>首领\n<div fontcolor=#eb5f06 outline=2,#000000>来源</div>：购买特权卡-橙色通缉",
        errorcode="",
        sourceId={
            
        },
    },
}
