return {
  version = "1.1",
  luaversion = "5.1",
  tiledversion = "0.14.2",
  orientation = "isometric",
  renderorder = "right-down",
  width = 25,
  height = 25,
  tilewidth = 264,
  tileheight = 120,
  nextobjectid = 65,
  properties = {},
  tilesets = {
    {
      name = "shui01",
      firstgid = 1,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shui01.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu01",
      firstgid = 2,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu01.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "caodi01",
      firstgid = 3,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/caodi01.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "caodi02",
      firstgid = 4,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/caodi02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "caodi03",
      firstgid = 5,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/caodi03.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "caodi04",
      firstgid = 6,
      tilewidth = 266,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/caodi04.png",
      imagewidth = 266,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huangdi01",
      firstgid = 7,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huangdi01.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huangdi02",
      firstgid = 8,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huangdi02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shui01",
      firstgid = 9,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shui01.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shui02",
      firstgid = 10,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shui02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shui03",
      firstgid = 11,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shui03.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu01",
      firstgid = 12,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu01.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu02",
      firstgid = 13,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu03",
      firstgid = 14,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu03.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu04",
      firstgid = 15,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu04.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "youdi01",
      firstgid = 16,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/youdi01.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "youdi02",
      firstgid = 17,
      tilewidth = 265,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/youdi02.png",
      imagewidth = 265,
      imageheight = 120,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "youdi03",
      firstgid = 18,
      tilewidth = 265,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/youdi03.png",
      imagewidth = 265,
      imageheight = 120,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou01",
      firstgid = 19,
      tilewidth = 266,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou01.png",
      imagewidth = 266,
      imageheight = 120,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huoshan02",
      firstgid = 20,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huoshan02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huoshan03",
      firstgid = 21,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huoshan03.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu05",
      firstgid = 22,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu05.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tu06",
      firstgid = 23,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tu06.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou02",
      firstgid = 24,
      tilewidth = 266,
      tileheight = 233,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou02.png",
      imagewidth = 266,
      imageheight = 233,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "2026"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou03",
      firstgid = 25,
      tilewidth = 266,
      tileheight = 233,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou03.png",
      imagewidth = 266,
      imageheight = 233,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "2027"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou04",
      firstgid = 26,
      tilewidth = 266,
      tileheight = 393,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou04.png",
      imagewidth = 266,
      imageheight = 393,
      tileoffset = {
        x = 3,
        y = 272
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou05",
      firstgid = 27,
      tilewidth = 296,
      tileheight = 671,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou05.png",
      imagewidth = 296,
      imageheight = 671,
      tileoffset = {
        x = -31,
        y = 549
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou06",
      firstgid = 28,
      tilewidth = 266,
      tileheight = 671,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou06.png",
      imagewidth = 266,
      imageheight = 671,
      tileoffset = {
        x = 0,
        y = 550
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou07",
      firstgid = 29,
      tilewidth = 269,
      tileheight = 671,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou07.png",
      imagewidth = 269,
      imageheight = 671,
      tileoffset = {
        x = 0,
        y = 549
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou08",
      firstgid = 30,
      tilewidth = 266,
      tileheight = 393,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou08.png",
      imagewidth = 266,
      imageheight = 393,
      tileoffset = {
        x = 0,
        y = 272
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou09",
      firstgid = 31,
      tilewidth = 296,
      tileheight = 671,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou09.png",
      imagewidth = 296,
      imageheight = 671,
      tileoffset = {
        x = 2,
        y = 551
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "bukezou10",
      firstgid = 32,
      tilewidth = 266,
      tileheight = 671,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/bukezou10.png",
      imagewidth = 266,
      imageheight = 671,
      tileoffset = {
        x = 0,
        y = 549
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huo01",
      firstgid = 33,
      tilewidth = 171,
      tileheight = 169,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huo01.png",
      imagewidth = 171,
      imageheight = 169,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1003"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "feng01",
      firstgid = 34,
      tilewidth = 173,
      tileheight = 141,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/feng01.png",
      imagewidth = 173,
      imageheight = 141,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1001"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "fuben01",
      firstgid = 35,
      tilewidth = 150,
      tileheight = 133,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/fuben01.png",
      imagewidth = 150,
      imageheight = 133,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1013"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "gonghui01",
      firstgid = 36,
      tilewidth = 152,
      tileheight = 155,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/gonghui01.png",
      imagewidth = 152,
      imageheight = 155,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1008"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lin01",
      firstgid = 37,
      tilewidth = 176,
      tileheight = 134,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lin01.png",
      imagewidth = 176,
      imageheight = 134,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1002"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shan01",
      firstgid = 38,
      tilewidth = 175,
      tileheight = 132,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shan01.png",
      imagewidth = 175,
      imageheight = 132,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1004"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "ta01",
      firstgid = 39,
      tilewidth = 150,
      tileheight = 184,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/ta01.png",
      imagewidth = 150,
      imageheight = 184,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1006"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "xuanshang01",
      firstgid = 40,
      tilewidth = 133,
      tileheight = 134,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/xuanshang01.png",
      imagewidth = 133,
      imageheight = 134,
      tileoffset = {
        x = 61,
        y = -25
      },
      properties = {
        ["id"] = "1007"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "yin01",
      firstgid = 41,
      tilewidth = 171,
      tileheight = 169,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/yin01.png",
      imagewidth = 171,
      imageheight = 169,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "1005"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huoshan01",
      firstgid = 42,
      tilewidth = 264,
      tileheight = 150,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huoshan01.png",
      imagewidth = 264,
      imageheight = 150,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "2009"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "xueshan02",
      firstgid = 43,
      tilewidth = 171,
      tileheight = 111,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/xueshan02.png",
      imagewidth = 171,
      imageheight = 111,
      tileoffset = {
        x = 87,
        y = -8
      },
      properties = {
        ["id"] = "2008"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lvshitou03",
      firstgid = 44,
      tilewidth = 187,
      tileheight = 107,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lvshitou03.png",
      imagewidth = 187,
      imageheight = 107,
      tileoffset = {
        x = 36,
        y = -13
      },
      properties = {
        ["id"] = "2015"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lvshu01",
      firstgid = 45,
      tilewidth = 197,
      tileheight = 127,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lvshu01.png",
      imagewidth = 197,
      imageheight = 127,
      tileoffset = {
        x = 31,
        y = -7
      },
      properties = {
        ["id"] = "2001"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "hongshu01",
      firstgid = 46,
      tilewidth = 208,
      tileheight = 134,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/hongshu01.png",
      imagewidth = 208,
      imageheight = 134,
      tileoffset = {
        x = 26,
        y = -3
      },
      properties = {
        ["id"] = "2003"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lvshitou01",
      firstgid = 47,
      tilewidth = 176,
      tileheight = 107,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lvshitou01.png",
      imagewidth = 176,
      imageheight = 107,
      tileoffset = {
        x = 58,
        y = -20
      },
      properties = {
        ["id"] = "2013"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lvshitou02",
      firstgid = 48,
      tilewidth = 176,
      tileheight = 107,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lvshitou02.png",
      imagewidth = 176,
      imageheight = 107,
      tileoffset = {
        x = 41,
        y = -26
      },
      properties = {
        ["id"] = "2014"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "hongshitou01",
      firstgid = 49,
      tilewidth = 211,
      tileheight = 118,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/hongshitou01.png",
      imagewidth = 211,
      imageheight = 118,
      tileoffset = {
        x = 22,
        y = -9
      },
      properties = {
        ["id"] = "2018"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lvshu02",
      firstgid = 50,
      tilewidth = 185,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lvshu02.png",
      imagewidth = 185,
      imageheight = 120,
      tileoffset = {
        x = 40,
        y = -13
      },
      properties = {
        ["id"] = "2002"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "tushitou01",
      firstgid = 51,
      tilewidth = 199,
      tileheight = 96,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/tushitou01.png",
      imagewidth = 199,
      imageheight = 96,
      tileoffset = {
        x = 40,
        y = -37
      },
      properties = {
        ["id"] = "2016"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "youshitou01",
      firstgid = 52,
      tilewidth = 192,
      tileheight = 113,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/youshitou01.png",
      imagewidth = 192,
      imageheight = 113,
      tileoffset = {
        x = 54,
        y = -29
      },
      properties = {
        ["id"] = "2017"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "youshu02",
      firstgid = 53,
      tilewidth = 196,
      tileheight = 108,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/youshu02.png",
      imagewidth = 196,
      imageheight = 108,
      tileoffset = {
        x = 48,
        y = -17
      },
      properties = {
        ["id"] = "2006"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shishan01",
      firstgid = 54,
      tilewidth = 196,
      tileheight = 115,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shishan01.png",
      imagewidth = 196,
      imageheight = 115,
      tileoffset = {
        x = 39,
        y = -22
      },
      properties = {
        ["id"] = "2010"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "suozhen02",
      firstgid = 55,
      tilewidth = 172,
      tileheight = 130,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/suozhen02.png",
      imagewidth = 172,
      imageheight = 130,
      tileoffset = {
        x = 45,
        y = -23
      },
      properties = {
        ["id"] = "2012"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "xueshan01",
      firstgid = 56,
      tilewidth = 234,
      tileheight = 153,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/xueshan01.png",
      imagewidth = 234,
      imageheight = 153,
      tileoffset = {
        x = 8,
        y = -6
      },
      properties = {
        ["id"] = "2007"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "zhen01",
      firstgid = 57,
      tilewidth = 134,
      tileheight = 87,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/zhen01.png",
      imagewidth = 134,
      imageheight = 87,
      tileoffset = {
        x = 65,
        y = -22
      },
      properties = {
        ["id"] = "2011"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "hongshu02",
      firstgid = 58,
      tilewidth = 216,
      tileheight = 130,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/hongshu02.png",
      imagewidth = 216,
      imageheight = 130,
      tileoffset = {
        x = 33,
        y = -15
      },
      properties = {
        ["id"] = "2004"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "maitian01",
      firstgid = 59,
      tilewidth = 252,
      tileheight = 118,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/maitian01.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 6,
        y = -3
      },
      properties = {
        ["id"] = "2019"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "diaoxiang01",
      firstgid = 60,
      tilewidth = 217,
      tileheight = 208,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/diaoxiang01.png",
      imagewidth = 217,
      imageheight = 208,
      tileoffset = {
        x = 12,
        y = -32
      },
      properties = {
        ["id"] = "2021"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "maitian02",
      firstgid = 61,
      tilewidth = 240,
      tileheight = 114,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/maitian02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 11,
        y = -4
      },
      properties = {
        ["id"] = "2020"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "gutou01",
      firstgid = 62,
      tilewidth = 157,
      tileheight = 89,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/gutou01.png",
      imagewidth = 157,
      imageheight = 89,
      tileoffset = {
        x = 56,
        y = -26
      },
      properties = {
        ["id"] = "2022"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "lei01",
      firstgid = 63,
      tilewidth = 183,
      tileheight = 180,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/lei01.png",
      imagewidth = 183,
      imageheight = 180,
      tileoffset = {
        x = 51,
        y = -20
      },
      properties = {
        ["id"] = "101"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huoshan04",
      firstgid = 64,
      tilewidth = 264,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huoshan04.png",
      imagewidth = 264,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "maitian02",
      firstgid = 65,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/maitian02.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "maitian01",
      firstgid = 66,
      tilewidth = 265,
      tileheight = 119,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/maitian01.png",
      imagewidth = 265,
      imageheight = 119,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jianzhu01",
      firstgid = 67,
      tilewidth = 483,
      tileheight = 255,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jianzhu01.png",
      imagewidth = 483,
      imageheight = 255,
      tileoffset = {
        x = -99,
        y = -16
      },
      properties = {
        ["id"] = "1014"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jianzhu02",
      firstgid = 68,
      tilewidth = 483,
      tileheight = 255,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jianzhu02.png",
      imagewidth = 483,
      imageheight = 255,
      tileoffset = {
        x = -99,
        y = -16
      },
      properties = {
        ["id"] = "1015"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jianzhu03",
      firstgid = 69,
      tilewidth = 483,
      tileheight = 255,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jianzhu03.png",
      imagewidth = 483,
      imageheight = 255,
      tileoffset = {
        x = -99,
        y = -16
      },
      properties = {
        ["id"] = "1016"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jianzhu04",
      firstgid = 70,
      tilewidth = 483,
      tileheight = 255,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jianzhu04.png",
      imagewidth = 483,
      imageheight = 255,
      tileoffset = {
        x = -99,
        y = -16
      },
      properties = {
        ["id"] = "1017"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "wanzigu01",
      firstgid = 71,
      tilewidth = 515,
      tileheight = 263,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/wanzigu01.png",
      imagewidth = 515,
      imageheight = 263,
      tileoffset = {
        x = -121,
        y = -16
      },
      properties = {
        ["id"] = "1010"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "biwu01",
      firstgid = 72,
      tilewidth = 209,
      tileheight = 168,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/biwu01.png",
      imagewidth = 209,
      imageheight = 168,
      tileoffset = {
        x = 26,
        y = -15
      },
      properties = {
        ["id"] = "1210"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinkuang01",
      firstgid = 73,
      tilewidth = 179,
      tileheight = 145,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinkuang01.png",
      imagewidth = 179,
      imageheight = 145,
      tileoffset = {
        x = 59,
        y = -25
      },
      properties = {
        ["id"] = "1012"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huangcheng01",
      firstgid = 74,
      tilewidth = 482,
      tileheight = 320,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huangcheng01.png",
      imagewidth = 482,
      imageheight = 320,
      tileoffset = {
        x = -99,
        y = -16
      },
      properties = {
        ["id"] = "1009"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shenyuan01",
      firstgid = 75,
      tilewidth = 796,
      tileheight = 362,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shenyuan01.png",
      imagewidth = 796,
      imageheight = 362,
      tileoffset = {
        x = -263,
        y = 241
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "dikuai01",
      firstgid = 76,
      tilewidth = 281,
      tileheight = 233,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/dikuai01.png",
      imagewidth = 286,
      imageheight = 236,
      tileoffset = {
        x = -13,
        y = 113
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinbi01",
      firstgid = 77,
      tilewidth = 120,
      tileheight = 97,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinbi01.png",
      imagewidth = 120,
      imageheight = 97,
      tileoffset = {
        x = 83,
        y = -36
      },
      properties = {
        ["id"] = "1201"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huoxing01",
      firstgid = 78,
      tilewidth = 266,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huoxing01.png",
      imagewidth = 266,
      imageheight = 120,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "1230"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "map_touming",
      firstgid = 79,
      tilewidth = 264,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/map_touming.png",
      imagewidth = 264,
      imageheight = 120,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "juexing01",
      firstgid = 80,
      tilewidth = 482,
      tileheight = 320,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/juexing01.png",
      imagewidth = 482,
      imageheight = 320,
      tileoffset = {
        x = -99,
        y = -16
      },
      properties = {
        ["id"] = "1220"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "guishu01",
      firstgid = 81,
      tilewidth = 242,
      tileheight = 176,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/guishu01.png",
      imagewidth = 242,
      imageheight = 176,
      tileoffset = {
        x = 36,
        y = -18
      },
      properties = {
        ["id"] = "2024"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "fengche01",
      firstgid = 82,
      tilewidth = 225,
      tileheight = 171,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/fengche01.png",
      imagewidth = 225,
      imageheight = 171,
      tileoffset = {
        x = 18,
        y = -20
      },
      properties = {
        ["id"] = "2023"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "huoshan05",
      firstgid = 83,
      tilewidth = 265,
      tileheight = 120,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/huoshan05.png",
      imagewidth = 265,
      imageheight = 120,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "shuxingjitan",
      firstgid = 84,
      tilewidth = 133,
      tileheight = 135,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/shuxingjitan.png",
      imagewidth = 133,
      imageheight = 135,
      tileoffset = {
        x = 59,
        y = -21
      },
      properties = {
        ["id"] = "2025"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinbi02_huangdi",
      firstgid = 85,
      tilewidth = 140,
      tileheight = 114,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinbi02_huangdi.png",
      imagewidth = 140,
      imageheight = 114,
      tileoffset = {
        x = 60,
        y = -20
      },
      properties = {
        ["id"] = "1202"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinbi03_huoshan",
      firstgid = 86,
      tilewidth = 129,
      tileheight = 110,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinbi03_huoshan.png",
      imagewidth = 129,
      imageheight = 110,
      tileoffset = {
        x = 67,
        y = -26
      },
      properties = {
        ["id"] = "1203"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinbi04_shulin",
      firstgid = 87,
      tilewidth = 124,
      tileheight = 109,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinbi04_shulin.png",
      imagewidth = 124,
      imageheight = 109,
      tileoffset = {
        x = 75,
        y = -27
      },
      properties = {
        ["id"] = "1204"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinbi05_xueshan",
      firstgid = 88,
      tilewidth = 120,
      tileheight = 103,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinbi05_xueshan.png",
      imagewidth = 120,
      imageheight = 103,
      tileoffset = {
        x = 60,
        y = -28
      },
      properties = {
        ["id"] = "1205"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jinbi06_youdi",
      firstgid = 89,
      tilewidth = 117,
      tileheight = 107,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jinbi06_youdi.png",
      imagewidth = 117,
      imageheight = 107,
      tileoffset = {
        x = 75,
        y = -23
      },
      properties = {
        ["id"] = "1206"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "dikuai02",
      firstgid = 90,
      tilewidth = 286,
      tileheight = 247,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/dikuai02.png",
      imagewidth = 286,
      imageheight = 247,
      tileoffset = {
        x = -17,
        y = 117
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "boss_xue",
      firstgid = 91,
      tilewidth = 339,
      tileheight = 244,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/boss_xue.png",
      imagewidth = 339,
      imageheight = 244,
      tileoffset = {
        x = -41,
        y = -36
      },
      properties = {
        ["id"] = "1304"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "boss_an",
      firstgid = 92,
      tilewidth = 339,
      tileheight = 244,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/boss_an.png",
      imagewidth = 339,
      imageheight = 244,
      tileoffset = {
        x = -40,
        y = -38
      },
      properties = {
        ["id"] = "1303"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "boss_huo",
      firstgid = 93,
      tilewidth = 339,
      tileheight = 244,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/boss_huo.png",
      imagewidth = 339,
      imageheight = 244,
      tileoffset = {
        x = -42,
        y = -46
      },
      properties = {
        ["id"] = "1302"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "boss_feng",
      firstgid = 94,
      tilewidth = 339,
      tileheight = 244,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/boss_feng.png",
      imagewidth = 339,
      imageheight = 244,
      tileoffset = {
        x = -41,
        y = -36
      },
      properties = {
        ["id"] = "1301"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jingying_feng",
      firstgid = 95,
      tilewidth = 212,
      tileheight = 198,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jingying_feng.png",
      imagewidth = 212,
      imageheight = 198,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "1251"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jingying_huo",
      firstgid = 96,
      tilewidth = 212,
      tileheight = 198,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jingying_huo.png",
      imagewidth = 212,
      imageheight = 198,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "1252"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jingying_an",
      firstgid = 97,
      tilewidth = 212,
      tileheight = 198,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jingying_an.png",
      imagewidth = 212,
      imageheight = 198,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "1253"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "jingying_bing",
      firstgid = 98,
      tilewidth = 212,
      tileheight = 198,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/jingying_bing.png",
      imagewidth = 212,
      imageheight = 198,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "1254"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "renhuangyunluo",
      firstgid = 99,
      tilewidth = 139,
      tileheight = 182,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/renhuangyunluo.png",
      imagewidth = 139,
      imageheight = 182,
      tileoffset = {
        x = 77,
        y = -16
      },
      properties = {
        ["id"] = "3001"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "liehundian",
      firstgid = 100,
      tilewidth = 171,
      tileheight = 169,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/liehundian.png",
      imagewidth = 171,
      imageheight = 169,
      tileoffset = {
        x = 50,
        y = -23
      },
      properties = {
        ["id"] = "1018"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "xinshou_huolang",
      firstgid = 101,
      tilewidth = 452,
      tileheight = 282,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/xinshou_huolang.png",
      imagewidth = 452,
      imageheight = 282,
      tileoffset = {
        x = -95,
        y = -43
      },
      properties = {
        ["id"] = "1255"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "effcet_huanhuashen",
      firstgid = 102,
      tilewidth = 190,
      tileheight = 212,
      spacing = 0,
      margin = 0,
      image = "../../../res/map/effcet_huanhuashen.png",
      imagewidth = 190,
      imageheight = 212,
      tileoffset = {
        x = 0,
        y = 0
      },
      properties = {
        ["id"] = "1256"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "bg",
      x = 0,
      y = 0,
      width = 25,
      height = 25,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 31,
        19, 9, 10, 11, 9, 11, 9, 11, 11, 14, 2, 2, 16, 17, 17, 17, 16, 18, 17, 17, 17, 17, 17, 18, 30,
        19, 9, 11, 11, 9, 9, 11, 11, 11, 11, 11, 2, 16, 17, 18, 16, 17, 17, 17, 16, 16, 17, 18, 17, 32,
        19, 11, 10, 11, 10, 11, 11, 17, 17, 11, 7, 7, 2, 17, 17, 17, 17, 17, 17, 16, 17, 16, 17, 17, 30,
        19, 9, 11, 11, 11, 10, 9, 17, 9, 15, 22, 22, 18, 17, 17, 17, 17, 17, 17, 18, 17, 17, 17, 17, 32,
        19, 11, 17, 9, 11, 11, 11, 11, 17, 11, 22, 22, 15, 15, 17, 17, 17, 16, 17, 17, 16, 17, 17, 17, 30,
        19, 11, 11, 9, 11, 17, 10, 11, 9, 17, 15, 15, 15, 17, 17, 18, 17, 17, 17, 17, 17, 17, 17, 17, 32,
        19, 9, 17, 11, 17, 17, 11, 17, 17, 17, 15, 22, 15, 15, 15, 15, 17, 17, 17, 18, 17, 17, 17, 17, 30,
        19, 2, 17, 17, 17, 11, 11, 10, 17, 17, 2, 14, 7, 15, 15, 22, 7, 17, 15, 17, 17, 16, 18, 17, 32,
        19, 2, 11, 13, 13, 17, 15, 11, 17, 9, 15, 7, 7, 7, 22, 7, 2, 2, 17, 17, 17, 15, 17, 16, 30,
        19, 13, 2, 2, 2, 13, 13, 15, 9, 9, 17, 3, 8, 66, 6, 65, 22, 2, 13, 13, 15, 15, 15, 17, 32,
        19, 13, 13, 13, 2, 14, 8, 7, 15, 17, 15, 65, 3, 3, 66, 65, 7, 7, 22, 22, 13, 2, 15, 15, 30,
        19, 13, 13, 2, 2, 13, 22, 7, 11, 15, 7, 3, 66, 65, 65, 3, 5, 3, 3, 5, 4, 6, 6, 6, 32,
        19, 2, 2, 13, 13, 2, 2, 13, 7, 7, 7, 3, 65, 5, 6, 5, 3, 5, 4, 4, 75, 79, 79, 6, 30,
        19, 20, 21, 21, 83, 2, 2, 13, 23, 2, 13, 3, 3, 5, 5, 5, 5, 65, 6, 6, 79, 76, 79, 4, 32,
        19, 21, 21, 64, 2, 13, 2, 2, 2, 2, 23, 13, 22, 3, 3, 3, 65, 6, 6, 6, 79, 90, 79, 3, 30,
        19, 64, 21, 20, 21, 2, 13, 2, 2, 2, 2, 7, 7, 3, 5, 5, 5, 6, 4, 3, 6, 4, 3, 6, 32,
        19, 83, 21, 83, 20, 21, 20, 2, 2, 2, 13, 13, 7, 22, 5, 4, 6, 66, 65, 4, 3, 4, 3, 6, 30,
        19, 21, 20, 64, 21, 21, 21, 64, 21, 2, 2, 13, 14, 3, 6, 5, 5, 3, 4, 3, 3, 3, 6, 7, 32,
        19, 21, 64, 64, 64, 83, 64, 64, 64, 20, 13, 13, 7, 7, 3, 4, 6, 7, 7, 7, 7, 7, 7, 14, 30,
        19, 83, 21, 64, 83, 21, 21, 21, 21, 2, 2, 23, 7, 7, 7, 7, 6, 6, 7, 7, 7, 15, 15, 13, 32,
        19, 83, 21, 83, 21, 20, 21, 21, 20, 2, 14, 22, 7, 7, 3, 5, 6, 6, 7, 14, 15, 16, 16, 19, 30,
        19, 64, 21, 20, 21, 83, 64, 21, 2, 13, 22, 7, 7, 7, 7, 4, 3, 6, 7, 7, 15, 20, 16, 16, 32,
        19, 20, 64, 21, 64, 83, 83, 2, 13, 13, 22, 7, 7, 22, 3, 3, 4, 6, 7, 15, 13, 16, 19, 18, 30,
        27, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 28, 26, 29
      }
    },
    {
      type = "tilelayer",
      name = "spine",
      x = 0,
      y = 0,
      width = 25,
      height = 25,
      visible = false,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {
        ["id"] = "2008"
      },
      encoding = "lua",
      data = {
        25, 0, 0, 25, 0, 0, 0, 0, 25, 25, 0, 0, 0, 0, 25, 0, 0, 0, 25, 0, 0, 0, 0, 0, 24,
        0, 43, 56, 56, 56, 56, 56, 43, 56, 0, 60, 51, 53, 53, 81, 89, 53, 0, 52, 81, 53, 0, 62, 84, 0,
        0, 56, 56, 0, 0, 56, 0, 0, 0, 0, 0, 51, 0, 0, 0, 53, 53, 0, 53, 0, 0, 53, 0, 0, 0,
        0, 56, 0, 0, 55, 0, 0, 0, 0, 0, 46, 0, 84, 52, 53, 0, 52, 53, 81, 53, 0, 0, 53, 52, 0,
        0, 56, 0, 55, 57, 55, 0, 0, 56, 0, 0, 49, 0, 0, 53, 0, 0, 53, 62, 0, 53, 81, 0, 0, 0,
        24, 56, 0, 0, 55, 0, 0, 0, 0, 88, 58, 58, 51, 51, 0, 0, 92, 0, 53, 53, 52, 0, 53, 53, 0,
        0, 56, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 53, 81, 0, 52, 53, 0, 89, 0, 57, 0, 81, 0,
        0, 51, 0, 0, 84, 0, 56, 0, 0, 0, 0, 58, 85, 0, 0, 51, 53, 0, 0, 0, 53, 0, 53, 53, 0,
        0, 0, 56, 0, 0, 0, 0, 56, 56, 56, 0, 0, 87, 0, 51, 58, 0, 0, 0, 0, 0, 89, 0, 0, 0,
        0, 0, 88, 51, 51, 56, 0, 43, 0, 0, 0, 0, 0, 0, 0, 97, 0, 51, 0, 71, 51, 0, 0, 53, 0,
        24, 51, 0, 0, 0, 0, 51, 0, 0, 91, 0, 45, 0, 0, 48, 0, 0, 58, 0, 0, 0, 0, 55, 0, 0,
        24, 0, 85, 51, 51, 0, 58, 87, 0, 0, 0, 0, 0, 74, 0, 0, 0, 0, 0, 87, 54, 51, 0, 51, 0,
        0, 54, 60, 0, 0, 51, 58, 0, 98, 0, 0, 44, 0, 0, 0, 44, 50, 82, 0, 0, 45, 45, 0, 48, 0,
        0, 62, 0, 51, 51, 0, 0, 0, 58, 87, 0, 45, 0, 50, 84, 0, 45, 45, 44, 45, 78, 78, 78, 45, 0,
        0, 0, 0, 0, 0, 0, 51, 0, 57, 0, 0, 0, 44, 45, 45, 45, 44, 0, 45, 50, 78, 39, 78, 49, 0,
        0, 0, 54, 0, 55, 0, 0, 0, 85, 0, 51, 0, 0, 0, 0, 50, 0, 87, 0, 0, 78, 0, 78, 45, 0,
        0, 0, 0, 0, 84, 0, 54, 0, 0, 51, 0, 0, 0, 0, 94, 45, 45, 36, 50, 45, 0, 50, 45, 48, 0,
        24, 42, 51, 0, 0, 55, 42, 0, 54, 0, 0, 0, 0, 45, 87, 45, 0, 0, 0, 0, 45, 45, 45, 40, 0,
        0, 0, 0, 0, 0, 42, 0, 0, 0, 0, 0, 0, 51, 0, 48, 0, 84, 0, 0, 45, 72, 45, 50, 45, 0,
        0, 55, 0, 42, 0, 0, 0, 93, 42, 0, 0, 80, 45, 0, 45, 44, 0, 47, 87, 49, 0, 58, 0, 85, 0,
        0, 42, 0, 54, 0, 0, 54, 42, 0, 0, 54, 0, 0, 49, 0, 95, 45, 0, 35, 0, 0, 0, 0, 51, 0,
        0, 42, 0, 0, 0, 0, 86, 86, 55, 0, 0, 0, 51, 0, 48, 50, 84, 45, 0, 51, 102, 87, 0, 0, 0,
        0, 62, 84, 0, 51, 0, 54, 96, 0, 51, 0, 58, 0, 0, 0, 0, 0, 50, 46, 0, 0, 101, 0, 81, 0,
        25, 54, 42, 0, 0, 42, 42, 0, 0, 0, 51, 100, 0, 0, 45, 0, 82, 44, 0, 0, 0, 84, 0, 0, 0,
        25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      name = "ui",
      x = 0,
      y = 0,
      width = 25,
      height = 25,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    }
  }
}
