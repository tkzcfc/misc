return {
    [1]={
        achvId=1,
        p2=10,
    },
    [2]={
        achvId=2,
        p2=20,
    },
    [3]={
        achvId=3,
        p2=5,
    },
    [4]={
        achvId=4,
        p2=10,
    },
}
