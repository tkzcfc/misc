return {
    [1]={
        id=1,
        name="新手推荐",
        star=2,
        team={
            20005,20012,20014,20017,20040,
        },
        teamCore={
            20014,20017,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【易上手】【性价比】【万金油】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【大荒剑士】攻击同时增加自身防御，不断提升生存能力\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【风十郎】建议放置前排，受击后对敌方进行反击，额外造成伤害，节省推图时间\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【千本樱】【卡伦】做为整个阵容的输出核心，输出不俗，前中后期性价比都非常高！\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【曼陀罗】持续治疗，非常强大的队伍续航能力",
        restrainText="新手极其容易获取的阵容，PVE能力不俗，在PVP中对没有续航的阵容也有着非常大的优势！",
    },
    [2]={
        id=2,
        name="前期压制",
        star=3,
        team={
            101,20017,20014,20047,20015,
        },
        teamCore={
            20017,20014,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【前期爆发】【一波流】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【千本樱】第2-4回合，每回合额外给随机敌人施加伤害加深\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【卡伦】第2-4回合，每回合额外给随机敌人造成伤害\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【千鹤流星】第2-4回合，每回合额外给随机敌人造成伤害并流血\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【龙影之刃】第2-4回合，每回合额外给随机后排敌人造成伤害\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【巫蛊娃娃】前期可以给队友增加大量暴击，此英雄可作为备选",
        restrainText="前期集中式的伤害爆发，克制减伤薄弱及输出过多的队伍，比如【白骨银霜】【蜂皇】【猫千岁】等。",
    },
    [3]={
        id=3,
        name="后排打击",
        star=4,
        team={
            20009,20047,20030,20042,20013,
        },
        teamCore={
            20042,20013,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【专打后排】【强力突袭】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【十二幻夜】沉睡后排敌人，让敌方输出哑火\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【御笔画眉】给后排敌人施加伤害加深，为队友提供输出环境\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【龙影之刃】【鬼火千兵卫】【影舞者】对后排敌人造成伤害；穿戴装备【影缚】四件套提升对被控制单位的伤害，搭配十二幻夜的沉睡，可以对目标造成毁灭打击",
        restrainText="无视前排，专打后排，克制恢复能力薄弱及后排脆皮多的队伍，比如【千鹤流星】【朽木白灵】等。",
    },
    [4]={
        id=4,
        name="流血暴击",
        star=4,
        team={
            101,20018,20015,20023,20020,
        },
        teamCore={
            20018,20015,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【叠加流血】【伤害必暴击】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【不败黄泉】【千鹤流星】对敌方群体叠加流血，持续造成伤害\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【不败黄泉】建议前排站位，受击后会对攻击者叠加流血\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【猫千岁】【假面银狐】她们的核心技能对流血目标造成伤害时必定暴击，强力爆发！\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【猫千岁】【假面银狐】会根据友方暴击和敌方流血人数，获得巨大的输出增幅\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【龙影之刃】也是一位强力的流血暴击英雄，此英雄可替代\"猫狐\"组合中的任意一位",
        restrainText="持续伤害搭配恐怖的暴击，专克一切菜刀英雄以及脆皮法师，比如【花京院幻心】【影舞者】等；不断叠加的持续伤害克制治疗英雄，比如【六道海皇】【曼陀罗】等。",
    },
    [5]={
        id=5,
        name="暴力菜刀",
        star=4,
        team={
            101,20022,20047,20024,20019,
        },
        teamCore={
            20022,20019,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【暴力输出】【单体点杀】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【龙影之刃】对敌方前排单体进行伤害，且施加防御降低\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【幽皇剑灵】【白骨银霜】【剑圣】三大前排单体输出，配合防御降低或伤害加深，打出成吨的伤害\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【八门石佛】也具备降低防御的能力，可作为备选\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>恐怖的单体输出，该阵容也适用BOSS战。",
        restrainText="可以正面突进防御，克制防御单调的坦克，比如【六道海皇】【九葬佛】等；克制其他一切脆皮，比如【千鹤流星】【朽木白灵】【十方琉璃】等。",
    },
    [6]={
        id=6,
        name="先手控制",
        star=4,
        team={
            20002,20043,20039,20050,20051,
        },
        teamCore={
            20002,20050,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【花样控制】【攻击叠加】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【骨魔】【狂音】对敌方群体造成伤害时附加控制\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【太慈雪一】每回合对敌方进行随机控制，并根据敌方的被控制次数提升自己的输出，穿戴装备【影缚】四件套提升对被控制单位的伤害再次强化输出\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【神州太月】【百里稻香】强力的魅惑控制，后排保护、治疗、抗暴击能力也极其强悍",
        restrainText="克制大部分输出阵容以及各种花里胡哨，先手控制，让敌方集体罚站，例如【皇八极】【假面银狐】【剑圣】，强大的抗暴击能力更是【天照帝】的天敌！",
    },
    [7]={
        id=7,
        name="能量永动",
        star=4,
        team={
            20025,20013,20031,20048,20054,
        },
        teamCore={
            20031,20048,20054,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【能量增减】【技能永动机】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【夜无月】变身型战士，变身前每回合额外回复生命以及能量，变身后输出大幅增加\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【影舞者】针对敌方后排单体进行高伤害输出，附加符能印记还能额外攻击一次\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【大咒术王】额外回复我方能量，减少敌方能量\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【幻神寺】队友暴击额外回能，搭配队友叠加的符能印记，造成爆炸输出\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【花鼓无常】入场清空敌方能量，每回合减少暴击最高目标能量，大招全体治疗驱散强力续航",
        restrainText="利用复活、变身增加生存能力，搭配高频的能量回复多次释放大招，打出成吨的伤害！频繁减少敌方能量，克制【骨魔】【太慈雪一】【忍皇】等大招发动机型英雄。",
    },
    [8]={
        id=8,
        name="护盾点杀",
        star=4,
        team={
            20002,20038,20048,20039,20021,
        },
        teamCore={
            20038,20021,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【无敌护盾】【单攻叠加】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【骨魔】【东方星辰】护盾两两叠加，激活无敌效果，搭配装备【回天】四件套，生存能力Max\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【神州太月】保护后排队友，魅惑敌方目标\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【不死鬼针】依靠队友生存，搭配能量回复，大招无限叠加伤害，穿戴装备【风刃】四件套，普通攻击针针致命",
        restrainText="依靠强生存能力坚持多回合，依靠【不死鬼针】后期超强单体爆发，一针一个小朋友，克制【龙影之刃】【六道海皇】【妖月】等。",
    },
    [9]={
        id=9,
        name="忍界五皇",
        star=5,
        team={
            20001,20008,20011,20029,20026,
        },
        teamCore={
            20029,20026,
        },
        traitText="<div fontcolor=#eb5f06 outline=2,#000000>【传说搭配】【绝地强袭】</div>",
        thinkingText="<div fontcolor=#eb5f06 outline=2,#000000>★</div>【六道海皇】【九皇座】【蜂皇】逆天的回复能力，无视防御的持续伤害，强大的群体三维属性提升\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【忍皇】【皇八极】毁天灭地的群体伤害轰炸，燃烧的怒气爆发\n<div fontcolor=#eb5f06 outline=2,#000000>★</div>【五皇传说】五皇聚集之时，忍界撼动之刻！",
        restrainText="持续爆发以及治疗能力，克制【东方星辰】【夜无月】【幽皇剑灵】等持续输出阵容。",
    },
}
