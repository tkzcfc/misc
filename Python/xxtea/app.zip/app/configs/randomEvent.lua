return {
    [1]={
        id=1,
        refreshType=1,
        eventTime={
            2,
        },
    },
}
