return {
    yarn_a = {
        idle = {
            totalTime = 1.6666,
            events = {
                {
                    int = 2,
                    name = "duang",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 1,
        },
    },
    sunnymoon_a_hit = {
        idle = {
            totalTime = 0.4,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    nightingale_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    jrio = {
        skill_a = {
            totalTime = 3.3333,
            events = {
                {
                    int = 44,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "jrio_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.9333,
            events = {
                {
                    name = "jrio_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "hit_high",
                    time = 0.6,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.2,
            events = {
                {
                    name = "jrio_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            events = {
                {
                    name = "jrio_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8666,
            events = {
                {
                    name = "jrio_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.1,
            triggerCnt = 0,
        },
    },
    jihan = {
        skill_a = {
            totalTime = 1.3333,
            events = {
                {
                    name = "jihan_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
            },
            triggerCnt = 3,
        },
        skill_b = {
            totalTime = 0.7666,
            events = {
                {
                    name = "jihan_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "jihan_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    buff_qusanzengyi = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "buff_qusanjianyi.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    funerarybuddha_b_bullet = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    kami_skill_dark_anim = {
        idle = {
            totalTime = 5,
            events = {
                {
                    name = "kami_skill_dark_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    monster_white = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "monster_kuwuwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.7333,
            triggerCnt = 0,
        },
    },
    bleachedbones_b_buff = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    ninsover = {
        skill_b_old = {
            totalTime = 1.1666,
            events = {
                {
                    name = "ninsover_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "hit_far",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        win = {
            totalTime = 4.3,
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 6.3333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.2666,
            triggerCnt = 0,
        },
        appear3 = {
            totalTime = 2.6666,
            triggerCnt = 0,
        },
        skill_a = {
            totalTime = 2.5333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "ninsover_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "break",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "hit_far",
                    time = 1.5,
                },
                {
                    name = "duang_start",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "duang_end",
                    time = 1.6666,
                },
            },
            triggerCnt = 3,
        },
        skill_c = {
            totalTime = 0.9333,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "buffend",
                    time = 0.4,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 2.9,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "hit_far",
                    time = 2.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.2333,
                },
            },
            triggerCnt = 11,
        },
        appear = {
            totalTime = 2.2666,
            events = {
                {
                    name = "ninsover_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.5,
            events = {
                {
                    name = "ninsover_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        attack_old2 = {
            totalTime = 1.2,
            events = {
                {
                    name = "ninsover_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        walknew = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "ninsover_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_far = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5.3,
            triggerCnt = 0,
        },
        attack_old = {
            totalTime = 0.6,
            events = {
                {
                    name = "ninsover_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 1,
        },
    },
    bldx_a = {
        idle = {
            totalTime = 4.4666,
            events = {
                {
                    name = "bldx_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 2.1333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.5,
                },
                {
                    name = "duang_end",
                    time = 4.1666,
                },
            },
            triggerCnt = 7,
        },
    },
    zenmaster_b_hit = {
        idle = {
            totalTime = 1.1333,
            triggerCnt = 0,
        },
    },
    hgwc_a = {
        idle = {
            totalTime = 3.9333,
            events = {
                {
                    name = "hgwc_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    name = "trigger",
                    time = 2,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "duang_end",
                    time = 2.3666,
                },
            },
            triggerCnt = 4,
        },
    },
    common_manualskill = {
        idle = {
            totalTime = 0.9,
            events = {
                {
                    name = "common_manualskill.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    monster_fan = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8333,
            events = {
                {
                    name = "monster_fanwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    boss_firegirl_c = {
        idle = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
    },
    boss_firegirl_a = {
        idle = {
            totalTime = 2.6,
            events = {
                {
                    name = "boss_firegirl_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "duang_end",
                    time = 2.4333,
                },
            },
            triggerCnt = 10,
        },
    },
    witch_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    eaststar_a = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "duang_start",
                    time = 0.6333,
                },
                {
                    name = "duang_end",
                    time = 0.9,
                },
            },
            triggerCnt = 6,
        },
    },
    common_hit_qi = {
        idle = {
            totalTime = 0.2666,
            events = {
                {
                    name = "common_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    monster_white_2 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "monster_kuwuwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.7333,
            triggerCnt = 0,
        },
    },
    boss_monkey_c_buff = {
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    kamione2 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3333,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.3333,
                },
                {
                    name = "duang_start",
                    time = 2.3333,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_start",
                    time = 4.8,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
                {
                    name = "end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    sand = {
        skill_a = {
            totalTime = 2.2666,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "sand_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 1.4333,
                },
                {
                    int = 4,
                    name = "duang",
                    time = 1.6,
                },
                {
                    name = "hit_far",
                    time = 2.2333,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 0.7333,
            events = {
                {
                    name = "sand_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1,
            events = {
                {
                    name = "sand_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.6333,
            events = {
                {
                    name = "sand_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8,
            events = {
                {
                    name = "sand_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_a1 = {
            totalTime = 6,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "sand_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 1.4333,
                },
                {
                    int = 4,
                    name = "duang",
                    time = 1.6,
                },
                {
                    name = "hit_far",
                    time = 2.2333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.0666,
            events = {
                {
                    name = "sand_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2666,
            events = {
                {
                    name = "sand_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.6333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.0333,
            triggerCnt = 0,
        },
    },
    rockbuddha_b_anim = {
        idle = {
            totalTime = 1.7333,
            events = {
                {
                    name = "duang_start",
                    time = 1.1333,
                },
                {
                    name = "duang_end",
                    time = 1.2666,
                },
            },
            triggerCnt = 0,
        },
    },
    sakura_b = {
        idle = {
            totalTime = 0.9,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 4,
        },
    },
    sakura_a = {
        idle = {
            totalTime = 1.5,
            events = {
                {
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
            },
            triggerCnt = 6,
        },
    },
    bldx_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    boss_monkey_b_anim = {
        idle = {
            totalTime = 1.9666,
            events = {
                {
                    name = "boss_monkey_b_anim.mp3",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
            },
            triggerCnt = 6,
        },
    },
    boss_cat_a_anim = {
        idle = {
            totalTime = 1.2666,
            events = {
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 3,
        },
    },
    bleachedbones = {
        skill_a = {
            totalTime = 2.1666,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "bleachedbones_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "hit_far",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
            },
            triggerCnt = 6,
        },
        skill_b = {
            totalTime = 0.8,
            events = {
                {
                    name = "bleachedbones_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 0.8666,
            events = {
                {
                    name = "bleachedbones_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 1.1,
            events = {
                {
                    name = "bleachedbones_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.4333,
            events = {
                {
                    name = "bleachedbones_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.1666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        skill_b2 = {
            totalTime = 0.8666,
            events = {
                {
                    name = "bleachedbones_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.2333,
            events = {
                {
                    name = "bleachedbones_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.8666,
            triggerCnt = 0,
        },
    },
    tramp_bullet = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    common_jiangdimingzhong_tou_buff = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    jihan_a_buff = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    ninsover_a1 = {
        idle = {
            totalTime = 6.0666,
            events = {
                {
                    name = "ninsover_a1_anim.mp3",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "duang_start",
                    time = 2,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.9666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.8,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 4.3666,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    name = "trigger",
                    time = 4.6333,
                },
                {
                    name = "duang_end",
                    time = 4.9,
                },
                {
                    name = "hit_far",
                    time = 4.9,
                },
            },
            triggerCnt = 10,
        },
    },
    kamione5 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3333,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.3333,
                },
                {
                    name = "duang_start",
                    time = 2.3333,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_start",
                    time = 4.8,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
                {
                    name = "end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        appear2222222 = {
            totalTime = 2,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    lqsez_shenqijineng_buff = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    lieyan_b_anim = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    painter_bullet_hit = {
        idle = {
            totalTime = 0.1333,
            triggerCnt = 0,
        },
    },
    sand_bullet_hit = {
        idle = {
            totalTime = 0.1666,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    boss_crab_b_anim = {
        idle = {
            totalTime = 1.3333,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "boss_crab_b_anim.mp3",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 9,
        },
    },
    stick_a = {
        idle = {
            totalTime = 1.5666,
            events = {
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 9,
        },
    },
    boss_monkey = {
        skill_a = {
            totalTime = 1.2666,
            events = {
                {
                    name = "boss_monkey_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "lieyan_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 5,
        },
        skill_c = {
            totalTime = 1.5333,
            events = {
                {
                    name = "boss_monkey_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "lieyan_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 1,
            events = {
                {
                    name = "lieyan_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.6333,
                },
                {
                    name = "duang_start",
                    time = 0.8,
                },
                {
                    name = "duang_end",
                    time = 0.9666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        angry = {
            totalTime = 5.7666,
            events = {
                {
                    name = "boss_monkey_angry.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 3.9333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.0333,
                },
                {
                    name = "duang_start",
                    time = 4.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 4.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.5333,
                },
                {
                    name = "duang_start",
                    time = 4.6666,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.7666,
            events = {
                {
                    name = "boss_monkey_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "lieyan_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    boss_crab = {
        skill_a = {
            totalTime = 0.8666,
            events = {
                {
                    name = "boss_crab_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 3,
        },
        skill_c = {
            totalTime = 1.1333,
            events = {
                {
                    name = "boss_crab_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1666,
            events = {
                {
                    name = "boss_crab_skill_b.mp3",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        angry = {
            totalTime = 6.3333,
            events = {
                {
                    name = "boss_crab_angry.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        hit_far = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
    },
    summon_ares = {
        skill_c = {
            totalTime = 1.3,
            events = {
                {
                    name = "ares_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.7333,
                },
                {
                    name = "hit_far",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "duang_start",
                    time = 0.9666,
                },
                {
                    name = "duang_end",
                    time = 1.1,
                },
            },
            triggerCnt = 3,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "ares_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "hit_down",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.8333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "ares_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        birth = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    common_silence = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    ghostfire_b_bullet = {
        idle = {
            totalTime = 0.6,
            events = {
                {
                    name = "ghostfire_b.mp3",
                    time = 0.5333,
                },
                {
                    name = "hit_down",
                    time = 0.6,
                },
            },
            triggerCnt = 0,
        },
    },
    rottenwood_a_bullet = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    common_energy_hit = {
        idle = {
            totalTime = 0.1333,
            events = {
                {
                    name = "common_energy_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    rockbuddha_c_anim = {
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    bigmon_fire = {
        skill_a = {
            totalTime = 2.3333,
            events = {
                {
                    name = "trigger",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8666,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 2,
            events = {
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 5,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    common_aoyixuli = {
        idle = {
            totalTime = 1.3,
            events = {
                {
                    name = "common_aoyixuli.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    witch = {
        skill_a = {
            totalTime = 2.6666,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "witch_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "hit_far",
                    time = 2.2666,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 2,
            events = {
                {
                    name = "witch_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "hit_far",
                    time = 1.7333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1,
            events = {
                {
                    name = "witch_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1,
            events = {
                {
                    name = "witch_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2,
            events = {
                {
                    name = "witch_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.6666,
            events = {
                {
                    name = "witch_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    common_dao_hit = {
        idle = {
            totalTime = 0.2,
            events = {
                {
                    name = "common_dao_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    acheron_a = {
        idle = {
            totalTime = 0.8666,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "duang_start",
                    time = 0.4333,
                },
                {
                    name = "duang_end",
                    time = 0.6333,
                },
            },
            triggerCnt = 4,
        },
    },
    kami_skill_wing_anim = {
        idle = {
            totalTime = 5,
            events = {
                {
                    name = "kami_skill_wing_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    destroyer_a = {
        idle = {
            totalTime = 2.1,
            events = {
                {
                    name = "destroyer_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.1333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    name = "duang_start",
                    time = 1.9,
                },
                {
                    name = "duang_end",
                    time = 2,
                },
            },
            triggerCnt = 11,
        },
    },
    jihan_a_hit = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "jihan_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    youming_b_hit = {
        idle = {
            totalTime = 0.8666,
            events = {
                {
                    name = "youming_b_hit.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 3,
        },
    },
    drunkard_a_bullet = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    monster_assassin = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.7333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 0.8333,
            events = {
                {
                    name = "monster_daggerwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        scare = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        speak = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    soul_1_a_hit = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "soul_3_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    boss_yaoshou = {
        skill_a = {
            totalTime = 4.1,
            events = {
                {
                    name = "boss_yaoshou_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "duang_end",
                    time = 1.2666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "duang_end",
                    time = 1.8666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "trigger",
                    time = 2.7,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9666,
                },
                {
                    name = "trigger",
                    time = 3.1,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 3.2,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "duang_end",
                    time = 3.6,
                },
            },
            triggerCnt = 13,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.7666,
            events = {
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.1333,
                },
                {
                    name = "duang_end",
                    time = 2.4,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "boss_yaoshou_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8666,
            events = {
                {
                    name = "boss_yaoshou_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 3,
        },
        skill_a2 = {
            totalTime = 3.6666,
            events = {
                {
                    name = "boss_yaoshou_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.9,
                },
            },
            triggerCnt = 3,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 4.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    monster_swords_bullet = {
        idle = {
            totalTime = 0.1666,
            triggerCnt = 0,
        },
    },
    kaze_a = {
        idle = {
            totalTime = 1.6666,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "hit_high",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "duang_end",
                    time = 1.6666,
                },
            },
            triggerCnt = 11,
        },
    },
    monster_sumo = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_punchhit.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    cullen_a_anim = {
        idle = {
            totalTime = 2.8333,
            triggerCnt = 0,
        },
    },
    sand_a = {
        idle = {
            totalTime = 1.9,
            events = {
                {
                    name = "sand_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.1,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.4666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    name = "hit_far",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "duang_start",
                    time = 1.6666,
                },
                {
                    name = "duang_end",
                    time = 1.8333,
                },
            },
            triggerCnt = 7,
        },
    },
    jrio_bullet = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    sand_b = {
        idle = {
            totalTime = 2.3,
            events = {
                {
                    name = "sand_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.6,
                },
                {
                    name = "duang_end",
                    time = 1.8,
                },
            },
            triggerCnt = 9,
        },
    },
    Illusion_5_bird = {
        idle = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
    },
    hgwc = {
        skill_a = {
            totalTime = 4.1333,
            events = {
                {
                    name = "hgwc_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.6666,
                },
                {
                    name = "duang_end",
                    time = 1.8666,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 1,
            events = {
                {
                    name = "hgwc_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.7,
            events = {
                {
                    name = "hgwc_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.1333,
            events = {
                {
                    name = "hgwc_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.4666,
            triggerCnt = 0,
        },
        skill_bxxxxxx = {
            totalTime = 1.1666,
            events = {
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 1,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.1333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.1333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.1333,
            triggerCnt = 0,
        },
        attackxxxx = {
            totalTime = 0.9,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
    },
    lieyan = {
        skill_a = {
            totalTime = 2.3333,
            events = {
                {
                    name = "lieyan_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 1.8666,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 0.8666,
            events = {
                {
                    name = "lieyan_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5,
                },
                {
                    name = "duang_start",
                    time = 0.6666,
                },
                {
                    name = "duang_end",
                    time = 0.8333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 2,
            events = {
                {
                    name = "lieyan_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 5,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    boss_firegirl = {
        skill_a = {
            totalTime = 3.9,
            events = {
                {
                    int = 26,
                    float = 10,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "boss_firegirl_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3666,
                },
                {
                    name = "hit_down",
                    time = 2.5,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        skill_b = {
            totalTime = 1.8333,
            events = {
                {
                    name = "boss_firegirl_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "hit_far",
                    time = 1.3333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "boss_firegirl_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    zenmaster_c = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    zenmaster_a = {
        idle = {
            totalTime = 2.5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "hit_down",
                    time = 0.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "duang_start",
                    time = 1,
                },
                {
                    name = "duang_end",
                    time = 1.2,
                },
            },
            triggerCnt = 4,
        },
    },
    shadowLord_b_buff = {
        idle = {
            totalTime = 1.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1,
                },
            },
            triggerCnt = 1,
        },
    },
    magicnight_b_anim = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    monster_mine_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_throwbomb.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    monster_fan_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    kamione = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_start",
                    time = 4.8,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
                {
                    name = "end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle4 = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    boss_skill_anim = {
        idle = {
            totalTime = 2.3333,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 2.3333,
            triggerCnt = 0,
        },
    },
    ghostfire_bullet = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    kami_skill_magic_anim = {
        idle = {
            totalTime = 5.4,
            events = {
                {
                    name = "kami_skill_light_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    moling_1 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
            },
            triggerCnt = 10,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    moling_3 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
            },
            triggerCnt = 10,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    moling_2 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
            },
            triggerCnt = 10,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    stick = {
        skill_a = {
            totalTime = 2.7666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "stick_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "hit_far",
                    time = 2,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.0666,
            events = {
                {
                    name = "stick_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "hit_down",
                    time = 0.6,
                },
                {
                    name = "duang_end",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.5333,
            events = {
                {
                    name = "stick_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "stick_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.1666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.4333,
            events = {
                {
                    name = "stick_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        skill_a2 = {
            totalTime = 3.8333,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "stick_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.9,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 3,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 3.1,
                },
            },
            triggerCnt = 12,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 2.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8,
                },
            },
            triggerCnt = 5,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.5333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5.3333,
            triggerCnt = 0,
        },
    },
    soul_2 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
            },
            triggerCnt = 9,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.7333,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    soul_3 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
            },
            triggerCnt = 9,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.7333,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    soul_1 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
            },
            triggerCnt = 10,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    soul_6 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
            },
            triggerCnt = 9,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.7333,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    soul_4 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
            },
            triggerCnt = 9,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.7333,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    soul_5 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
            },
            triggerCnt = 10,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    eight_bullet = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    kamione3 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3333,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.3333,
                },
                {
                    name = "duang_start",
                    time = 2.3333,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_start",
                    time = 4.8,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
                {
                    name = "end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        appear2222222 = {
            totalTime = 2,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    kamione1 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3333,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.3333,
                },
                {
                    name = "duang_start",
                    time = 2.3333,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_start",
                    time = 4.8,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
                {
                    name = "end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    taoist_a_anim = {
        idle = {
            totalTime = 2.1,
            triggerCnt = 0,
        },
    },
    kamione4 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3333,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.3333,
                },
                {
                    name = "duang_start",
                    time = 2.3333,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_start",
                    time = 4.8,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
                {
                    name = "end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        appear2222222 = {
            totalTime = 2,
            events = {
                {
                    name = "kamioneap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    cat = {
        skill_a = {
            totalTime = 2.1666,
            events = {
                {
                    int = 30,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "cat_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "hit_high",
                    time = 1.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    name = "duang_start",
                    time = 1.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    name = "duang_end",
                    time = 2,
                },
            },
            triggerCnt = 13,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "cat_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "duang_end",
                    time = 0.4666,
                },
                {
                    name = "duang_start",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "duang_end",
                    time = 0.8333,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.1,
            events = {
                {
                    name = "cat_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "cat_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 8.1666,
            events = {
                {
                    int = 30,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "cat_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.8666,
                },
                {
                    name = "duang_end",
                    time = 2,
                },
                {
                    name = "hit_high",
                    time = 7,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1,
            events = {
                {
                    name = "cat_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    boss_sand_b_buff = {
        idle = {
            totalTime = 1.2666,
            triggerCnt = 0,
        },
    },
    shadowLord_a_buff = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    common_bing_hit = {
        idle = {
            totalTime = 0.2,
            events = {
                {
                    name = "common_bing_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    meteor_b_hit = {
        idle = {
            totalTime = 0.5333,
            events = {
                {
                    name = "meteor_b_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 3,
        },
    },
    yaoshou_fire4 = {
        idle = {
            totalTime = 1.8666,
            triggerCnt = 0,
        },
    },
    yaoshou_fire5 = {
        skill_a = {
            totalTime = 1.2,
            events = {
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 3,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.5666,
            events = {
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
            },
            triggerCnt = 5,
        },
        hit_high = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.8,
            triggerCnt = 0,
        },
    },
    yaoshou_fire1 = {
        skill_a = {
            totalTime = 1.3333,
            events = {
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
            },
            triggerCnt = 4,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
    },
    yaoshou_fire2 = {
        skill_a = {
            totalTime = 0.8666,
            events = {
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 3,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 3,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    yaoshou_fire3 = {
        idle = {
            totalTime = 1.8666,
            triggerCnt = 0,
        },
    },
    monster_pipe_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_smogwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    monster_fan_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8333,
            events = {
                {
                    name = "monster_fanwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    tcxy_bullet = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    common_kamiappear_b = {
        idle = {
            totalTime = 1.8333,
            events = {
                {
                    name = "common_kamiappear_b.mp3",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 1,
        },
    },
    kami_skill_fire_anim = {
        idle = {
            totalTime = 5,
            events = {
                {
                    name = "kami_skill_fire_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    eaststar_a_anim = {
        idle = {
            totalTime = 1.3666,
            events = {
                {
                    name = "eaststar_a_anim",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    ares_a_amin = {
        idle = {
            totalTime = 2.4,
            triggerCnt = 0,
        },
    },
    monster_oldman_bullet = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    common_shandian_xiong_buff = {
        idle = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
    },
    acheron_b_anim = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    magicnight_a_buff = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    summon_undead_bs = {
        skill_a = {
            totalTime = 2.3333,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "undead_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 4,
                    name = "duang",
                    time = 1.5,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 3.2,
            events = {
                {
                    name = "undead_skill_b.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.6,
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 0.8,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "undead_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        vertigo3 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.6,
            triggerCnt = 0,
        },
        win = {
            totalTime = 4,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    sand_bullet = {
        idle = {
            totalTime = 0.1666,
            triggerCnt = 0,
        },
    },
    kami_skill_sword_anim = {
        idle = {
            totalTime = 5.3333,
            events = {
                {
                    name = "kami_skill_sword_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    blackeight_bullet1 = {
        idle = {
            totalTime = 2.7333,
            events = {
                {
                    name = "blackeight_bullet.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.8666,
                },
                {
                    name = "duang_start",
                    time = 2.0666,
                },
                {
                    name = "duang_end",
                    time = 2.1666,
                },
            },
            triggerCnt = 5,
        },
    },
    poseidon = {
        skill_a = {
            totalTime = 2.7666,
            events = {
                {
                    int = 39,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "poseidon_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3547,
                },
            },
            triggerCnt = 8,
        },
        skill_b = {
            totalTime = 2.4333,
            events = {
                {
                    name = "poseidon_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.4333,
            events = {
                {
                    name = "poseidon_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.9666,
            events = {
                {
                    name = "poseidon_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.6666,
            events = {
                {
                    name = "poseidon_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            events = {
                {
                    name = "poseidon_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.4333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.7666,
            triggerCnt = 0,
        },
    },
    sakura_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    blademaster_a_anim = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    buff_sanwei_jia = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "buff_sanwei_jia.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    glaze_bullet = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    common_heroappear = {
        idle = {
            totalTime = 0.6666,
            events = {
                {
                    name = "common_heroappear.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    hades_b_hit = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    boss_firegirl_hit = {
        idle = {
            totalTime = 0.7333,
            events = {
                {
                    name = "boss_firegirl_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    sunnymoon_bianshen = {
        idle = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
    },
    lsc = {
        skill_a = {
            totalTime = 4.7666,
            events = {
                {
                    int = 37,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 0.7666,
            events = {
                {
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        hit2 = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.5333,
            events = {
                {
                    name = "lsc_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 9.3333,
            events = {
                {
                    int = 37,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 2.3,
            events = {
                {
                    name = "lsc_attack.mp3",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
            },
            triggerCnt = 7,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        skill_b = {
            totalTime = 1.1666,
            events = {
                {
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.5333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.5333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    shadowLord_a_anim = {
        idle = {
            totalTime = 3.4666,
            triggerCnt = 0,
        },
    },
    monster_katana = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "monster_tachiwhoosh2.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    youming_b_buff = {
        idle = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
    },
    bldx_a1 = {
        idle = {
            totalTime = 5.2666,
            events = {
                {
                    name = "bldx_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "trigger",
                    time = 2.2666,
                },
                {
                    int = 3,
                    name = "trigger",
                    time = 2.4,
                },
                {
                    name = "duang_star",
                    time = 2.5,
                },
                {
                    name = "trigger",
                    time = 2.5,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "duang_star",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "duang_end",
                    time = 4,
                },
            },
            triggerCnt = 15,
        },
    },
    shenfeng_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    drunkard_a_hit = {
        idle = {
            totalTime = 1.2666,
            events = {
                {
                    name = "drunkard_a_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.3666,
                },
                {
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "duang_end",
                    time = 0.7,
                },
            },
            triggerCnt = 0,
        },
    },
    calligrapher_a_buff = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    common_jian_hit = {
        idle = {
            totalTime = 0.2,
            events = {
                {
                    name = "common_jian_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    common_zhongdu_xiong_buff = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "buff_poison.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    cullen_b_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    tramp = {
        skill_a = {
            totalTime = 2.4333,
            events = {
                {
                    int = 34,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "tramp_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.2333,
            events = {
                {
                    name = "tramp_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.6,
            events = {
                {
                    name = "tramp_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6333,
            events = {
                {
                    name = "tramp_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8333,
            events = {
                {
                    name = "tramp_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.8,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4,
            triggerCnt = 0,
        },
    },
    bleachedbones_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    eaststar_b_buff = {
        idle = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
    },
    yaoshou_mu4 = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    yaoshou_mu5 = {
        skill_a = {
            totalTime = 1.3333,
            events = {
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 2,
        },
        skill_b = {
            totalTime = 1.7333,
            events = {
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "buffend",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2,
            events = {
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "buffend",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        hit_high = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    yaoshou_mu1 = {
        skill_a = {
            totalTime = 1.0666,
            events = {
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "buffend",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
            },
            triggerCnt = 2,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.5666,
            triggerCnt = 0,
        },
    },
    yaoshou_mu2 = {
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    yaoshou_mu3 = {
        skill_a = {
            totalTime = 1.0666,
            events = {
                {
                    name = "trigger",
                    time = 0.4,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "buffend",
                    time = 0.5666,
                },
            },
            triggerCnt = 1,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.9,
            triggerCnt = 0,
        },
    },
    boss_pluto_c = {
        idle = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
    },
    boss_pluto_b = {
        idle = {
            totalTime = 1,
            events = {
                {
                    int = 1,
                    name = "duang",
                    time = 0.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 5,
        },
    },
    magicnight_a = {
        idle = {
            totalTime = 2,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "duang_start",
                    time = 1.2666,
                },
                {
                    name = "duang_end",
                    time = 1.4333,
                },
            },
            triggerCnt = 1,
        },
    },
    magicnight = {
        skill_a = {
            totalTime = 4.1666,
            events = {
                {
                    int = 25,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "magicnight_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "magicnight_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3,
            events = {
                {
                    name = "magicnight_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 0.7333,
            events = {
                {
                    name = "magicnight_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "magicnight_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3,
            events = {
                {
                    name = "magicnight_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle3 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.4,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.3,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
    },
    lqsez_bullet1_hit = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "lqsez_bullet1_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    name = "duang_end",
                    time = 0.2666,
                },
            },
            triggerCnt = 0,
        },
    },
    cat_c_buff = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    lqsez_bullet_hit = {
        idle = {
            totalTime = 0.9333,
            events = {
                {
                    name = "lqsez_bullet_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    sunnymoon_b_hit = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    ghostfire_a_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    graveman_bullet = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    common_chixuzhiliao_jiao_buff = {
        idle = {
            totalTime = 0.9,
            triggerCnt = 0,
        },
    },
    silverfox = {
        skill_a = {
            totalTime = 3.5333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "silverfox_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "duang_start",
                    time = 2.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.2,
                },
                {
                    name = "duang_end",
                    time = 2.3,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.6333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.8333,
                },
                {
                    name = "hit_far",
                    time = 2.8333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "duang_start",
                    time = 2.9333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "duang_end",
                    time = 3.0666,
                },
            },
            triggerCnt = 11,
        },
        skill_b = {
            totalTime = 1.2666,
            events = {
                {
                    name = "silverfox_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.8,
            events = {
                {
                    name = "silverfox_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 4,
            events = {
                {
                    name = "silverfox_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 8.3333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "silverfox_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    name = "duang_end",
                    time = 2,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 5.3333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 5.6333,
                },
                {
                    name = "duang_start",
                    time = 5.9333,
                },
                {
                    name = "hit_far",
                    time = 6,
                },
                {
                    name = "duang_end",
                    time = 6.1333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.5,
            events = {
                {
                    name = "silverfox_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 5,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        attack_xxx = {
            totalTime = 0.6666,
            events = {
                {
                    name = "silverfox_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 3,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        skill_bxxxxx = {
            totalTime = 0.6666,
            events = {
                {
                    name = "silverfox_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 1,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.8,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4,
            triggerCnt = 0,
        },
    },
    common_oldman_hit = {
        idle = {
            totalTime = 0.2666,
            events = {
                {
                    name = "common_oldman_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    shenfeng = {
        skill_a = {
            totalTime = 1.8333,
            events = {
                {
                    name = "shenfeng_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1,
            events = {
                {
                    name = "shenfeng_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.8333,
            events = {
                {
                    name = "shenfeng_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
            },
            triggerCnt = 3,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    ghostfire_b_hit = {
        idle = {
            totalTime = 0.7,
            triggerCnt = 0,
        },
    },
    taoist = {
        skill_a = {
            totalTime = 2.7666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "taoist_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.4,
            events = {
                {
                    name = "taoist_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.0666,
            events = {
                {
                    name = "taoist_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8,
            events = {
                {
                    name = "taoist_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "taoist_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.9666,
            events = {
                {
                    name = "taoist_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.0666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4,
            triggerCnt = 0,
        },
    },
    bldx_c_bullet = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    monster_ironball = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.8666,
            events = {
                {
                    name = "monster_ironball.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 4,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    buff_liaoxiao_jian = {
        idle = {
            totalTime = 1.7,
            events = {
                {
                    name = "buff_liaoxiao_jian.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    blackeight_bullet = {
        idle = {
            totalTime = 1.5666,
            events = {
                {
                    name = "blackeight_bullet.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "duang_start",
                    time = 1.3333,
                },
                {
                    name = "duang_end",
                    time = 1.5,
                },
            },
            triggerCnt = 4,
        },
    },
    calligrapher_b_hit = {
        idle = {
            totalTime = 1.0666,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    calligrapher = {
        skill_a = {
            totalTime = 2.8333,
            events = {
                {
                    int = 47,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "calligrapher_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 1.7333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1666,
            events = {
                {
                    name = "calligrapher_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.4333,
            events = {
                {
                    name = "calligrapher_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "calligrapher_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.0666,
            events = {
                {
                    name = "calligrapher_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.4666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.4333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 3.8333,
            triggerCnt = 0,
        },
    },
    monster_white_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "monster_kuwuwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.7333,
            triggerCnt = 0,
        },
    },
    common_vertigo = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    boss_cat_b_anim = {
        idle = {
            totalTime = 3.6,
            events = {
                {
                    name = "man_8_shandianqun.mp3",
                    time = 0,
                },
                {
                    name = "boss_cat_b_anim.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
            },
            triggerCnt = 9,
        },
    },
    lieyan_b_buff = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    shenfeng_a = {
        idle = {
            totalTime = 2.3333,
            events = {
                {
                    name = "shenfeng_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
            },
            triggerCnt = 10,
        },
    },
    common_sheqishifa_amin = {
        idle = {
            totalTime = 0.7333,
            events = {
                {
                    name = "common_sheqishifa_amin.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    undead = {
        skill_a = {
            totalTime = 2.3333,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "undead_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.5,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.6333,
                },
                {
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    name = "duang_end",
                    time = 1.9,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 3.2,
            events = {
                {
                    name = "undead_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 3.2,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "undead_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "undead_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        skill_b2 = {
            totalTime = 1.7,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.6,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    taoist_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    bldx = {
        skill_a = {
            totalTime = 4,
            events = {
                {
                    int = 42,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "bldx_skill_b.mp3",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.3333,
            events = {
                {
                    name = "bldx_skill_b.mp3",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3,
            events = {
                {
                    name = "bldx_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 6.2666,
            events = {
                {
                    name = "bldx_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 6.5,
            events = {
                {
                    int = 42,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "bldx_attack.mp3",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle321 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.3,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 6.3,
            triggerCnt = 0,
        },
        skill_c2 = {
            totalTime = 1.2666,
            events = {
                {
                    name = "bldx_skill_c.mp3",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
    },
    thor_b_hit = {
        idle = {
            totalTime = 0.5333,
            events = {
                {
                    name = "thor_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    buff_nengliang_jia = {
        idle = {
            totalTime = 1.5,
            events = {
                {
                    name = "buff_nengliang_jia.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    glaze_b_hit = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    yarn = {
        skill_a = {
            totalTime = 2.1,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "yarn_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "buffend",
                    time = 0.4,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.4333,
            events = {
                {
                    name = "yarn_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.9666,
            events = {
                {
                    name = "yarn_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "yarn_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4,
            events = {
                {
                    name = "yarn_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.4333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.1333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 3.6,
            triggerCnt = 0,
        },
    },
    blademaster_a2 = {
        idle = {
            totalTime = 6.6666,
            events = {
                {
                    name = "blademaster_skill_a2.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_star",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 2,
                },
                {
                    name = "duang_star",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 3.2,
                },
                {
                    name = "trigger",
                    time = 3.6,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.6,
                },
                {
                    name = "trigger",
                    time = 4.9333,
                },
                {
                    name = "trigger",
                    time = 5.2666,
                },
                {
                    name = "hit_far",
                    time = 5.6,
                },
                {
                    name = "trigger",
                    time = 5.6,
                },
                {
                    name = "duang_end",
                    time = 5.9666,
                },
            },
            triggerCnt = 11,
        },
    },
    blademaster_a1 = {
        idle = {
            totalTime = 1.4666,
            events = {
                {
                    name = "blademaster_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "duang_end",
                    time = 0.7333,
                },
            },
            triggerCnt = 6,
        },
    },
    cullen_c_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    meteor_a_anim = {
        idle = {
            totalTime = 2.6666,
            events = {
                {
                    name = "meteor_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.7,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.8333,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 1.9,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.1,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.3,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.3666,
                },
                {
                    name = "duang_end",
                    time = 2.6,
                },
            },
            triggerCnt = 0,
        },
    },
    witch_c_hit = {
        idle = {
            totalTime = 0.7,
            events = {
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.1666,
                },
                {
                    name = "duang_end",
                    time = 0.3,
                },
            },
            triggerCnt = 0,
        },
    },
    sunnymoon = {
        skill_a = {
            totalTime = 3.7,
            events = {
                {
                    int = 48,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "sunnymoon_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.9,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "trigger",
                    time = 2.3,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "duang_start",
                    time = 2.6,
                },
                {
                    name = "duang_end",
                    time = 2.8333,
                },
            },
            triggerCnt = 7,
        },
        skill_c = {
            totalTime = 1.1666,
            events = {
                {
                    int = 2,
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "sunnymoon_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    int = 3,
                    name = "trigger",
                    time = 1.1666,
                },
            },
            triggerCnt = 3,
        },
        skill_b = {
            totalTime = 1.2333,
            events = {
                {
                    int = 2,
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "sunnymoon_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 3,
                    name = "trigger",
                    time = 1.2333,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.1666,
            events = {
                {
                    name = "sunnymoon_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.9666,
            events = {
                {
                    name = "sunnymoon_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.3,
            events = {
                {
                    name = "sunnymoon_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.0666,
            events = {
                {
                    name = "sunnymoon_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.1666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.2,
            triggerCnt = 0,
        },
    },
    tramp_b_hit = {
        idle = {
            totalTime = 0.4666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_master_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_magicwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    rottenwood_bullet = {
        idle = {
            totalTime = 0.1,
            triggerCnt = 0,
        },
    },
    monster_mine = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 3.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_throwbomb.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    yarn_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    monster_ninja_black = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_tachiwhoosh1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    shenfeng_b_hit = {
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    painter_b_hit = {
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    minister_b_hit = {
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    common_chaofeng_tou_buff = {
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    common_autoskill = {
        idle = {
            totalTime = 0.7,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.7,
            triggerCnt = 0,
        },
    },
    lqsez_skill_a1 = {
        idle = {
            totalTime = 7.6666,
            events = {
                {
                    name = "lqsez_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 3.6,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 4,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    name = "trigger",
                    time = 4.6666,
                },
                {
                    name = "trigger",
                    time = 4.8,
                },
                {
                    name = "trigger",
                    time = 4.9333,
                },
                {
                    name = "trigger",
                    time = 5.0666,
                },
                {
                    name = "trigger",
                    time = 5.2,
                },
                {
                    name = "trigger",
                    time = 5.3333,
                },
                {
                    name = "trigger",
                    time = 5.4666,
                },
            },
            triggerCnt = 15,
        },
    },
    monster_gun_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_gunshot.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    blademaster_a = {
        idle = {
            totalTime = 0.9333,
            events = {
                {
                    name = "blademaster_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
            },
            triggerCnt = 4,
        },
    },
    needle = {
        skill_a = {
            totalTime = 2.3666,
            events = {
                {
                    int = 43,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "needle_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8333,
            events = {
                {
                    name = "needle_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "hit_far",
                    time = 0.5,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.3333,
            events = {
                {
                    name = "needle_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "needle_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 7.1333,
            events = {
                {
                    int = 43,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1,
            events = {
                {
                    name = "needle_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 2.1333,
            triggerCnt = 0,
        },
    },
    needle_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    rockbuddha = {
        skill_a = {
            totalTime = 4.0666,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "rockbuddha_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 1.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 0,
                    name = "duang_end",
                    time = 1.5333,
                },
                {
                    name = "duang_start",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 0,
                    name = "duang_end",
                    time = 1.7666,
                },
                {
                    name = "duang_start",
                    time = 2.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    int = 0,
                    name = "duang_end",
                    time = 2.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.9,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.9333,
                },
                {
                    name = "hit_down",
                    time = 2.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 3.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.3,
                },
                {
                    name = "duang_start",
                    time = 3.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "duang_end",
                    time = 3.5666,
                },
            },
            triggerCnt = 8,
        },
        skill_c = {
            totalTime = 1.6666,
            events = {
                {
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.7333,
            events = {
                {
                    name = "rockbuddha_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "hit_down",
                    time = 1.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.4333,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.2333,
            events = {
                {
                    name = "rockbuddha_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 3.8,
            events = {
                {
                    name = "rockbuddha_attack.mp3",
                    time = 2.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.5,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
            },
            triggerCnt = 3,
        },
        attack = {
            totalTime = 1.0666,
            events = {
                {
                    name = "rockbuddha_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle4 = {
            totalTime = 9.1333,
            triggerCnt = 0,
        },
        idle3 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 2.3,
            events = {
                {
                    name = "rockbuddha_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.2333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5,
            triggerCnt = 0,
        },
    },
    lqsez_skill_a = {
        idle = {
            totalTime = 3.8666,
            events = {
                {
                    name = "lqsez_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.9666,
                },
                {
                    name = "duang_end",
                    time = 1.1333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.9,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.1,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    name = "trigger",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.5,
                },
                {
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    name = "trigger",
                    time = 2.9,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.3,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 3.3333,
                },
                {
                    name = "duang_end",
                    time = 3.5666,
                },
            },
            triggerCnt = 13,
        },
    },
    common_hit_li = {
        idle = {
            totalTime = 0.2666,
            events = {
                {
                    name = "common_dao_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    kami_skill_black_anim = {
        idle = {
            totalTime = 5,
            events = {
                {
                    name = "kami_skill_black_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    youming = {
        skill_a = {
            totalTime = 1.3333,
            events = {
                {
                    name = "youming_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8333,
            events = {
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "youming_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 2,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    needle_b_bullet = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    common_bloodsucking = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    thor_a = {
        idle = {
            totalTime = 4.1333,
            events = {
                {
                    name = "thor_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.1,
                },
                {
                    name = "duang_end",
                    time = 2.3666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.6666,
                },
                {
                    name = "hit_high",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 2.9666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.0666,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "trigger",
                    time = 3.5666,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.7666,
                },
                {
                    name = "duang_end",
                    time = 3.9,
                },
            },
            triggerCnt = 24,
        },
    },
    boss_appear_anim = {
        idle = {
            totalTime = 7.2333,
            events = {
                {
                    name = "boss_chuchang.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 5.7333,
                },
                {
                    name = "trigger",
                    time = 5.7333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 6.1666,
                },
                {
                    name = "duang_end",
                    time = 6.6666,
                },
            },
            triggerCnt = 1,
        },
    },
    boss_angry_anim = {
        idle4 = {
            totalTime = 5.4,
            events = {
                {
                    name = "boss_angry_anim.mp3",
                    time = 0.5,
                },
            },
            triggerCnt = 0,
        },
        idle3 = {
            totalTime = 4.6,
            events = {
                {
                    name = "boss_angry_anim.mp3",
                    time = 0.0666,
                },
            },
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 3.6333,
            events = {
                {
                    name = "boss_angry_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        idle1 = {
            totalTime = 4.5,
            events = {
                {
                    name = "boss_angry_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    monster_white_bullet = {
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    assassin_a_anim = {
        idle = {
            totalTime = 3.4666,
            events = {
                {
                    name = "hit_far",
                    time = 2.6333,
                },
            },
            triggerCnt = 0,
        },
    },
    kami_skill_cut_anim = {
        idle = {
            totalTime = 5.4666,
            events = {
                {
                    name = "kami_skill_cut_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    poseidon_a_anim = {
        idle = {
            totalTime = 2.5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.4333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.6333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.0666,
                },
                {
                    name = "duang_end",
                    time = 2.3,
                },
            },
            triggerCnt = 0,
        },
    },
    shadowLord_c_buff = {
        idle = {
            totalTime = 0.5333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        idle2 = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
    },
    monster_boxer = {
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "monster_punchwhoosh1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        big_atk = {
            totalTime = 2.3,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 2,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    wanderer = {
        skill_a = {
            totalTime = 4.3,
            events = {
                {
                    int = 26,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1333,
            events = {
                {
                    name = "wanderer_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "hit_far",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1,
            events = {
                {
                    name = "wanderer_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            events = {
                {
                    name = "wanderer_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 5.3,
            events = {
                {
                    int = 26,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "wanderer_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        skill_b2 = {
            totalTime = 0.8666,
            events = {
                {
                    name = "wanderer_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        win = {
            totalTime = 3.7,
            triggerCnt = 0,
        },
        knee = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 7.8333,
            triggerCnt = 0,
        },
    },
    emperor_a = {
        idle = {
            totalTime = 0.7666,
            events = {
                {
                    name = "emperor_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0666,
                },
            },
            triggerCnt = 1,
        },
    },
    graveman_b = {
        idle = {
            totalTime = 2.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_hat_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "monster_magicwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    monster_mine_black = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.8666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_throwbomb.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    buff_baoji_jia = {
        idle = {
            totalTime = 1.3,
            events = {
                {
                    name = "buff_baoji_jia.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    common_hhs_fight = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    kami_skill_laser_anim = {
        idle = {
            totalTime = 5.1333,
            events = {
                {
                    name = "kami_skill_laser_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    buff_jianshang = {
        idle = {
            totalTime = 1.8333,
            events = {
                {
                    name = "buff_jianshang.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    ninsover_a_anim = {
        idle = {
            totalTime = 2.6333,
            triggerCnt = 0,
        },
    },
    monster_katana_black = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "monster_tachiwhoosh2.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    hades_bullet = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    jrio_b_hit = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "hit_high",
                    time = 0.2666,
                },
            },
            triggerCnt = 0,
        },
    },
    common_kamienergymax = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    eight = {
        skill_a = {
            totalTime = 1.6666,
            events = {
                {
                    int = 45,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "eight_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "eight_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 4,
                    name = "duang",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 3.4333,
            events = {
                {
                    name = "eight_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.9666,
            events = {
                {
                    name = "eight_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.3,
            events = {
                {
                    name = "eight_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 3.2333,
            events = {
                {
                    name = "eight_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 3.4333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.7333,
            triggerCnt = 0,
        },
        appear3 = {
            totalTime = 2.7,
            events = {
                {
                    int = 1,
                    name = "wacao",
                    time = 1.0666,
                },
            },
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.9333,
            triggerCnt = 0,
        },
    },
    kamitwelve = {
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 2,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 2,
                },
            },
            triggerCnt = 10,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamieleven.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    common_kamiappear = {
        idle = {
            totalTime = 1.8333,
            events = {
                {
                    name = "common_kamiappear.mp3",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 1,
        },
    },
    common_energy = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    common_hit_bing = {
        idle = {
            totalTime = 0.3333,
            events = {
                {
                    name = "common_hit_bing",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    buff_qusanjianyi = {
        idle = {
            totalTime = 1.5333,
            events = {
                {
                    name = "buff_qusanjianyi.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    summon_evilboy = {
        skill_b = {
            totalTime = 1,
            events = {
                {
                    name = "evilboy_skill_a",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.6666,
            events = {
                {
                    name = "evilboy_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        skill_b2 = {
            totalTime = 0.6666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    common_fenghuang_jianling_hit = {
        idle = {
            totalTime = 0.1666,
            events = {
                {
                    name = "common_fenghuang_jianling_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    stick_b = {
        idle = {
            totalTime = 0.5666,
            events = {
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 3,
        },
    },
    monster_boxer_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "monster_punchwhoosh1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    tcxy_skill_b_hit = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "tcxy_skill_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    blackeight_bianshen = {
        idle = {
            totalTime = 0.5333,
            events = {
                {
                    name = "blackeight_bianshen.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    monster_pipe = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_smogwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    Illusion_10 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "camisix.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.9,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "trigger",
                    time = 2.3,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "trigger",
                    time = 2.7,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 2.9666,
                },
                {
                    name = "trigger",
                    time = 3.1,
                },
                {
                    name = "trigger",
                    time = 3.2333,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.5,
                },
                {
                    name = "trigger",
                    time = 3.6333,
                },
                {
                    name = "trigger",
                    time = 3.7666,
                },
                {
                    name = "trigger",
                    time = 3.9,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.1666,
                },
                {
                    name = "trigger",
                    time = 4.3,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.3333,
                },
                {
                    name = "duang_start",
                    time = 4.6666,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_11 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamieleven.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 4,
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "trigger",
                    time = 2.2,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.8,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "trigger",
                    time = 4.2,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.5666,
                },
                {
                    name = "duang_end",
                    time = 4.7666,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_12 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamieleven.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    name = "trigger",
                    time = 2,
                },
                {
                    name = "trigger",
                    time = 2.1333,
                },
                {
                    name = "trigger",
                    time = 2.2666,
                },
                {
                    name = "trigger",
                    time = 2.4,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0666,
                },
                {
                    name = "trigger",
                    time = 3.2,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "trigger",
                    time = 3.6,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 4,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.5333,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    name = "duang_end",
                    time = 4.8,
                },
            },
            triggerCnt = 34,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_pipe_bullet = {
        idle = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
    },
    common_sunder_armor = {
        idle = {
            totalTime = 0.9333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 1,
        },
    },
    lqsez_bullet = {
        idle = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
    },
    buff_shanbi_jian = {
        idle = {
            totalTime = 1.4,
            triggerCnt = 0,
        },
    },
    rottenwood_b_anim = {
        idle = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
    },
    bladesoul_a = {
        idle = {
            totalTime = 1.9,
            events = {
                {
                    name = "bladesoul_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.6333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.7333,
                },
                {
                    name = "duang_end",
                    time = 0.9333,
                },
            },
            triggerCnt = 5,
        },
    },
    destroyer_bullet = {
        idle = {
            totalTime = 0.1333,
            triggerCnt = 0,
        },
    },
    monster_swords_1 = {
        hit2 = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.7,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 2,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "monster_kuwuwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high2 = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    lieyan_a_buff = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    common_heroenergymax = {
        idle = {
            totalTime = 0.7333,
            events = {
                {
                    name = "common_heroenergymax.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    rottenwood = {
        skill_a = {
            totalTime = 2.3666,
            events = {
                {
                    int = 37,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "rottenwood_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6,
            events = {
                {
                    name = "rottenwood_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "duang_end",
                    time = 0.9,
                },
                {
                    name = "duang_start",
                    time = 1.1333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "hit_high",
                    time = 1.1666,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "duang_end",
                    time = 1.3333,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 0.8,
            events = {
                {
                    name = "rottenwood_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 1.0666,
            events = {
                {
                    name = "rottenwood_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2333,
            events = {
                {
                    name = "rottenwood_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2333,
            events = {
                {
                    name = "rottenwood_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.4666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    monster_ironball_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.8666,
            events = {
                {
                    name = "monster_ironball.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    lordBlack = {
        skill_a = {
            totalTime = 4.2,
            events = {
                {
                    name = "lordBlack_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.8666,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "lordBlack_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    monster_gun = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_gunshot.mp3",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    boss_monkey_a_anim = {
        idle = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
    },
    bumblebee_a_amin = {
        idle = {
            totalTime = 3.0333,
            events = {
                {
                    name = "bumblebee_a_amin.mp3",
                    time = 1.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.4333,
                },
            },
            triggerCnt = 6,
        },
    },
    tcxy_skill_b_buff = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    drunkard = {
        skill_a = {
            totalTime = 3.1666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "drunkard_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3333,
                },
            },
            triggerCnt = 4,
        },
        skill_b = {
            totalTime = 1.1333,
            events = {
                {
                    name = "drunkard_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.9666,
            events = {
                {
                    name = "drunkard_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.9333,
            events = {
                {
                    name = "drunkard_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2333,
            events = {
                {
                    name = "drunkard_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4666,
            events = {
                {
                    name = "drunkard_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.9666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.3666,
            triggerCnt = 0,
        },
    },
    monster_zhandouhuanhuazhu_shifa = {
        idle = {
            totalTime = 3.5666,
            events = {
                {
                    name = "ui_zhandouhuanhuazhu_shifa.mp3",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
            },
            triggerCnt = 1,
        },
    },
    common_hit_an = {
        idle = {
            totalTime = 0.4666,
            events = {
                {
                    name = "common_hit_an.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    sand_a_buff = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    boss_typhoon_b = {
        idle = {
            totalTime = 1.1,
            events = {
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 7,
        },
    },
    boss_typhoon_c = {
        idle = {
            totalTime = 2.9,
            events = {
                {
                    name = "boss_typhoon_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "duang_end",
                    time = 2.7,
                },
            },
            triggerCnt = 18,
        },
    },
    boss_typhoon_a = {
        idle = {
            totalTime = 3.3666,
            events = {
                {
                    name = "boss_typhoon_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "duang_start",
                    time = 2.3,
                },
                {
                    name = "duang_end",
                    time = 2.6,
                },
            },
            triggerCnt = 9,
        },
    },
    silverfox_b = {
        idle = {
            totalTime = 0.9,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 5,
        },
    },
    buff_baoshang_jian = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "buff_baoshang_jian.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    eaststar_bullet = {
        idle = {
            totalTime = 0.3,
            triggerCnt = 0,
        },
    },
    nightingale = {
        skill_a = {
            totalTime = 1.9333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "nightingale_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "hit_far",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "duang_start",
                    time = 1.6666,
                },
                {
                    name = "duang_end",
                    time = 1.8,
                },
            },
            triggerCnt = 4,
        },
        skill_b = {
            totalTime = 1.3,
            events = {
                {
                    name = "nightingale_skill_b.mp3",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.2666,
            events = {
                {
                    name = "nightingale_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8,
            events = {
                {
                    name = "nightingale_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.4,
            events = {
                {
                    name = "nightingale_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1666,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        skill_b2 = {
            totalTime = 1.2,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.4,
            events = {
                {
                    name = "nightingale_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.2666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.6,
            triggerCnt = 0,
        },
    },
    summon_sandoll = {
        vertigo = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "trigger",
                    time = 0.0333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        birth = {
            totalTime = 0.7666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4,
            triggerCnt = 0,
        },
    },
    bumblebee_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    ghostfire = {
        skill_a = {
            totalTime = 3.2333,
            events = {
                {
                    int = 47,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "ghostfire_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "hit_high",
                    time = 2.3333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 2.0333,
            events = {
                {
                    name = "ghostfire_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "hit_down",
                    time = 1.8333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.5333,
            events = {
                {
                    name = "ghostfire_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "ghostfire_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.0666,
            events = {
                {
                    name = "ghostfire_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.5333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.5333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 3.9333,
            triggerCnt = 0,
        },
    },
    thor_a_anim = {
        idle = {
            totalTime = 2.0666,
            triggerCnt = 0,
        },
    },
    drunkard_bullet = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    painter_a_hit = {
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    buff_fangyu_jia = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "buff_fangyu_jia.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    meteor_b_bullet = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    acheron = {
        skill_a = {
            totalTime = 2.0666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "acheron_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "hit_down",
                    time = 1.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.7,
            events = {
                {
                    name = "acheron_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1,
            events = {
                {
                    name = "acheron_appear.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.6666,
            events = {
                {
                    name = "acheron_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "acheron_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2333,
            events = {
                {
                    name = "acheron_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.7,
            triggerCnt = 0,
        },
    },
    common_dianji_hit = {
        idle = {
            totalTime = 0.6,
            events = {
                {
                    name = "common_dianji_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    glaze = {
        skill_a = {
            totalTime = 2.2,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "glaze_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0333,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 0.9333,
            events = {
                {
                    name = "glaze_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.4333,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.0666,
            events = {
                {
                    name = "glaze_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        xinshou_appear = {
            totalTime = 4.5,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8666,
            events = {
                {
                    name = "glaze_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2,
            events = {
                {
                    name = "glaze_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle3 = {
            totalTime = 5.5666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 6.6666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.1,
            events = {
                {
                    name = "glaze_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.5666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 7.1,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 5.1,
                },
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 6.1,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_hat_bullet = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    common_hit_dun = {
        idle = {
            totalTime = 0.2666,
            events = {
                {
                    name = "common_hit_dun.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    hades_a_hit = {
        idle = {
            totalTime = 1.6,
            events = {
                {
                    int = 2,
                    name = "duang_star",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "duang_star",
                    time = 0.7,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
            },
            triggerCnt = 0,
        },
    },
    summon_evilgirl = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.7333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "evilgirl_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    nightingale_b = {
        idle = {
            totalTime = 0.3333,
            events = {
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 3,
        },
    },
    ares_a1 = {
        idle = {
            totalTime = 6.2333,
            events = {
                {
                    name = "ares_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.2,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.9,
                },
                {
                    name = "trigger",
                    time = 4.1,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 4.2,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    name = "trigger",
                    time = 4.5666,
                },
                {
                    name = "trigger",
                    time = 4.7333,
                },
                {
                    name = "trigger",
                    time = 4.8666,
                },
                {
                    name = "trigger",
                    time = 5,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 5.1666,
                },
                {
                    name = "trigger",
                    time = 5.1666,
                },
                {
                    name = "trigger",
                    time = 5.3333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 5.5333,
                },
                {
                    name = "duang_start",
                    time = 5.8666,
                },
                {
                    name = "duang_end",
                    time = 6.2333,
                },
            },
            triggerCnt = 17,
        },
    },
    bumblebee_a = {
        idle = {
            totalTime = 1.9,
            events = {
                {
                    name = "bumblebee_a_amin.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
            },
            triggerCnt = 6,
        },
    },
    zenmaster = {
        skill_a = {
            totalTime = 1.8,
            events = {
                {
                    int = 17,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "zenmaster_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "hit_down",
                    time = 1.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1333,
            events = {
                {
                    name = "zenmaster_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3,
            events = {
                {
                    name = "zenmaster_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.6666,
            events = {
                {
                    name = "zenmaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "zenmaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6,
            events = {
                {
                    name = "zenmaster_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.3,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.2,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.3666,
            triggerCnt = 0,
        },
    },
    destroyer_b_hit = {
        idle = {
            totalTime = 0.9,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    lieyan_a_hit = {
        idle = {
            totalTime = 0.7333,
            events = {
                {
                    name = "lieyan_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    rocker_a = {
        idle = {
            totalTime = 1.5333,
            events = {
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "duang_start",
                    time = 1.1333,
                },
                {
                    name = "duang_end",
                    time = 1.3666,
                },
            },
            triggerCnt = 6,
        },
    },
    yaoshou_jin2 = {
        idle = {
            totalTime = 1.7333,
            triggerCnt = 0,
        },
    },
    yaoshou_jin3 = {
        skill_a = {
            totalTime = 1.6666,
            events = {
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 0.8666,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "buffend",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 3,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    yaoshou_jin1 = {
        skill_a = {
            totalTime = 0.8333,
            events = {
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "buffend",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    undead_bs = {
        skill_a = {
            totalTime = 2.3333,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "undead_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 4,
                    name = "duang",
                    time = 1.5,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 3.2,
            events = {
                {
                    name = "undead_skill_b.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.6,
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 0.8,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "undead_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        vertigo3 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.6,
            triggerCnt = 0,
        },
        win = {
            totalTime = 4,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    yaoshou_jin4 = {
        idle = {
            totalTime = 1.7333,
            triggerCnt = 0,
        },
    },
    yaoshou_jin5 = {
        skill_a = {
            totalTime = 1.7333,
            events = {
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 9,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3,
            events = {
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.7666,
            triggerCnt = 0,
        },
    },
    monster_white_2_black = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "monster_kuwuwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.7333,
            triggerCnt = 0,
        },
    },
    monster_master_bullet = {
        idle = {
            totalTime = 0.1333,
            triggerCnt = 0,
        },
    },
    calligrapher_bullet_hit = {
        idle = {
            totalTime = 0.9333,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    destroyer = {
        skill_a = {
            totalTime = 2.8333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "destroyer_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.2666,
            events = {
                {
                    name = "destroyer_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.1666,
            events = {
                {
                    name = "destroyer_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            events = {
                {
                    name = "destroyer_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 5.8333,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "destroyer_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1,
            events = {
                {
                    name = "destroyer_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.1666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    rottenwood_a_hit = {
        idle = {
            totalTime = 1,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "rottenwood_a_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
            },
            triggerCnt = 0,
        },
    },
    thor = {
        skill_a = {
            totalTime = 2.6666,
            events = {
                {
                    int = 46,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "thor_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "hit_high",
                    time = 2.3,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1,
            events = {
                {
                    name = "thor_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "hit_down",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.6666,
            events = {
                {
                    name = "thor_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        xinshou_appear = {
            totalTime = 4.3333,
            events = {
                {
                    name = "thor_xinshou_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 0.9,
            events = {
                {
                    name = "thor_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.4,
            events = {
                {
                    name = "thor_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 8.6666,
            events = {
                {
                    int = 46,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "thor_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "hit_high",
                    time = 2.3,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "thor_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.4666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear3 = {
            totalTime = 2.9333,
            events = {
                {
                    int = 1,
                    name = "wacao",
                    time = 1.0666,
                },
            },
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.2333,
            triggerCnt = 0,
        },
    },
    calligrapher_a = {
        idle = {
            totalTime = 1.3333,
            events = {
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 0.1666,
                },
                {
                    name = "duang_end",
                    time = 0.3,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
            },
            triggerCnt = 5,
        },
    },
    shadowLord_b_hit = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    monster_oldman = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.4666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_poisonwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    common_jiuzui_tou_buff = {
        idle = {
            totalTime = 1.5,
            triggerCnt = 0,
        },
    },
    soul_6_a_hit = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "soul_3_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    kaze_a_anim = {
        idle = {
            totalTime = 1.2333,
            events = {
                {
                    name = "kaze_a_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    common_hit_kami = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    boneskin_b_buff = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    ghostfire_b_anim = {
        idle = {
            totalTime = 1.2333,
            triggerCnt = 0,
        },
    },
    graveman_c = {
        idle = {
            totalTime = 2.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
            },
            triggerCnt = 1,
        },
    },
    bumblebee = {
        skill_a = {
            totalTime = 2.5,
            events = {
                {
                    int = 38,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "bumblebee_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "bumblebee_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "hit_down",
                    time = 0.8333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1,
            events = {
                {
                    name = "bumblebee_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.9666,
            events = {
                {
                    name = "bumblebee_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.4333,
            events = {
                {
                    name = "bumblebee_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 2.5666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.8,
            triggerCnt = 0,
        },
    },
    youming_bullet = {
        skill_a = {
            totalTime = 0.6333,
            events = {
                {
                    name = "youming_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.4666,
            events = {
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8666,
            events = {
                {
                    name = "youming_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 2,
        },
        hit_high = {
            totalTime = 0,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 0,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    tcxy = {
        skill_a = {
            totalTime = 2.8,
            events = {
                {
                    name = "shirly_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 0.7333,
            events = {
                {
                    name = "shirly_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1,
            events = {
                {
                    name = "shirly_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "shirly_skill_b.mp3",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.8,
            events = {
                {
                    name = "shirly_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.8333,
            events = {
                {
                    name = "shirly_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 5.7333,
            events = {
                {
                    name = "shirly_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "shirly_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.8,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.8,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
    },
    boss_idle_anim = {
        idle = {
            totalTime = 4,
            triggerCnt = 0,
        },
    },
    sunnymoon_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    taoist_a = {
        idle = {
            totalTime = 1.8666,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "duang_start",
                    time = 1.1333,
                },
                {
                    name = "duang_end",
                    time = 1.4,
                },
            },
            triggerCnt = 5,
        },
    },
    minister = {
        skill_a = {
            totalTime = 3.1,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "minister_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.6666,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 1.3333,
            events = {
                {
                    name = "minister_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.3333,
            events = {
                {
                    name = "minister_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "minister_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 9.4,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0.0333,
                },
                {
                    name = "minister_skill_a2.mp3",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.0666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "minister_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.2,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 3.4,
            triggerCnt = 0,
        },
    },
    needle_a_anim = {
        idle = {
            totalTime = 2.3666,
            events = {
                {
                    name = "needle_a1_anim.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.6,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.6333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.7,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    name = "duang_end",
                    time = 2,
                },
            },
            triggerCnt = 0,
        },
    },
    common_halo_dress = {
        idle = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
    },
    painter = {
        skill_a = {
            totalTime = 2.0666,
            events = {
                {
                    int = 37,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "painter_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 1.5,
            events = {
                {
                    name = "painter_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1,
            events = {
                {
                    name = "painter_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.9666,
            events = {
                {
                    name = "painter_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.4,
            events = {
                {
                    name = "painter_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "painter_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    minister_a_hit = {
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    jihan_b_buff = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    buff_fuhuo = {
        idle = {
            totalTime = 1.0666,
            events = {
                {
                    name = "buff_fuhuo.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "end",
                    time = 1.0666,
                },
            },
            triggerCnt = 1,
        },
    },
    hgwc_c_buff = {
        idle = {
            totalTime = 1.7333,
            triggerCnt = 0,
        },
    },
    cullen_a_hit = {
        idle = {
            totalTime = 0.7,
            triggerCnt = 0,
        },
    },
    monster_assassin_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8333,
            events = {
                {
                    name = "monster_daggerwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    monster_assassin_2 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8333,
            events = {
                {
                    name = "monster_daggerwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    lsc_skill_b = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "lsc_skill_b_anim.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 6,
        },
    },
    bladesoul_a1 = {
        idle = {
            totalTime = 1.4666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 5,
        },
    },
    lsc_skill_a = {
        idle = {
            totalTime = 4.7666,
            events = {
                {
                    name = "lsc_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 1.1666,
                },
                {
                    name = "duang_start",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "trigger",
                    time = 2.3,
                },
                {
                    name = "duang_start",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.5,
                },
                {
                    name = "duang_end",
                    time = 3.9333,
                },
            },
            triggerCnt = 7,
        },
    },
    tramp_bullet_hit = {
        idle = {
            totalTime = 0.3666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    witch_a_hit = {
        idle = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
    },
    rockbuddha_a_anim = {
        idle = {
            totalTime = 4.0666,
            triggerCnt = 0,
        },
    },
    eight_b_hit = {
        idle = {
            totalTime = 0.9333,
            events = {
                {
                    name = "eight_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    kamieleven = {
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 2,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 2,
                },
            },
            triggerCnt = 10,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamieleven.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    witch_a = {
        idle = {
            totalTime = 1.6,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "duang_start",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "duang_end",
                    time = 1.4,
                },
            },
            triggerCnt = 5,
        },
    },
    common_shanghaifentan_jiao_buff = {
        idle = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
    },
    bumblebee_b_hit = {
        idle = {
            totalTime = 0.8666,
            events = {
                {
                    name = "bumblebee_b_hit.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    taoist_b_anim = {
        idle = {
            totalTime = 1.5666,
            triggerCnt = 0,
        },
    },
    boss_pluto = {
        skill_a = {
            totalTime = 3.5,
            events = {
                {
                    int = 27,
                    float = 10,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "boss_pluto_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "duang",
                    time = 2.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.4,
                },
                {
                    name = "hit_far",
                    time = 2.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.8666,
                },
            },
            triggerCnt = 4,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.3333,
            events = {
                {
                    name = "boss_pluto_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "hit_down",
                    time = 1,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "boss_pluto_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    minister_a_anim = {
        idle = {
            totalTime = 2.5666,
            triggerCnt = 0,
        },
    },
    sakura = {
        skill_a = {
            totalTime = 2.6666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "sakura_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "hit_far",
                    time = 1.5333,
                },
                {
                    int = 5,
                    name = "duang",
                    time = 1.6666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1666,
            events = {
                {
                    name = "sakura_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 0.9666,
            events = {
                {
                    name = "sakura_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.8333,
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 6.9333,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "sakura_skill_a.mp3",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "hit_far",
                    time = 3.0666,
                },
                {
                    int = 5,
                    name = "duang",
                    time = 3.3333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "sakura_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        knee = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    ares_a = {
        idle = {
            totalTime = 5.3,
            events = {
                {
                    name = "ares_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.9,
                },
                {
                    name = "trigger",
                    time = 3.0333,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.3,
                },
                {
                    name = "trigger",
                    time = 3.4333,
                },
                {
                    name = "trigger",
                    time = 3.5666,
                },
                {
                    name = "trigger",
                    time = 3.7,
                },
                {
                    name = "trigger",
                    time = 3.8333,
                },
                {
                    name = "trigger",
                    time = 3.9666,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.5,
                },
                {
                    name = "duang_start",
                    time = 4.8333,
                },
                {
                    name = "duang_end",
                    time = 5.3,
                },
            },
            triggerCnt = 13,
        },
    },
    assassin_b_anim = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "hit_down",
                    time = 0.8333,
                },
            },
            triggerCnt = 0,
        },
    },
    buff_baoshang_jia = {
        idle = {
            totalTime = 1.5,
            events = {
                {
                    name = "buff_baoshang_jia.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    dark_a = {
        idle = {
            totalTime = 1.9666,
            events = {
                {
                    name = "dark_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "hit_high",
                    time = 0.4,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.3333,
                },
                {
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "duang_end",
                    time = 1.6,
                },
            },
            triggerCnt = 5,
        },
    },
    buff_baoji_jian = {
        idle = {
            totalTime = 1.5333,
            events = {
                {
                    name = "buff_baoji_jian.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    cullen_b_hit = {
        idle = {
            totalTime = 0.2666,
            events = {
                {
                    name = "cullen_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    cullen = {
        skill_a = {
            totalTime = 3,
            events = {
                {
                    int = 41,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "cullen_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "hit_down",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "duang_start",
                    time = 2.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3,
                },
                {
                    name = "duang_end",
                    time = 2.4333,
                },
            },
            triggerCnt = 6,
        },
        skill_c = {
            totalTime = 1.3666,
            events = {
                {
                    name = "cullen_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.3666,
            events = {
                {
                    name = "cullen_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.5333,
            events = {
                {
                    name = "cullen_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1,
            events = {
                {
                    name = "cullen_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 8.4,
            events = {
                {
                    name = "cullen_skill_a1.mp3",
                    time = 0.0666,
                },
                {
                    int = 41,
                    float = 5,
                    name = "freezingstart",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 3.0666,
                },
                {
                    name = "hit_down",
                    time = 3.1333,
                },
                {
                    name = "duang_start",
                    time = 3.9666,
                },
                {
                    name = "duang_end",
                    time = 5.9333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.0666,
            events = {
                {
                    name = "cullen_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 2.7,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.9333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.5333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 3.4666,
            triggerCnt = 0,
        },
    },
    lqsez_shenqijineng_a = {
        idle = {
            totalTime = 2.3333,
            events = {
                {
                    name = "lqsez_shenqijineng_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 0.8,
                },
                {
                    name = "duang_end",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
            },
            triggerCnt = 1,
        },
    },
    common_liuxue_xiong_buff = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    rocker_b_hit = {
        idle = {
            totalTime = 0.2666,
            triggerCnt = 0,
        },
    },
    buff_sanwei_jian = {
        idle = {
            totalTime = 2,
            events = {
                {
                    name = "buff_sanwei_jian.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    common_hit_dian = {
        idle = {
            totalTime = 0.4,
            events = {
                {
                    name = "common_dianji_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    common_chuchang1 = {
        idle = {
            totalTime = 1.6,
            events = {
                {
                    name = "common_chuchang1.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "end",
                    time = 1.6,
                },
            },
            triggerCnt = 1,
        },
    },
    common_chuchang2 = {
        idle = {
            totalTime = 1.6,
            events = {
                {
                    name = "common_chuchang2.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "end",
                    time = 1.6,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_swords = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.7,
            events = {
                {
                    name = "monster_kuwuwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    thor_bullet = {
        idle = {
            totalTime = 0.1333,
            triggerCnt = 0,
        },
    },
    buff_jianbaoji = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    kami_skill_light_anim = {
        idle = {
            totalTime = 5.4,
            events = {
                {
                    name = "kami_skill_light_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    bleachedbones_a_anim = {
        idle = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
    },
    hgwc_c_hit = {
        idle = {
            totalTime = 1.9333,
            events = {
                {
                    name = "hgwc_c_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    hgwc_b_hit = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "hgwc_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    cullen_a1_hit = {
        idle = {
            totalTime = 1.3666,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.1333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.3,
                },
                {
                    name = "duang_end",
                    time = 0.6333,
                },
            },
            triggerCnt = 0,
        },
    },
    graveman_a_hit = {
        idle = {
            totalTime = 0.7,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0666,
                },
            },
            triggerCnt = 1,
        },
    },
    rocker = {
        skill_a = {
            totalTime = 2.8666,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "rocker_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "hit_far",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8666,
            events = {
                {
                    name = "rocker_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "hit_down",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.9,
            events = {
                {
                    name = "rocker_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6666,
            events = {
                {
                    name = "rocker_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2333,
            events = {
                {
                    name = "rocker_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.5666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.9,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 3.9,
            triggerCnt = 0,
        },
    },
    glaze_a_hit = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    boss_sand_c_buff = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    calligrapher_bullet = {
        idle = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
    },
    hades = {
        skill_a = {
            totalTime = 1.8,
            events = {
                {
                    int = 37,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "hades_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.3333,
            events = {
                {
                    name = "hades_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.8666,
            events = {
                {
                    name = "hades_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "hades_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "hades_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.8666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5.6666,
            triggerCnt = 0,
        },
    },
    funerarybuddha_a_buff = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    boss_sand_a_anim = {
        idle = {
            totalTime = 1.8666,
            events = {
                {
                    name = "boss_sand_a_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    shadow = {
        skill_a = {
            totalTime = 2.6666,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "shadow_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 1.4,
                },
                {
                    name = "hit_down",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.8,
            events = {
                {
                    name = "shadow_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "hit_down",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "duang_end",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.8666,
            events = {
                {
                    name = "shadow_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6,
            events = {
                {
                    name = "shadow_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2333,
            events = {
                {
                    name = "shadow_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        hurt = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.6,
            events = {
                {
                    name = "shadow_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
            },
            triggerCnt = 1,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.8666,
            triggerCnt = 0,
        },
        appear3 = {
            totalTime = 4.5666,
            events = {
                {
                    int = 1,
                    name = "wacao",
                    time = 1.9333,
                },
            },
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.2,
            triggerCnt = 0,
        },
    },
    boss_die_anim = {
        idle = {
            totalTime = 2.2666,
            triggerCnt = 0,
        },
    },
    boss_sand = {
        skill_a = {
            totalTime = 1.2,
            events = {
                {
                    name = "boss_sand_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 1.6,
            events = {
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "buffend",
                    time = 1.0666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "boss_sand_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        angry = {
            totalTime = 3.6,
            events = {
                {
                    name = "boss_sand_angry.mp3",
                    time = 0.0666,
                },
            },
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        hit_far = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1.2666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.2666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.2666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
    },
    witch_c_bullet = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    monster_ninja_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_tachiwhoosh1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    taoist_b_hit = {
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    boneskin_a = {
        idle = {
            totalTime = 1.0333,
            events = {
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 3,
        },
    },
    monster_oldman_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_poisonwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    shadowLord = {
        skill_a = {
            totalTime = 2.8666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "shadowLord_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 1.4333,
            events = {
                {
                    name = "shadowLord_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
            },
            triggerCnt = 2,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "shadowLord_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "shadowLord_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 2,
            events = {
                {
                    name = "shadowLord_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8666,
            events = {
                {
                    name = "shadowLord_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 6,
        },
        hit_far = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 16.4,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5.1666,
            triggerCnt = 0,
        },
    },
    boss_pluto_b_hit = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "boss_pluto_b_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
            },
            triggerCnt = 5,
        },
    },
    ninsover_b_anim = {
        idle = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
    },
    magicnight_a_anim = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    dark = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "dark_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "duang",
                    time = 1.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.2,
            events = {
                {
                    name = "dark_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.9666,
            events = {
                {
                    name = "dark_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        xinshou_appear = {
            totalTime = 3.3666,
            events = {
                {
                    name = "dark_xinshou_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            events = {
                {
                    name = "dark_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "dark_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.4666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.9666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    boss_sand_b_anim = {
        idle = {
            totalTime = 1.2333,
            triggerCnt = 0,
        },
    },
    assassin = {
        skill_a = {
            totalTime = 3.6666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "assassin_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.9,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "trigger",
                    time = 2.3,
                },
                {
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 2.9,
                },
                {
                    name = "duang_start",
                    time = 3,
                },
                {
                    name = "hit_high",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "duang_end",
                    time = 3.2,
                },
            },
            triggerCnt = 14,
        },
        skill_b = {
            totalTime = 1.4666,
            events = {
                {
                    name = "assassin_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "hit_down",
                    time = 0.8333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.8,
            events = {
                {
                    name = "assassin_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 0.7333,
            events = {
                {
                    name = "assassin_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        attack2 = {
            totalTime = 0.7333,
            events = {
                {
                    name = "assassin_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2333,
            events = {
                {
                    name = "assassin_attack.mp3",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle3 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "assassin_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.8,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    buff_electric = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "buff_electric.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    meteor_a1 = {
        idle = {
            totalTime = 8.1666,
            events = {
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "duang_start",
                    time = 4.1333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 4.5333,
                },
                {
                    name = "trigger",
                    time = 4.7,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 5,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 5.4,
                },
                {
                    name = "trigger",
                    time = 5.4333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 5.8666,
                },
                {
                    name = "trigger",
                    time = 6.1,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 6.3333,
                },
                {
                    name = "hit_far",
                    time = 6.4666,
                },
                {
                    name = "duang_end",
                    time = 6.8,
                },
            },
            triggerCnt = 6,
        },
    },
    painter_bullet = {
        idle = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
    },
    boss_ghost_b = {
        idle = {
            totalTime = 2.1666,
            events = {
                {
                    name = "boss_ghost_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "duang_start",
                    time = 1.7666,
                },
                {
                    name = "duang_end",
                    time = 2,
                },
            },
            triggerCnt = 6,
        },
    },
    minister_bullet = {
        idle = {
            totalTime = 0.3333,
            triggerCnt = 0,
        },
    },
    common_shandianmabi = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "common_shandianmabi.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "duang_end",
                    time = 0.6666,
                },
            },
            triggerCnt = 4,
        },
    },
    monster_sumo_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.4,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_punchhit.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    kaze = {
        skill_a = {
            totalTime = 2.2333,
            events = {
                {
                    int = 34,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "kaze_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "hit_high",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8333,
            events = {
                {
                    name = "kaze_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 3,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.0666,
            events = {
                {
                    name = "kaze_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 0.8666,
            events = {
                {
                    name = "kaze_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 4.3333,
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 6.4333,
            events = {
                {
                    int = 34,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "kaze_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "hit_high",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.5333,
            events = {
                {
                    name = "kaze_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0333,
                },
            },
            triggerCnt = 2,
        },
        rest = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.0666,
            triggerCnt = 0,
        },
        die2 = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_far = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.7333,
            triggerCnt = 0,
        },
        knee = {
            totalTime = 1.6,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.3333,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    destroyer_a1 = {
        idle = {
            totalTime = 6.1,
            events = {
                {
                    name = "destroyer_a1.mp3",
                    time = 0.0333,
                },
                {
                    name = "duang_start",
                    time = 2.3666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.4666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.6333,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.7,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 4.0333,
                },
                {
                    name = "trigger",
                    time = 4.2333,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.6333,
                },
                {
                    name = "duang_start",
                    time = 4.7666,
                },
                {
                    name = "duang_end",
                    time = 4.9333,
                },
            },
            triggerCnt = 11,
        },
    },
    dark_bullet = {
        idle = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
    },
    common_kamienergymax_c = {
        animation = {
            totalTime = 1,
            events = {
                {
                    name = "common_kamienergymax_c.mp3",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
    },
    common_bianshen = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "blackeight_bianshen.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    tramp_a = {
        idle = {
            totalTime = 1.8666,
            events = {
                {
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "duang_end",
                    time = 0.4666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    name = "duang_end",
                    time = 1.5333,
                },
            },
            triggerCnt = 8,
        },
    },
    bumblebee_a_hit = {
        idle = {
            totalTime = 1.4666,
            triggerCnt = 0,
        },
    },
    lqsrz = {
        skill_a = {
            totalTime = 3.3333,
            events = {
                {
                    name = "lqsrz_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.1666,
            events = {
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1,
            events = {
                {
                    name = "lqsrz_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 7.1666,
            events = {
                {
                    name = "lqsrz_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 4.7,
                },
                {
                    name = "trigger",
                    time = 6.7666,
                },
            },
            triggerCnt = 5,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    lord_a = {
        idle = {
            totalTime = 2.6333,
            events = {
                {
                    name = "lordBlack_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    name = "trigger",
                    time = 2.0333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.1333,
                },
                {
                    name = "trigger",
                    time = 2.1333,
                },
                {
                    name = "trigger",
                    time = 2.2333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 2.3333,
                },
                {
                    name = "duang_end",
                    time = 2.4333,
                },
            },
            triggerCnt = 17,
        },
    },
    buff_nengliang_jian = {
        idle = {
            totalTime = 1.5,
            events = {
                {
                    name = "buff_nengliang_jian",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    bleachedbones_a_hit = {
        idle = {
            totalTime = 1.2666,
            events = {
                {
                    name = "bleachedbones_a_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 2,
                    name = "daung_start",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "daung_start",
                    time = 0.4333,
                },
                {
                    name = "daung_end",
                    time = 0.6,
                },
            },
            triggerCnt = 0,
        },
    },
    blademaster = {
        win = {
            totalTime = 1.4,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        skill_b_old5 = {
            totalTime = 0.9666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "hit_far",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_b_old2 = {
            totalTime = 0.9666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "hit_far",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        skill_c2 = {
            totalTime = 0.9,
            events = {
                {
                    name = "blademaster_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        appear2 = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        skill_a = {
            totalTime = 2.6333,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "blademaster_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 6,
                    name = "duang",
                    time = 1.4,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 0.6333,
            events = {
                {
                    name = "trigger",
                    time = 0.2,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.9666,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "hit_far",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        appear = {
            totalTime = 0.9666,
            events = {
                {
                    name = "blademaster_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 1.6333,
            events = {
                {
                    name = "blademaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        attack2 = {
            totalTime = 3.3333,
            events = {
                {
                    name = "blademaster_attack.mp3",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
            },
            triggerCnt = 4,
        },
        attack = {
            totalTime = 1.3,
            events = {
                {
                    name = "blademaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 4,
        },
        attack5 = {
            totalTime = 1.3333,
            events = {
                {
                    name = "blademaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 4,
        },
        attack4 = {
            totalTime = 1.5666,
            events = {
                {
                    name = "blademaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        skill_a2 = {
            totalTime = 6.6666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "blademaster_skill_a.mp3",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    int = 6,
                    name = "duang",
                    time = 2.8,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.3,
            events = {
                {
                    name = "blademaster_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_buff = {
            totalTime = 0.7333,
            events = {
                {
                    name = "blademaster_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5.5,
            triggerCnt = 0,
        },
    },
    soul_3_a_hit = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "soul_3_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    cullen_c_hit = {
        idle = {
            totalTime = 0.2666,
            events = {
                {
                    name = "cullen_c_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    boss_cat = {
        skill_a = {
            totalTime = 1,
            events = {
                {
                    name = "boss_cat_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 3,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "boss_cat_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.5333,
            events = {
                {
                    name = "boss_cat_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
            },
            triggerCnt = 2,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        angry = {
            totalTime = 3.5333,
            events = {
                {
                    name = "boss_cat_angry.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.8666,
                },
            },
            triggerCnt = 5,
        },
        hit_high = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        hit_far = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
    },
    bumblebee_a_buff = {
        idle = {
            totalTime = 2.5,
            triggerCnt = 0,
        },
    },
    wanderer_b_anim = {
        idle = {
            totalTime = 1.3,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
    },
    graveman = {
        skill_a = {
            totalTime = 2.3666,
            events = {
                {
                    int = 51,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "graveman_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    name = "hit_down",
                    time = 1.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "duang_start",
                    time = 2.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "duang_end",
                    time = 2.2666,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 3,
            events = {
                {
                    name = "graveman_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 3,
            events = {
                {
                    name = "graveman_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 1.0333,
            events = {
                {
                    name = "graveman_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "graveman_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            events = {
                {
                    name = "graveman_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 3,
            triggerCnt = 0,
        },
        win = {
            totalTime = 2.9333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 7.2333,
            triggerCnt = 0,
        },
    },
    funerarybuddha_b_hit1 = {
        idle = {
            totalTime = 0.3333,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    funerarybuddha_b_hit2 = {
        idle = {
            totalTime = 1.3333,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_hat = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.8,
            events = {
                {
                    name = "monster_magicwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    monster_master = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_magicwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    destroyer_xs_chuxian_heihua = {
        idle2 = {
            totalTime = 1.1333,
            triggerCnt = 0,
        },
        idle1 = {
            totalTime = 2.2666,
            events = {
                {
                    name = "destroyer_xs_chuxian_heihua_idle1.mp3",
                    time = 0.0333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "duang_end",
                    time = 1.6666,
                },
            },
            triggerCnt = 1,
        },
    },
    jrio_a = {
        idle = {
            totalTime = 2.0666,
            events = {
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.1666,
                },
                {
                    name = "duang_start",
                    time = 0.3,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.4333,
                },
                {
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.7,
                },
                {
                    name = "duang_start",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.9666,
                },
                {
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.2333,
                },
                {
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.5,
                },
                {
                    name = "duang_start",
                    time = 1.6333,
                },
                {
                    name = "duang_end",
                    time = 1.7666,
                },
            },
            triggerCnt = 6,
        },
    },
    common_jiansu_jiao_buff = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    tcxy_skill_a = {
        idle = {
            totalTime = 2.3333,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.2333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "duang_end",
                    time = 0.3666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "duang_end",
                    time = 0.6,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "duang_end",
                    time = 0.8,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "duang_end",
                    time = 1.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "duang_end",
                    time = 1.4333,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.6333,
                },
                {
                    name = "duang_end",
                    time = 1.7,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 1.9,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.9666,
                },
                {
                    name = "duang_end",
                    time = 2.0333,
                },
            },
            triggerCnt = 10,
        },
    },
    needle_a_buff = {
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    emperor = {
        skill_a = {
            totalTime = 2.3333,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "emperor_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "duang_start",
                    time = 1.5666,
                },
                {
                    name = "duang_end",
                    time = 1.6666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 2.2666,
            events = {
                {
                    name = "emperor_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "hit_down",
                    time = 1.2333,
                },
                {
                    name = "duang_start",
                    time = 1.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "duang_end",
                    time = 2.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 0.9666,
            events = {
                {
                    name = "emperor_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.5,
            events = {
                {
                    name = "emperor_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 9.2666,
            events = {
                {
                    int = 35,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.3666,
                },
                {
                    name = "hit_far",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.4666,
                },
                {
                    name = "duang_start",
                    time = 1.5666,
                },
                {
                    name = "duang_end",
                    time = 1.6666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.6,
            events = {
                {
                    name = "emperor_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.1333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "hit_down",
                    time = 1.1666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "duang_start",
                    time = 1.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "duang_end",
                    time = 1.4,
                },
            },
            triggerCnt = 6,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack_old = {
            totalTime = 1.0333,
            events = {
                {
                    name = "emperor_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 4,
        },
        idle2 = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.4666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 0.9666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.3333,
            triggerCnt = 0,
        },
        skill_b_old = {
            totalTime = 0.8333,
            events = {
                {
                    name = "emperor_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "hit_down",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "duang_start",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "duang_end",
                    time = 0.6333,
                },
            },
            triggerCnt = 3,
        },
    },
    jihan_bullet = {
        idle = {
            totalTime = 0,
            triggerCnt = 0,
        },
    },
    kaze_hit = {
        idle = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
    },
    common_hit_huo = {
        idle = {
            totalTime = 0.3333,
            events = {
                {
                    name = "common_fier_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    boss_typhoon = {
        skill_a = {
            totalTime = 2.4333,
            events = {
                {
                    int = 26,
                    float = 10,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "boss_typhoon_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "hit_high",
                    time = 1.2666,
                },
            },
            triggerCnt = 1,
        },
        skill_c = {
            totalTime = 2.0666,
            events = {
                {
                    name = "boss_typhoon_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "hit_high",
                    time = 0.8666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 3.2333,
            events = {
                {
                    name = "boss_typhoon_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2666,
            events = {
                {
                    name = "boss_typhoon_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    blackeight_a_hit = {
        idle = {
            totalTime = 0.4,
            events = {
                {
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "bleachedbones_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 1,
        },
    },
    buff_jingu = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    boss_crab_a_anim = {
        idle = {
            totalTime = 0.8333,
            triggerCnt = 0,
        },
    },
    boss_ghost = {
        skill_a = {
            totalTime = 3.3333,
            events = {
                {
                    int = 46,
                    float = 10,
                    name = "feezingstart",
                    time = 0,
                },
                {
                    name = "boss_ghost_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3666,
                },
                {
                    int = 6,
                    name = "duang",
                    time = 2.4,
                },
                {
                    name = "hit_far",
                    time = 2.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3,
                },
            },
            triggerCnt = 7,
        },
        skill_c = {
            totalTime = 2.1666,
            events = {
                {
                    name = "boss_ghost_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "hit_far",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
            },
            triggerCnt = 5,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "boss_ghost_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.0333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.2333,
            events = {
                {
                    name = "boss_ghost_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    ares = {
        skill_c = {
            totalTime = 4.4,
            events = {
                {
                    name = "trigger",
                    time = 1.2,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 2,
            events = {
                {
                    name = "ares_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "duang_start",
                    time = 1.3333,
                },
                {
                    name = "buffend",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "duang_start",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "duang_start",
                    time = 1.5333,
                },
                {
                    name = "duang_end",
                    time = 1.6666,
                },
            },
            triggerCnt = 5,
        },
        hit = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        birth = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.8333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "ares_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        skill_c2 = {
            totalTime = 1.3,
            events = {
                {
                    name = "ares_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.7,
                },
                {
                    name = "buffend",
                    time = 0.8,
                },
            },
            triggerCnt = 1,
        },
        skill_b2 = {
            totalTime = 1.2,
            events = {
                {
                    name = "ares_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "hit_down",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "buffend",
                    time = 0.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 3,
        },
        hit_down = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    monster_ninja = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "monster_tachiwhoosh1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    lordRed = {
        skill_a = {
            totalTime = 4.2,
            events = {
                {
                    name = "trigger",
                    time = 1.8666,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.1333,
            events = {
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        walk = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
    },
    monster_katana_1 = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9,
            events = {
                {
                    name = "monster_tachiwhoosh2.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    blademaster_b_hit = {
        idle = {
            totalTime = 1,
            events = {
                {
                    name = "blademaster_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    hgwc_a_buff = {
        idle = {
            totalTime = 2,
            triggerCnt = 0,
        },
    },
    silverfox_a_anim = {
        idle = {
            totalTime = 2.9666,
            triggerCnt = 0,
        },
    },
    eaststar = {
        skill_a = {
            totalTime = 2.5,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "eaststar_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 6,
                    name = "duang",
                    time = 1.4,
                },
                {
                    name = "hit_far",
                    time = 1.4666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.0666,
            events = {
                {
                    name = "eaststar_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.3333,
            events = {
                {
                    name = "eaststar_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        xinshou_appear = {
            totalTime = 2.2333,
            events = {
                {
                    name = "eaststar_xinshou_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack3 = {
            totalTime = 3.3,
            events = {
                {
                    name = "eaststar_attack.mp3",
                    time = 1.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.8666,
                },
            },
            triggerCnt = 3,
        },
        attack2 = {
            totalTime = 1.0333,
            events = {
                {
                    name = "eaststar_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        skill_a1 = {
            totalTime = 6.2666,
            events = {
                {
                    int = 36,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "eaststar_skill_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.8,
            events = {
                {
                    name = "eaststar_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3666,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            events = {
                {
                    name = "eaststar_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.1666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.7333,
            triggerCnt = 0,
        },
    },
    Illusion_8 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.3333,
            events = {
                {
                    name = "black",
                    time = 1.8333,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.8333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "trigger",
                    time = 0.2666,
                },
                {
                    name = "trigger",
                    time = 0.4,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
                {
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    name = "trigger",
                    time = 2,
                },
                {
                    name = "trigger",
                    time = 2.1333,
                },
                {
                    name = "trigger",
                    time = 2.2666,
                },
                {
                    name = "trigger",
                    time = 2.4,
                },
                {
                    name = "trigger",
                    time = 2.5333,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 2.9333,
                },
                {
                    name = "trigger",
                    time = 3.0666,
                },
                {
                    name = "trigger",
                    time = 3.2,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "trigger",
                    time = 3.6,
                },
                {
                    name = "trigger",
                    time = 3.7333,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.1333,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    name = "duang_start",
                    time = 4.5,
                },
                {
                    name = "trigger",
                    time = 4.5333,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 34,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_9 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "camisix.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "trigger",
                    time = 2.2,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.8,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.2,
                },
                {
                    name = "trigger",
                    time = 4.2,
                },
                {
                    name = "duang_start",
                    time = 4.6,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 32,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    boss_generalred = {
        skill_a = {
            totalTime = 1.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.721,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7983,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
            },
            triggerCnt = 4,
        },
        skill_b = {
            totalTime = 1.3333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
            },
            triggerCnt = 5,
        },
        hit = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        die = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.4,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8333,
                },
            },
            triggerCnt = 3,
        },
        hit_far = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1,
            triggerCnt = 0,
        },
    },
    soul_4_a_hit = {
        idle = {
            totalTime = 1.2,
            events = {
                {
                    name = "soul_3_a_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    Illusion_2 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamitwoap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 2.9666,
                },
                {
                    name = "trigger",
                    time = 3.0666,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "trigger",
                    time = 3.5666,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.7666,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 3.9666,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "trigger",
                    time = 4.1666,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.4666,
                },
                {
                    name = "duang_start",
                    time = 4.7,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 32,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_3 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamitwoap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 2.9666,
                },
                {
                    name = "trigger",
                    time = 3.0666,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "trigger",
                    time = 3.5666,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.7666,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 3.9666,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "trigger",
                    time = 4.1666,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.4333,
                },
                {
                    name = "duang_start",
                    time = 4.7,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 31,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    monster_master_black = {
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3666,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 0.9333,
            events = {
                {
                    name = "monster_magicwhoosh.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    Illusion_6 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "camisix.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "trigger",
                    time = 2.2,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.8,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "trigger",
                    time = 4.2,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "duang_start",
                    time = 4.6666,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_7 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "camisix.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.2,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0666,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2666,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 1.9333,
                },
                {
                    name = "trigger",
                    time = 2.0666,
                },
                {
                    name = "trigger",
                    time = 2.2,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7333,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1333,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "trigger",
                    time = 3.5333,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.8,
                },
                {
                    name = "trigger",
                    time = 3.9333,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "trigger",
                    time = 4.2,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.3333,
                },
                {
                    name = "trigger",
                    time = 4.3333,
                },
                {
                    name = "duang_start",
                    time = 4.6333,
                },
                {
                    name = "duang_end",
                    time = 4.9,
                },
            },
            triggerCnt = 33,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_4 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamitwoap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "trigger",
                    time = 1.8,
                },
                {
                    name = "trigger",
                    time = 2,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.2,
                },
                {
                    name = "trigger",
                    time = 2.2,
                },
                {
                    name = "trigger",
                    time = 2.3,
                },
                {
                    name = "trigger",
                    time = 2.4,
                },
                {
                    name = "trigger",
                    time = 2.5,
                },
                {
                    name = "trigger",
                    time = 2.6,
                },
                {
                    name = "trigger",
                    time = 2.7,
                },
                {
                    name = "trigger",
                    time = 2.8,
                },
                {
                    name = "trigger",
                    time = 2.9,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1,
                },
                {
                    name = "trigger",
                    time = 3.2,
                },
                {
                    name = "trigger",
                    time = 3.3,
                },
                {
                    name = "trigger",
                    time = 3.4,
                },
                {
                    name = "trigger",
                    time = 3.5,
                },
                {
                    name = "trigger",
                    time = 3.6,
                },
                {
                    name = "trigger",
                    time = 3.7,
                },
                {
                    name = "trigger",
                    time = 3.8,
                },
                {
                    name = "trigger",
                    time = 3.9,
                },
                {
                    name = "trigger",
                    time = 4,
                },
                {
                    name = "trigger",
                    time = 4.1,
                },
                {
                    name = "trigger",
                    time = 4.2,
                },
                {
                    name = "trigger",
                    time = 4.3,
                },
                {
                    name = "trigger",
                    time = 4.4,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.4666,
                },
                {
                    name = "duang_start",
                    time = 4.7333,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 32,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    Illusion_5 = {
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2,
            events = {
                {
                    name = "kamitwoap.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "black",
                    time = 1.5,
                },
                {
                    int = 1,
                    name = "end",
                    time = 1.5,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack = {
            totalTime = 5,
            events = {
                {
                    name = "duang_start",
                    time = 0,
                },
                {
                    name = "trigger",
                    time = 0.1,
                },
                {
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.9,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    int = 3,
                    name = "duang_start",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.3666,
                },
                {
                    name = "trigger",
                    time = 2.4666,
                },
                {
                    name = "trigger",
                    time = 2.5666,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.7666,
                },
                {
                    name = "trigger",
                    time = 2.8666,
                },
                {
                    name = "trigger",
                    time = 2.9666,
                },
                {
                    name = "trigger",
                    time = 3.0666,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.2666,
                },
                {
                    name = "trigger",
                    time = 3.3666,
                },
                {
                    name = "trigger",
                    time = 3.4666,
                },
                {
                    name = "trigger",
                    time = 3.5666,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.7666,
                },
                {
                    name = "trigger",
                    time = 3.8666,
                },
                {
                    name = "trigger",
                    time = 3.9666,
                },
                {
                    name = "trigger",
                    time = 4.0666,
                },
                {
                    name = "trigger",
                    time = 4.1666,
                },
                {
                    name = "trigger",
                    time = 4.2666,
                },
                {
                    name = "trigger",
                    time = 4.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4.4333,
                },
                {
                    name = "trigger",
                    time = 4.4666,
                },
                {
                    name = "duang_start",
                    time = 4.7,
                },
                {
                    name = "duang_end",
                    time = 5,
                },
            },
            triggerCnt = 32,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        buff = {
            totalTime = 1,
            events = {
                {
                    name = "trigger",
                    time = 0.1666,
                },
            },
            triggerCnt = 1,
        },
    },
    dark_ball = {
        idle = {
            totalTime = 1.0666,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.6333,
            events = {
                {
                    name = "dark_ball2.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6333,
                },
            },
            triggerCnt = 1,
        },
    },
    buff_gongji_jia = {
        idle = {
            totalTime = 1.0333,
            events = {
                {
                    name = "buff_gongji_jia.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    kamiappear_1 = {
        idle = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
    },
    kamiappear_2 = {
        idle = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
    },
    sunnymoon_a_anim = {
        idle = {
            totalTime = 3.6,
            triggerCnt = 0,
        },
    },
    common_fier_hit = {
        idle = {
            totalTime = 0.3666,
            events = {
                {
                    name = "common_fier_hit.mp3",
                    time = 0,
                },
            },
            triggerCnt = 0,
        },
    },
    monster_mine_bullet = {
        idle = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    boss_crab_c_buff = {
        idle = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
    },
    common_kamienergymax_b = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    boss_cat_c_anim = {
        idle = {
            totalTime = 0.9333,
            events = {
                {
                    name = "boss_cat_c_anim.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.1666,
                },
                {
                    name = "trigger",
                    time = 0.3333,
                },
            },
            triggerCnt = 3,
        },
    },
    nightingale_a_anim = {
        idle = {
            totalTime = 2.1666,
            triggerCnt = 0,
        },
    },
    buff_gongji_jian = {
        idle = {
            totalTime = 1.6,
            events = {
                {
                    name = "buff_gongji_jian.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    kaze_a1 = {
        idle = {
            totalTime = 6.5,
            events = {
                {
                    int = 3,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    name = "kaze_a1.mp3",
                    time = 0.0333,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1,
                },
                {
                    name = "trigger",
                    time = 1.1666,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.5,
                },
                {
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    name = "trigger",
                    time = 1.8333,
                },
                {
                    name = "trigger",
                    time = 2,
                },
                {
                    name = "trigger",
                    time = 2.1666,
                },
                {
                    name = "trigger",
                    time = 2.3333,
                },
                {
                    name = "trigger",
                    time = 2.5,
                },
                {
                    name = "trigger",
                    time = 2.6666,
                },
                {
                    name = "trigger",
                    time = 2.8333,
                },
                {
                    name = "trigger",
                    time = 3,
                },
                {
                    name = "trigger",
                    time = 3.1666,
                },
                {
                    name = "trigger",
                    time = 3.3333,
                },
                {
                    name = "trigger",
                    time = 3.5,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 3.6666,
                },
                {
                    name = "hit_high",
                    time = 3.6666,
                },
                {
                    name = "trigger",
                    time = 3.6666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 4,
                },
                {
                    name = "duang_end",
                    time = 4.3333,
                },
            },
            triggerCnt = 17,
        },
    },
    kami_skill_ice_anim = {
        idle = {
            totalTime = 5,
            events = {
                {
                    name = "kami_skill_wing_anim.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    ghostfire_a_hit = {
        idle = {
            totalTime = 2,
            events = {
                {
                    name = "ghostfire_a_hit.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.1,
                },
                {
                    name = "hit_high",
                    time = 0.1,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.3,
                },
                {
                    name = "duang_end",
                    time = 0.8333,
                },
            },
            triggerCnt = 0,
        },
    },
    undead_a_hit = {
        idle = {
            totalTime = 1.2666,
            events = {
                {
                    name = "trigger",
                    time = 0.1,
                },
            },
            triggerCnt = 1,
        },
    },
    meteor = {
        skill_a = {
            totalTime = 2.6666,
            events = {
                {
                    int = 45,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "meteor_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6666,
                },
                {
                    int = 5,
                    name = "duang",
                    time = 1.7333,
                },
                {
                    name = "hit_far",
                    time = 1.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.0666,
                },
            },
            triggerCnt = 5,
        },
        skill_c = {
            totalTime = 1.2,
            events = {
                {
                    name = "meteor_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "hit_high",
                    time = 0.7,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.8,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 1.5666,
            events = {
                {
                    name = "meteor_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.8333,
            events = {
                {
                    name = "meteor_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
            },
            triggerCnt = 1,
        },
        skill_a1 = {
            totalTime = 10.6666,
            events = {
                {
                    int = 45,
                    float = 5,
                    name = "freezingstart",
                    time = 0.0666,
                },
                {
                    name = "meteor_skill_a1.mp3",
                    time = 0.0666,
                },
                {
                    int = 5,
                    name = "duang",
                    time = 2.0666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.3333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.1666,
            events = {
                {
                    name = "meteor_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
            },
            triggerCnt = 2,
        },
        hit_far = {
            totalTime = 1.3,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.3333,
            events = {
                {
                    name = "meteor_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 1.5666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.3333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.3666,
            triggerCnt = 0,
        },
    },
    lord_hit = {
        idle = {
            totalTime = 1.3333,
            events = {
                {
                    name = "lordBlack_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    common_hudun_jiao_buff = {
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
    boss_firegirl_b_hit = {
        idle = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
    },
    needle_b_hit = {
        idle = {
            totalTime = 0.4,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 0,
                },
                {
                    name = "needle_b_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 1,
        },
    },
    shadow_a = {
        idle = {
            totalTime = 1.6333,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 0.2,
                },
                {
                    name = "duang_start",
                    time = 0.3666,
                },
                {
                    name = "duang_end",
                    time = 0.4666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.3666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "duang_end",
                    time = 1.5666,
                },
            },
            triggerCnt = 10,
        },
    },
    bladesoul = {
        skill_a = {
            totalTime = 2.8333,
            events = {
                {
                    int = 34,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "bladesoul_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
                {
                    int = 2,
                    name = "duang",
                    time = 1.4,
                },
                {
                    name = "hit_down",
                    time = 1.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.9333,
            events = {
                {
                    name = "bladesoul_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    name = "hit_far",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6666,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.1333,
            events = {
                {
                    name = "bladesoul_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.6,
            events = {
                {
                    name = "bladesoul_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        win = {
            totalTime = 1,
            triggerCnt = 0,
        },
        jump2 = {
            totalTime = 1.8,
            events = {
                {
                    name = "bladesoul_attack.mp3",
                    time = 0.4666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5333,
                },
            },
            triggerCnt = 4,
        },
        attack = {
            totalTime = 1.3666,
            events = {
                {
                    name = "bladesoul_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        skill_a2 = {
            totalTime = 2.8333,
            events = {
                {
                    int = 34,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "bladesoul_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.3,
                },
                {
                    int = 2,
                    name = "duang",
                    time = 1.4,
                },
                {
                    name = "hit_down",
                    time = 1.4333,
                },
            },
            triggerCnt = 1,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 0.6666,
            events = {
                {
                    name = "bladesoul_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3,
                },
            },
            triggerCnt = 1,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.1333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    poseidon_b_hit = {
        idle = {
            totalTime = 1.1,
            triggerCnt = 0,
        },
    },
    dark_b_hit = {
        idle = {
            totalTime = 1.4,
            events = {
                {
                    name = "trigger",
                    time = 0.6,
                },
                {
                    name = "hit_high",
                    time = 0.6666,
                },
            },
            triggerCnt = 1,
        },
    },
    wanderer_a = {
        idle = {
            totalTime = 3.3,
            events = {
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.0333,
                },
                {
                    name = "wanderer_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.1333,
                },
                {
                    name = "duang_end",
                    time = 0.1666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "duang_end",
                    time = 0.5666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 0.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.9666,
                },
                {
                    name = "duang_end",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5,
                },
                {
                    int = 4,
                    name = "duang_start",
                    time = 1.9,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 1.9666,
                },
                {
                    name = "hit_down",
                    time = 2,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.1,
                },
                {
                    int = 2,
                    name = "trigger",
                    time = 2.2666,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 2.3333,
                },
                {
                    name = "duang_start",
                    time = 2.5,
                },
                {
                    name = "duang_end",
                    time = 2.6,
                },
            },
            triggerCnt = 11,
        },
    },
    emperor_b_hit = {
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
    },
    blademaster_c_hit = {
        idle = {
            totalTime = 0.9,
            triggerCnt = 0,
        },
    },
    common_hit = {
        idle = {
            totalTime = 0.1333,
            events = {
                {
                    name = "common_hit.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
    },
    eaststar_b1_buff = {
        idle = {
            totalTime = 0.6,
            triggerCnt = 0,
        },
    },
    boneskin = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    int = 43,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "boneskin_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.6,
                },
                {
                    name = "hit_high",
                    time = 1.6333,
                },
                {
                    int = 2,
                    name = "duang_start",
                    time = 1.6666,
                },
                {
                    int = 1,
                    name = "duang_start",
                    time = 1.8333,
                },
                {
                    name = "duang_start",
                    time = 2,
                },
                {
                    name = "duang_end",
                    time = 2.1666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.6666,
            events = {
                {
                    name = "boneskin_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.2,
                },
            },
            triggerCnt = 1,
        },
        hit = {
            totalTime = 0.4666,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 0.8666,
            events = {
                {
                    name = "boneskin_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        xinshou_appear = {
            totalTime = 2.4333,
            events = {
                {
                    name = "boneskin_xinshou_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack2 = {
            totalTime = 3.0333,
            events = {
                {
                    int = 1,
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.8,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.2,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 2.3,
                },
            },
            triggerCnt = 4,
        },
        attack = {
            totalTime = 1.0666,
            events = {
                {
                    name = "boneskin_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.2333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.7,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.8,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        skill_b2 = {
            totalTime = 0.8666,
            events = {
                {
                    name = "trigger",
                    time = 0.3666,
                },
            },
            triggerCnt = 1,
        },
        die = {
            totalTime = 1.6666,
            events = {
                {
                    name = "boneskin_die",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 0.8666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.8333,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 5.7333,
            triggerCnt = 0,
        },
    },
    summon_blackeight = {
        skill_a = {
            totalTime = 1.7,
            events = {
                {
                    int = 46,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "blackeight_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.7,
                },
            },
            triggerCnt = 1,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1666,
            events = {
                {
                    name = "blackeight_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1,
            events = {
                {
                    name = "blackeight_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4666,
                },
            },
            triggerCnt = 1,
        },
        hit_far = {
            totalTime = 1.1666,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.2,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        win = {
            totalTime = 1.7333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        bianshen_b = {
            totalTime = 0.5333,
            triggerCnt = 0,
        },
    },
    youming_a = {
        idle = {
            totalTime = 2,
            events = {
                {
                    name = "trigger",
                    time = 0.7333,
                },
                {
                    name = "trigger",
                    time = 0.8333,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2333,
                },
                {
                    name = "trigger",
                    time = 1.3333,
                },
                {
                    name = "trigger",
                    time = 1.4333,
                },
                {
                    name = "trigger",
                    time = 1.5333,
                },
            },
            triggerCnt = 9,
        },
    },
    funerarybuddha = {
        skill_a = {
            totalTime = 2.1333,
            events = {
                {
                    int = 33,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "funerarybuddha_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.2666,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 0.9333,
            events = {
                {
                    name = "funerarybuddha_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 2,
                    name = "trigger1",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.4333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.5666,
                },
            },
            triggerCnt = 4,
        },
        hit = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear = {
            totalTime = 2.1666,
            events = {
                {
                    name = "funerarybuddha_appear.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1,
            events = {
                {
                    name = "funerarybuddha_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        skill_a1 = {
            totalTime = 5,
            events = {
                {
                    int = 33,
                    float = 5,
                    name = "freezingstart",
                    time = 0,
                },
                {
                    name = "funerarybuddha_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 3.4333,
                },
            },
            triggerCnt = 1,
        },
        attack = {
            totalTime = 1.4,
            events = {
                {
                    name = "funerarybuddha_attack.mp3",
                    time = 0.0333,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.3666,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 0.6,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1,
                },
                {
                    int = 1,
                    name = "trigger",
                    time = 1.1,
                },
            },
            triggerCnt = 4,
        },
        hit_far = {
            totalTime = 0.9333,
            triggerCnt = 0,
        },
        walk = {
            totalTime = 0.8,
            triggerCnt = 0,
        },
        jump = {
            totalTime = 0.4,
            triggerCnt = 0,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1,
            triggerCnt = 0,
        },
        idle2 = {
            totalTime = 1,
            triggerCnt = 0,
        },
        win = {
            totalTime = 3.7333,
            triggerCnt = 0,
        },
        hit_down = {
            totalTime = 0.5,
            triggerCnt = 0,
        },
        appear2 = {
            totalTime = 2.1666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 4.8333,
            triggerCnt = 0,
        },
    },
    moling_4 = {
        skill_a = {
            totalTime = 2.3,
            events = {
                {
                    name = "soul_3_skill_a.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 1.0333,
                },
                {
                    name = "trigger",
                    time = 1.1,
                },
                {
                    name = "trigger",
                    time = 1.1333,
                },
                {
                    name = "trigger",
                    time = 1.2,
                },
                {
                    name = "trigger",
                    time = 1.3,
                },
                {
                    name = "trigger",
                    time = 1.4,
                },
                {
                    name = "trigger",
                    time = 1.4666,
                },
                {
                    name = "trigger",
                    time = 1.5666,
                },
                {
                    name = "trigger",
                    time = 1.6333,
                },
                {
                    name = "trigger",
                    time = 1.7333,
                },
            },
            triggerCnt = 10,
        },
        skill_c = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_skill_c.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4333,
                },
            },
            triggerCnt = 1,
        },
        skill_b = {
            totalTime = 1.6666,
            events = {
                {
                    name = "soul_3_skill_b.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.5,
                },
                {
                    name = "trigger",
                    time = 0.5666,
                },
                {
                    name = "trigger",
                    time = 0.6666,
                },
                {
                    name = "trigger",
                    time = 0.8,
                },
                {
                    name = "trigger",
                    time = 0.9333,
                },
                {
                    name = "trigger",
                    time = 1.0666,
                },
            },
            triggerCnt = 6,
        },
        hit = {
            totalTime = 1,
            triggerCnt = 0,
        },
        die = {
            totalTime = 1.1333,
            events = {
                {
                    name = "soul_3_die.mp3",
                    time = 0.0333,
                },
            },
            triggerCnt = 0,
        },
        attack = {
            totalTime = 1.3333,
            events = {
                {
                    name = "soul_3_attack.mp3",
                    time = 0.0333,
                },
                {
                    name = "trigger",
                    time = 0.4666,
                },
                {
                    name = "trigger",
                    time = 0.5333,
                },
                {
                    name = "trigger",
                    time = 0.6333,
                },
                {
                    name = "trigger",
                    time = 0.7666,
                },
            },
            triggerCnt = 4,
        },
        hit_high = {
            totalTime = 0.6666,
            triggerCnt = 0,
        },
        vertigo = {
            totalTime = 1.6666,
            triggerCnt = 0,
        },
        idle = {
            totalTime = 1.3333,
            triggerCnt = 0,
        },
    },
}
