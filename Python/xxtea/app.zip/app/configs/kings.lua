return {
    [1]={
        id=1,
        time=7200,
        openTime=1,
        muti=3,
    },
}
