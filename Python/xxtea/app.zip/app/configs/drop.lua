return {
    ["pvp"]={
        object="pvp",
        openObject=1023,
    },
}
