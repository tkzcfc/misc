return {
    [1]={
        id=1,
        stepNum={
            6,
        },
    },
}
