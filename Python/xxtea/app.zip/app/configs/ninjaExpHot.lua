return {
    [1]={
        seq=1,
        all=5000,
    },
    [2]={
        seq=2,
        all=5000,
    },
}
