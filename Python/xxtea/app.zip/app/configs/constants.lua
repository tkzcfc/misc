
local client = {}

if cc then -- 客户端

	client = {
		FRAME_TIME = 0.016, --每帧时间 1/60

		NORMALFONT = "fonts/HYh3gj.ttf",

		--测试配置
		SERVER_LIST = "http://%s:%s/server/list",
		-- MY_SERVER_LIST = "http://192.168.0.207:7100/server/user_chars",
		MY_SERVER_LIST = "http://%s:%s/server/user_chars",
		SEVER_PORT = 7400,
		SERVER_ID = "game1",
		SERVER_IP_LIST = {--第一个为默认地址
		    "192.168.0.207",
		    "192.168.0.240",
		    "120.92.16.46",
			"106.75.48.219",
			"203.195.235.214",
		},

		--关卡状态
		LevelStatus = {
			LOCKED = 1,--未开启
			CURRENT = 2,--已开启 未通关
			PASSED = 3,--已通关
			EXPLORE = 4,--正在挂机
		},

		--1整数，2百分比，3小数1位数值
		ArmorAttribute = {
			integers = 1,
			percentages = 2,
			decimalOne = 3,
		},

		-- 玩法id
		SourceID = {
			wanted = 4, --通缉大厅
			dungeon = 6,--地下城
			tower = 7, --秘术之塔
			hall = 12,--群英殿
			arena = 15, --比武场
			ghostStep = 16, --幻神殿
			rewardPalace = 28, --日常试炼
			notId = 999, 
		},

		--货币ID
		CurrencyName = {
			gold = 10100, --金币
			diamond = 10200, --钻石
			exp = 10300, --玩家经验
			heroExp = 10301, --英雄经验
			vip = 10302, --vip点
			talent = 10304, --天赋点
			-- crusadeCoin = 10504, --征讨令(通缉boss攻打)
			tower = 11005, -- 秘符
			achievement = 10303, -- 成就点
			soulCrash = 10305, --碎魂
			arenaGold = 10500, -- 竞技场货币
			guildGold = 10501, -- 公会货币
			activityScore = 10600, --活动积分
			stoneCrash = 10307, --魂尘
			wuhoon = 10505, --武勋
			court = 10506, --皇庭币
			worldFightScore = 10507,--争霸积分
			mysteryShopScore = 10601, --神秘商店积分
			copyShopScore = 10508, --副本商店积分
			marsMedal = 10509, --战神勋章
			trainShopScore = 10511, ---跨服战
			magicShopScore = 10603, ---镇魔
			oreShopScore = 10537, ---矿洞
			txwsScore = 10604, --天下无双
			guildTroops = 10605, --家园兵营兵力
			strength = 10700, --体力
			imprint = 10711, --秘术之印
			ration = 10807, --兵粮丸
			assaultOrder = 10808, --攻击令
			iron = 10802, --精铁
			collectionjade = 10806, --典藏玉
			yingshi = 10722, --荧石
			missionGold = 30127, -- 随机派遣货币
			guess = 10809, -- 冠军币
			refresh = 10721, --刷新令
			runeCrash = 10811,--粉尘
		},

		--次数ID
		COUNTERNAME = {
			DUNGEON = 1000001, --挑战令(副本挑战消耗)
			DUNGEONBUYCOUNT = 1000002, --副本令购买次数
			ARENA = 1000003, -- 竞技场次数
			ARENABUYCOUNT = 1000004, --竞技场购买次数
			TOWER= 1000005,--推塔次数
			TOWERBUYCOUNT = 1000006, --推塔重置次数
			BUYGOLDCOUNT = 1000007, --招财喵次数
			GUILDDONATE = 1000008, --家族捐献次数
			CHALLENGEPOINT = 1000024, --通缉大厅挑战次数
			DAILYKILLCNT = 1000025, --通缉大厅击杀次数
			DUNGEONMAXCOUNT = 2000001, --每日副本令上限
			DUNGEONMAXBUYCOUNT = 2000002, --每日副本令购买次数上限
			GUILDMAXDONATE = 2000003, --每日家族捐献次数上限
			TOWERMAXCOUNT = 2000004, --每日塔挑战次数上限
			TOWERMAXBUYCOUNT = 2000005, --每日塔挑战次数购买次数上限
			ARENAMAXCOUNT = 2000006, --每日比武场挑战次数上限
			ARENAMAXBUYCOUNT = 2000007, --每日比武场挑战次数购买次数上限
			BUYGOLDMAXCOUNT = 2000008, --每日招财喵次数上限
			BUYGOLDCRIT = 2000009, --增加招财喵购买金币暴击几率
			BUYSTRENGTH = 2000053, --增加招财喵购买体力暴击几率
			GJLOOTMAXTIMECOUNT = 2000010, --挂机时间上限
			REFRESHSHOPCOUNT = 2000011, --珍藏商城刷新次数上限
			REFRESHAUTOGAIN = 2000012, --每日挂机加速次数上限
			CHALLENGEMAXPOINT = 2000026, --通缉大厅挑战次数上限
			DAILYKILLMAXCNT = 2000027, --通缉大厅可击杀次数上限
		},

		--属性类型 1整数，2百分比，3小数1位数值
		ValueType = {
			integer = 1,
			percentage = 2,
			pointOne = 3, 
		},

		--装备tips操作Index
		EquipTipsBtn = {
			unload = 1, -- 卸下
			strengthen = 2, -- 强化
			replace = 3, -- 替换
			equipment = 4, -- 装备
			lock = 5, -- 锁定
			enter = 6, -- 放入
		},

		--loading之后干嘛
		AfterLoading = {
			outsideScene = "OutsideScene", --（正常逻辑）打开城外界面
			mainScene = "MainScene", --正常回主城
			loginScene = "LoginScene", --登录界面
			ghostStepScene = "GhostStepScene", --幻神殿界面
			gameScene = "GameScene", --战斗场景
			landScene = "LandScene", --领地争夺
			worldFightScene = "WorldFightScene", --忍界大战
			worldBossScene = "WorldBossScene", --忍阶主宰
			kingFightScene = "KingFightScene", --国王争夺
			loginLoadingScene = "LoginLoadingScene", --登陆场景
			valleyScene = "ValleyScene", --万字谷
			mineHoleScene = "MineHoleScene", --矿洞
			TxwsPlusScene = "TxwsPlusScene",--天下无双
			guildHomeScene = "GuildHomeScene", --家园场景
			mineWarScene = "MineWarScene", --矿战
			runePlayScene = "RunePlayScene", --符文圣地
		},

		--背包道具使用状态
		BagUseType = {
			use = "use",
			synthesis = "synthesis",
			skinUse = "skinUse",
		},

		TipsType = {
		    goods = 1,--物品
		    skill = 2,--技能
		    mars = 3, --战神意志
		    miner = 4, --矿工
		    rune = 5, --符文
		    buff = 6, --buff
		    gem = 7, --宝石
		    title = 8, -- 称号
		},

		ITEM_COLOR = { --道具品质颜色
			[1] = cc.c3b(255,255,255),
			[2] = cc.c3b(55,227,20),
			[3] = cc.c3b(7,158,245),
			[4] = cc.c3b(221,64,255),
			[5] = cc.c3b(255,156,0),
			[6] = cc.c3b(255,89,89),
			[7] = cc.c3b(255,210,0),
		},

		ITEM_QUALITY_COLOR = {
			[401] = cc.c3b(98,204,235),
			[402] = cc.c3b(239,100,241), 
			[403] = cc.c3b(255,100,0), 
			[404] = cc.c3b(245,70,66),
		},

		ITEM_COLOR_16 = { --道具品质颜色16进制
			[1] = "#FFFFFF",
			[2] = "#37E314",
			[3] = "#079EF5",
			[4] = "#DD40FF",
			[5] = "#FF9C00",
			[6] = "#FF5959",
		},
		-----成就状态
		ACHV_STATUS = {
			canGet = 1,
		    working = 2,
		    noOpen = 3,
		    finished = 4,
		},

		ITEM_TOP_COLOR = 6,

		SceneNodeTag = { --scene层级
			moveLabel = 2000,
		},

		WIN_ZORDER = {
			NORMAL = 0, -- 普通
			PERMANENT = 1, -- 常驻窗口
			POPUP = 2, -- 弹出
			TOP = 3, -- 置顶
			GUIDE = 4, -- 新手
			DIALOG = 5, -- 对话
			ERROR = 6, -- 错误
		},

		RANK_ITEM_ID = {
			arena = 107,
			tower = 110,
			wanted = 108,
			land = 112,
			hallStar = 115,
		},

		GUILD_AMODE = {
			level = 1,
			apply = 2,
			deny = 3,
		},

		GUILD_RK = {
			owner  = 1,
			vice   = 2,
			member = 3,
		},

		GUIDE_STEP_TYPE = {

		    VIDEO = 1, -- 播放视频
		    DIALOGUE = 2, -- 对话
		    CLICK = 3, --玩家点击
		    CALLBACK = 4, --回调
		    CHANGE_SCENE = 5, --切换场景
		    SPEAK_ASIDE = 6, --旁白
		    TIPS_LAYER = 7, --新手tips页面
		},

		ACTIVITY_NAME = {
			Act7DayLogin = 1,
			ActFirstRecharge = 2,  ---首充活动
			ActFund = 3,  ---基金活动
			ActFundWelfare = 4, --基金福利
			ActAccumulativeRecharge = 5, --累计充值
			ActConRecharge = 6, -- 天天好礼
			ActWish = 7, --许愿阁
			ActAddGift = 8,  ---进阶礼包
			ActLimitSummon = 9, --限时召唤
			ActRoulette = 10,
			ActLevelShop = 11, -- 冲级商店
			ActCostRebate = 13, -- 消费返利
			ActLimitBuy = 14, --限购礼包
			ActRechargeBack = 15, --充值回馈
			Act3DayTarget = 16, -- 开服狂欢（3日）
			Act4DayTarget = 17, -- 开服狂欢（4日）
			ActNewServerRank = 18, -- 新服比拼
			ActLimitTreasury = 19, -- 限时宝库
			ActPointShop = 20, -- 积分商店
			ActDoubleGains = 21, -- 双倍收益
			ActSumOnline = 22, -- 在线奖励
			ActLevelGift = 23, --等级好礼
			ActTimeDrop = 24, --挂机掉落
			-- ActTimeExchange = 25, -- 限时兑换
			ActGashapon = 26, -- 扭蛋
			ActLuckyFlop = 27, --幸运翻牌
			ActAccumulativeCost = 28, --累计消费
			ActTenDiamond = 31, --十万钻石
			ActSuperPurchase = 32, --超值礼包
			ActDailyCumulativeRecharge = 33, --每日累计充值
			ActDailyRecharge = 34, --每日首充
			ActDayGift = 35, ---每日礼包
			ActWeekGift = 36, ---每周礼包
			ActWechatWin = 37, --微信福利
			ActSummonReward = 38, --召唤奖励
			ActRewardRecall = 39, -- 资源找回
			ActPhysicalStrength = 40, --召唤奖励
			ActTimeChallenge = 41,
			ActRebateShop = 42,--折扣商店
			ActSupremeRoulette = 43,--至尊轮盘
			ActFestLogin = 44,--节日登陆
			ActFestRecharge = 45,--节日累充
			ActFestPoint = 46,--圣诞雪人
			ActFestBless = 47,--元旦祈福
			ActFestSpecial = 48,--元旦祈福
			ActFestMission = 49, --新年任务
			ActHappySlots = 50, --欢乐
			ActCNYMonopoly = 51, --新年大富翁
			ActCNYYearBeast = 52, ----春节年兽 [CNY = chinese new year]
			ActFestDiShop = 53, --节日折扣 [ActFestDiShop = actFestDicountShop]
			ActCNYRedPack = 54,--春节红包雨
			ActFestGiftBuy = 55,--新春礼包
			ActFestAddReset = 56, -- 首充重置
			ActFestExchange = 57, --节日兑换
			ActFestCard = 58, -- 刮刮卡
			ActSignInReward = 59, -- 签到福利
			ActDispatchReward = 60,-- 派遣福利
			ActSignInRoulette = 61, -- 签到轮盘
			ActMysteryStore = 62, --神秘商店  资源周卡
			ActSmashEggs = 63, --砸蛋
			ActSelectGift = 64, --自选礼包
			ActLevelUpGift = 65, --飞升礼包
			-- ActFund = 9, ---基金活动
			-- ActTotalrecharge = 7, ---累计充值活动
			-- ActConRecharge = 11,   ---每日充值活动
			-- ActEveryRecharge = 12,  ---每日累计充值活动
			-- ActTotalOnline = 13,  ---累计在线活动
			-- Act7DayRank = 14,  ---七日排行活动
			-- ActLandRank = 15,  ---领地争夺排行
			-- ActLandTarget = 16,  ---领地争夺目标
			-- ActAddGift = 17,  ---进阶礼包  
			-- ActSumLogin = 18,  ---累计登陆
			-- Act7DayFund = 19,  ---七日基金 
			-- ActWish = 20, --许愿阁
			-- ActRoll = 21, --幸运轮盘
			-- ActMultiConRecharge = 22, --多重连续充值 
			-- ActCondBuy = 23, --条件限购 
			-- ActSumCost = 24, --累计消费 
			-- ActSingleRecharge = 25, --单笔充值
			-- ActDiamondParty = 26, --钻石派对
			-- ActFlashSale = 27, --限时抢购
			-- ActMysteryShop = 28, ---神秘商店
			-- ActHappySeekTreasure = 29, ---换欢乐寻宝
			-- ActLimitSummon = 30, --限时召唤
			-- ActThreeRecGiftBox = 33, --三次首冲
			-- ActFestivalLogin = 34, --节日登录
			-- ActFestivalCost = 35, --节日消费
			-- ActFestivalRecharge = 36, --节日充值
			-- ActFestivalExchange = 37, --节日兑换
			-- ActFestivalDrop = 38, --节日掉落
			-- ActNationalDayVote = 39, --国庆英雄投票
			-- ActNationalDaySignIn = 40, --国庆签到
			-- ActFestivalFlashSale = 41, --节日限时秒杀
			-- ActSkinExchange = 42, --炫彩皮肤
			-- ActVipShop = 43, --vip特权商店
			-- ActFestivalFirstRecharge = 45, ---节日首冲
			-- ActFestivalLimitBuy = 46, ----节日限购
			-- ActCNYRedPackets = 47, ----春节红包
			-- ActCNYYearBeast = 48, ----春节年兽
			-- ActMonthCard = 199, ------月卡
			-- ActWeekCard = 198, ------周卡
			-- ActLifeCard = 197,  -----终身卡
			-- ActCNYRoulette = 49, ----春节轮盘
			-- ActLoverDay = 50, ----情人节告白
			-- ActBillSale = 51, --充值礼包 (开服大礼)
			-- ActFundWelfare = 52, --基金福利
			-- ActOneYuan = 53, --一元礼包
			-- ActRollPlus = 54, --千变轮回
		},

		ACTIVITY_STAGE = {
			OPEN = 1,
			START = 2,
			END = 3,
			CLOSE = 4,
		},

		ACTIVITY_TYPE = {
			PLAYER = 1,
			OPENSERVER = 2,
		    FIXED = 3,
			MERGESERVER = 4,
		},

		GUILD_BUILD_NAME = {
			MAIN_CITY = 101,
			SHOP = 302,
		},

		FESTIVAL_ID = {
            Christmas = 1, ---圣诞节
            NewYear = 2, --元旦
            CNY = 3, ---春节
            Lantern = 4, ---元宵节
            Valentine = 5,  ----情人节
            FuNeng = 6,-- 符能
            FuNengTwo = 7, -- 符能2
            -- Moon = 1, ---中秋节
            -- Country = 2,  ---国庆节
            -- Halloween = 3, ---万圣节
            -- Eleven = 4, ---双十一
            -- Thanksgiving = 5, ---感恩节
            -- Laba = 8, ----腊八节
            -- Celebration = 9, ---神之庆典
            -- AloneDay = 13, ---韩国独立日
            -- WhiteLoverDay = 14, ---白色情人节
            -- ChunFen = 15, --春分
            -- AprilBloom = 16 , --花开四月
            -- Normal = 999, ---通用
	    },
	    
	    TIMEPLAY_STATUS = {
            Open = 1,---已开启
		    SoonClose = 2, --待关闭
		    SoonOpen = 3,---待开启
		    NotOpen = 4, ---未开启
		    Lock = 5, ---未解锁
		    Close = 6, ---未开放
	    },
		--玲珑塔类型
		RANK_TOWER_TYPE = {
			EXQUISITE_TOWER = 1,
			MOON_TOWER = 2,
		},
	    KING_PRIVILEGE = {
	    	Escort = 1,
		},

		CURRENCY_TYPE={
			CNY="￥",
			KRW="￦",
			USD="$",
			TWD="NT$",
		},
		ACT_FIRSTREDTIPS={
            [1] = 9, ----基金活动
            [2] = 199, -----月卡
	    },

	    HERO_GENDER_ICON = {
	    	[201] = "array/suiji-05.png",
	    	[202] = "array/suiji-04.png",
		},

		HERO_RARE = {
			["R"] = "public/public_frame_03.png",
			["SR"] = "public/public_frame_04.png",
			["SSR"] = "public/public_frame_05.png",
			["KKK"] = "public/public_frame_06.png",
		},

		ITEMID_TO_HEROID = 10000,--itemid到heroId的索引差值f
		
		HORCRUXID_TO_HEROID = 19000,--itemid到heroId的索引差值f

		MAIN_HERO_RANK = 5,--主英雄的最低排名

		KAMI_LEVEL_COE = 1000,--幻化神等级系数

		MAX_KAMI_AST_SKL_NUM = 4,--幻化神星盘技能个数

		MAX_APPLY_FAMILY_CNT = 5,--同一时间最多申请家族次数

		KAMI_JADE_GROUP_CNT = 3,--幻化神宝石一组的宝石个数

		KAMI_JADE_MAX_LEVEL = 10,--宝石最大等级

		DUNGEON_CHARPTER_NUM = 6,--地下城每一章节的关卡数

		DUNGEON_CHARPTER_BOX_NUM = 3,--地下城每一章节的宝箱数

		NEW_HERO_MAX_SHOW_IN_MAIN = 2,--新英雄气泡提示最大显示个数

		LINE_UP_MAX_STAR = 5,--阵容最高星级

		ADDITIONAL_TYPE = {
			onlyShow = 1,--仅用于显示
			realGet = 2,--实际获得
		},--加成物品类型

		JIAMIANYINHU_AD_ID = 7,

		----随机派遣事件-----
		REvtStatus_Create = 0,      -- // 未派遣
		REvtStatus_Start  = 1,     -- // 派遣中
		REvtStatus_Finish = 2,      -- // 完成
		REvtStatus_Taken = 3,      -- // 已领取

		REvt_HeroMaxStar = 3,  -- //英雄最高星级
		REvt_HeroTotalStar = 4,  -- //英雄最高星级


		FESTIVAL_STYLE = {
			Christmas = {startTs = "2020-1-1", endTs = "2020-1-18", style = 1},---圣诞节
			NewYear = {startTs = "2020-1-20", endTs = "2020-2-3", style = 2},---春节
		}
	}
end

-- 服务器战斗需要，客户端不能添加里边!!!
local constants = {

	GameState = {
		NONE = 0,
		ATTACK_WIN = 1,
		RUNNING = 2,
		ATTACK_LOSE = 3,
		COMPLETE = 4,
		NEXT_WAVE = 5,
	},

	UnitGroup = {
		NONE = 0,
		ATTACKER = 1,
		DEFENDER = 2,
	},

	UnitState = {
		NONE = 0,
		IDLE = 1,
		ATTACK = 2,
		DIE = 3,
		REMOVED = 4,
		REBORN = 5,
		EXTRA_ATTACK = 6,
		DEATH_ATTACK = 7,
		KAMI_APPEAR = 8,
	},

	UnitType = {
		NONE = 0,
		TRANSFROM = 1,
	},

	SkillType = {
		NORMAL = "normal", -- 普通攻击
		SPECIAL = "special", -- 小技能
		POWERMAX = "powerMax", -- 大招
		ENTERING = "entering", -- 进场释放
		PASSIVE = "passive", -- 被动
		ARTIFACTSKILL = "artifactSkill", --神器技能
	},

	UpdateHpType = {
		HEALING = 1, -- 治疗
		DAMAGE_TO_LIFE_BUFF = 2, -- 受击回血buff
		DAMAGE = 3, -- 伤害
		SHARE_DAMAGE = 4, -- 分摊伤害
		LIFE_PER_HIT = 5, -- 吸血
		SKILL = 6, -- 技能回复
		DIE = 7, -- 死亡回血
		SKILL_REDUCE = 8, -- 技能掉血
		BUFF = 9, -- buff持续治疗或伤害
		SUCK_MARKER = 10, -- 吸血标记
		BUFF_LIFE_PCT = 11, -- lifePct buff
		ATTACK_REPLY = 12, -- 攻击回复
		SPURT_DAMAGE = 13, --溅射伤害
	},

	--出征状态
	FightStatus = {
		debug = 999, -- 调试
		specialLevel = 100, --特殊关卡
		wantedOrdinary = 1, --通缉Boss（普通）
		wantedComplete = 2, --通缉Boss（2.5被攻击）
		ordinary = 3, --普通副本
		tower = 4, --秘术之塔
		dungeon = 5, --地下城
		selectHero = 6, -- 选择英雄
		arena = 7, -- 竞技场
		guildBoss = 8, --公会boss
		mineWar = 9, --矿战
		awake = 10, --觉醒
		ghostStep = 10, --幻神殿
		land = 11, --领地争夺
		huntSoul = 12, --猎魂殿
		worldFight = 13, --忍界争霸
		guildMonster = 14, --家族灵兽
		worldBoss = 15, --世界boss
		crossServer = 16, --跨服战
		kingFight = 17, --国王争夺
		devilSoulSeal = 18, --魔灵封印
		escort = 19, --魔灵押送
		escortRob = 20, --魔灵抢夺
		escortRobPre = 21, --魔灵抢夺预设阵容
		KingSwordPre = 22, --玲珑塔阵容预设
		KingSwordBoss = 23,--玲珑塔boss
		KingSwordFightOther = 24,--玲珑塔抢别人坑位
		hallFight = 25, --主宰之殿
		hallSpecialFight = 26, --主宰之殿噩梦模式
		txwsPVP = 27, 
		txwsPVE = 28, --天下无双boss
		forceLeader = 29, ---势力领袖
		phantomTower = 30, --七重塔
		ninjaHall = 31, --- 忍者大厅
		royalFight = 32, --- 皇庭争夺
		crossServerPVP = 33, --跨服战PVP
		rewardPalace = 34,--日常试炼
		familyCompetePre = 35,--家族竞争阵容预设
		familyCompeteFight = 36,--家族竞争
		towerElite = 37, --秘术之塔精英关卡
		timeChallenge = 38, -- 限时挑战战斗
		mapBoss = 39, -- 地图boss
		ninjaExp = 40, --忍界远征
		actTimeChallenge = 41, -- 限时挑战战斗
		kfbsLadder = 42, ---杯赛天梯赛
		kfbsChampion = 43, ---杯赛冠军赛
		ninjaMaster = 44, ---忍术大师
		patrol = 45, ---领地巡逻
		plotStep = 46, ---符能地穴
		plotBoss = 47, ---符能BOSS
		runePlay = 48, --符文圣地
		ninjaLegend = 49 -- 忍界传说
	},

	ITEM_TOP_COLOR = 6,

	BATTLE_EVENT = {
		BATTLE_START = 10001,
		BATTLE_NEXTWAVE = 10002,
		BATTLE_UPDATEROUND = 10003,
		BATTLE_UPDATESTATE = 10004,
		BATTLE_UPDATEHP = 10005,
		BATTLE_UPDATEMP = 10006,
		BATTLE_UNITUSESKILL = 10007,
		BATTLE_KAMIUSESKILL = 10008,
		BATTLE_UNITREBORN = 10009,
	},
}

for key, value in pairs(client) do
	constants[key] = value
end

return constants
