return {
    [1]={
        id=1,
        name="跨服杯赛",
        namePng="meishuzi_kuafubeisai",
        openPng="05",
        unOpenPng="05_weikaiqi",
        openId=270,
        unOpen=0,
        reward={
            36999,33164,30744,30251,
        },
        timePlayUnlock=0,
        time={
            
        },
    },
    [2]={
        id=2,
        name="忍界主宰",
        namePng="meishuzi_renjiezhuzai",
        openPng="02",
        unOpenPng="02_weikaiqi",
        openId=49,
        unOpen=0,
        reward={
            10100,33172,33171,36113,
        },
        timePlayUnlock=60,
        time={
            "12:00-12:30/20:30-21:00","12:00-12:30/20:30-21:00","12:00-12:30/20:30-21:00","12:00-12:30/20:30-21:00","12:00-12:30/20:30-21:00","12:00-12:30/20:30-21:00","12:00-12:30/20:30-21:00",
        },
    },
    [3]={
        id=3,
        name="忍界远征",
        namePng="meishuzi_renjieyuanzhen",
        openPng="01",
        unOpenPng="01_weikaiqi",
        openId=260,
        unOpen=0,
        reward={
            
        },
        timePlayUnlock=0,
        time={
            
        },
    },
    [4]={
        id=4,
        name="暂未开放",
        namePng="meishuzi_shenmiwanfa",
        openPng="04",
        unOpenPng="04_weikaiqi",
        openId=0,
        unOpen=1,
        reward={
            
        },
        timePlayUnlock=0,
        time={
            
        },
    },
}
