return {
    [1001]={
        id=1001,
        stageType=4,
        group=2002,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1002]={
        id=1002,
        stageType=4,
        group=2002,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2001]={
        id=2001,
        stageType=4,
        group=2002,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2002]={
        id=2002,
        stageType=4,
        group=2002,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1003]={
        id=1003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1004]={
        id=1004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1005]={
        id=1005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1006]={
        id=1006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1008]={
        id=1008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1009]={
        id=1009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1011]={
        id=1011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1012]={
        id=1012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1014]={
        id=1014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [1015]={
        id=1015,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2003]={
        id=2003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2004]={
        id=2004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2005]={
        id=2005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2008]={
        id=2008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2009]={
        id=2009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2010]={
        id=2010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2011]={
        id=2011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2012]={
        id=2012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2013]={
        id=2013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [2014]={
        id=2014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3001]={
        id=3001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3002]={
        id=3002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3003]={
        id=3003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3004]={
        id=3004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3005]={
        id=3005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3006]={
        id=3006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3007]={
        id=3007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3008]={
        id=3008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3009]={
        id=3009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3010]={
        id=3010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3011]={
        id=3011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3012]={
        id=3012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3013]={
        id=3013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3014]={
        id=3014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [3015]={
        id=3015,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4003]={
        id=4003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4004]={
        id=4004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4005]={
        id=4005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4006]={
        id=4006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4007]={
        id=4007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4008]={
        id=4008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4009]={
        id=4009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4010]={
        id=4010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4011]={
        id=4011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4012]={
        id=4012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4013]={
        id=4013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [4014]={
        id=4014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5001]={
        id=5001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5002]={
        id=5002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5003]={
        id=5003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5004]={
        id=5004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5005]={
        id=5005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5006]={
        id=5006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5007]={
        id=5007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5008]={
        id=5008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5009]={
        id=5009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5010]={
        id=5010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5011]={
        id=5011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5012]={
        id=5012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [5013]={
        id=5013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6002]={
        id=6002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6003]={
        id=6003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6004]={
        id=6004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6005]={
        id=6005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6006]={
        id=6006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6007]={
        id=6007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6008]={
        id=6008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6009]={
        id=6009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6010]={
        id=6010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6011]={
        id=6011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6012]={
        id=6012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6013]={
        id=6013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [6014]={
        id=6014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7002]={
        id=7002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7003]={
        id=7003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7004]={
        id=7004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7005]={
        id=7005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7006]={
        id=7006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7007]={
        id=7007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7008]={
        id=7008,
        stageType=2,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7009]={
        id=7009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7010]={
        id=7010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7011]={
        id=7011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [7012]={
        id=7012,
        stageType=6,
        group=0,
        noNumlang={
            "花非花，雾非雾，镜花水月虽是虚幻，却让人向往！","这片符文圣地总是对那些充满耐心的人们报以善意","眼见不一定为实，因为还有一些眼睛看不见的宝藏。",
        },
        lockNum=3,
        Numlang={
            "符文圣地某个地块点，埋葬着忍界的宝藏，几百年了，它还在等待发现它的那个人","神社是这片圣地最神圣的地方，也是最安全的地方",
        },
    },
    [7013]={
        id=7013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8001]={
        id=8001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8002]={
        id=8002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8003]={
        id=8003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8004]={
        id=8004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8005]={
        id=8005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8006]={
        id=8006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8007]={
        id=8007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8008]={
        id=8008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8009]={
        id=8009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8010]={
        id=8010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8011]={
        id=8011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8012]={
        id=8012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8013]={
        id=8013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [8014]={
        id=8014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9001]={
        id=9001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9002]={
        id=9002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9003]={
        id=9003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9004]={
        id=9004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9005]={
        id=9005,
        stageType=6,
        group=0,
        noNumlang={
            "花非花，雾非雾，镜花水月虽是虚幻，却让人向往！","这片符文圣地总是对那些充满耐心的人们报以善意","眼见不一定为实，因为还有一些眼睛看不见的宝藏。",
        },
        lockNum=3,
        Numlang={
            "符文圣地某个地块点，埋葬着忍界的宝藏，几百年了，它还在等待发现它的那个人","神社周围是这片圣地最神圣的地方，也是最安全的地方",
        },
    },
    [9006]={
        id=9006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9007]={
        id=9007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9008]={
        id=9008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9009]={
        id=9009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9010]={
        id=9010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9011]={
        id=9011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9012]={
        id=9012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [9013]={
        id=9013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10001]={
        id=10001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10002]={
        id=10002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10003]={
        id=10003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10004]={
        id=10004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10005]={
        id=10005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10006]={
        id=10006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10007]={
        id=10007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10008]={
        id=10008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10009]={
        id=10009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10010]={
        id=10010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10011]={
        id=10011,
        stageType=5,
        group=11012,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10012]={
        id=10012,
        stageType=5,
        group=11012,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11011]={
        id=11011,
        stageType=5,
        group=11012,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11012]={
        id=11012,
        stageType=5,
        group=11012,
        noNumlang={
            "我的神力和魔物的数量息息相关，魔物越少，我的神力就越强","年轻人啊，若你能帮助我恢复神力，这片圣地必定会赐予你回报","神像的话语，你铭记于心了吗？",
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10013]={
        id=10013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [10014]={
        id=10014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11002]={
        id=11002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11003]={
        id=11003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11004]={
        id=11004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11005]={
        id=11005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11006]={
        id=11006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11007]={
        id=11007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11008]={
        id=11008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11009]={
        id=11009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11010]={
        id=11010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11013]={
        id=11013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11014]={
        id=11014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [11015]={
        id=11015,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12001]={
        id=12001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12002]={
        id=12002,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12003]={
        id=12003,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12004]={
        id=12004,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12005]={
        id=12005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12006]={
        id=12006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12007]={
        id=12007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12008]={
        id=12008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12009]={
        id=12009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12010]={
        id=12010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12011]={
        id=12011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12012]={
        id=12012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [12013]={
        id=12013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13001]={
        id=13001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13002]={
        id=13002,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13003]={
        id=13003,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13004]={
        id=13004,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14002]={
        id=14002,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14003]={
        id=14003,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14004]={
        id=14004,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15002]={
        id=15002,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15003]={
        id=15003,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15004]={
        id=15004,
        stageType=4,
        group=13004,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13005]={
        id=13005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13006]={
        id=13006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13007]={
        id=13007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13008]={
        id=13008,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13009]={
        id=13009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13010]={
        id=13010,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13011]={
        id=13011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13012]={
        id=13012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13013]={
        id=13013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [13014]={
        id=13014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14001]={
        id=14001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14005]={
        id=14005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14006]={
        id=14006,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14007]={
        id=14007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14009]={
        id=14009,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14011]={
        id=14011,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14012]={
        id=14012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14013]={
        id=14013,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14014]={
        id=14014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [14015]={
        id=14015,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15001]={
        id=15001,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15005]={
        id=15005,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15007]={
        id=15007,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15012]={
        id=15012,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
    [15014]={
        id=15014,
        stageType=0,
        group=0,
        noNumlang={
            
        },
        lockNum=0,
        Numlang={
            
        },
    },
}
