return {
  version = "1.1",
  luaversion = "5.1",
  tiledversion = "0.14.2",
  orientation = "isometric",
  renderorder = "right-down",
  width = 14,
  height = 14,
  tilewidth = 264,
  tileheight = 120,
  nextobjectid = 1,
  properties = {},
  tilesets = {
    {
      name = "zhuangshi01",
      firstgid = 1,
      tilewidth = 138,
      tileheight = 156,
      spacing = 0,
      margin = 0,
      image = "../../../res/awakeMap/awakeMap/zhuangshi01.png",
      imagewidth = 138,
      imageheight = 156,
      tileoffset = {
        x = 60,
        y = 33
      },
      properties = {
        ["id"] = "2001"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "zhuangshi02",
      firstgid = 2,
      tilewidth = 140,
      tileheight = 102,
      spacing = 0,
      margin = 0,
      image = "../../../res/awakeMap/awakeMap/zhuangshi02.png",
      imagewidth = 140,
      imageheight = 102,
      tileoffset = {
        x = 48,
        y = -15
      },
      properties = {
        ["id"] = "2002"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "dikuai01",
      firstgid = 3,
      tilewidth = 265,
      tileheight = 181,
      spacing = 0,
      margin = 0,
      image = "../../../res/awakeMap/awakeMap/dikuai01.png",
      imagewidth = 265,
      imageheight = 181,
      tileoffset = {
        x = 0,
        y = 60
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "dikuai02",
      firstgid = 4,
      tilewidth = 275,
      tileheight = 193,
      spacing = 0,
      margin = 0,
      image = "../../../res/awakeMap/awakeMap/dikuai02.png",
      imagewidth = 275,
      imageheight = 193,
      tileoffset = {
        x = -9,
        y = 73
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "dikuai03",
      firstgid = 5,
      tilewidth = 265,
      tileheight = 211,
      spacing = 0,
      margin = 0,
      image = "../../../res/awakeMap/awakeMap/dikuai03.png",
      imagewidth = 265,
      imageheight = 211,
      tileoffset = {
        x = 0,
        y = 91
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "qidian",
      firstgid = 6,
      tilewidth = 161,
      tileheight = 73,
      spacing = 0,
      margin = 0,
      image = "../../../res/awakeMap/awakeMap/qidian.png",
      imagewidth = 161,
      imageheight = 73,
      tileoffset = {
        x = 50,
        y = -23
      },
      properties = {
        ["id"] = "3001"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "floor",
      x = 0,
      y = 0,
      width = 14,
      height = 14,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0,
        0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 2, 0, 1, 0, 2, 0, 0, 1, 0, 0, 0,
        0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 2, 0, 0,
        0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0,
        0, 2, 0, 0, 2, 0, 0, 0, 1, 0, 0, 2, 0, 0,
        0, 0, 0, 0, 0, 1, 0, 0, 2, 0, 0, 0, 1, 0,
        0, 0, 0, 2, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0,
        0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      name = "bg",
      x = 0,
      y = 0,
      width = 14,
      height = 14,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 4, 4, 4, 4, 0, 4, 4, 0, 0, 5, 0,
        0, 4, 0, 0, 0, 0, 4, 0, 0, 4, 5, 5, 5, 0,
        0, 5, 0, 0, 0, 0, 3, 0, 0, 4, 0, 0, 0, 0,
        0, 5, 5, 5, 4, 4, 3, 0, 0, 3, 0, 0, 0, 0,
        0, 5, 0, 0, 0, 0, 3, 0, 0, 3, 0, 0, 0, 0,
        0, 4, 5, 0, 0, 5, 3, 5, 5, 5, 3, 4, 4, 0,
        0, 0, 0, 0, 0, 0, 4, 0, 0, 5, 0, 0, 4, 0,
        0, 4, 4, 0, 0, 0, 3, 0, 0, 5, 0, 0, 0, 0,
        0, 4, 0, 0, 0, 0, 4, 0, 0, 5, 0, 0, 0, 0,
        0, 4, 0, 0, 0, 4, 4, 0, 0, 3, 4, 3, 4, 0,
        0, 4, 4, 4, 4, 5, 0, 0, 0, 0, 0, 0, 3, 0,
        0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      name = "cover",
      x = 0,
      y = 0,
      width = 14,
      height = 14,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {
        ["id"] = "2008"
      },
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      name = "ui",
      x = 0,
      y = 0,
      width = 14,
      height = 14,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    }
  }
}
