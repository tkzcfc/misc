return {
  version = "1.1",
  luaversion = "5.1",
  tiledversion = "0.14.2",
  orientation = "isometric",
  renderorder = "right-down",
  width = 14,
  height = 14,
  tilewidth = 264,
  tileheight = 120,
  nextobjectid = 13,
  properties = {},
  tilesets = {
    {
      name = "zhuangshi01",
      firstgid = 1,
      tilewidth = 138,
      tileheight = 156,
      spacing = 0,
      margin = 0,
      image = "幻神殿地&资源/map/zhuangshi01.png",
      imagewidth = 138,
      imageheight = 156,
      tileoffset = {
        x = 60,
        y = 33
      },
      properties = {
        ["id"] = "2001"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "zhuangshi02",
      firstgid = 2,
      tilewidth = 140,
      tileheight = 102,
      spacing = 0,
      margin = 0,
      image = "幻神殿地&资源/map/zhuangshi02.png",
      imagewidth = 140,
      imageheight = 102,
      tileoffset = {
        x = 48,
        y = -15
      },
      properties = {
        ["id"] = "2002"
      },
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "HSDdikuai01",
      firstgid = 3,
      tilewidth = 265,
      tileheight = 181,
      spacing = 0,
      margin = 0,
      image = "幻神殿地&资源/map/HSDdikuai01.png",
      imagewidth = 265,
      imageheight = 181,
      tileoffset = {
        x = 0,
        y = 102
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "HSDdikuai02",
      firstgid = 4,
      tilewidth = 275,
      tileheight = 193,
      spacing = 0,
      margin = 0,
      image = "幻神殿地&资源/map/HSDdikuai02.png",
      imagewidth = 275,
      imageheight = 193,
      tileoffset = {
        x = -9,
        y = 100
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    },
    {
      name = "HSDdikuai03",
      firstgid = 5,
      tilewidth = 265,
      tileheight = 211,
      spacing = 0,
      margin = 0,
      image = "幻神殿地&资源/map/HSDdikuai03.png",
      imagewidth = 265,
      imageheight = 211,
      tileoffset = {
        x = 0,
        y = 91
      },
      properties = {},
      terrains = {},
      tilecount = 1,
      tiles = {}
    }
  },
  layers = {
    {
      type = "tilelayer",
      name = "floor",
      x = 0,
      y = 0,
      width = 14,
      height = 14,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 2,
        0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 2, 0, 0, 2, 1, 0, 0, 0, 0,
        1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "tilelayer",
      name = "bg",
      x = 0,
      y = 0,
      width = 14,
      height = 14,
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      encoding = "lua",
      data = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 3, 5, 3, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0,
        0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 3, 0,
        0, 0, 0, 0, 0, 0, 4, 3, 3, 0, 0, 0, 5, 0,
        0, 0, 0, 0, 0, 0, 3, 0, 4, 5, 0, 0, 3, 0,
        0, 0, 0, 0, 0, 0, 5, 0, 0, 3, 0, 0, 4, 0,
        0, 0, 4, 3, 5, 4, 4, 0, 0, 4, 0, 0, 5, 3,
        0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 5, 3, 4, 0,
        0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 4, 3, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 5, 4, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        4, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      }
    },
    {
      type = "objectgroup",
      name = "level",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      properties = {},
      objects = {
        {
          id = 1,
          name = "level 01",
          type = "",
          shape = "rectangle",
          x = 148.545,
          y = 1599.45,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "1"
          }
        },
        {
          id = 2,
          name = "level 02",
          type = "",
          shape = "rectangle",
          x = 268.545,
          y = 1354.45,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "2"
          }
        },
        {
          id = 3,
          name = "level 03",
          type = "",
          shape = "rectangle",
          x = 627.455,
          y = 1231.55,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "3"
          }
        },
        {
          id = 4,
          name = "level 04",
          type = "",
          shape = "rectangle",
          x = 267.909,
          y = 991.091,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "4"
          }
        },
        {
          id = 5,
          name = "level 05",
          type = "",
          shape = "rectangle",
          x = 511.818,
          y = 753.182,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "5"
          }
        },
        {
          id = 6,
          name = "level 06",
          type = "",
          shape = "rectangle",
          x = 748.636,
          y = 636.364,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "6"
          }
        },
        {
          id = 7,
          name = "level 07",
          type = "",
          shape = "rectangle",
          x = 748.364,
          y = 270.636,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "7"
          }
        },
        {
          id = 8,
          name = "level 08",
          type = "",
          shape = "rectangle",
          x = 1112.91,
          y = 516.091,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "8"
          }
        },
        {
          id = 9,
          name = "level 09",
          type = "",
          shape = "rectangle",
          x = 1233.27,
          y = 873.727,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "9"
          }
        },
        {
          id = 10,
          name = "level 10",
          type = "",
          shape = "rectangle",
          x = 1474.09,
          y = 750.909,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "10"
          }
        },
        {
          id = 11,
          name = "level 11",
          type = "",
          shape = "rectangle",
          x = 1476.45,
          y = 390.545,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "11"
          }
        },
        {
          id = 12,
          name = "level 12",
          type = "",
          shape = "rectangle",
          x = 1355.09,
          y = 31.9091,
          width = 52.1818,
          height = 45.8182,
          rotation = 0,
          visible = true,
          properties = {
            ["order"] = "12"
          }
        }
      }
    }
  }
}
