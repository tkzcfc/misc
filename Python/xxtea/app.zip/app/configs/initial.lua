return {
    [1]={
        initialBattle=23023,
        awakeInitialBattle=12012,
        bagLimit=999,
        initialTitle=0,
    },
    [2]={
        initialBattle=0,
        awakeInitialBattle=0,
        bagLimit=0,
        initialTitle=0,
    },
}
