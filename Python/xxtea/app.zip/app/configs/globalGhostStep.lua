return {
    [1]={
        structureNum=1,
        ghostStepAtt={
        },
        vip={
            {
                vip=6,
                id=2000043,
            },
            {
                vip=12,
                id=2000043,
            },
        },
        monthCardSweep=9,
    },
}
