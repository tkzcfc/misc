
local GemModel = class("GemModel")

local gemData = {
	["seq"] = 0,
	["id"] = 0,
	["heroId"] = 0,
	["slot"] = 0,
	["locked"] = 0,
	["atkPwr"] = 0,
}

function GemModel:ctor()
	self.gems = {}
end


function GemModel:addGems(gems)
	for _,gem in pairs(gems or {}) do 
		self:addGem(gem)
	end
end

function GemModel:addGem(gem)
	local attr = clone(gemData)

	attr.seq = gem.Seq
	attr.id = gem.Id
	attr.heroId = gem.HeroId or nil
	attr.slot = gem.Slot or nil
	attr.locked = gem.Locked or nil
	attr.atkPwr = gem.AtkPwr or 0

	self.gems[gem.Seq] = attr
end

function GemModel:getGems()
	return self.gems
end

function GemModel:getGem(seq)
	return self.gems[seq]
end

function GemModel:updateGem(data)
	local gemData = self.gems[data.Seq] or {}
	gemData.heroId = data.HeroId or gemData.heroId
	gemData.slot = data.Slot or gemData.slot
	gemData.atkPwr = data.AtkPwr or gemData.atkPwr
	--gemData.locked = data.Locked or gemData.Locked
	if data.Locked == false then
		gemData.locked = false
	elseif data.Locked then
		gemData.locked = true
	end
end

function GemModel:getGemsBox(heroId) 
	local gemsBox = {}
	for _,gem in pairs(self.gems) do
		if heroId == gem.heroId then
			gemsBox[gem.slot] = gem
		end
	end
	return gemsBox
end

function GemModel:getCanEquipGems(seq)
	local gems = {}
	for k,v in pairs(self.gems) do
		if (not v.heroId) or (v.heroId == 0) then
			if v.seq ~= seq then
                table.insert(gems, v)
            end
		end
	end
	return gems
end

function GemModel:removeGem(gems)
	for _,seq in pairs(gems or {}) do
		self.gems[seq] = nil
	end
end


function GemModel:getGemAttriStrs(gemIds)
	local Helper = require "app.Helper"
    local itemConf = require "app.configs.item"
    local attributeConf = require "app.configs.attribute"
    
    local attrStrs = {}
    local attrData = {}
    local data_ = {}
    for i,id in pairs(gemIds) do
    	local itemData = itemConf[id]
    	for _,k in ipairs(itemData.basicProperty) do
    		if data_[k.id] then
    			data_[k.id] = data_[k.id] + k.val
    		else
    			data_[k.id] = k.val
    		end
    	end
    end
    for k,v in pairs(data_) do
        table.insert(attrData, {id = k, val = v})
    end
    table.sort(attrData, function(a, b)
        return a.id < b.id
    end)

    for i,v in ipairs(attrData) do
        local attr = attributeConf[v.id]
        local value = Helper.getAttriValue(v.id, v.val, true)
        table.insert(attrStrs, {name = attr.name, val = value})
    end

    return attrStrs

end

return GemModel