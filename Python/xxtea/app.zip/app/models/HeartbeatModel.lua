--HeartbeatModel.lua

local HeartbeatModel = class("HeartbeatModel")
local msgids = require "app.network.msgids"
local network = require "app.network.network"

function HeartbeatModel:ctor()
	self.serverTime = 0
	self.perTime = 0
end

function HeartbeatModel:init()
    network.tcpSend(msgids.C_TimeSync, {}, {lockScreen=false})
end

function HeartbeatModel:setServerTime(serverTime)
	self.serverTime = serverTime
	self.perTime = self.serverTime - os.time()
end

function HeartbeatModel:getServerTime()
	return self.serverTime
end

function HeartbeatModel:getTimeDifference()
	return self.perTime
end

function HeartbeatModel:getFixedTime()
	return self:getTimeDifference() + os.time()
end

return HeartbeatModel
