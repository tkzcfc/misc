------矿工---------

local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"

local MinerModel = class("MinerModel")

function MinerModel:ctor()
	self.allMines = {}
	self.sumFloor = nil
	self.dieMiner = {}
end

function MinerModel:addMiner(data)
	self.sumFloor = data.Floor or 1
	self.allMines = {}
    if data.Miners and #data.Miners > 0 then
    	for k,v in pairs(data.Miners) do
    		table.insert(self.allMines, v)
    	end
    end
end

function MinerModel:addNewMiner(data)
	if data.Miners and #data.Miners > 0 then
		for k,v in pairs(data.Miners) do
			table.insert(self.allMines, v)
		end
	end
end
--------获取同一类型的所有矿工
function MinerModel:getMiners()
	local miners_ = {}
	for i,v in pairs(self.allMines) do
		if miners_[v.Id] then
			miners_[v.Id].N = miners_[v.Id].N + 1
		else
			miners_[v.Id] = {Id = v.Id, N = 1}
		end
	end
	local miners = {}
	for k,v in pairs(miners_) do
		table.insert(miners, v)
	end
	table.sort(miners, function(a,b)
		return a.Id < b.Id
	end)
    
    return miners
end
-------获取可以遣散的矿工
function MinerModel:getCanDismissMiners(showAll)
	local miners_ = {}
	local allMines_ = {}
	for i,v in pairs(self.allMines) do
		if not v.IsBegin then
			if miners_[v.Id] then
				miners_[v.Id].N = miners_[v.Id].N + 1
				table.insert(miners_[v.Id].Seq, v.Seq)
			else
				miners_[v.Id] = {Id = v.Id, N = 1, Seq = {v.Seq}}
			end
			table.insert(allMines_, v)
		end 
	end
	local miners = {}
	for k,v in pairs(miners_) do
		table.insert(miners, v)
	end
	table.sort(miners, function(a,b)
		return a.Id < b.Id
	end)

    if showAll then
    	return allMines_
    else
    	return miners
    end
end

function MinerModel:getAllMiners()
    return self.allMines
end

function MinerModel:getHoleSumFloor()
    return self.sumFloor
end

function MinerModel:getDieMiner()
    return self.dieMiner
end

function MinerModel:removeDieMiner(seq)
	for k,v in ipairs(self.dieMiner) do
		if v.Seq == seq then
			table.remove(self.dieMiner, k)
			break
		end
	end
end

function MinerModel:setSumFloor(data)
    if data.Floor and data.Floor >= self.sumFloor then
    	self.sumFloor = data.Floor
    end
end

function MinerModel:removeMiner(data,isDie)
	for k,seq in pairs(data or {}) do
		for i,v in pairs(self.allMines) do
			if v.Seq == seq then
				table.remove(self.allMines, i)
				if isDie then
					table.insert(self.dieMiner, v)
				end
				break
			end
		end
	end
end
-----获取正在挖矿的矿工
function MinerModel:getMiningMiners(floorId)
	local miners = {}
	for k,v in pairs(self.allMines) do
		if v.IsBegin and math.floor(v.LocId/1000) == floorId then
            miners[v.LocId] = v
		end
	end
	return miners
end
-----改变矿工状态
function MinerModel:changeMinerState(data)
	if data and #data > 0 then
		for i,v in pairs(data) do
			for _,k in pairs(self.allMines) do
				if k.Seq == v.Seq then
					k.IsBegin = v.IsBegin
					k.LocId = v.LocId
					k.BeginTs = v.BeginTs
					break
				end
			end
		end
	end
	
end



return MinerModel