local msgids = require "app.network.msgids"
local network = require "app.network.network"
local Helper = require "app.Helper"
local RedTipsConfig = require "app.RedTipsConfig"
local msgPack = require "app.network.MessagePack"
local _M = {}

_M.PlayerModel = require("app.models.PlayerModel").new()
_M.HeroModel = require("app.models.HeroModel").new()
_M.ItemModel = require("app.models.ItemModel").new()
_M.ArmorModel = require("app.models.ArmorModel").new()
_M.RuneModel = require("app.models.RuneModel").new()
_M.LevelModel = require("app.models.LevelModel").new()
_M.TowerModel = require("app.models.TowerModel").new()
_M.MailModel = require("app.models.MailModel").new()
_M.MainLineModel = require("app.models.MainLineModel").new()
_M.HeartbeatModel = require("app.models.HeartbeatModel").new()
_M.RedTipsModel = require("app.views.RedTipsModel").new()
_M.RandomDispatchModel = require("app.models.RandomDispatchModel").new()
_M.GhostStepModel = require("app.models.GhostStepModel").new()
_M.MineModel = require("app.models.MineModel").new()
_M.ChatModel = require("app.models.ChatModel").new()
_M.PayModel = require("app.models.PayModel").new()
_M.ActivityModel = require("app.models.ActivityModel").new()
_M.WorldFightModel = require("app.models.WorldFightModel").new()
_M.SoulModel = require("app.models.SoulModel").new()
_M.KfbsModel = require("app.models.KfbsModel").new()
_M.EscortModel = require("app.models.EscortModel").new()
_M.ValleyModel = require("app.models.ValleyModel").new()
_M.ArtifactModel = require("app.models.ArtifactModel").new()
_M.MinerModel = require("app.models.MinerModel").new()
_M.GemModel = require("app.models.GemModel").new()
_M.KingSwordModel = require("app.models.KingSwordModel").new()
_M.HallModel = require("app.models.HallModel").new()
_M.TxwsPlusModel = require("app.models.TxwsPlusModel").new()
_M.LandWarModel = require("app.models.LandWarModel").new()
_M.DrawModel = require("app.models.DrawModel").new()
_M.LimitShopModel = require("app.models.LimitShopModel").new()
_M.SignInModel = require("app.models.SignInModel").new()
_M.RewardPalaceModel = require("app.models.RewardPalaceModel").new()
_M.ShopModel = require("app.models.ShopModel").new()
_M.MineWarModel = require("app.models.MineWarModel").new()
_M.ChaseTraitorModel = require("app.models.ChaseTraitorModel").new()
_M.ArenaModel = require("app.models.ArenaModel").new()
_M.NinjaHeartModel = require("app.models.NinjaHeartModel").new()
_M.FamilyModel = require("app.models.FamilyModel").new()
_M.PushShopModel = require("app.models.PushShopModel").new()
_M.SpeCardModel = require("app.models.SpeCardModel").new()
_M.PushGiftModel = require("app.models.PushGiftModel").new()
_M.RewardRecallModel = require("app.models.RewardRecallModel").new()
_M.NinjaExpModel = require("app.models.NinjaExpModel").new()
_M.HappyGiveModel = require("app.models.HappyGiveModel").new()
_M.NinjaMasterModel = require("app.models.NinjaMasterModel").new()
_M.SpecShopModel = require("app.models.SpecShopModel").new()
_M.RunePlayModel = require("app.models.RunePlayModel").new()
_M.PlotModel = require("app.models.PlotModel").new()
_M.NinjaLegendModel = require("app.models.NinjaLegendModel").new()

function _M.handleMsg(op, data)
	if op == msgids.GS_UserInfo then
		local wLevelData = data.WLevel
		local fieldsData = data.Fields
		_M.PlayerModel:initData({
			userId = data.UserId,
			name = data.Name,
			isChgName = not data.Misc.FreeRename,
			head = data.Head,
			hFrame = data.HFrame,
			title = data.Title or 0,
			hFStore = data.HFStore,
			headStore = data.HeadStore,
			titleStore = data.TitleStore or {},
			level =	data.Lv,
			exp = data.Exp,
			vipData = data.Vip,
			atkPwr = data.AtkPwr,
			loginIP = data.LoginIP,
			-- currency = bagData.Currency,
			counter = fieldsData.Fields,
			kami = data.GhostData,
			reinGod = data.ReinGod,
			guildId = data.GuildId,
			guildName = data.GuildName,
			guildRank = data.GuildRank,
			tutorialData = data.Tutorial,
			questData = {
				finItems = data.Quest.FinItems or {},
				finObjs = data.Quest.FinObjs or {},
				items = data.Quest.Items or {},
			},
			medal = data.Medal,
			isNew = data.IsNew,
			createTs = data.CreateTs,
			monopolyData = data.Monopoly,
			landLastRecTs = data.Misc.LandLastRecTs,
			svrOpenTs = data.Misc.SvrOpenTs,
			guildLeaveTs = data.Misc.GuildLeaveTs,
			guildLeaveCnt = data.Misc.GuildLeaveCnt,
			guildFirstJoinReward = data.Misc.GuildFirstJoinReward,
			mergeTs = data.Misc.SvrMergeTs,
			mergeCnt = data.Misc.SvrMergeCnt or 0,
			comment = data.Misc.Comment,
			questionTake = data.Misc.QuestionTake or {},
			forLoading = data.ForLoading,
			fetter = data.Fetter.Data,
			glory = data.Glory,
			cjg = data.Cjg,
			batGrp = data.BatGrp,
			ghostJadeData = data.GhostJadeData,
			guildLeaveTs = data.GuildPlrData.LeaveTs,
			guildLeaveCnt = data.GuildPlrData.LeaveCnt,
		})
		_M.LevelModel:addLevels(wLevelData.PLevels)
		_M.LevelModel:setExploreLevel(wLevelData.GJLv)
		_M.LevelModel:setExploreStartTs(wLevelData.GJTs, wLevelData.GJGTs, wLevelData.GJSTs)
		_M.LevelModel:addGJHeroIds(wLevelData.GJHero)
		_M.LevelModel:setBossReward(wLevelData.BossRwds)
		_M.LevelModel:addDungeonBoxIds(wLevelData.DgBox)
		_M.LevelModel:initMapBossData(wLevelData.CBoss)
		_M.RuneModel:setRuneBroken(data.RuneBroken)
		_M.ChatModel:addCacheLampMessag(data.LampCached)

		for _, dLevelData in pairs(wLevelData.DLevels) do
			_M.LevelModel:addDungeonLevel(dLevelData)
		end
		_M.LevelModel:setExploreReward(wLevelData.ERwdId)

		_M.TowerModel:initInfo(data.Tower)
		_M.MailModel:initMailList(data.Mails)
		_M.ArtifactModel:addArtifacts(data.Artifact.Arts)
		_M.RedTipsModel:initFreshTips()

		_M.PlayerModel:initOpenData(_M.LevelModel.levels)
		RedTipsConfig.new()
		_M.RedTipsModel:getLocalRed()

		_M.RandomDispatchModel:initRandomDispatchList(data.Data)
		_M.HappyGiveModel:initGiveList(data.Data)
		_M.MineModel:updateMine(data.RandMine)
		_M.ChatModel:initHistroyMsg(data.ChatHistroy)
		_M.EscortModel:setMaxFreeCnt()
		_M.RewardPalaceModel:initData(data.OfferToken or {})
		
		_M.NinjaHeartModel:initData(data.Rzzx)
		_M.FamilyModel:initData({GuildId = data.GuildId, GuildName = data.GuildName, GuildRank = data.GuildRank})
		_M.FamilyModel:initPlrData(data.GuildPlrData or {})
		network.tcpSend(msgids.C_SpeCardInfo)
		network.tcpSend(msgids.C_PushGiftGetInfo)
		network.tcpSend(msgids.C_MissionInfo)
		network.tcpSend(msgids.C_HappyGiveInfo)
		network.tcpSend(msgids.C_SpecialShopInfo) -- 独立商店
	elseif op == msgids.GS_UserBagInfo then
		local bagData = data.Bag
		_M.PlayerModel:initCurrency({currency=bagData.Currency})
		_M.ItemModel:addItems(bagData.Items)
		_M.RuneModel:addRunes(bagData.Runes)
		_M.ArmorModel:addArmors(bagData.Armors)
		_M.SoulModel:addSouls(bagData.Souls)
		_M.GemModel:addGems(bagData.Gems)
	    _M.HeroModel:addHeros(bagData.Heroes, _M.ArmorModel:getArmors(), _M.SoulModel:getSouls(), _M.GemModel:getGems())
	elseif op == msgids.GS_UserAchvInfo then
		_M.MainLineModel:initData({
			nowCpt = data.MainObj.CptId,
			finishTask = data.MainObj.TaskId,
			achvData = {
				finItems = data.Achv.FinItems or {},
				finObjs = data.Achv.FinObjs or {},
				Objs = data.Achv.Objs or {},
			}
		})
	elseif op == msgids.GS_PlayerUpdate_Lv then --解锁地块
		local oldLevel = _M.PlayerModel:getInfo().level
		_M.MineModel:checkLevelUp(oldLevel,data.Level)
		_M.PlayerModel:updateLevel({level = data.Level, exp = data.Exp})
		_M.LevelModel:updatePlayerLevel(oldLevel, data.Level)
		_M.RedTipsModel:refreshMainLine()
		_M.RunePlayModel:refreshOpenInfo()
		local SDKController = require "app.sdk.SDKController"
		if SDKController.getSDKHelper() and oldLevel ~= data.Level then
			SDKController.getSDKHelper():submitData(SDKController.LEVEL_UP_TAG)
		end
	elseif op == msgids.GS_BagUpdate then
		if data.Heroes then --英雄
			_M.HeroModel:addHeros(data.Heroes)
			_M.RedTipsModel:addNewHeros(data.Heroes)
		    for _,info in ipairs(data.Heroes or {}) do
			    _M.HeroModel:updateLineUpHero(info.Id)
		    end
		end
		if data.Items then --道具
			_M.RedTipsModel:addNewItem(data.Items)
			_M.ItemModel:addItems(data.Items)
			_M.RedTipsModel:checkHeroSprite(data.Items)
			_M.RedTipsModel:refreshCanCallHero()
		end
		if data.Currency then --货币
			_M.PlayerModel:updateCurrency(data.Currency)
			_M.RedTipsModel:refreshVipTips()
		end
		if data.Armors then --装备
			_M.ArmorModel:addArmors(data.Armors)
			_M.RedTipsModel:addNewItem(data.Armors)
		end
		if data.ArmorsDel then --??
			_M.ArmorModel:removeArmors(data.ArmorsDel)
			_M.RedTipsModel:delArmors(data.ArmorsDel)
		end
		if data.Souls then
			_M.SoulModel:addSouls(data.Souls)
			_M.RedTipsModel:addNewSouls(data.Souls)
		end
		if data.SoulsDel then
			_M.SoulModel:removeSoul(data.SoulsDel)
			_M.RedTipsModel:delSouls(data.SoulsDel)
		end
		if data.Runes then
			_M.RuneModel:addRunes(data.Runes)
			--_M.RedTipsModel:addNewItem(data.Runes)
		end
		if data.RunesDel then
			_M.RuneModel:removeRunes(data.RunesDel)
			--_M.RedTipsModel:delRunes(data.RunesDel)
		end
	    if data.Gems then ----宝石---
			_M.GemModel:addGems(data.Gems)
		end
		if data.GemsDel then
			_M.GemModel:removeGem(data.GemsDel)
		end
		
		if data.Items or data.Currency then
			_M.RedTipsModel:refreshKamiTips()
		end

		_M.RedTipsModel:refreshHeroTips()
		-- _M.RedTipsModel:refreshArtifactRedTips()
	elseif op == msgids.GS_WLevelFightNormal_R then
		if data.LevelId then
			_M.LevelModel:addLevel(data.LevelId,true)
			_M.PlayerModel:updateOpenData(data.LevelId)
			_M.LevelModel:refreshStepNum()
		end
	elseif op == msgids.GS_FetterActive_R then
        _M.PlayerModel:updateFetter(data.Data)
    elseif op == msgids.GS_FetterReset then
    	_M.PlayerModel:updateFetters(data.Data)
	elseif op == msgids.GS_TowerActivityFloor_R then
		if data.ActFloor then
			_M.TowerModel:updateActFloor(data.ActFloor)
		end
	elseif op == msgids.GS_TowerChallenge_R then
		if data.CurFloor then
			_M.TowerModel:updateCurFloor(data.CurFloor)
		end
		_M.RedTipsModel:refreshTowerRedTips()
	elseif op == msgids.GS_TowerTakeRewards_R  then
		_M.TowerModel:onTakeReward(data)
		_M.RedTipsModel:refreshTowerRedTips()
	elseif op == msgids.GS_TowerEliteChallenge_R then
		_M.TowerModel:onFightTowerElite(data)
		_M.RedTipsModel:refreshTowerRedTips()
	elseif op == msgids.GS_TowerSweepOneKey_R 
		or op == msgids.GS_TowerEliteSweep_R then
		_M.RedTipsModel:refreshTowerRedTips()
	elseif op == msgids.GS_HeroUpdate then
		_M.HeroModel:updateHero(data.Hero)
		_M.RedTipsModel:refreshHeroTips()
	elseif op == msgids.GS_HeroUpdateExp then
		_M.HeroModel:updateHeroExp(data)
	elseif op == msgids.GS_HerosInfo_R then
		for _, hero in pairs(data.Heros or {}) do
			_M.HeroModel:updateHero(hero)
		end
	elseif op == msgids.GS_ArmorUpdate_Lv then --装备升级
		_M.ArmorModel:updateLevel({
			seq = data.Seq,
			level = data.Lv,
		})
	elseif op == msgids.GS_ArmorUpdate_Smt_Lv then --精炼等级
		_M.ArmorModel:updateSmeltLevel({
			seq = data.Seq,
			smtLv = data.SmtLv,
		})
	elseif op == msgids.GS_ArmorUpdate_Star then
		_M.ArmorModel:updateStarLevel({
			seq = data.Seq,
			star = data.Star,
		})
	elseif op == msgids.GS_ArmorUpdate_RProps then --装备随机属性刷新
		_M.ArmorModel:updateRProps({
			seq = data.Seq,
			RProps = data.RProps
		})
	elseif op == msgids.GS_ArmorUpdate_AtkPower then
		_M.ArmorModel:updateAtkPower({
			seq = data.Seq,
			atkPwr = data.AtkPwr,
		})
	elseif op == msgids.GS_SummonSoulInfo_R then  --- 护灵阵信息
        _M.SoulModel:soulAltarInfo(data.Data)
    elseif op == msgids.GS_SoulBlock_Unlock then  --- 护灵解锁格子
    	_M.SoulModel:soulAltarInfo(data)
	elseif op == msgids.GS_SoulUpdate_HeroId then  ---护灵穿戴---
        _M.SoulModel:updateHeroId({
        	seq = data.Seq,
        	heroId = data.HeroId,
        	slot = data.Slot,
        })
	elseif op == msgids.GS_ArmorUpdate_HeroId then --英雄穿戴(卸下)装备推送
		local heroId = _M.ArmorModel:getArmor(data.Seq).heroId
		_M.ArmorModel:updateHeroId({
			seq = data.Seq,
			heroId = data.HeroId
		})
		if data.HeroId == 0 then --卸下装备
			_M.HeroModel:unloadHeroArmor(_M.ArmorModel:getArmor(data.Seq),heroId)
		else
			_M.HeroModel:wearHeroArmor(_M.ArmorModel:getArmor(data.Seq))
			_M.RedTipsModel:updateNewArmorByID(data.Seq)
			_M.RedTipsModel:refreshNewItemTips()
		end
	elseif op == msgids.GS_ArmorUpdate_Locked then --更新装备枷锁状态
		_M.ArmorModel:updateLocked({
			seq = data.Seq,
			locked = data.Locked
		})
	elseif op == msgids.GS_WLevelUnlockDungeon_R then--激活地下城关卡
		if data.DgId then
			_M.LevelModel:addDungeonLevel({DgId = data.DgId, St = 1})
		end
	elseif op == msgids.GS_MailNew then--新邮件
		_M.MailModel:addNewMail(data.M)
		_M.RedTipsModel:refreshMailTips()
	elseif op == msgids.GS_MailNewGS_MailDel then--推送删除邮件
		_M.MailModel:deleteMails(data.Ids)
		_M.RedTipsModel:refreshMailTips()
	elseif op == msgids.GS_MailDel_R then--手动删除邮件
		_M.MailModel:deleteMails({data.Id})
		_M.RedTipsModel:refreshMailTips()
	elseif op == msgids.GS_MailRead_R then--读邮件
		_M.MailModel:updateReadMail(data)
		_M.RedTipsModel:refreshMailTips()
	elseif op == msgids.GS_MailTakeAttachment_R then--取附件
		_M.MailModel:updateTakeMail(data)
		_M.RedTipsModel:refreshMailTips()
	elseif op == msgids.GS_MailTakeAttachmentAll_R then
		_M.MailModel:updateTakeAllMail(data)
	elseif op == msgids.GS_GhostActivateJm_R then --幻化神激活经脉
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_GhostUpdate then --幻化神升级
		_M.PlayerModel:updateKami(data.Gst)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_GhostTakeReward_R then --幻神升级奖励领取
		_M.PlayerModel:updateKamiRewardTaken(data.Id)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_AchvValueChanged then --进度变化
		_M.MainLineModel:achvValueChanged(data)
		-- _M.RedTipsModel:refreshMainLine()
		-- _M.RedTipsModel:refreshAchievement()
	elseif op == msgids.GS_AchvObjectiveCompleted then --目标完成
		_M.MainLineModel:achvObjectiveCompleted(data)
		_M.RedTipsModel:refreshMainLine()
		_M.RedTipsModel:refreshAchievement()
	elseif op == msgids.GS_AchvItemCompleted then --成就项完成
		_M.MainLineModel:achvItemCompleted(data)
		_M.RedTipsModel:refreshMainLine()
		_M.RedTipsModel:refreshAchievement()
	elseif op == msgids.GS_AchvTakeReward_R then --领取成就奖励
		_M.MainLineModel:achvItemCompletedOver(data)
		_M.RedTipsModel:refreshAchievement()
	elseif op == msgids.GS_QuestValueChanged then --进度变化
		_M.PlayerModel:questValueChanged(data)
		_M.RedTipsModel:refreshQuestTips()
	elseif op == msgids.GS_QuestObjectiveCompleted then --目标完成
		_M.PlayerModel:questObjectiveCompleted(data)
		_M.RedTipsModel:refreshQuestTips()
	elseif op == msgids.GS_QuestItemCompleted then --日常项完成
		_M.PlayerModel:questItemCompleted(data)
		_M.RedTipsModel:refreshQuestTips()
	elseif op == msgids.GS_PlayerMedalUpdate then--更新勋章
		_M.PlayerModel:updateMedal({data.Medal})
	elseif op == msgids.GS_PlayerGloryNew then--获得新徽记
		_M.PlayerModel:addNewGlory(data.Id)
	elseif op == msgids.GS_PlayerHFrameNew then--新头像框解锁
		_M.PlayerModel:addNewHFrame(data.Id)
	elseif op == msgids.GS_PlayerHeadNew then
		_M.PlayerModel:addNewHead(data.Id)
	elseif op == msgids.GS_PlayerTitleNew then
		_M.PlayerModel:addNewHeadTitle(data.Id)
	elseif op == msgids.GS_PlayerTitleDel then
		_M.PlayerModel:delHeadTitle(data.Id)
	elseif op == msgids.GS_TimeSync_R then--心跳返回的时间
		_M.HeartbeatModel:setServerTime(data.Ts)
	elseif op == msgids.GS_PlayerChangeName_R then--更改名字
		_M.PlayerModel:updateName(data.Name)
	elseif op == msgids.GS_PlayerChangeHead_R then--更改头像
		_M.PlayerModel:updateHead(data.Id)
	elseif op == msgids.GS_PlayerChangeHFrame_R then--更改头像框
		_M.PlayerModel:updateHFrame(data.Id)
	elseif op == msgids.GS_PlayerChangeTitle_R or op == msgids.GS_PlayerTitleUse then--更改称号
		_M.PlayerModel:updateTitle(data.Id)
	elseif op == msgids.GS_PlayerUpdate_AtkPower then --玩家战斗力变更
		local perAtk = _M.PlayerModel.info.atkPwr
		local atk = data.AtkPwr
		_M.PlayerModel:updateAtkPower(atk)
		if atk > perAtk then --需要播放战斗力增加的动画
			Helper.playAtkAnimation()
		end
	elseif op == msgids.GS_RankGetNo1_R then--排行榜 榜首信息
		_M.LevelModel:updateBuildingRankData(data.Data)
	elseif op == msgids.GS_WLevelFightDungeon_R then--地下城挑战胜利
		if data.DgId then
			_M.LevelModel:addDungeonLevel({DgId = data.DgId, St = data.Result})
		end
	-- elseif op == msgids.GS_Guild_Join then --公会信息（拉取公会信息改变数据）
	-- 	_M.PlayerModel:updateGuildInfo(data)
	-- 	_M.GuildModel:guildJoin(data)
	-- elseif op == msgids.GS_Guild_Leave then --离开公会
	-- 	_M.PlayerModel:guildLeave(data)
	-- 	_M.GuildModel:guildLeave(data)
	-- elseif op == msgids.GS_Guild_Rank then --成员职位变更
	-- 	_M.PlayerModel:updateGuildRank(data)
	-- 	_M.GuildModel:updateRank(data)
	elseif op == msgids.GS_GuildAchvData_R then --拉取公会成就
		_M.PlayerModel:initGuildAchvData(data)
	-- elseif op == msgids.GS_GuildChangeName_R then --更新公会名字
	-- 	_M.PlayerModel:changeGuildName(data.Name)
	-- 	_M.GuildModel:changeName(data)
	-- elseif op == msgids.GS_Guild_AchvItemCompleted then --更新公会成就数据
	-- 	_M.PlayerModel:addGuildAchvData(data)
	-- elseif op == msgids.GS_GuildDonate_R then
	-- 	_M.GuildModel:updateMyDonation(data.Donation)
	elseif op == msgids.GS_VipUpdate then --vip数据发生改变
		_M.PlayerModel:updateVipData(data)
		_M.RedTipsModel:refreshVipTips()
	elseif op == msgids.GS_VipTakeGift_R then
		_M.PlayerModel:onTakeVipGift(data)
		_M.RedTipsModel:refreshVipTips()
	elseif op == msgids.GS_MainObjFinishTask_R then --主线任务完成
		_M.MainLineModel:updateFinishTask(data.Data.TaskId)
		_M.RedTipsModel:refreshMainLine()
	elseif op == msgids.GS_MainObjIdUp_R then --主线章节完成
		_M.MainLineModel:updateNowCpt(data.Data.CptId)
		_M.MainLineModel:updateFinishTask(data.Data.TaskId)
		_M.RedTipsModel:refreshMainLine()
	elseif op == msgids.GS_FieldUpdate then
		_M.PlayerModel:updateFiled(data)
	-- elseif op == msgids.GS_GuildInfoFull_R then --公会信息
	-- 	_M.GuildModel:initData(data)
	-- elseif op == msgids.GS_Guild_Lv then --公会经验变化
	-- 	_M.GuildModel:updateLevel(data)
	-- elseif op == msgids.GS_GuildChangeSetting_R then
	-- 	_M.GuildModel:changeSetting(data)
	-- elseif op == msgids.GS_GuildBossUnlock then --boss解锁
	-- 	_M.GuildModel:bossUnlock(data)
	-- elseif op == msgids.GS_GuildBossDonate then --boss捐献
	-- 	_M.GuildModel:bossDonate(data)
	-- elseif op == msgids.GS_GuildBossActAtk then --boss可攻打
	-- 	_M.GuildModel:bossActAtk(data)
	-- elseif op == msgids.GS_GuildBossFight then --boss挑战
	-- 	_M.GuildModel:bossFight(data)
	-- elseif op == msgids.GS_GuildBossDead then --boss死亡
	-- 	_M.GuildModel:bossDead(data)
	-- elseif op == msgids.GS_GuildBossRelive then --boss复活
	-- 	_M.GuildModel:bossRelive(data)
	-- elseif op == msgids.GS_GuildMonsterGldInpire then
	-- 	_M.GuildModel:updateGuildInpire(data)
	-- 	_M.RedTipsModel:refreshGuildTips()
	-- elseif op == msgids.GS_GuildMonsterGldDmg then
	-- 	_M.GuildModel:updateGuildMonsterDmg(data)
	-- elseif op == msgids.GS_GuildMonsterInfo_R then
	-- 	_M.GuildModel:initMonsterInfo(data.Data)
	-- elseif op == msgids.GS_GuildMonsterPlrInspire_R then
	-- 	_M.GuildModel:updatePlayerInpire(data)
	-- 	_M.RedTipsModel:refreshGuildTips()
	elseif op == msgids.GS_MissionInfo_R or op == msgids.GS_MissionRefresh_R then --新的随机派遣
		_M.RandomDispatchModel:initRandomDispatchList(data.Data)
	elseif op == msgids.GS_MissionTake_R or op == msgids.GS_MissionAccelerate_R then
		_M.RandomDispatchModel:dispatchTaken(data.Id)
	elseif op == msgids.GS_MissionCancel_R then
		_M.RandomDispatchModel:dispatchGiveUp(data.Id)
	elseif op == msgids.GS_MissionExecute_R or op == msgids.GS_MissionAdd_R then
		_M.RandomDispatchModel:addNewDispatch(data)
	elseif op == msgids.GS_MissionLock_R or op == msgids.GS_MissionUnLock_R then
		_M.RandomDispatchModel:updateDispatchLock(data)
	elseif op == msgids.GS_MissionExpAdd then
		_M.RandomDispatchModel:updateMissionExp(data)
	elseif op == msgids.GS_HappyGiveInfo_R then ----============欢乐送=======----
		_M.HappyGiveModel:initGiveList(data.Data)
	elseif op == msgids.GS_HappyGiveDrw_R or op == msgids.GS_HappyGiveRefresh_R or op == msgids.GS_HappyGiveRefreshRwd_R then
		if data.Grid then
			_M.HappyGiveModel:updateGridData(data)
		end
		if data.Rwds then
			_M.HappyGiveModel:updateRwdsData(data)
		end
	elseif op == msgids.GS_MineEnter_R or op == msgids.GS_MinesId_R or op == msgids.GS_MineBag_R then
		_M.MineModel:updateMine(data,op == msgids.GS_MinesId_R)
	elseif op == msgids.GS_MineNewPlr then
		_M.MineModel:addNewMiner(data)
	elseif op == msgids.GS_MineOutPlr then
		network.tcpSend(msgids.C_MineBag)
		_M.MineModel:removeMiner(data)
	elseif op == msgids.GS_MineCapacity then
		_M.MineModel:updateCapacity(data)
	elseif op == msgids.GS_MineDel then
		network.tcpSend(msgids.C_MineBag)
		_M.MineModel:removeMine(data)
		network.tcpSend(msgids.C_MinesId)
	elseif op == msgids.GS_MineRobed then
		network.tcpSend(msgids.C_MinesId)
	elseif op == msgids.GS_MineCheckOut_R then
		_M.MineModel:clearMinerBag()
	elseif op == msgids.GS_MineStop_R then
		_M.MineModel:clearMinerBag()
		_M.MineModel.mine.CurId = 0
	elseif op == msgids.GS_MineBegin_R then
		_M.MineModel.mine.CurId = data.Id
	elseif op == msgids.GS_ChatMsg then
		_M.ChatModel:addMessage(data.Data)
	elseif op == msgids.GS_LampMsg then
		_M.ChatModel:addLampMessage(data)
	elseif op == msgids.GS_BillConfGet_R then
		local unpackData = msgPack.unpack(data.Data)
		_M.PayModel:updateConf(unpackData)
		
		local SDKController = require "app.sdk.SDKController"
		local sdkHelper = SDKController.getSDKHelper()
		if sdkHelper.getPayInfo then
			Helper.lockWindow()
			sdkHelper:getPayInfo()
	    end
	elseif op == msgids.GS_BillConfChange then
		network.tcpSend(msgids.C_BillConfGet,{PlatId=PAY_PLATFORM})
	-- elseif op == msgids.GS_GuildBuildInfo_R then
	-- 	_M.GuildModel:initGuildBuild(data.Data)
	-- elseif op == msgids.GS_GuildResUpdate then
	-- 	_M.GuildModel:updateGuildRes(data)
	-- 	_M.RedTipsModel:refreshGuildTips()
	-- elseif op == msgids.GS_GuildBuildAcc then
	-- 	_M.GuildModel:updateBuildInfo(data)
	-- elseif op == msgids.GS_GuildBuildFinish then
	-- 	_M.GuildModel:updateBuildInfo(data)
	-- elseif op == msgids.GS_GuildBuild then
	-- 	_M.GuildModel:updateBuildInfo(data)
	elseif op == msgids.GS_BillCardInfo_R then
		_M.PayModel:updateCardInfo(data)
		_M.RedTipsModel:refreshWeekCardTips()
		_M.RedTipsModel:refreshMonthCardTips()
	elseif op == msgids.GS_GuildPlrLeaveTs then
		_M.PlayerModel:updateLeaveTs(data)
	elseif op == msgids.GS_GuildFirstJoinReward_R then
		_M.PlayerModel:updateGuildFirstJoin(data)
	elseif op == msgids.GS_WLevelTakeBossLvRewards_R then
		_M.LevelModel:addBossReward(data.LevelId)
	elseif op == msgids.GS_QuestInfo_R then
		local questData = {
			finItems = data.Data.FinItems or {},
			finObjs = data.Data.FinObjs or {},
			items = data.Data.Items or {},
		}
		_M.PlayerModel:updateQuestData(questData)
		_M.RedTipsModel:refreshQuestTips()
	elseif op == msgids.GS_WFightBriefing then
		_M.WorldFightModel:addFightBriefing(data)
	elseif op == msgids.GS_WFightResult then
		_M.WorldFightModel:updatePlrWData(data.PlrWData)
		_M.RedTipsModel:refreshWorldFightTips()
	elseif op == msgids.GS_WFightEnter_R then
		_M.WorldFightModel:updatePlrWData(data.PlrWData)
		_M.RedTipsModel:refreshWorldFightTips()
	elseif op == msgids.GS_WfightObjvTakeReward_R then
		_M.WorldFightModel:refreshTakeReward(data.Id)
		_M.RedTipsModel:refreshWorldFightTips()
	elseif op == msgids.GS_SoulUpdate_Lv then
		_M.SoulModel:updateLevel(data)
	elseif op == msgids.GS_MiscBillLocal_R then
		local SDKController = require "app.sdk.SDKController"
		local sdkHelper = SDKController.getSDKHelper()
		local jsonObj = json.decode(data.R)
		local flag = json.decode(jsonObj.flag)
		local productId = flag.prod_id
		local payConfData = _M.PayModel:getConfById(productId)
        sdkHelper:pay(payConfData,function(ret)
            
        end,jsonObj.sign)
    elseif op == msgids.GS_UpdateSkills_R then
    	_M.PlayerModel:updateReinGodSkill(data.Skills or {})
    elseif op == msgids.GS_ReinGodInfo_R 
    	or op == msgids.GS_ReinGodLevelup_R
    	or op == msgids.GS_ReinGodPowerup_R then
    	_M.PlayerModel:updateReinGod(data.Data)
    elseif op == msgids.GS_HeroReset_R then
    	-- _M.PlayerModel:removeFetterHero(data.Id)
    	_M.HeroModel:removeAoYiSkill(data.Id)
    	_M.HeroModel:resetClsGrov(data.Id)
    elseif op == msgids.GS_EscortSight_R then
    	_M.EscortModel:setSight(data)
    elseif op == msgids.GS_EscortNotifyBeenRobbed then
    	_M.EscortModel:addLog(data, true)
    elseif op == msgids.GS_EscortRob_R then
    	_M.EscortModel:addLog(data, true)
    	_M.EscortModel:updatePlayerCnt(data)
    	_M.EscortModel:addRobCnt()
    elseif op == msgids.GS_EscortNotifyFinish then
    	_M.EscortModel:addLog(data, false)
    	_M.EscortModel:finishMyCar(data)
    elseif op == msgids.GS_EscortInfo_R then
    	_M.EscortModel:setMyCar(data.Info)
    elseif op == msgids.GS_EscortRefreshCar_R then
    	_M.EscortModel:updateMyCar(data)
    elseif op == msgids.GS_EscortCarStart_R then
    	_M.EscortModel:updateEscortInfo(data.CarInfo, 1)
    elseif op == msgids.GS_EscortPlaySched_R then
    	_M.EscortModel:setSchedInfo(data)
    elseif op == msgids.GS_CjgSkillLevelUp then
    	_M.PlayerModel:updateCjgSkill(data)
    elseif op == msgids.GS_HeroAoYi then
    	_M.HeroModel:updateAoYi(data)
    elseif op == msgids.GS_HeroSkinNew then
    	_M.HeroModel:addNewSkin(data.Id, data.SkinId)
    	_M.RedTipsModel:addNewSkin(data.Id)
    elseif op == msgids.GS_ArtifactInfo_R then
		_M.ArtifactModel:addArtifacts(data.Data.Arts)
    elseif op == msgids.GS_ArtifactActivite_R then
		_M.ArtifactModel:addArtifact(data.Art)
		_M.RedTipsModel:refreshArtifactRedTips()
	elseif op == msgids.GS_ArtifactUpgrade_R then
		_M.ArtifactModel:updateArtifact(data)
	elseif op == msgids.GS_ArtifactStarUp_R then
		_M.ArtifactModel:updateArtifact(data)
	elseif op == msgids.GS_ArtifactEquip_R then
		_M.ArtifactModel:updateArtifact(data)
	elseif op == msgids.GS_ArtifactFetterActivite_R then
		_M.ArtifactModel:updateArtifact(data)
		_M.RedTipsModel:refreshArtifactRedTips()
	elseif op == msgids.GS_ArtifactPowerUpdate then
		_M.ArtifactModel:updatePower(data)
	elseif op == msgids.GS_ArtifactRunesExtractInfo_R
		or op == msgids.GS_ArtifactRunesExtract_R then
		_M.RedTipsModel:refreshRuneSummonTips(data)
    elseif op == msgids.GS_SqMineInfo_R then
	    _M.MinerModel:addMiner(data.Data)
	elseif op == msgids.GS_SqMineRecuit_R then
		_M.MinerModel:addNewMiner(data)
	elseif op == msgids.GS_SqMineDissmissMiner_R then
		_M.MinerModel:removeMiner(data.Seqs)
	elseif op == msgids.GS_SqMineWork_R then
		_M.MinerModel:changeMinerState(data.Miners)
	elseif op == msgids.GS_SqMineTakeReward_R then
		_M.MinerModel:removeMiner(data.Seq, true)
	elseif op == msgids.GS_SqMineUnlockFloor_R then
		_M.MinerModel:setSumFloor(data)
	elseif op == msgids.GS_RFStateInfo_R then
		_M.ValleyModel:setKingFightStage(data)
	elseif op == msgids.GS_GemUpdate_HeroId or 
		op == msgids.GS_GemUpdate_Locked or
		op == msgids.GS_GemUpdate_AtkPower then
	    _M.GemModel:updateGem(data)
	elseif op == msgids.GS_WzzjDonationInfo_R then
		_M.KingSwordModel:updateDonationData(data)
	elseif op == msgids.GS_WzzjBGroupInfo_R then
		--有战区才拉取捐赠信息
		network.tcpSend(msgids.C_WzzjDonationInfo)
		--获取服务器信息
		network.tcpSend(msgids.C_WzzjServerInfo)
	elseif op == msgids.GS_HhsslGetInfo_R then
		_M.ValleyModel:checkTrialRedTips(data.Data)
	elseif op == msgids.GS_ZzzdGetInfo_R then
		_M.HallModel:initData(data.Data)
		_M.RedTipsModel:refreshHallRedTips()
	elseif op == msgids.GS_ZzzdFightNormal_R then
		_M.HallModel:onFightNormal(data)
		_M.RedTipsModel:refreshHallRedTips()
	elseif op == msgids.GS_ZzzdFightNightmare_R then
		_M.HallModel:onFightSpecial(data)
		_M.RedTipsModel:refreshHallRedTips()
	elseif op == msgids.GS_ZzzdRewardsTake_R then
		_M.HallModel:onRewardTake(data)
		_M.RedTipsModel:refreshHallRedTips()
	elseif op == msgids.GS_ZzzdSweepNightmare_R then
		_M.HallModel:onSweepNightmare(data)
		_M.RedTipsModel:refreshHallRedTips()
	elseif op == msgids.GS_ZzzdBuyNMCnt_R then
		_M.HallModel:onBuyNMCnt(data)
	elseif op == msgids.GS_ZzzdReset then
		_M.HallModel:initData(data.Data)
		_M.RedTipsModel:refreshHallRedTips()
	elseif op == msgids.GS_TxwsPlusGetInfo_R then
		_M.TxwsPlusModel:initData(data.Data)
	elseif op == msgids.GS_TxwsPlusVersionInfo then
		_M.TxwsPlusModel:updateStageInfo(data)
	elseif op == msgids.GS_TxwsPlusPvpBoss_R then
		_M.TxwsPlusModel:onFightPvpBoss(data)
	elseif op == msgids.GS_TxwsPlusSvrScoreRank then
		_M.TxwsPlusModel:updateSvrScoreRank(data)
	elseif op == msgids.GS_TxwsPlusSetTeam_R then
		_M.TxwsPlusModel:updateTeam(data.Teams)
	elseif op == msgids.GS_TxwsPlusFight_R then
		_M.TxwsPlusModel:onFight(data)
	elseif op == msgids.GS_TxwsPlusBossUpdate then
		_M.TxwsPlusModel:updateBossData(data)
	elseif op == msgids.GS_PhantomGetInfo_R then
		_M.ChaseTraitorModel:updateChaseData(data.Data)
		-- _M.RedTipsModel:refreshPhantomRedTips(data.Data)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_DrawGetInfo_R then
		_M.DrawModel:initData(data.Draw)
		_M.RedTipsModel:refreshSummonTips()
	elseif op == msgids.GS_DrawTp_R then
		network.tcpSend(msgids.C_ActTimeRecruitInfo)
		_M.DrawModel:onDrawTp(data.DrawTp)
		_M.RedTipsModel:refreshSummonTips()
	elseif op == msgids.GS_LimitShopGetInfo_R then
		_M.LimitShopModel:refreshLimitShopData(data)
	elseif op == msgids.GS_MythAnimalGetInfo_R then
		_M.RedTipsModel:initMythAnimalData(data)
	elseif op == msgids.GS_MythAnimalAdd_R 
		or op == msgids.GS_MythAnimalTakeFree_R
		or op == msgids.GS_MythAnimalBillNew then
		_M.RedTipsModel:updateMythAnimalData(data)
	elseif op == msgids.GS_Act7DRankOLReward_R then
		_M.PlayerModel.olRewards = true
	elseif op == msgids.GS_CalendarInfo_R then
		_M.SignInModel:refreshSignInData(data)
	elseif op == msgids.GS_WLevelTakeDungeonBox_R then
		_M.LevelModel:addDungeonBoxIds(data.Id, true)
		_M.RedTipsModel:refreshDungeonTips()
	elseif op == msgids.GS_MineMapInfo_R then
		_M.MineWarModel:initData(data)
	elseif op == msgids.GS_MineInfo_R then
		_M.MineWarModel:updateMineDetailInfo(data)
	elseif op == msgids.GS_MineTakeSelfOutput then
		_M.MineWarModel.fightLog = true
		_M.RedTipsModel:refreshMineWarTips()
	elseif op == msgids.GS_MineSetTeam_R then
		_M.MineWarModel:updateMyTeam(data)
	elseif op == msgids.GS_MineSetModel_R then
		_M.MineWarModel:updateMyModel(data)
	elseif op == msgids.GS_MinerTrans_R then
		_M.MineWarModel:onTransMine(data)
		_M.MineWarModel:onTakeMyOutput()
	elseif op == msgids.GS_MineFightLog_R then	
		_M.MineWarModel:updateFightLog(data)
	elseif op == msgids.GS_MineSynMine then
		_M.MineWarModel:updateMineBaseInfo(data)
	elseif op == msgids.GS_SyncMineLogIdx then
		_M.MineWarModel:updateFightLogIdx(data)
	elseif op == msgids.GS_MineSynSuperM then
		_M.MineWarModel:updateSuperMineState(data)
	elseif op == msgids.GS_MineSynOutput then
		_M.MineWarModel:updateMyOutput(data)
	elseif op == msgids.GS_MineTakeSelfOutput_R then
		_M.MineWarModel:onTakeMyOutput()
	elseif op == msgids.GS_AstrolabeBless_R then
		_M.PlayerModel:updateKamiAstAdv(data)
	elseif op == msgids.GS_AstrolabeSkillLevelUp_R then
		_M.PlayerModel:astrolabeSkillLevelUp(data)
	elseif op == msgids.GS_AstrolabePointUnlock_R then
		_M.PlayerModel:astrolabePointUnlock(data)
	elseif op == msgids.GS_AstrolabePointUnlock_R then
		_M.PlayerModel:astrolabePointUnlock(data)
	elseif op == msgids.GS_GhostJadeEuqip_R then
		_M.PlayerModel:ghostJadeEuqip(data)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_GhostJadeUnEuqip_R then
		_M.PlayerModel:ghostJadeUnEuqip(data)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_GhostJadeLevelUp_R then
		_M.PlayerModel:ghostJadeLevelUp(data)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_GhostJadeSynthesis_R then
		_M.PlayerModel:ghostJadeSynthesis(data)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GhostJadeData then
		_M.PlayerModel:ghostJadeData(data)
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_ArenaGetInfo_R then
		_M.ArenaModel:updateInfo(data)
		_M.RedTipsModel:refreshArenaTips()
	elseif op == msgids.GS_ArenaTagRewardsTake_R then
		_M.ArenaModel:updateTagTaken(data)
		_M.RedTipsModel:refreshArenaTips()
	elseif op == msgids.GS_ArenaBuyPVPCounter_R
		or op == msgids.GS_ArenaFight_R then
		_M.RedTipsModel:refreshArenaTips()
	elseif op == msgids.GS_ArenaNewRep then
		_M.ArenaModel:updateRepsRed()
		_M.RedTipsModel:refreshArenaTips()
	elseif op == msgids.GS_WantedHallGetInfo_R then
		_M.RedTipsModel.wantedInfo = data.HallInfo
		_M.RedTipsModel:refreshWantedTips()
	elseif op == msgids.GS_WantedNewBoss then
		_M.RedTipsModel:addNewWantedBoss(data.Ids)
	elseif op == msgids.GS_WLevelGJInfo_R then
		_M.PlayerModel:updateAutoGain(data.GJAcc)
		_M.LevelModel:setExploreStartTs(data.GJTs, data.GJGTs, data.GJSTs)
	elseif op == msgids.GS_WLevelGJTakeLoot_R then
		_M.LevelModel:setExploreStartTs(Helper.getFixedTime())
	elseif op == msgids.GS_HeroHorcruxLevelUp_R then
		_M.HeroModel:heroHorcruxLevelUp(data)
	elseif op == msgids.GS_HeroHorcruxXPropsLock_R then
		_M.HeroModel:heroHorcruxXPropsLock(data)
	elseif op == msgids.GS_HeroHorcruxXProps then
		_M.HeroModel:heroHorcruxXProps(data)
	elseif op == msgids.GS_HeroHorcruxPolish_R then
		_M.HeroModel:heroHorcruxPolish(data)
	elseif op == msgids.GS_AstrolabeBless_R
		or op == msgids.GS_AstrolabeSkillLevelUp_R
		or op == msgids.GS_AstrolabePointUnlock_R then
		_M.RedTipsModel:refreshKamiTips()
	elseif op == msgids.GS_CBossAppearBox then
		_M.LevelModel:addMapBox(data.Data)
	elseif op == msgids.GS_CBossOpenBox_R then
		_M.LevelModel:removeMapBox(data.StepId)
	elseif op == msgids.GS_CBossCall_R then
		_M.LevelModel:addMapBoss(data.Data)
	elseif op == msgids.GS_CBossRiseHero_R then
		_M.LevelModel:reviveDieHero(data.Id)
	elseif op == msgids.GS_CBossFight_R then
		_M.LevelModel:updateMapBossInfo(data)
	elseif op == msgids.GS_CBossReset then
		_M.LevelModel:updateMapBossDecHp(data.HeroHp)
	elseif op == msgids.GS_HeroActivate_R then
		_M.RedTipsModel:refreshCanCallHero()
	elseif op == msgids.GS_ZzzdReGetInfo_R then
		_M.RedTipsModel.hallDetailData = data.Data 
	elseif op == msgids.GS_PatrolInfo_R then
		_M.RedTipsModel.patrolData = data.Data or {}
	elseif op == msgids.GS_RuneChangeSync then
		_M.RuneModel:updateRunes(data.Runes)
	elseif op == msgids.GS_RuneEquip_R or op == msgids.GS_RuneUnequip_R or op == msgids.GS_RuneLock_R or op == msgids.GS_RuneRecast_R then
		if data.Rune then
	        _M.RuneModel:updateRune(data.Rune)
	    end
	    if data.Old then
	        _M.RuneModel:updateRune(data.Old)
	    end
	elseif op == msgids.GS_RuneCompose_R or op == msgids.GS_RuneFractureTake_R then
		_M.RuneModel:setRuneBroken(data.RuneBroken)
	elseif op == msgids.GS_SpecialShopInfo_R then
		_M.SpecShopModel:initShopData(data.Data)
	elseif op == msgids.GS_SpecialShopShopInfo_R then
		_M.SpecShopModel:addOrUpdateShopData(data.Data)
	elseif op == msgids.GS_SpecialShopTake_R or op == msgids.GS_SpecialShopBill then
		_M.SpecShopModel:updateShopData(data)
	elseif op == msgids.GS_PlotsInfo_R then
		_M.PlotModel:updateData(data.Data)
	elseif op == msgids.GS_PlotsJournalInfo_R then
		_M.PlotModel:updateData({Journal = data.Data})
	elseif op == msgids.GS_PlotsJournalTake_R then
		_M.PlotModel:updateJournalTaken(data.Id)
	elseif op == msgids.GS_PlotsStepFight_R then
		_M.PlotModel:updateStep(data.Step)
	elseif op == msgids.GS_PlotsStepTake_R then
		_M.PlotModel:updateStepBoxTaken()
	elseif op == msgids.GS_PlotsBossRank_R then
		_M.PlotModel:updateRankData(data)
	elseif op == msgids.GS_PlotsBossFight_R then
		_M.PlotModel:updateData({Boss = data.Boss})
	end

	_M.ActivityModel:handleMsg(op,data)
    _M.KfbsModel:handleMsg(op,data)
	_M.KingSwordModel:handleMsg(op, data)
	_M.LandWarModel:handleMsg(op,data)
	_M.RewardPalaceModel:handleMsg(op,data)
	_M.ShopModel:handleMsg(op,data)
	_M.NinjaHeartModel:handleMsg(op, data)
	_M.FamilyModel:handleMsg(op, data)
	_M.PushShopModel:handleMsg(op, data)
	_M.SpeCardModel:handleMsg(op, data)
	_M.GhostStepModel:handleMsg(op, data)
	_M.PushGiftModel:handleMsg(op, data)
	_M.RewardRecallModel:handleMsg(op, data)
	_M.NinjaExpModel:handleMsg(op, data)
	_M.NinjaMasterModel:handleMsg(op, data)
	_M.RunePlayModel:handleMsg(op, data)
	_M.NinjaLegendModel:handleMsg(op, data)
end

return _M
