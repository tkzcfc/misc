--推送商城
local SpeCardModel = class("SpeCardModel")
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local speCardConf = require "app.configs.speCard"
local wantedCardConf = require "app.configs.wantedCard"

local MONTH_TYPE_STR_TO_ID = {
    honor = 1,
    extreme = 2,
}

local SPEC_TYPE_STR_TO_ID = {
    purpleWanted = 1001,
    orangeWanted = 1002,
    hangSpeed = 2001,
}

function SpeCardModel:ctor()
    self.pCard = {} -- 特权卡
    self.mCard = {} -- 月卡
    self.trial = false -- 是否体验过
    self.inLastTrial = false --最后一次体验,最后一次体验要单独记录
    self.lastTrialCard = 1 --最后一次体验,最后一次体验要单独记录
end

function SpeCardModel:initData(data)
    self.trial = data.Trial
    for _,info in ipairs(data.MCard or {}) do
        self.mCard[info.Id] = info
    end
    for _,info in ipairs(data.Priv or {}) do
        self.pCard[info.Id] = info
    end
end

function SpeCardModel:getTrial()
    return self.trial
end

function SpeCardModel:getInLastTrial()
    return self.inLastTrial
end

function SpeCardModel:setInLastTrial(inLastTrial)
    self.inLastTrial = inLastTrial
end

function SpeCardModel:getLastTrialCard()
    return self.lastTrialCard
end

function SpeCardModel:getHangSpeedFreeTimes()
    if self:getLeaveDay("special", "hangSpeed") <= 0 then
        return 0
    end
    local all = wantedCardConf[2001].freenum
    local use = self.pCard[2001].Cnt
    return all - use
end

function SpeCardModel:getUseHangSpeedFree()
    return self.pCard[2001] and self.pCard[2001].Cnt or 0
end

function SpeCardModel:getOnceRewards(typeStr)
    return {id = c.CurrencyName.exp, n = self.mCard[MONTH_TYPE_STR_TO_ID[typeStr]].Exp}
end

function SpeCardModel:getLeaveDay(belongTo, typeStr)
    local endTime = 0
    if belongTo == "month" then
        endTime = self.mCard[MONTH_TYPE_STR_TO_ID[typeStr]] and self.mCard[MONTH_TYPE_STR_TO_ID[typeStr]].End or 0
    elseif belongTo == "special" then
        endTime = self.pCard[SPEC_TYPE_STR_TO_ID[typeStr]] and self.pCard[SPEC_TYPE_STR_TO_ID[typeStr]].End or 0
        if endTime == -1 then
            return 1
        end
    end
    
    if endTime < Helper.getFixedTime() then
        return 0
    else
        local endTimeTs = os.date("*t",endTime)
        local curTimeTs = os.date("*t",Helper.getFixedTime())
        --结束时 0时时间
        local endDayTime = os.time({year = endTimeTs.year, month = endTimeTs.month, day = endTimeTs.day, hour = 0, min = 0, sec = 0})
        --当前天 0时时间
        local curDayTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
        
        local day = (endDayTime - curDayTime)/(24*60*60)
        return math.ceil(day)
    end
end

function SpeCardModel:hasCardEffect(typeStr)
    local id = typeStr == "honor" and 1 or 2
    local data = self:getExpAddData()
    for _,info in pairs(data) do
        if info.conf.id == id then
            return true
        end
    end
    return false
end

--是否购买荣耀月卡
function SpeCardModel:isBuyHonorCard()
    return self:getLeaveDay("month", "honor") > 0
end
--是否购买至尊月卡
function SpeCardModel:isBuyExtremeCard()
    return self:getLeaveDay("month", "extreme") > 0
end
--是否购买挂机加速卡
function SpeCardModel:isBuyHangSpeedCard()
    return self:getLeaveDay("special", "hangSpeed") > 0
end
--是否购买紫色通缉卡
function SpeCardModel:isBuyPurpleWantedCard()
    return self:getLeaveDay("special", "purpleWanted") > 0
end
--是否购买橙色通缉卡
function SpeCardModel:isBuyOrangeWantedCard()
    return self:getLeaveDay("special", "orangeWanted") > 0
end

function SpeCardModel:hasTakenDailyRwd(typeStr)
    return self.mCard[MONTH_TYPE_STR_TO_ID[typeStr]].DTaken
end

function SpeCardModel:getChargeData(typeStr)
    return self.mCard[MONTH_TYPE_STR_TO_ID[typeStr]].Charge, speCardConf[MONTH_TYPE_STR_TO_ID[typeStr]].cond
end

function SpeCardModel:getExprienceId()
    for _,info in pairs(self.mCard or {}) do
        if info.Cnt > 0 then
            return info.Id
        end
    end
    return 0
end

function SpeCardModel:getExpAddData()
    local data = {}
    local isExprience = false
    local honorLeaveDay = self:getLeaveDay("month", "honor")
    local extremeLeaveDay = self:getLeaveDay("month", "extreme")
    local exprienceId = self:getExprienceId()
    if honorLeaveDay > 0 then
        table.insert(data, {conf = speCardConf[1], isExprience = false})
    end
    if extremeLeaveDay > 0 then
        table.insert(data, {conf = speCardConf[2], isExprience = false})
    end
    --体验
    if exprienceId ~= 0 then
        isExprience = true
        table.insert(data, {conf =speCardConf[exprienceId], isExprience = true})
    end
    if self.inLastTrial then
        table.insert(data, {conf =speCardConf[self.lastTrialCard], isExprience = true})
    end
    return data, isExprience
end

function SpeCardModel:handleMsg(op, msg)
    if op == msgids.GS_SpeCardInfo_R then
        self:initData(msg.Data)
    elseif op == msgids.GS_SpeCardDailyTake_R then
        self.mCard[msg.Id].DTaken = true

        local init = require "app.models.init"
        local RedTipsModel = init.RedTipsModel
        RedTipsModel:refreshMonthCardTips()
    elseif op == msgids.GS_SpeCardOnTrial_R then
        self.trial = true
        self.mCard[msg.Data.Id] = msg.Data
    elseif op == msgids.GS_SpeCardTrial_R then
        if msg.Data.Cnt == 0 then
            self.inLastTrial = true
            self.lastTrialCard = self:getExprienceId()
        end
        self.mCard[msg.Data.Id] = msg.Data
    elseif op == msgids.GS_SpeCardCharge then
        if msg.Data.End ~= self.mCard[msg.Data.Id].End then
            local network = require "app.network.network"
            network.tcpSend(msgids.C_SpeCardTakeExp, {Id = msg.Data.Id})
        end
        self.mCard[msg.Data.Id] = msg.Data

        local init = require "app.models.init"
        local RedTipsModel = init.RedTipsModel
        RedTipsModel:refreshMonthCardTips()
    elseif op == msgids.GS_SpeCardTakeExp_R then
        if self.mCard[msg.Id] then
            self.mCard[msg.Id].Exp = 0
        end
        if msg.Rewards and table.nums(msg.Rewards) > 0 then
            display.getRunningScene():getChildByName("ViewBase"):openWin("PublicGetRewardWin",{rewards = msg.Rewards})
        end
    elseif op == msgids.GS_SpeCardExp then
        self.mCard[msg.Data.Id] = msg.Data
    elseif op == msgids.GS_SpeCardPrivBuy_R then
        self.pCard[msg.Data.Id] = msg.Data
    elseif op == msgids.GS_SpeCardPrivNew then
        self.pCard[msg.Data.Id] = msg.Data
    elseif op == msgids.GS_SpeCardPrivCnt then
        self.pCard[msg.Data.Id] = msg.Data
    end
end

function SpeCardModel:checkCardRedTips()
    for name,info in pairs(MONTH_TYPE_STR_TO_ID) do
        if self:hasRed(name) then
            return true
        end
    end
    for name,info in pairs(SPEC_TYPE_STR_TO_ID) do
        if self:hasRed(name) then
            return true
        end
    end
    return false
end

function SpeCardModel:checkSpeCardHasBuy(cname)
    if cname == "purpleWanted" or cname == "orangeWanted" or cname == "hangSpeed" then
        for name,info in pairs(SPEC_TYPE_STR_TO_ID) do
            if cname == name then
                if self:getLeaveDay("special", name) > 0 then
                    return true
                else
                    return false
                end
            end
        end
    elseif cname == "honor" or cname == "extreme" then
        for name,info in pairs(MONTH_TYPE_STR_TO_ID) do
            if cname == name then
                if self:getLeaveDay("month", name) > 0 then
                    return true
                else
                    return false
                end
            end
        end
    end
    return false
end

function SpeCardModel:hasRed(name)
    local PlayerConfig = require "sandglass.core.PlayerConfig"
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local time = PlayerConfig.getSetting(PlayerModel.info.userId..name.."speCard", 0)
    if Helper.getFixedTime() < time + 24 * 3600 then
        if name ~= "honor" and name ~= "extreme" then
            return false
        end
        return self:getLeaveDay("month", name) > 0 and not self:hasTakenDailyRwd(name)
    else
        if self:checkSpeCardHasBuy(name) then
            if name ~= "honor" and name ~= "extreme" then
                return false
            end
            return self:getLeaveDay("month", name) > 0 and not self:hasTakenDailyRwd(name)
        end
    end
    return true
end

function SpeCardModel:getProperty(name)
    return self[name]
end

return SpeCardModel