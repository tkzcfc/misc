local NinjaHeartModel = class("NinjaHeartModel")
local pvpTargetConf = require "app.configs.pvpTarget"
local msgids = require "app.network.msgids"
local rzzxConf = require "app.configs.rzzx"
function NinjaHeartModel:ctor()
    self.data = nil
end

function NinjaHeartModel:initData(data)
    self.data = data
end

function NinjaHeartModel:getInfo()
    return self.data
end

function NinjaHeartModel:canUpLv()
    if rzzxConf[self.data.Lv + 1] == nil then
        return false
    end
    local conf = rzzxConf[self.data.Lv]
    return (self.data.ExpStore + self.data.Exp) >= conf.exp
end

function NinjaHeartModel:handleMsg(op, data)
    local init = require "app.models.init"
    local RedTipsModel = init.RedTipsModel
    if op == msgids.GS_RzzxExpStore then
        self.data.ExpStore = data.ExpStore
        self.data.MaxAtk = data.MaxAtk
        RedTipsModel:refreshNinjaHeartRedTips()
    elseif op == msgids.GS_RzzxUpdate then
        self.data.Lv = data.Lv
        self.data.Exp = data.Exp
        self.data.ExpStore = data.ExpStore
        self.data.MaxAtk = data.MaxAtk
        RedTipsModel:refreshNinjaHeartRedTips()
    elseif op == msgids.GS_RzzxAddExp_R then
        RedTipsModel:refreshNinjaHeartRedTips()
    end
end

return NinjaHeartModel