--PlayerModel.lua

local c = require "app.configs.constants"
local astrolabeMapConf = require "app.configs.astrolabeMap"
local ghostAstrolabeConf = require "app.configs.ghostAstrolabe"
local gloryConf = require "app.configs.glory"
local ghostJadeSynthesisConf = require "app.configs.ghostJadeSynthesis"
local itemConf = require "app.configs.item"
local ghostJadeConf = require "app.configs.ghostJade"
local PlayerModel = class("PlayerModel")
local Helper = require "app.Helper"

local attributes = {
	["userId"] = 0, -- 玩家ID
	["name"] = "", -- 玩家名字
	["head"] = "", -- 玩家头像
	["hFrame"] = "", -- 玩家头像框
	["title"] = 0, -- 玩家头像称号
	["hFStore"] = "", -- 玩家拥有头像框
	["headStore"] = {},
	["titleStore"] = {}, --拥有的称号
	["currency"] = {}, -- 货币
	["counter"] = {}, --计数
	["level"] = 1, -- 等级
	["exp"] = 0, --经验
	["vip"] = 0, --vip等级
	["vipExp"] = 0, --vip开启项
	["vipTakenGift"] = {},
	["atkPwr"] = 0,--战斗力
	["kami"] = {}, --幻化神
	["reinGod"] = {}, --御神
	["questData"] = {}, --日常数据
	["medal"] = {},--勋章
	["isNew"] = false, --是否新号
	["createTime"] = "", --创建时间
	["isWhite"] = false, --是否是白名单
	["isAudit"] = false, --是否是提神包
	["loginIP"] = "",--玩家登陆IP
	["questionTake"] = {}, --
	["fetter"] = {},
}

local jadeStartId = {33301,33351,33401,33451,33501,33551,33601,33651}

function PlayerModel:ctor()
	self.info = {}
	self.openLevels = {}
	self.openConf = {}
	self.olRewards = false
	self.serverInfo = {}
    self.myServerId = 0
end

function PlayerModel:initData(params)
	local attr = clone(attributes)
	attr.userId = params.userId
	attr.name = params.name
	attr.isChgName = params.isChgName
	attr.head = params.head
	attr.hFrame = params.hFrame
	attr.title = params.title
	attr.titleStore = params.titleStore or {}
	attr.hFStore = params.hFStore
	attr.headStore = params.headStore or {}
	attr.level = params.level
	attr.perLevel = params.level
	attr.exp = params.exp
	attr.vip = params.vipData.Lv
	attr.vipExp = params.vipData.Exp
	attr.vipTakenGift = params.vipData.TakenGift or {}
	attr.atkPwr = params.atkPwr
	attr.loginIP = params.loginIP
	attr.perAtkPwr = params.atkPwr
	attr.kami = params.kami.Gst or {}
	attr.kami.ast = params.kami.Ast
	attr.kami.jade = params.ghostJadeData or {}
	attr.reinGod = params.reinGod
	attr.guildId = params.guildId or ""
	attr.guildName = params.guildName or ""
	attr.guildRank = params.guildRank or c.GUILD_RK.member
	attr.tutorialData = params.tutorialData or {}
	attr.step = attr.tutorialData.Step or 1
	-- attr.achvData = self:initAchvData(params.achvData)
	attr.questData = self:initQuestData(params.questData)
	--attr.medal = self:updateMedal(params.medal)
	attr.glory = self:initGloryData(params.glory or {})
	attr.isNew = params.isNew
	attr.createTime = params.createTs
	attr.monopolyData = params.monopolyData
	attr.landLastRecTs = params.landLastRecTs
	attr.svrOpenTs = params.svrOpenTs
	attr.guildLeaveTs = params.guildLeaveTs
	attr.guildLeaveCnt = params.guildLeaveCnt
	attr.guildFirstJoinReward = params.guildFirstJoinReward
	attr.mergeTs = params.mergeTs
	attr.mergeCnt = params.mergeCnt
	attr.questionTake = params.questionTake or {}
	attr.forLoading = params.forLoading
	attr.batGrp = params.batGrp
	attr.comment = params.comment and params.comment.RwdRec or {}
	attr.currency = {}
	for k,v in pairs(params.currency or {}) do
		attr.currency[v.Id] = v.Val
	end

	attr.counter = {}
	for k,v in pairs(params.counter or {}) do
		attr.counter[v.Id] = v.Val
	end

	--藏经阁
	attr.cjg = {}
	local cjg = {}
	if params.cjg and params.cjg.Skills then
		cjg = params.cjg.Skills
	end
	for _, v in pairs(cjg) do
		attr.cjg[v.SkillId] = v.LvId
	end
	self.info = attr
	--更新幻化升星盘技能
	self:updateKamiAstSkill()
	self:updateKamiAstAdvProps()
	self:updateMedal(params.medal)
	self:updateFetters(params.fetter)
end

function PlayerModel:updateKamiAstSkill()
	local tmp = {}
	for _,info in ipairs(self.info.kami.ast.Skill or {}) do
		tmp[info.Pos] = info
	end
	self.info.kami.ast.Skill = tmp
end

function PlayerModel:getKamiAstSkill()
	return self.info.kami.ast.Skill
end

function PlayerModel:updateKamiAstAdvProps()
	local tmp = {}
	for _,info in ipairs(self.info.kami.ast.LvMod or {}) do
		tmp[info.Id] = info
	end
	self.info.kami.ast.LvMod = tmp
end

function PlayerModel:initCurrency(params)
	for k,v in pairs(params.currency or {}) do
		self.info.currency[v.Id] = v.Val
	end
end

function PlayerModel:getInfo()
	return self.info
end

function PlayerModel:getCurrencyByID(id)
	if not self.info.currency then
		return 0
	end
	local num = self.info.currency[id] or 0
    return num
end

function PlayerModel:getCounterByID(id)
	if not self.info.counter then
		return 0
	end
	local num = self.info.counter[id] or 0
	return num
end

function PlayerModel:updateCurrency(currency)
	for k,v in pairs(currency) do
		self.info.currency[v.Id] = v.Val
	end
end

function PlayerModel:updateFiled(data)
	for k,v in pairs(data.Fields) do
		self.info.counter[v.Id] = v.Val
	end
end

function PlayerModel:getPlayerCurrency(currency)
	local c = require "app.configs.constants"

    local id = nil
    if type(currency) == "number" then
    	id = currency
    else
	    id = c.CurrencyName[currency]
	end
    local num = self.info.currency[id] or 0
    return num
end

function PlayerModel:updateLevel(data)
	if data.level ~= -1 then
		self.info.perLevel = self.info.level
		self.info.level = data.level
	end
	self.info.exp = data.exp
end

function PlayerModel:updateKami(kami)
	self.info.kami.Gst = kami
	self.info.kami.CurSkin = kami.CurSkin or {}
	self.info.kami.Id = kami.Id
	self.info.kami.Skins = kami.Skins or {}
	self.info.kami.Taken = kami.Taken or {}
end

function PlayerModel:updateKamiRewardTaken(Id)
	if self.info.kami and Id then
		if not self.info.kami.Taken then
			self.info.kami.Taken = {}
		end
		table.insert(self.info.kami.Taken, Id)
	end
end

function PlayerModel:updateName(name)
	self.info.isChgName = true
	self.info.name = name
end

function PlayerModel:updateHead(id)
	self.info.head = id
end

function PlayerModel:updateHFrame(id)
	self.info.hFrame = id
end

function PlayerModel:updateQuestData(data)
	self.info.questData = self:initQuestData(data)
end

function PlayerModel:updateFetters(data)
	for k,v in pairs(data or {}) do
		self:updateFetter(v)
	end
end

function PlayerModel:updateFetter(data)
	local fettersConf = require "app.configs.fetters"
	local fetterData = fettersConf[data.Id]

	if fetterData then
		local masterId = fetterData.heroMaster
		local fetterId = fetterData.heroFetter
		local starLv = data.N
		if self.info.fetter.Heros then
			local hasHeroId = false
			for i,v in ipairs(self.info.fetter.Heros) do
				if v.HeroID == masterId then
					hasHeroId = true
					local hasFetterId = false
					for _,k in ipairs(v.FetterIDs or {}) do
						if k.HeroId == fetterId then
							k.StarLv = starLv
							hasFetterId = true
							break
						end
					end
					if not hasFetterId then
						v.FetterIDs = v.FetterIDs or {}
						table.insert(v.FetterIDs, {HeroId=fetterId, StarLv=starLv})
					end
					break
				end
			end
			if not hasHeroId then
				table.insert(self.info.fetter.Heros, {HeroID = masterId, FetterIDs = {{HeroId=fetterId, StarLv=starLv}}})
			end
		else
			self.info.fetter.Heros = {}
			table.insert(self.info.fetter.Heros, {HeroID = masterId, FetterIDs = {{HeroId=fetterId, StarLv=starLv}}})
		end
	end
end

function PlayerModel:initQuestData(data)--初始化日常
	local Helper = require "app.Helper"
	self.initQuestTime = Helper.getFixedTime()
	local questData = {}
	-- type questData struct {
	-- 	FinItems []int32
	-- 	FinObjs  []*questObj
	-- 	Items    []*questObj
	-- }

	-- type questObj struct {
	-- 	QId int32  日常ID
	-- 	OId int32  目标ID
	-- 	Val int32  进度
	-- }
	
	for k,v in pairs(data.items or {}) do --目标进度未完成
		if not questData[v.QId] then
			questData[v.QId] = {}
		end
		if not questData[v.QId].finObjs then
			questData[v.QId].finObjs = {}
		end
		questData[v.QId].finObjs[v.OId] = {val = v.Val}
	end

	for k,v in pairs(data.finObjs or {}) do --目标进度完成了的
		if not questData[v.QId] then
			questData[v.QId] = {}
		end
		if not questData[v.QId].finObjs then
			questData[v.QId].finObjs = {}
		end
		questData[v.QId].finObjs[v.OId] = {finItem = true}
	end

	for _,v in pairs(data.finItems or {}) do --完成的日常
		questData[v.QId] = {finItems = true, T = v.T}
	end
	return questData
end

function PlayerModel:questValueChanged(data) --日常进度变化
	if not self.info.questData[data.QId] then
		self.info.questData[data.QId] = {}
	end
	if not self.info.questData[data.QId].finObjs then
		self.info.questData[data.QId].finObjs = {}
	end
	self.info.questData[data.QId].finObjs[data.OId] = {val = data.Val}
end

function PlayerModel:questObjectiveCompleted(data) --日常目标完成
	if not self.info.questData[data.QId] then
		self.info.questData[data.QId] = {}
	end
	if not self.info.questData[data.QId].finObjs then
		self.info.questData[data.QId].finObjs = {}
	end
	self.info.questData[data.QId].finObjs[data.OId] = {finItem = true}
end

function PlayerModel:questItemCompleted(data) --日常项完成
	if not self.info.questData[data.QId] then
		self.info.questData[data.QId] = {}
	end
	self.info.questData[data.QId] = {finItems = true, T = data.T}
end

function PlayerModel:updateMedal(medal)
	for k,v in pairs(medal) do
		self.info.medal[v.T] = v
	end
end

function PlayerModel:initGloryData(glory)
	local gloryIds = {}--徽记数据
	for k,id in pairs(glory) do
		if gloryConf[id] then
			gloryIds[gloryConf[id].type] = id
		end
	end

	return gloryIds
end

function PlayerModel:updateAtkPower(atkPwr)
	self.info.perAtkPwr = self.info.atkPwr
	self.info.atkPwr = atkPwr
end

function PlayerModel:getQuestData() --获取日常
	return self.info.questData
end

function PlayerModel:addNewGlory(id)
	self.info.glory[gloryConf[id].type] = id
end

function PlayerModel:addNewHFrame(id)
	table.insert(self.info.hFStore,id)
end

function PlayerModel:addNewHead(id)
	table.insert(self.info.headStore, id)
end

function PlayerModel:updateGuildInfo(data)
	if data.Mb.Id == self.info.userId then
		self.info.guildId = data.GuildId
		self.info.guildName = data.GuildName
		self.info.guildRank = data.Mb.Rank
	end
end

--初始化公会成就数据
function PlayerModel:initGuildAchvData(data)
	self.info.guildAchvData = {}
	for k,v in pairs(data.Data and data.Data.Items or {}) do
		self.info.guildAchvData[v.AId] = v
	end
end

--增加公会完成的成就
function PlayerModel:addGuildAchvData(data)
	if not self.info.guildAchvData then
		return
	end
	if self.info.guildAchvData[data.AId] then
		self.info.guildAchvData[data.AId].F = true
	else
		self.info.guildAchvData[data.AId] = {}
		self.info.guildAchvData[data.AId].AId = data.AId
		self.info.guildAchvData[data.AId].F = true
	end
end

--更新自己在公会中的职位信息
function PlayerModel:updateGuildRank(data)
	if self.info.userId == data.PId then
		self.info.guildRank = data.Rank
	end
end

--更改公会名字
function PlayerModel:changeGuildName(name)
	self.info.guildName = name
end

function PlayerModel:guildLeave(data)
	if data.PId == self.info.userId then
		self.info.guildId = ""
		self.info.guildName = ""
		self.info.guildRank = c.GUILD_RK.member
	end
end

function PlayerModel:updateVipData(data)
	self.info.preVip = self.info.vip
	self.info.vip = data.Lv
	self.info.vipExp = data.Exp
	-- self.info.vipTakenGift = data.Vip.TakenGift or {}
end

function PlayerModel:onTakeVipGift(data)
	if data.Id then
		table.insert(self.info.vipTakenGift, data.Id)
	end
end

function PlayerModel:initOpenData(levels)
	local levels = levels or {}

	for levelId,status in pairs(levels) do
		if status == c.LevelStatus.PASSED or status == c.LevelStatus.EXPLORE then
			self.openLevels[levelId] = status
		end
	end
	self.openConf = self:getOpenConf()
end

function PlayerModel:updateOpenData(levelId)
	self.openLevels[levelId] = c.LevelStatus.PASSED
end

function PlayerModel:updateAutoGain(autoGain)
	self.info.autoGain = autoGain
end

function PlayerModel:getAutoGain()
	return self.info.autoGain
end

--未开启功能
function PlayerModel:getOpenConf()
	local openConf = require "app.configs.open"
	local init = require "app.models.init"
	local c = require "app.configs.constants"
	local LevelModel = init.LevelModel
	local allData = LevelModel:getLevels()
	local lv = self.info.level

	local data = clone(openConf)

	for k,v in pairs(data) do
		for allK,allV in pairs(allData) do
			if v.p1 ~= 0 and v.p1 == allK and allV >= 3 then
				data[k] = nil
				break
			end
		end
		if v.cond == 10 and lv >= v.p2 then
			data[k] = nil
		end
	end

	-- for k,v in pairs(data) do
	-- 	if v.cond == 10 and lv >= v.p2 then
	-- 		data[k] = nil
	-- 	end
	-- end

	return data
end

function PlayerModel:updateLeaveTs(data)
	self.info.guildLeaveTs = data.LeaveTs
	self.info.guildLeaveCnt = data.LeaveCnt
end

function PlayerModel:updateGuildFirstJoin()
	self.info.guildFirstJoinReward = true
end

function PlayerModel:updateReinGodSkill(skillIds)
	self.info.reinGod.Skills = skillIds
end

function PlayerModel:updateReinGod(reinGod)
	self.info.reinGod = reinGod
end

function PlayerModel:removeFetterHero(heroId)
	if self.info.fetter.Heros then
		for _,v in ipairs(self.info.fetter.Heros) do
			for i,k in ipairs(v.FetterIDs or {}) do
				if k.HeroId == heroId then
					table.remove(v.FetterIDs, i)
					break
				end
			end
		end
	end
end

function PlayerModel:updateCjgSkill(data)
	self.info.cjg[data.SkillId] = data.LvId
end

function PlayerModel:updateComment(commentType)
	local isExist = false
	for _,v in pairs(self.info.comment) do
		if v == commentType then
			isExist = true
		end
	end
	if not isExist then
		table.insert(self.info.comment, commentType)
	end
end

function PlayerModel:getAstrolabeSkillConf(pos, level)
	local astrolabeSkillConf = require "app.configs.astrolabeSkill"
	return astrolabeSkillConf[pos * 1000 + level]
end

function PlayerModel:updateKamiAstAdv(data)
	if data.Level then
		self.info.kami.ast.Level = data.Level
	end
	if data.Skill then
		for _,info in ipairs(data.Skill) do
			self.info.kami.ast.Skill[info.Pos] = info
		end
	end
	if data.LvMod then
		for _,info in ipairs(data.LvMod) do
			self.info.kami.ast.LvMod[info.Id] = info
		end
	end
	self.info.kami.ast.Bless = data.Bless or 0
end

function PlayerModel:astrolabePointUnlock()
	self.info.kami.ast.Point = (self.info.kami.ast.Point or 0) + 1
end

function PlayerModel:astrolabeSkillLevelUp(data)
	if self.info.kami.ast.Skill[data.Pos] then
		self.info.kami.ast.Skill[data.Pos].Lv = self.info.kami.ast.Skill[data.Pos].Lv + 1
	else
		self.info.kami.ast.Skill[data.Pos] = {Pos = data.Pos, Lv = 1}
	end
end

function PlayerModel:getAstTotalAttr()
	--星图
	local totalAttrs = self:getAstMapAttr()
	--进阶
	local advAttr = {}
	for i,v in ipairs(ghostAstrolabeConf[1].gradeAttr) do
		local num = self.info.kami.ast.LvMod[v.attId] and self.info.kami.ast.LvMod[v.attId].C or 0
		table.insert(advAttr, {attId = v.attId, n = num})
	end
	for _,info in ipairs(advAttr) do
		if info.n ~= 0 then
			totalAttrs[info.attId] = totalAttrs[info.attId] == nil and info.n or (totalAttrs[info.attId] + info.n)
		end
	end

	--是否显示进阶失败属性
	return totalAttrs
end

function PlayerModel:getAstMapAttr()
	local ret = {}
	for i=1,(self.info.kami.ast.Point or 0) do
		local attr = astrolabeMapConf[i].attr[1]
		if ret[attr.attId] == nil then
			ret[attr.attId] = attr.n
		else
			ret[attr.attId] = ret[attr.attId] + attr.n
		end
	end
	return ret
end

function PlayerModel:getAllQuestInfo()
	local questConf = require "app.configs.quest"
	local questData = self:getQuestData()
	local openData = self:getOpenConf()
	local QUEST_STATUS = {
		canGet = 1,
		working = 2,
		noOpen = 3,
		finished = 4,
	}--同QuestWin一致
	local tasks = {}
	local leftTasks = {}
	local boxTasks = {}

	local datas = clone(questConf)
	for _,v in pairs(datas) do
		if v.showType ~= 2 then
			local data = questData[v.id]
			local status = nil
			local val = 0
			if data then
				if data.finItems then
					if data.T then
						status = QUEST_STATUS.finished
					else
						status = QUEST_STATUS.canGet
					end
				else
					local allFinish = true
					for Oid,k in pairs(data.finObjs) do
						if not k.finItem then
							allFinish = false
							val = k.val
							break
						end
					end
					if allFinish then
						status = QUEST_STATUS.finished
					else
						status = QUEST_STATUS.working
					end
				end
			else
				status = QUEST_STATUS.working
			end
	        table.insert(tasks, {id = v.id, status = status, val = val, openId = v.openId, cond = v.cond})
	    end
	end
    for i,v in ipairs(tasks) do
    	for _,data in pairs(openData) do
    	 	if data.funcId == v.openId then
    	 		v.status = QUEST_STATUS.noOpen
    	 		break
    	 	end
    	end
    	if v.cond == 402 then
    		table.insert(boxTasks, v)
    	else
    		table.insert(leftTasks, v)
    	end
    end

    return leftTasks, boxTasks
end

--------------------------------宝石start----------------------------
function PlayerModel:ghostJadeEuqip(data)
	if not self.info.kami.jade.EqId then
		self.info.kami.jade.EqId = {}
	end
	self.info.kami.jade.EqId[data.Pos] = data.Id or 0
end

function PlayerModel:ghostJadeUnEuqip(data)
	if not self.info.kami.jade.EqId then
		self.info.kami.jade.EqId = {}
	end
	self.info.kami.jade.EqId[data.Pos] = 0
end

function PlayerModel:ghostJadeLevelUp(data)
	if not self.info.kami.jade.EqId then
		self.info.kami.jade.EqId = {}
	end
	self.info.kami.jade.EqId[data.Pos] = data.Id or 0
end

function PlayerModel:ghostJadeSynthesis(data)
	
end

function PlayerModel:getCurJadeMaster()
	local ghostJadeMasterConf = require "app.configs.ghostJadeMaster"
	local masterId = 1
	for idx,info in ipairs(ghostJadeMasterConf) do
		local lvUp = true
		for _,id in ipairs(self.info.kami.jade.EqId or {}) do
			if id == 0 or itemConf[id].jadeLevel < info.levelCond then
				lvUp = false
				break
			end
		end
		if lvUp then
			masterId = idx
		end
	end
	return masterId
end

function PlayerModel:ghostJadeData(data)
	self.info.kami.jade.EqId = data.EqId
end

function PlayerModel:getInsetJadeCnt()
	local cnt = 0
	for _,id in ipairs(self.info.kami.jade.EqId) do
		if id ~= 0 then
			cnt = cnt + 1
		end
	end
	return cnt
end

function PlayerModel:canReplaceJade(pos)
	local jadeId = self.info.kami.jade.EqId[pos]
	local canReplace = false
	if jadeId ~= nil and jadeId ~= 0 then
		for i=jadeId,jadeId+c.KAMI_JADE_MAX_LEVEL do
			if itemConf[i] == nil then
				break
			elseif i > jadeId and Helper.getItemOrCurrencyCnt(i) > 0 then
				canReplace = true
				break
			end
		end
	end
	return canReplace
end

function PlayerModel:canInsetJade(pos)
	local jadeId = self.info.kami.jade.EqId[pos]
	local canInset = false
	if jadeId == 0 or jadeId == nil then
		local startId = self:getStartJadeIdBySlot(ghostJadeConf[pos].slot)
		local jadeLimit = self:getJadeLevelLimitAndNameBySlot()
		for i=startId,startId + c.KAMI_JADE_MAX_LEVEL - 1 do
			if Helper.getItemOrCurrencyCnt(i) > 0 and jadeLimit[ghostJadeConf[pos].slot].levelLimit <= self.info.level then
				canInset = true
				break
			end
		end
	end
	return canInset
end

function PlayerModel:getJadeLevelLimitAndNameBySlot()
	local jadeLevelLimitAndName = {}
	for _,info in ipairs(ghostJadeConf) do
		if not jadeLevelLimitAndName[info.slot] then
			jadeLevelLimitAndName[info.slot] = {}
		end
		if info.levelLimit ~= 0 and info.name ~= "" then
			jadeLevelLimitAndName[info.slot] = {levelLimit = info.levelLimit,name = info.name}
		end
	end
	return jadeLevelLimitAndName
end

function PlayerModel:getStartJadeIdBySlot(slot)
	return jadeStartId[slot]
end

function PlayerModel:canUpgradeJade(pos)
	local jadeId = self.info.kami.jade.EqId[pos]
	local items = {}
	local canUpgrade = false
	local ccyEnough = true
	local useCcy = 0
	if jadeId ~= nil and jadeId ~= 0 and ghostJadeSynthesisConf[jadeId] ~= nil then
		local selfNum = ghostJadeSynthesisConf[jadeId].costSelfNum
		local ownCcy = Helper.getItemOrCurrencyCnt(ghostJadeSynthesisConf[jadeId].costElse[1].id)
		--计算可以通过升级获得jId的数量
		local function calculateCnt(jId, needCnt)
			--退出条件
			--1.查找完最后一个宝石
			local conf = ghostJadeSynthesisConf[jId]
			if itemConf[jId] == nil then
				return false
			end
			--2.ccy消耗不足
			if ownCcy < conf.costElse[1].n then
				ccyEnough = false
			end
			local oneNeed = jId == jadeId and 1 or 3
			local use = Helper.getItemOrCurrencyCnt(jId)
			--排除当前等级宝石升级消耗
			if oneNeed ~= 1 then
				ownCcy = ownCcy - conf.costElse[1].n * math.max(1, needCnt / oneNeed)
			end
			if use >= needCnt then
				table.insert(items, {id = jId, num = needCnt})
				return ownCcy >= 0
			else
				if use > 0 then
					table.insert(items, {id = jId, num = use})
				end
				return calculateCnt(jId - 1, (needCnt - use) * selfNum)
			end
		end
		--本级消耗
		ownCcy = ownCcy - ghostJadeSynthesisConf[jadeId].costElse[1].n
		canUpgrade = calculateCnt(jadeId, 2)
		useCcy = Helper.getItemOrCurrencyCnt(ghostJadeSynthesisConf[jadeId].costElse[1].id) - ownCcy
		ccyEnough = Helper.getItemOrCurrencyCnt(ghostJadeSynthesisConf[jadeId].costElse[1].id) >= useCcy
	end
	return canUpgrade, items, ccyEnough, useCcy
end

function PlayerModel:getJadeTotalAttr()
	local itemConf = require "app.configs.item"
	local ghostJadeMasterConf = require "app.configs.ghostJadeMaster"
	local attrs = {}
	for pos,id in ipairs(self.info.kami.jade.EqId or {}) do
		if id ~= 0 then
			local prop = itemConf[id].basicProperty[1]
			attrs[prop.id] = attrs[prop.id] and (attrs[prop.id] + prop.val) or prop.val
		end
	end
	local curId = self:getCurJadeMaster()
	for _,info in ipairs(ghostJadeMasterConf[curId].attribute) do
		attrs[info.id] = attrs[info.id] and (attrs[info.id] + info.val) or info.val
	end
	return attrs
end

function PlayerModel:getInsetRedData()
	local insetRed = false
	local upgradeRed = false
	local replaceRed = false
	local insetData = {}
	local upgradeData = {}
	local replaceData = {}
 	for pos=1,#ghostJadeConf do
 		--镶嵌
 		insetData[pos] = self:canInsetJade(pos)
 		if not insetRed and insetData[pos] then
 			insetRed = true
 		end
 		--升级
 		upgradeData[pos] = self:canUpgradeJade(pos)
 		if not upgradeRed and upgradeData[pos] then
 			upgradeRed = true
 		end
 		--替换
 		replaceData[pos] = self:canReplaceJade(pos)
 		if not replaceRed and replaceData[pos] then
 			replaceRed = true
 		end
 	end
 	return {
 		insetRed = insetRed,
 		upgradeRed = upgradeRed,
 		replaceRed = replaceRed,
 		insetData = insetData,
 		upgradeData = upgradeData,
 		replaceData = replaceData
 	}
end

--------------------------------宝石end----------------------------
-----获取宝石初始化数据
function PlayerModel:getMedalInitData(playerMedal)
	local medallionConf = require "app.configs.medallion"

	local medal = {}
    for _,v in pairs(medallionConf) do
        if v.hide ~= 1 then--过滤需要隐藏的
            if not medal[v.type] then
                medal[v.type] = {}
            end

            medal[v.type][v.stage] = v
            if v.stage == 1 then
                medal[v.type].type = v.type
                medal[v.type].openDes = v.openDes
                medal[v.type].des = v.des
                medal[v.type].rare = v.rare

                --组装0级数据
                medal[v.type][0] = clone(v)
                medal[v.type][0].stage = 0
                medal[v.type][0].cost = {}
                for _,attr in ipairs(medal[v.type][0].attachAttrId or {}) do
                    attr.val = 0
                end
            end

            medal[v.type].curStage = 0
            if playerMedal[v.type] then
                medal[v.type].curStage = playerMedal[v.type].Stage
            end
        end
    end

    return medal
end

function PlayerModel:setServerListData(data)
    for _, info in pairs(data or {}) do
        self.serverInfo[info.id] = info
    end
end

function PlayerModel:getServerById(id)
    return self.serverInfo[id] ~= nil and self.serverInfo[id].text or ""
end

function PlayerModel:setMyServerId(id)
    self.myServerId = id
end

function PlayerModel:getMyServerId()
    return self.myServerId
end

function PlayerModel:addNewHeadTitle(id)
	if not table.indexof(self.info.titleStore, id) then
		table.insert(self.info.titleStore,id)
	end
end
function PlayerModel:delHeadTitle(id)
	if table.indexof(self.info.titleStore, id) then
		table.remove(self.info.titleStore,table.indexof(self.info.titleStore, id))
	end
end
function PlayerModel:updateTitle(id)
	self.info.title = id
end

return PlayerModel
