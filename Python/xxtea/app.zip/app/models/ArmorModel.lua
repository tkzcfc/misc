--ArmorModel.lua

local ArmorModel = class("ArmorModel")
local itemConf = require "app.configs.item"

local attributes = {
	["seq"] = 0, -- 序号
	["id"] = 0, -- 表 Id
	["lv"] = 0, -- 强化等级
	["exp"] = 0, --强化经验
	["smtLv"] = 0, --精炼等级
	["star"] = 0, --星级
	["RProps"] = {}, --随机属性
-- 	// 属性
-- type Prop struct {
-- 	Id  int32
-- 	Val float64
-- }
}


function ArmorModel:ctor()
	self.Armors = {}
	self.ArmorCount = 0
end

function ArmorModel:removeArmors(armorsDel)
	for _,seq in pairs(armorsDel or {}) do
		if self.Armors[seq] then
			self.ArmorCount = self.ArmorCount - 1
		end
		self.Armors[seq] = nil
	end
end

function ArmorModel:addArmors(Armors)
	for _, Armor in pairs(Armors or {}) do
		self:addArmor(Armor)
	end
end

function ArmorModel:addArmor(data)
	local attr = clone(attributes)

	attr.seq = data.Seq
	attr.id = data.Id
	attr.level = data.Lv or 0
	attr.exp = data.Exp
	attr.heroId = data.HeroId or 0
	attr.locked = data.Locked or false
	attr.smtLv = data.SmtLv or 0
	attr.star = data.Star or 0
	attr.RProps = {}
	attr.atkPwr = data.AtkPwr
	
	for _, props in ipairs(data.RProps or {}) do
		table.insert(attr.RProps,{id = props.Id,val = props.Val})
	end

	self.Armors[data.Seq] = attr
	self:basicProperty(self.Armors[data.Seq])
	self.ArmorCount = self.ArmorCount + 1
end

function ArmorModel:basicProperty(armor)
	armor.basicVal = itemConf[armor.id].basicProperty[1].val + itemConf[armor.id].attrLvIncr * armor.level
end

function ArmorModel:getArmor(seq)
	return self.Armors[seq]
end

function ArmorModel:getArmors()
	return self.Armors
end

function ArmorModel:isInitialization(seq)
	local armor = self:getArmor(seq)
	local isInit = true
	if armor.level ~= 0 then
		isInit = false
	end
	return isInit
end

function ArmorModel:getEmptyArmors()
	local armors = {}
	for seq, armor in pairs(self.Armors) do
		if armor.heroId == 0 then
			armors[seq] = armor
		end
	end

	return armors
end

function ArmorModel:getHeroArmors(heroId)
	local armors = {}
	for seq, armor in pairs(self.Armors) do
		if armor.heroId == 0 or armor.heroId == heroId then
			armors[seq] = armor
		end
	end
	return armors
end

function ArmorModel:updateLevel(data)
	self.Armors[data.seq].level = data.level
	self:basicProperty(self.Armors[data.seq])
end

function ArmorModel:updateSmeltLevel(data)
	self.Armors[data.seq].smtLv = data.smtLv
end

function ArmorModel:updateStarLevel(data)
	self.Armors[data.seq].star = data.star
end

function ArmorModel:updateRProps(data)
	self.Armors[data.seq].RProps = {}
	for _, props in ipairs(data.RProps) do
		table.insert(self.Armors[data.seq].RProps,{id = props.Id,val = props.Val})
	end
end

function ArmorModel:checkArmorInit(seq) --检测装备是否为初始状态
	local isInit = true
	local armor = self.Armors[seq]
	if armor.level > 0 or armor.smtLv > 0 or armor.star > 0 then
		return false
	end
	return true
end

function ArmorModel:updateHeroId(data)
	self.Armors[data.seq].heroId = data.heroId
end

function ArmorModel:updateLocked(data)
	self.Armors[data.seq].locked = data.locked
end

function ArmorModel:updateAtkPower(data)
	self.Armors[data.seq].atkPwr = data.atkPwr
end

function ArmorModel:getArmorCount()
	return self.ArmorCount
end

return ArmorModel
