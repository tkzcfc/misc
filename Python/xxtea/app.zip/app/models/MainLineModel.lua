--MainLineModel.lua
local MainLineModel = class("MainLineModel")

local attributes = {
	["nowCpt"] = 0,-- 当前章节
    ["finCpt"] = 0,-- 已完成章节
	["finishTask"] = {}, -- 当前章节已完成任务
	["achvData"] = {}, --成就数据
}

function MainLineModel:ctor()
	self.info = {}
    self.refresh = false
end

function MainLineModel:initData(params)
	local attr = clone(attributes)
	attr.nowCpt = params.nowCpt
	attr.finishTask = params.finishTask
	attr.achvData = self:initAchvData(params.achvData)
	self.info = attr
end

function MainLineModel:initAchvData(data)
	local achvData = {}
	-- type AchvData struct {
	-- 	FinItems []int32
	-- 	FinObjs  []*AchvObj
	-- 	Items    []*AchvObj
	-- }

	-- type AchvObj struct {
	-- 	AId int32  成就ID
	-- 	OId int32  目标ID
	-- 	Val int32  进度
	-- }
	
	for k,v in pairs(data.Objs or {}) do --目标进度未完成
		if not achvData[v.AId] then
			achvData[v.AId] = {}
			achvData[v.AId].achvId = v.AId
		end
		if not achvData[v.AId].finObjs then
			achvData[v.AId].finObjs = {}
		end
		achvData[v.AId].finObjs[v.OId] = {val = v.Val}
	end

	for k,v in pairs(data.finObjs or {}) do --目标进度完成了的
		if not achvData[v.AId] then
			achvData[v.AId] = {}
			achvData[v.AId].achvId = v.AId
		end
		if not achvData[v.AId].finObjs then
			achvData[v.AId].finObjs = {}
		end
		achvData[v.AId].finObjs[v.OId] = {finItem = true}
	end

	for _,v in pairs(data.finItems or {}) do --完成的成就
		achvData[v.AId] = {finItems = true, T = v.T}
	end

	return achvData
end

function MainLineModel:achvValueChanged(data) --成就进度变化
	if not self.info.achvData[data.AId] then
		self.info.achvData[data.AId] = {}
		self.info.achvData[data.AId].achvId = data.AId
	end
	if not self.info.achvData[data.AId].finObjs then
		self.info.achvData[data.AId].finObjs = {}
	end
	self.info.achvData[data.AId].finObjs[data.OId] = {val = data.Val}
    if not self.refresh then
        self.refresh = true
        local scheduler = require "sandglass.core.Scheduler"
        self.timer = scheduler.scheduleGlobal(function()
            self.refresh = false
            local init = require "app.models.init"
            local RedTipsModel = init.RedTipsModel
            RedTipsModel:refreshMainLine()
            RedTipsModel:refreshAchievement()
            scheduler.unscheduleGlobal(self.timer)
            scheduler = nil
        end, 0.5)
    end
end

function MainLineModel:achvObjectiveCompleted(data) --成就目标完成
	if not self.info.achvData[data.AId] then
		self.info.achvData[data.AId] = {}
		self.info.achvData[data.AId].achvId = data.AId
	end
	if not self.info.achvData[data.AId].finObjs then
		self.info.achvData[data.AId].finObjs = {}
	end
	self.info.achvData[data.AId].finObjs[data.OId] = {finItem = true}
end

function MainLineModel:achvItemCompleted(data) --成就项完成（未领取）
	if not self.info.achvData[data.AId] then
		self.info.achvData[data.AId] = {}
		self.info.achvData[data.AId].achvId = data.AId
	end
	self.info.achvData[data.AId] = {finItems = true}
end

function MainLineModel:achvItemCompletedOver(data) --成就项完成（领取）
	if not self.info.achvData[data.AId] then
		self.info.achvData[data.AId] = {}
		self.info.achvData[data.AId].achvId = data.AId
	end
	self.info.achvData[data.AId] = {finItems = true, T = true}
end

function MainLineModel:updateNowCpt(nowCpt)
	self.info.nowCpt = nowCpt
end

function MainLineModel:updateFinishTask(finishTask)
	self.info.finishTask = finishTask
end

function MainLineModel:getNowCpt()
	return self.info.nowCpt
end

function MainLineModel:getAchvData()
	return self.info.achvData
end

function MainLineModel:getFinishTaskIds()
	return self.info.finishTask
end
-----获取成就的状态
function MainLineModel:getAchvStatusInfo(achvId)
    local c = require "app.configs.constants"
    local achvData = self:getAchvData()
    local statusInfo = {status = c.ACHV_STATUS.working, val = 0}

    local aData = achvData[achvId]
    if aData then
        if aData.finItems then
            if aData.T then
                statusInfo.status = c.ACHV_STATUS.finished
            else
                statusInfo.status = c.ACHV_STATUS.canGet
            end
        else
            local allFinish = true
            for _,k in pairs(aData.finObjs) do
                if not k.finItem then
                    allFinish = false
                    statusInfo.val = k.val
                    break
                end
            end
            if allFinish then
                statusInfo.status = c.ACHV_STATUS.canGet
            else
                statusInfo.status = c.ACHV_STATUS.working
            end
        end
    end
    
    return statusInfo
end
-----获取主线任务当前章节的任务
function MainLineModel:getCurCptTasks()
	local mainObjConf = require "app.configs.mainObj"
	local init = require "app.models.init"
	local c = require "app.configs.constants"
    local PlayerModel = init.PlayerModel

    local curCpt = self:getNowCpt()
    local finishIds = self:getFinishTaskIds() 
    local openData = PlayerModel:getOpenConf()

    local tasks = {}
    for i,v in pairs(mainObjConf) do
        if v.chapterId == curCpt then
            table.insert(tasks, {id = v.id, openId = v.open, achvId = v.achvId})
        end
    end  
    for _,v in ipairs(tasks) do
        local aData = self:getAchvStatusInfo(v.achvId)
        if aData.status == c.ACHV_STATUS.finished then
            aData.status = c.ACHV_STATUS.canGet
        end
        v.status = aData.status
        v.val = aData.val

        for _,id in pairs(finishIds) do
            if v.id == id then
                v.status = c.ACHV_STATUS.finished 
                break
            end
        end

        for _,k in pairs(openData) do
            if v.openId == k.funcId then
                status = c.ACHV_STATUS.noOpen
                break
            end
        end
    end
    
    table.sort(tasks, function(a, b)
		return a.id < b.id
    end)
    local finishedTasks = {}
    local canGetTasks = {}
    for k = #tasks,1,-1 do
        if tasks[k].status == c.ACHV_STATUS.finished then
            table.insert(finishedTasks,tasks[k])
            table.remove(tasks,k)
        elseif tasks[k].status == c.ACHV_STATUS.canGet then
            table.insert(canGetTasks, tasks[k])
            table.remove(tasks, k)
        end
    end
    table.sort(finishedTasks, function(a, b)
		return a.id > b.id
    end)
    table.sort(canGetTasks,function(a, b)
        return a.id < b.id
    end)

    local finalTasks = {}
    for _,v in pairs(canGetTasks) do
        table.insert(finalTasks,v)
    end
    for _,v in pairs(tasks) do
        table.insert(finalTasks,v)
    end
    for k,v in pairs(finishedTasks) do
        table.insert(finalTasks,v)
    end
    return finalTasks
end


------获取全部类型成就数据
function MainLineModel:getAllTypeAchvs()
    local achvConf = require "app.configs.achv"
    local achvObjConf = require "app.configs.achvObj"
    local c = require "app.configs.constants"
    local conf = clone(achvConf)

    local typeData = {}
    for k,v in pairs(conf) do
        if v.type > 0 then
            if not typeData[v.type] then
                typeData[v.type] = {}
            end
            if v.start == 1 then
                table.insert(typeData[v.type], v)
            end
        end
    end
    local allAchvs = {}
    for type_,achvs in pairs(typeData) do
        for i,v in ipairs(achvs) do
            local achvData = self:getUnlokeAchv(v.achvId)
            if achvData then
                if not allAchvs[type_] then
                    allAchvs[type_] = {}
                end
                local sData = self:getAchvStatusInfo(achvData.achvId)
                achvData.status = sData.status
                achvData.val = sData.val
                table.insert(allAchvs[type_], achvData)
            end
        end
    end
    
    for type_,achvs in pairs(allAchvs) do
        table.sort(achvs, function(a, b)
            return a.status < b.status
        end)
    end
    return allAchvs
end

------递归解锁成就
function MainLineModel:getUnlokeAchv(achvId, upData)
    local achvConf = require "app.configs.achv"
    local c = require "app.configs.constants"
    local data = achvConf[achvId]
    if not data then
        return upData
    end

    local statusData = self:getAchvStatusInfo(achvId)
    if statusData.status == c.ACHV_STATUS.finished then
        return self:getUnlokeAchv(data.next, data)
    else
        return data
    end
    
end


return MainLineModel
