
local attributeConf = require "app.configs.attribute"
local heroUpConf = require "app.configs.heroUp"
local itemConf = require "app.configs.item"
local suitConf = require "app.configs.suit"
local WordDictionary = require "app.configs.WordDictionary"
local levelUpConf = require "app.configs.levelUp"
local Helper = require "app.Helper"
local currencyConf = require "app.configs.currency"
local globalPublicConf = require "app.configs.globalPublic"
local talentConf = require "app.configs.talent"
local talentGrooveConf = require "app.configs.talentGroove"
local awakeStageConf = require "app.configs.awakeStage"
local awakeLevelConf = require "app.configs.awakeLevel"
local heroConf = require "app.configs.hero"
local openConf = require "app.configs.open"
local fettersConf = require "app.configs.fetters"
local heroHorcruxConf = require "app.configs.heroHorcrux"
local runeConf = require "app.configs.rune"
local PlayerConfig = require "sandglass.core.PlayerConfig"

local HeroModel = class("HeroModel")

local attributes = {
    ["level"] = 0, -- 等级
    ["exp"] = 0, -- 经验
    ["star"] = 0, -- 星级
    ["cls"] = 0, -- 突破等级
    ["clsGrov"] =  {0,0,0,0},
    ["atkPwr"] = 0, -- 战斗力
    ["awkPw"] = 0, --觉醒忍道
    ["awkJb"] = 0, --觉醒宿命
    ["awkLv"] = 0, --觉醒等级
    ["curSkin"] = 0, --当前时装id
    ["skin"] = nil, --开通时装id

    -- props
    ["attack"] = {a = 0, b = 0, c = 0}, -- 攻击,
    ["defense"] = {a = 0, b = 0, c = 0}, -- 防御,
    ["maxLife"] = {a = 0, b = 0, c = 0}, -- 生命,
    ["energy"] = {a = 0, b = 0, c = 0}, -- 能量,
    ["attackCoef"] = {a = 0, b = 0, c = 0}, -- 攻击加成,
    ["defenseCoef"] = {a = 0, b = 0, c = 0}, -- 防御加成,
    ["maxLifeCoef"] = {a = 0, b = 0, c = 0}, -- 生命加成,
    ["attackLvIncr"] = {a = 0, b = 0, c = 0}, -- 攻击成长,
    ["defenseLvIncr"] = {a = 0, b = 0, c = 0}, -- 防御成长,
    ["maxLifeLvIncr"] = {a = 0, b = 0, c = 0}, -- 生命成长,
    ["crit"] = {a = 0, b = 0, c = 0}, -- 暴击,
    ["critDamage"] = {a = 0, b = 0, c = 0}, -- 暴击伤害,
    ["critOdds"] = {a = 0, b = 0, c = 0}, --暴击几率
    ["hit"] = {a = 0, b = 0, c = 0}, -- 命中,
    ["dodge"] = {a = 0, b = 0, c = 0}, -- 闪避,
    ["speed"] = {a = 0, b = 0, c = 0}, -- 速度,
    ["lifePerHit"] = {a = 0, b = 0, c = 0}, -- 吸血,
    ["lifePerRound"] = {a = 0, b = 0, c = 0}, -- 生命回复,
    ["energyPerRound"] = {a = 0, b = 0, c = 0}, -- 能量回复,
    ["addCure"] = {a = 0, b = 0, c = 0}, -- 附加治疗,
    ["cureRatio"] = {a = 0, b = 0, c = 0}, -- 治疗加成,
    ["damageRatio"] = {a = 0, b = 0, c = 0}, -- 伤害减免,
    ["healingRatio"] = {a = 0, b = 0, c = 0}, -- 治疗减免,
    ["effectHit"] = {a = 0, b = 0, c = 0}, -- 效果命中,
    ["effectDodge"] = {a = 0, b = 0, c = 0}, -- 效果抵抗,
    ["critOdds"] = {a = 0, b = 0, c = 0}, -- 暴击率,
    ["calmOdds"] = {a = 0, b = 0, c = 0}, -- 抗暴,
    ["critCoef"] = {a = 0, b = 0, c = 0}, -- 暴击加成,
    ["hitCoef"] = {a = 0, b = 0, c = 0}, -- 命中加成,
    ["dodgeCoef"] = {a = 0, b = 0, c = 0}, -- 闪避加成,
    ["speedCoef"] = {a = 0, b = 0, c = 0}, -- 速度加成,
    ["lifePerHitCoef"] = {a = 0, b = 0, c = 0}, -- 吸血加成,
    ["damageUpRatio"] = {a = 0, b = 0, c = 0}, --伤害加深,
    ["attackLvExtra"] = {a = 0, b = 0, c = 0}, --额外攻击,
    ["defenseLvExtra"] = {a = 0, b = 0, c = 0}, --额外防御
    ["maxLifeLvExtra"] = {a = 0, b = 0, c = 0}, --额外生命
}

local nameByType = {
    ["attack"] = 1,
    ["defense"] = 1,
    ["maxLife"] = 1,
    ["energy"] = 1,
    ["attackCoef"] = 2,
    ["defenseCoef"] = 2,
    ["maxLifeCoef"] = 2,
    ["attackLvIncr"] = 3,
    ["defenseLvIncr"] = 3,
    ["maxLifeLvIncr"] = 3,
    ["crit"] = 1,
    ["critDamage"] = 2,
    ["critOdds"] = 2,
    ["hit"] = 1,
    ["dodge"] = 1,
    ["speed"] = 1,
    ["lifePerHit"] = 1,
    ["lifePerRound"] = 1,
    ["energyPerRound"] = 1,
    ["addCure"] = 1,
    ["cureRatio"] = 2,
    ["damageRatio"] = 2,
    ["healingRatio"] = 2,
    ["effectHit"] = 2,
    ["effectDodge"] = 2,
    ["critOdds"] = 2,
    ["calmOdds"] = 2,
    ["critCoef"] = 2,
    ["hitCoef"] = 2,
    ["dodgeCoef"] = 2,
    ["speedCoef"] = 2,
    ["lifePerHitCoef"] = 2,
    ["damageUpRatio"] = 2,
    ["attackLvExtra"] = 3, --额外攻击,
    ["defenseLvExtra"] = 3, --额外防御
    ["maxLifeLvExtra"] = 3, --额外生命
}

local attrName = {
    "attack",
    "defense",
    "maxLife",
    "energy",
    "attackCoef",
    "defenseCoef",
    "maxLifeCoef",
    "attackLvIncr",
    "defenseLvIncr",
    "maxLifeLvIncr",
    "crit",
    "critDamage",
    "hit",
    "dodge",
    "speed",
    "lifePerHit",
    "lifePerRound",
    "energyPerRound",
    "addCure",
    "cureRatio",
    "damageRatio",
    "healingRatio",
    "effectHit",
    "effectDodge",
    "critOdds",
    "calmOdds",
    "critCoef",
    "hitCoef",
    "dodgeCoef",
    "speedCoef",
    "lifePerHitCoef",
    "damageUpRatio",
    "attackLvExtra", --额外攻击,
    "defenseLvExtra", --额外防御
    "maxLifeLvExtra", --额外生命
}

local function ArmorSlot(t)
    return t % 10
end

function HeroModel:ctor()
    self.heros = {}
end

function HeroModel:addHeros(heros,armors,souls,gems)
    self.armors = armors or {}
    self.souls = souls or {}
    self.gems = gems or {}
    for _, hero in pairs(heros or {}) do
        self:addHero(hero)
    end
    self:updateHeroRank()
end

function HeroModel:addHero(data)
    local attr = clone(attributes)
    attr.level = data.Lv or 0
    attr.exp = data.Exp or 0
    attr.star = data.Star or 0
    attr.cls = data.Cls or 0
    attr.clsGrov = data.ClsGrov or {0,0,0,0}
    attr.atkPwr = data.AtkPwr or 0
    attr.awkPw = data.AwkPw or 0
    attr.awkJb = data.AwkJb or 0
    attr.awkLv = data.AwkLv or 0
    attr.curSkin = data.CurSkin or 0
    attr.skin = data.Skin or {}
    attr.aoyi = data.AoYi or false
    attr.color = data.Color
    attr.horcrux = data.Horcrux or {}
    attr.id = data.Id or 0
    for _, prop in pairs(data.Props or {}) do
        local attrName = attributeConf[prop.Id].alias
        attr[attrName] = {a = prop.A, b = prop.B, c = prop.C}
    end
    attr["attackLvIncr"] = {a = heroUpConf[attr.id * 100 + attr.star].attack, b = 0, c = 0} -- 攻击成长,
    attr["defenseLvIncr"] = {a = heroUpConf[attr.id * 100 + attr.star].defense, b = 0, c = 0} -- 防御成长,
    attr["maxLifeLvIncr"] = {a = heroUpConf[attr.id * 100 + attr.star].maxLife, b = 0, c = 0} -- 生命成长,

    attr["attackLvExtra"] = {a = 0, b = 0, c = heroUpConf[attr.id * 100 + attr.star].attackBase} -- 额外攻击,
    attr["defenseLvExtra"] = {a = 0, b = 0, c = heroUpConf[attr.id * 100 + attr.star].defenseBase} -- 额外防御,
    attr["maxLifeLvExtra"] = {a = 0, b = 0, c = heroUpConf[attr.id * 100 + attr.star].maxLifeBase} -- 额外生命,

    local armors = self.armors or {}
    local armorBox = {}
    for _,armor in pairs(armors) do
        if armor.heroId == attr.id then
            armorBox[ArmorSlot(itemConf[armor.id].type)] = armor
        end
    end
    attr.armorBox = armorBox

    local souls = self.souls or {}
    local soulsBox = {}
    for _,soul in pairs(souls) do
        if soul.heroId == attr.id then
            soulsBox[soul.slot] = soul
        end
    end
    attr.soulsBox = soulsBox

    local gems = self.gems or {}
    local gemsBox = {}
    for _,gem in pairs(gems) do
        if gem.heroId == attr.id then
            gemsBox[gem.slot] = gem
        end
    end
    attr.gemsBox = gemsBox

    self.heros[data.Id] = attr
end

function HeroModel:updateLineUpHero(hId)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local RedTipsModel = init.RedTipsModel
    local lineupConf = require "app.configs.lineup"

    local inLineUpHrs = PlayerConfig.getSetting(PlayerModel.info.userId .. "lineUpHeros", {})
    if not inLineUpHrs[hId] and heroConf[hId].adviseLineup == 1 then
        --按阵容保存
        local lineUpIds = {}
        for _,info in ipairs(lineupConf) do
            for _,heroId in ipairs(info.team) do
                if hId == heroId then
                    table.insert(lineUpIds, info.id)
                    break
                end
            end
        end
        inLineUpHrs[hId] = {ts = Helper.getFixedTime(), lineUpIds = lineUpIds}
        PlayerConfig.setSetting(PlayerModel.info.userId .. "lineUpHeros", inLineUpHrs)
        Helper.sendEvent("refreshLineUpHeros", {inLineUpHrs = inLineUpHrs})
    end
    RedTipsModel:refreshMainMoreBtn()
end

function HeroModel:removeLineUpHero(heros)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local RedTipsModel = init.RedTipsModel
    local inLineUpHrs = PlayerConfig.getSetting(PlayerModel.info.userId .. "lineUpHeros", {})
    for _,hData in ipairs(heros) do
        if inLineUpHrs[hData.hId] then
            --去除某一个阵容的英雄
            for idx,id in ipairs(inLineUpHrs[hData.hId].lineUpIds or {}) do
                if hData.lineupId == id then
                    table.remove(inLineUpHrs[hData.hId].lineUpIds, idx)
                end
            end
            --若阵容id全部被查看，不在保存该英雄为新阵容
            if #inLineUpHrs[hData.hId].lineUpIds == 0 then
                inLineUpHrs[hData.hId] = nil
            end
        end
    end
    PlayerConfig.setSetting(PlayerModel.info.userId .. "lineUpHeros", inLineUpHrs)
    Helper.sendEvent("refreshLineUpHeros", {inLineUpHrs = inLineUpHrs})
    RedTipsModel:refreshMainMoreBtn()
end

function HeroModel:hasNewHero(heros)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local inLineUpHrs = PlayerConfig.getSetting(PlayerModel.info.userId .. "lineUpHeros", {})
    local hasNew = false
    for _,hData in ipairs(heros) do
        if inLineUpHrs[hData.hId] then
            for _,lId in ipairs(inLineUpHrs[hData.hId].lineUpIds or {}) do
                if lId == hData.lineupId then
                    hasNew = true
                    break
                end
            end
        end
    end
    return hasNew
end

function HeroModel:getHero(heroId)
    return self.heros[heroId]
end

function HeroModel:getHeros()
    return self.heros
end

function HeroModel:updateHeroExp(data)
    local heroData = self.heros[data.Id]
    heroData.exp = data.Exp
end

function HeroModel:updateHero(data)
    local heroData = self.heros[data.Id]
    if not heroData then return end
    heroData.level = data.Lv
    heroData.exp = data.Exp
    heroData.star = data.Star
    heroData.cls = data.Cls
    heroData.clsGrov = data.ClsGrov
    heroData.atkPwr = data.AtkPwr
    heroData.awkPw = data.AwkPw
    heroData.awkJb = data.AwkJb
    heroData.awkLv = data.AwkLv
    heroData.curSkin = data.CurSkin
    heroData.skin = data.Skin
    heroData.aoyi = data.AoYi
    heroData.color = data.Color
    local attr = {}
    for _, prop in pairs(data.Props or {}) do
        local attrName = attributeConf[prop.Id].alias
        attr[attrName] = {a = prop.A, b = prop.B, c = prop.C}
    end

    attr["attackLvIncr"] = {a = heroUpConf[data.Id * 100 + heroData.star].attack, b = 0, c = 0} -- 攻击成长,
    attr["defenseLvIncr"] = {a = heroUpConf[data.Id * 100 + heroData.star].defense, b = 0, c = 0} -- 防御成长,
    attr["maxLifeLvIncr"] = {a = heroUpConf[data.Id * 100 + heroData.star].maxLife, b = 0, c = 0} -- 生命成长,

    attr["attackLvExtra"] = {a = 0, b = 0, c = heroUpConf[data.Id * 100 + heroData.star].attackBase} -- 额外攻击,
    attr["defenseLvExtra"] = {a = 0, b = 0, c = heroUpConf[data.Id * 100 + heroData.star].defenseBase} -- 额外防御,
    attr["maxLifeLvExtra"] = {a = 0, b = 0, c = heroUpConf[data.Id * 100 + heroData.star].maxLifeBase} -- 额外生命,

    for k,v in pairs(attr) do
        heroData[k] = v
    end

    self:updateHeroRank()
end

function HeroModel:getHeroAttributeBasics(heroId)
    local attr = {}
    local hero = self:getHero(heroId)
    for _,name in ipairs(attrName) do
        local vaule = Helper.arrangementAttrNumber(hero[name].a, nameByType[name])
        attr[name] = vaule
    end

    return attr
end

function HeroModel:getHeroAttributeExtra(heroId)
    local attr = {}
    local hero = self:getHero(heroId)
    for _,name in ipairs(attrName) do
        local vaule = Helper.arrangementAttrNumber(hero[name].c, nameByType[name])
        attr[name] = vaule
    end

    return attr
end

function HeroModel:getHeroAttributeAdditional(heroId)
    local attr = {}
    local hero = self:getHero(heroId)
    for _,name in ipairs(attrName) do
        local vaule = Helper.arrangementAttrNumber(hero[name].a * hero[name].b + hero[name].c,nameByType[name])
        attr[name] = vaule
    end

    return attr
end

function HeroModel:getHeroFinalAttribute(heroId)
    local attr = {}
    local hero = self:getHero(heroId)
    for _,name in ipairs(attrName) do
        local vaule = hero[name].a * (1 + hero[name].b) + hero[name].c,nameByType[name]
        attr[name] = vaule
    end

    return attr
end

function HeroModel:getAttriType(name)
    return nameByType[name]
end

function HeroModel:getNextAttrByStar(heroId)
    local hero = self:getHero(heroId) 
    local attr = {}
    local heroUp = heroUpConf[hero.id * 100 + hero.star + 1]
    if not heroUp then return attr end
    attr["attackLvIncr"] = heroUpConf[hero.id * 100 + hero.star + 1].attack -- 攻击成长,
    attr["defenseLvIncr"] = heroUpConf[hero.id * 100 + hero.star + 1].defense -- 防御成长,
    attr["maxLifeLvIncr"] = heroUpConf[hero.id * 100 + hero.star + 1].maxLife -- 生命成长,

    attr["attackLvExtra"] = heroUpConf[hero.id * 100 + hero.star + 1].attackBase -- 额外攻击,
    attr["defenseLvExtra"] = heroUpConf[hero.id * 100 + hero.star + 1].defenseBase -- 额外防御,
    attr["maxLifeLvExtra"] = heroUpConf[hero.id * 100 + hero.star + 1].maxLifeBase -- 额外生命,

    return attr
end

function HeroModel:wearHeroArmor(armor)
    local hero = self:getHero(armor.heroId)
    hero.armorBox[ArmorSlot(itemConf[armor.id].type)] = armor
end

function HeroModel:unloadHeroArmor(armor,heroId)
    if not heroId or heroId == 0 then return end
    local hero = self:getHero(heroId)
    hero.armorBox[ArmorSlot(itemConf[armor.id].type)] = nil
end

function HeroModel:updateHeroSkin(heroId, skinId)
    local heroData = self.heros[heroId]
    if not heroData then return end
    heroData.curSkin = skinId
end

function HeroModel:getStarInfo()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local limitData = globalPublicConf[1].starTimeLimit[1]
    local secs = Helper.getFixedTime() - PlayerModel.info.svrOpenTs
    local factor = 24 * 60 * 60
    local minSecs = (limitData.days - 7) * factor
    local maxSecs = limitData.days * factor

    if secs < minSecs then
        return limitData.n
    elseif secs > maxSecs then
        return globalPublicConf[1].heroStarLimit
    else
        return limitData.n, (maxSecs - secs)
    end
end

--英雄升级红点
function HeroModel:checkLevelUp(heroData)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local haveItem = false

    local lvupItem = heroConf[heroData.id].lvupItem or {}
    for i,v in ipairs(lvupItem) do
        local _id = v.itemId
        local _cnt = Helper.getItemOrCurrencyCnt(_id)
        if _cnt > 0 then
            haveItem = true
            break
        end
    end

    local lv = PlayerModel.info.level

    return haveItem and heroData.level < lv
end

--英雄升星红点
function HeroModel:checkStarUp(heroData)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local ItemModel = init.ItemModel
    local heroId = heroData.id
    local star = heroData.star

    --功能开启
    if not Helper.getOpenState(12, true) then
        return false
    end

    local heroId = heroData.id
    local star = heroData.star
    local lv = PlayerModel.info.level

    --等级限制
    local conf = heroUpConf[heroId * 100 + star] or {}
    local needLevel = conf.herolevelLimit or 999
    if heroData.level < needLevel then
        return false
    end

    --满星
    if star >= globalPublicConf[1].heroStarLimit then
        return false
    end

    local starConsume = conf.starConsume or {}

    local rOriginId = 0--替换道具原始Id
    local rCnt = 0--替换道具数量
    local universal = heroConf[heroId].universal[1]
    if universal and universal.replace and star < globalPublicConf[1].heroStarLimit then
        local rId = universal.replace
        rOriginId = universal.original
        rCnt = ItemModel:getItemCntById(rId)
    end

    for i,data in ipairs(starConsume) do
        local cnt = Helper.getItemOrCurrencyCnt(data.id)
        if data.id == rOriginId and cnt < data.n and cnt + rCnt < data.n then--当前是碎片 且数量小于需求
            return false
        elseif data.id ~= rOriginId and cnt < data.n then--其他道具
            return false
        end
    end

    return true
end


function HeroModel:checkQualityUp(heroData)
    -- 现在不开启品质突破
    if true then
        return false
    end
    --英雄可以升星
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local ItemModel = init.ItemModel
    local heroQualityConf = require "app.configs.heroQuality"

    if not Helper.getOpenState(12, true) then
        return false
    end

    local qualityConf = nil
    local qualityNextConf = nil
    local qConf = {}
    local heroColor = heroData.useData and heroData.useData.color or heroData.color
    for _,v in pairs(heroQualityConf) do
        if (v.heroId == heroData.id or v.heroId == heroData.heroID) and v.color == heroColor then
            qualityConf = v
        elseif (v.heroId == heroData.id or v.heroId == heroData.heroID) and v.color == (heroColor + 1) then
            qualityNextConf = v
        end
    end


    local flag = true

    local qualityConsume = qualityConf.cost or {}
    if qualityConf.open == 1 then
    else
        flag = false
    end


    if flag then
        for k,v in ipairs(qualityConsume) do
            local useNum = 0
            if itemConf[v.id] then
                local item = ItemModel:getItem(v.id)
                useNum = item and item.number or 0
            elseif currencyConf[v.id] then
                useNum = PlayerModel:getPlayerCurrency(v.id)
            end
            local needNum = v.n
            if useNum < needNum then
                flag = false
            end    
        end
    end
    return flag and false
end

--检测是否有天赋可以激活
function HeroModel:checkTalent(heroData)
    --没有可激活返回false
    local redType = {
        slot = 1,--槽位可以激活
        cls = 2,--天赋可以升级
    }

    --开启状态
    if not Helper.getOpenState(19, true) then
        return false
    end

    --满级
    local conf = talentConf[heroData.id]
    if heroData.cls >= #conf.extraAttribute then
        return false
    end

    local upId = heroData.id * 100 + heroData.cls
    local upConf = talentGrooveConf[upId]

    local canUp = 0--是否可以升级
    for i=1,4 do
        local isSlotActive = heroData.clsGrov[i] ~= 0
        if isSlotActive then--已激活槽位
            canUp = canUp + 1
        elseif heroData.level >= upConf.level[i] then--等级满足
            local c = require "app.configs.constants"
            local init = require "app.models.init"
            local PlayerModel = init.PlayerModel
            local costItem = upConf.cost[i]
            local costGlod = upConf.goldCost[i]
            local itemCnt = Helper.getItemOrCurrencyCnt(costItem.id)--检测背包数量
            local glodCnt = PlayerModel:getCurrencyByID(c.CurrencyName.gold)
            if itemCnt >= costItem.n and glodCnt >= costGlod then
                return redType.slot
            end
        end
    end
        
    if canUp >= 4 then--检测升级所需金币
        local goldCost = conf.goldCost[heroData.cls + 1]
        local cnt = Helper.getItemOrCurrencyCnt(goldCost.id)
        return cnt >= goldCost.n and redType.cls or false
    end

    return false
end

function HeroModel:checkEquip(heroData, needPos)
    --英雄可以穿戴装备
    local init = require "app.models.init"
    local ArmorModel = init.ArmorModel

    local armorBox = heroData.armorBox  --英雄已穿戴装备
    local armors = ArmorModel:getEmptyArmors()  --背包所有装备
    local typeNum = {1,2,3,4,5,6}

    local armorBoxCount = 0    --英雄已穿戴装备数量
    for k,v in pairs(armorBox) do
        armorBoxCount = armorBoxCount + 1
    end

    local armorsCount = 0    --背包剩余装备数量
    for k,v in pairs(armors) do
        armorsCount = armorsCount + 1
    end

    --背包里没有空闲装备
    if armorsCount == 0 then
        return false
    end

    --检查每个位置是否有更好装备
    local posIdx = {}
    local cHeroData = heroConf[heroData.id]
    for i=1,6 do
        local wear = armorBox[i]
        if wear then--查找更好的
            --策划没有想好规则 暂时屏蔽2019/08/30
            -- local wearConf = itemConf[wear.id]
            -- for _,v in pairs(armors) do
            --     local conf = itemConf[v.id]
            --     --当前位置
            --     --当前未穿2、4件套
            --     --品质更高 或者 品质相等且该装备是推荐的2、4件套
            --     if (conf.type % 10) == i and wearConf.suit ~= cHeroData.equip2 and wearConf.suit ~= cHeroData.equip4 and 
            --         (conf.color > wearConf.color or (conf.color == wearConf.color and (conf.suit ~= cHeroData.equip2 or conf.suit ~= cHeroData.equip4))) then
            --         if not needPos then
            --             return true
            --         else
            --             posIdx[i] = true
            --             break
            --         end
            --     end
            -- end
        else--查询是否有部件
            for _,v in pairs(armors) do
                local conf = itemConf[v.id]
                if (conf.type % 10) == i then
                    if not needPos then
                        return true
                    else
                        posIdx[i] = true
                        break
                    end
                end
            end
        end
    end

    if table.nums(posIdx) == 0 then
        return false
    end

    return posIdx                
end

function HeroModel:checkOneKeyWear(heroData)
    local init = require "app.models.init"
    local ArmorModel = init.ArmorModel

    local armorBox = heroData.armorBox  --英雄已穿戴装备
    local armors = ArmorModel:getEmptyArmors()  --背包所有装备
    local typeNum = {1,2,3,4,5,6}

    local canWearPos = {}
    local highSuitEquip = {}
    for i=1,6 do
        local wear = armorBox[i]
        local wearConf = wear and itemConf[wear.id]
        for k,v in pairs(armors) do
            local conf = itemConf[v.id]
            local isCurPos = (conf.type % 10) == i
            if not wear and isCurPos then
                canWearPos[i] = true
            elseif wear and isCurPos and conf.color > wearConf.color then
                
            -- elseif wear and isCurPos then
                if not highSuitEquip[conf.suit] then
                    highSuitEquip[conf.suit] = {color = conf.color, pos = {}}
                end
                table.insert(highSuitEquip[conf.suit].pos, i)
            end
        end
    end

    local curEquipColor = 0
    for _,info in pairs(highSuitEquip) do
        if #info.pos >= 2 and info.color > curEquipColor then
            curEquipColor = info.color
            for _,n in pairs(info.pos) do
                canWearPos[n] = true
            end
        end
    end

    if table.nums(canWearPos) == 0 then
        canWearPos = nil
    end

    return canWearPos
end

function HeroModel:checkEquipLevelUp(heroData)
    --英雄穿戴的装备可以强化
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local flag = false
    local lv = PlayerModel.info.level
    local armorBox = heroData.armorBox  --英雄已穿戴装备

    local minK = nil
    for k,armorHero in pairs(armorBox) do
        if minK == nil then 
            minK = k 
        end

        local minData = armorBox[minK]
        if armorHero.level < minData.level then
            minK = k
        elseif armorHero.level == minData.level then
            if itemConf[armorHero.id].color < itemConf[minData.id].color then
                minK = k
            end
        end
    end

    if minK then
        local minData = armorBox[minK]
        local ratio = itemConf[minData.id].refineRatio
        local equipUpExp = levelUpConf[minData.level].equipUpExp
        local canUp = true
        for i,v in ipairs(equipUpExp) do
            if Helper.getItemOrCurrencyCnt(v.id) < math.floor(v.n * ratio) then
                canUp = false
                break
            end
        end
        flag = canUp

        if minData.level >= lv or lv == 1 then
            flag = false
        end
    end

    return flag
end

function HeroModel:checkAwake(heroData)
    ---英雄觉醒
    local init = require "app.models.init"
    local RedTipsModel = init.RedTipsModel

    if not Helper.getOpenState(121, true) then
        return false
    end

    local flag = HeroModel:checkAwakeLv(heroData)
    if not flag then
        flag = HeroModel:checkAwakePw(heroData)
        if not flag then
            flag = HeroModel:checkAwakeJb(heroData)
            if not flag then
                flag = RedTipsModel:hasNewSkin(heroData.id)
            end
        end
    end
    return flag
end

function HeroModel:checkAwakeLv(heroData)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local ItemModel = init.ItemModel

    if #awakeStageConf[heroData.awkLv].stageCostNum == 0 then --最高等级
        return false
    end

    if awakeLevelConf[heroData.awkPw].awakeStageLimit > heroData.awkLv 
        and awakeLevelConf[heroData.awkJb].awakeStageLimit > heroData.awkLv then --宿命和忍道都达到当前觉醒等级的最高等级

        local enough = true
        for k,v in ipairs(heroConf[heroData.id].awakeCostId) do
            local hasNum = 0
            if itemConf[v] then
                local needItem = ItemModel:getItem(v)
                hasNum = needItem and needItem.number or 0
            elseif currencyConf[v] then
                hasNum = PlayerModel:getPlayerCurrency(v)
            end

            local needNum = awakeStageConf[heroData.awkLv].stageCostNum[k]
            if needNum > hasNum then
                enough = false
                break
            end
        end

        if enough then
            local needLevel = awakeStageConf[heroData.awkLv].herolevelLimit
            if not needLevel or heroData.level < needLevel then
                enough = false
            end
        end

        return enough
    end
    return false
end

function HeroModel:checkAwakePw(heroData)
    local init = require "app.models.init"
    local ItemModel = init.ItemModel

    local pwLevel = heroData.awkPw

    if awakeLevelConf[pwLevel].powerLevelCostNum == 0 then
        return false
    end

    if awakeLevelConf[pwLevel].awakeStageLimit > heroData.awkLv then
        return false
    end

    local needItemId = nil
    for k,v in ipairs(heroConf[heroData.id].powerLevelCostId) do
        if pwLevel >= v.lvDown then
            needItemId = v.id
            break
        end
    end

    if needItemId == nil then 
        return false
    else
        local needItem = ItemModel:getItem(needItemId)
        local hasNum = needItem and needItem.number or 0
        if hasNum >= awakeLevelConf[pwLevel].powerLevelCostNum then
            return true
        else
            return false
        end
    end
end

function HeroModel:checkAwakeJb(heroData)
    local init = require "app.models.init"
    local ItemModel = init.ItemModel

    local jbLevel = heroData.awkJb

    if awakeLevelConf[jbLevel].jobLevelCostNum == 0 then
        return false
    end

    if awakeLevelConf[jbLevel].awakeStageLimit > heroData.awkLv then
        return false
    end

    local needItemId = nil
    for k,v in ipairs(heroConf[heroData.id].jobLevelCostId) do
        if jbLevel >= v.lvDown then
            needItemId = v.id
            break
        end
    end

    if needItemId == nil then
        return false
    else
        local needItem = ItemModel:getItem(needItemId)
        local hasNum = needItem and needItem.number or 0
        if hasNum >= awakeLevelConf[jbLevel].jobLevelCostNum then
            return true
        else
            return false
        end
    end
end

function HeroModel:checkSoul(heroData)
    ----英雄护灵
    local init = require "app.models.init"
    local SoulModel = init.SoulModel
    
    if not Helper.getOpenState(47, true) then
        return false
    end
    
    local soulsBox = heroData.soulsBox
    local openData = globalPublicConf[1].openGuardSoulFence
    local allSoul = SoulModel:getSouls()
    local unlockSlot = SoulModel:getSoulUnlockSlot()
    for i=1,7 do
        if i <= unlockSlot then
            if not soulsBox[i] then
                if SoulModel:checkHaveSoul(heroData.id) then
                    return true
                end
            end
        end
    end
    return false
end

function HeroModel:checkFetter(heroData)
    ----英雄羁绊
    local globalPublicConf = require "app.configs.globalPublic"
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local HeroModel = init.HeroModel

    local useData = HeroModel:getHeros()
    local hasActiv = false
    local cData = heroConf[heroData.id]
    if cData then
        local useFetterData = PlayerModel.info.fetter
        local allFetterHero = cData.fetters
        local activData = {}
        if useFetterData and useFetterData.Heros then
            for _,v in ipairs(useFetterData.Heros) do
                if v.HeroID == heroData.id then
                    for _,n in ipairs(v.FetterIDs or {}) do
                        activData[n.HeroId] =  n.StarLv--羁绊英雄上次激活的星级
                    end
                end
            end
        end

        for i,id_ in ipairs(allFetterHero) do
            local heroId = fettersConf[id_].heroFetter

            local curLevel = activData[heroId] or 0
            local fetterStar = globalPublicConf[1].heroFetterStar
            local needStar = fetterStar[curLevel + 1] and fetterStar[curLevel + 1] or fetterStar[#fetterStar] 
            if useData and useData[heroId] --当前有这个英雄
                and useData[heroId].star >= fettersConf[id_].actStar and heroData.star >= fettersConf[id_].actStar--星级足够
                and needStar <= useData[heroId].star and needStar <= heroData.star and curLevel < globalPublicConf[1].heroFettersStarLimit then--当前星级没有激活或升级

                hasActiv = true
                break
            end
        end
    end
    return hasActiv
end

function HeroModel:checkHorcrux(heroData)
    --未开启
    if heroData.level < globalPublicConf[1].heroHorcruxOpenLv then
        return false
    end
    local cost = self:getHeroHorcruxLvUpCost(heroData.id)
    --满级
    if cost.normal == nil then
        return false
    end
    local lvUpConf = levelUpConf[self.heros[heroData.id].horcrux.Lv]
    local limit = lvUpConf.horcruxLvLimit
    --没有达到英雄等级要求
    if heroData.level < limit then
        return false
    end

    local universal = Helper.getItemOrCurrencyCnt(cost.universal)
    --普通消耗
    local hasHorcrux = true
    if Helper.getItemOrCurrencyCnt(cost.normal.id) < cost.normal.n then
        hasHorcrux = false
    end
    --如果有高级消耗判断高级消耗
    if cost.speciel and hasHorcrux and Helper.getItemOrCurrencyCnt(cost.speciel.id) + universal < cost.speciel.n then
        hasHorcrux = false
    end
    -- 独立商店红点
    local init = require "app.models.init"
    local SpecShopModel = init.SpecShopModel
    if SpecShopModel:checkRedTips(1) then
        hasHorcrux = true
    end
    return hasHorcrux
end


function HeroModel:checkEquipStar(heroData)
    ------一键升星------------
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local ItemModel = init.ItemModel

    if not Helper.getOpenState(44, true) then
        return false
    end

    local armorBox = heroData.armorBox
    local flag = false

    local minK = nil
    for k,armorHero in pairs(armorBox) do
        if minK == nil then
            if itemConf[armorHero.id].color >= globalPublicConf[1].equipStarLimit[1].down and itemConf[armorHero.id].color <= globalPublicConf[1].equipStarLimit[1].up then
                minK = k
            end
        end

        if minK then
            local minData = armorBox[minK]
            if armorHero.star < minData.star 
                and itemConf[armorHero.id].color >= globalPublicConf[1].equipStarLimit[1].down 
                and itemConf[armorHero.id].color <= globalPublicConf[1].equipStarLimit[1].up then
                minK = k
            elseif armorHero.smtLv == minData.smtLv then
                if itemConf[armorHero.id].color < itemConf[minData.id].color 
                    and itemConf[armorHero.id].color >= globalPublicConf[1].equipStarLimit[1].down 
                    and itemConf[armorHero.id].color <= globalPublicConf[1].equipStarLimit[1].up then
                    minK = k
                end
            end
        end
    end

    if minK then
        local minData = armorBox[minK]
        local needData = itemConf[minData.id].equipStarCost[minData.star+1]
        if needData then
            local useNum = 0
            if itemConf[needData.id] then
                local item = ItemModel:getItem(needData.id)
                useNum = item and item.number or 0
            elseif currencyConf[needData.id] then
                useNum = PlayerModel:getPlayerCurrency(needData.id)
            end
            local needNum = needData.n

            if useNum >= needNum then
                flag=true
            end
            local levelLimit = #itemConf[minData.id].equipStarAttrId
            if minData.star >= levelLimit then
                flag = false
            end
        else
            flag = false
        end
    end
    return flag
end

function HeroModel:checkEquipSmelt(heroData)
    ------一键精炼------------
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local ItemModel = init.ItemModel

    if not Helper.getOpenState(43, true) then
        return false
    end
    
    local flag = false
    local lv = math.floor(PlayerModel.info.level * globalPublicConf[1].smeltUpLimit) --精炼等级上限
    local armorBox = heroData.armorBox

    local minK = nil
    for k,armorHero in pairs(armorBox) do
        if minK == nil then 
            minK = k 
        end

        local minData = armorBox[minK]
        if armorHero.smtLv < minData.smtLv then
            minK = k
        elseif armorHero.smtLv == minData.smtLv then
            if itemConf[armorHero.id].color < itemConf[minData.id].color then
                minK = k
            end
        end
    end

    if minK then
        local minData = armorBox[minK]
        local needData = levelUpConf[minData.smtLv].equipSmeltExp[1]
        if needData then
            local useNum = 0
            if itemConf[needData.id] then
                local item = ItemModel:getItem(needData.id)
                useNum = item and item.number or 0
            elseif currencyConf[needData.id] then
                useNum = PlayerModel:getPlayerCurrency(needData.id)
            end
            local needNum = needData.n * itemConf[minData.id].smeltRatio

            if useNum >= needNum then
                flag=true
            end
            if minData.smtLv >= lv or lv == 1 then
                flag = false
            end
        else
            flag = false
        end
    end
    return flag
end

function HeroModel:checkWearRune(heroData, slot)
    local init = require "app.models.init"
    local RuneModel = init.RuneModel

    if (heroData.level < globalPublicConf[1].levleNum and heroData.star < globalPublicConf[1].starNum)
        or (slot and ((slot == 1 and heroData.level < globalPublicConf[1].levleNum) or (slot == 2 and heroData.star < globalPublicConf[1].starNum))) then
        
        return false
    end

    local runes = RuneModel:getRunes()
    local emptyRunes = RuneModel:getEmptyRunes()
    local heroId = heroData.id
    local isWear = {}
    local hasEmpty = false
    for seq,v in pairs(runes) do
        if heroId == v.heroId and v.heroId ~= 0 then
            isWear[v.slot] = v.id
        elseif v.heroId == 0 then
            hasEmpty = true
        end
    end

    if table.nums(isWear) > 0 then--check better
        for idx,id in pairs(isWear) do
            local curLv = runeConf[itemConf[id].type].level
            for _,v in pairs(emptyRunes) do
                if runeConf[itemConf[v.id].type].level > curLv and (not slot or idx == slot) then
                    return true
                end
            end
        end

        if (not slot and table.nums(isWear) < 2 and hasEmpty) or ( slot and not isWear[slot] and hasEmpty) then
            return true
        end
    elseif hasEmpty then
        return true
    end
    
    return false
end

function HeroModel:updateAoYi(data)
    local hero = self:getHero(data.Id)
    hero.aoyi = data.AoYi
end

function HeroModel:removeAoYiSkill(heroId)
    local hero = self:getHero(heroId)
    hero.aoyi = false
end

function HeroModel:resetClsGrov(heroId)
    local hero = self:getHero(heroId)
    hero.clsGrov = {0,0,0,0}
end

function HeroModel:getHeroArtifactSkill(heroId)
    local init = require "app.models.init"
    local sqartifactConf = require "app.configs.sqartifact"
    local ArtifactModel = init.ArtifactModel
    local skillInfo = nil
    for k,v in ipairs(sqartifactConf) do
        if v.heroId == heroId then
            if ArtifactModel:checkRunesTerm(v.artifactId, v) then
                return heroConf[heroId].artifactSkill[1]
            end
        end
    end
    return skillInfo
end

function HeroModel:addNewSkin(heroId, skinId)
    local heroData = self.heros[heroId]
    if not heroData then return end
    table.insert(heroData.skin, skinId)
end

function HeroModel:checkGem(useData)
    local gemHoleConf = require "app.configs.gemHole"
    
    if not Helper.getOpenState(147, true) then
        return false
    end

    local gemsBox = useData.gemsBox or {}
    for i,v in ipairs(gemHoleConf) do
        if not gemsBox[v.holeId] then
            local addTip = HeroModel:checkGemHole(v.holeId)
            if addTip then
                return true
            end
        end
    end
    return false
end

function HeroModel:checkGemHole(holeId)
    local init = require "app.models.init"
    local gemHoleConf = require "app.configs.gemHole"
    local itemConf = require "app.configs.item"
    local GemModel = init.GemModel

    local gems = GemModel:getCanEquipGems()
    local gemType = gemHoleConf[holeId].gemType
    for _,k in pairs(gems) do
        local itemData = itemConf[k.id]
        if itemData.type == gemType then
            return true
        end
    end
    return false
end
--前五排名
function HeroModel:updateHeroRank()
    local c = require "app.configs.constants"
    local tmp = table.values(self.heros)
    table.sort(tmp, function (fir, sec)
        if fir.atkPwr == sec.atkPwr then
            return fir.id < sec.id
        else
            return fir.atkPwr > sec.atkPwr
        end
    end)
    for i=1,#tmp do
        self.heros[tmp[i].id].rank = i
    end
end

function HeroModel:isMainHero(heroId)
    local c = require "app.configs.constants"
    if self.heros[heroId] == nil then
        return false
    else
        return self.heros[heroId].rank <= c.MAIN_HERO_RANK
    end
end

function HeroModel:isPartnerHero(heroId)
    for _,info in pairs(fettersConf) do
        --只有主英雄的羁绊才算羁绊英雄
        if info.heroFetter == heroId and self.heros[info.heroMaster] ~= nil and self:isMainHero(info.heroMaster) then
            return true
        end
    end
    return false
end

--------------------------魂器----------------------------
function HeroModel:heroHorcruxLevelUp(data)
    self.heros[data.Id].horcrux.Lv = data.Lv
end

function HeroModel:heroHorcruxPolish(data)
    if data.GuardCnt == 10 then
        self.heros[data.Id].horcrux.GuardCnt = 0
    else
        self.heros[data.Id].horcrux.GuardCnt = data.GuardCnt or 0
    end
end

function HeroModel:heroHorcruxXPropsLock(data)
    if self.heros[data.Id].horcrux.XProps == nil then
        self.heros[data.Id].horcrux.XProps = {}
    end
    self.heros[data.Id].horcrux.XProps[data.Slot].Lock = data.Lock
end

function HeroModel:heroHorcruxXProps(data)
    self.heros[data.Id].horcrux.XProps = data.XProps
end

function HeroModel:getHorCruxHeroes(curHeroId)
    local heroes = {}
    local tmp = {}
    local curIdx = 1
    for _,hero in pairs(self.heros) do
        local lv = hero.level or 0
        if lv >= globalPublicConf[1].heroHorcruxOpenLv then
            table.insert(tmp, hero)
        end
    end
    table.sort(tmp, function (fir, sec)
        if fir.level ~= sec.level then
            return fir.level > sec.level
        else
            if fir.star ~= sec.star then
                return fir.star > sec.star
            else
                if fir.cls ~= sec.cls then
                    return fir.cls > sec.cls
                else
                    return heroConf[fir.id].sequence > heroConf[sec.id].sequence
                end
            end
        end
    end)
    for i,hero in ipairs(tmp) do
        if curHeroId == hero.id then
            curIdx = i
        end
    end
    return tmp, curIdx
end

function HeroModel:getHeroHorcruxLvUpCost(heroId)
    local hero = self.heros[heroId]
    local lvUpConf = levelUpConf[hero.horcrux.Lv]
    local cost = {}
    --normal
    cost.normal = lvUpConf.horcruxLvCost[1]
    --add
    if lvUpConf.horcruxLvAddNum > 0 then
        cost.speciel = {id = heroHorcruxConf[heroId].addCostId, n = lvUpConf.horcruxLvAddNum}
    end
    --万能材料
    cost.universal = heroHorcruxConf[heroId].universal
    return cost
end
--------------------------魂器----------------------------

return HeroModel
