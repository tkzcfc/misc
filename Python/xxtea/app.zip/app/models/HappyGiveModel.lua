
local HappyGiveModel = class("HappyGiveModel")
local Helper = require "app.Helper"


function HappyGiveModel:ctor()
    self.gridSwitchData = {}
    self.beforeRefreshData = {}
end

--初始化列表
function HappyGiveModel:initGiveList(list)
	if not list then
		return
	end
	self.list = list or {}
	self:updateSwitchData()
end

function HappyGiveModel:updateGridData(data)
	if not self.list then
		self.list = {}
	end
	self.list.Grid = data.Grid
end

function HappyGiveModel:updateRwdsData(data)
	if not self.list then
		self.list = {}
	end
	self.list.Rwds = data.Rwds
end
function HappyGiveModel:getGiveList()
	return self.list
end
function HappyGiveModel:updateSwitchData()
	if not self.list or (not self.list.Grid) or (not self.list.Rwds) then
		return
	end
	self.beforeRefreshData = clone(self.list)
	local gridData = clone(self.list.Grid)
	local rwdsData = clone(self.list.Rwds)
	self.gridSwitchData = {}
	for k, v in ipairs(gridData) do
		self.gridSwitchData[v.Id] = {Index = k, Done = v.Done, Id = v.Id}
	end
end

function HappyGiveModel:updateRefreshCnt()
	if not self.list or (not self.list.RefreshCnt) then
		return
	end
	self.list.RefreshCnt = self.list.RefreshCnt + 1
end
function HappyGiveModel:updateRefreshRwdCnt()
	if not self.list or (not self.list.RefreshRwdCnt) then
		return
	end
	self.list.RefreshRwdCnt = self.list.RefreshRwdCnt + 1
end

-- 转换抽取的数字
function HappyGiveModel:switchUpdateNumber(number,isGrid)
	if isGrid then
		self:updateNumberStatus(number,isGrid)
		if self.gridSwitchData[number] then
			self.gridSwitchData[number].Done = true
			return self.gridSwitchData[number]
		end
	end
	return nil
end

function HappyGiveModel:updateNumberStatus(number,isGrid)
	if not self.beforeRefreshData or (not self.beforeRefreshData.Grid) or (not self.beforeRefreshData.Rwds) then
		return
	end
	local gridData = self.beforeRefreshData.Grid
	local rwdsData = self.beforeRefreshData.Rwds
	if isGrid then
		for k,v in ipairs(gridData) do
			if v.Id == number then
				self.beforeRefreshData.Grid[k].Done = true
			end
		end
	else
		for k,v in ipairs(rwdsData) do
			if v.Id == number then
				self.beforeRefreshData.Rwds[k].Done = true
			end
		end
	end
end

return HappyGiveModel