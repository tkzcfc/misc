--ValleyModel.lua

local Helper = require "app.Helper"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local cjgskillConf = require "app.configs.cjgskill"
local cjgdevelopConf = require "app.configs.cjgdevelop"
local cjgConf = require "app.configs.cjg"
local itemConf = require "app.configs.item"


local ValleyModel = class("ValleyModel")

function ValleyModel:ctor()
	
end

function ValleyModel:checkSkillRedTips(skillId, index)
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local HeroModel = init.HeroModel
	local ItemModel = init.ItemModel
    
    local heros = {}
    for i,heroId in ipairs(cjgskillConf[skillId].clear) do----检查英雄是否凑齐
    	local heroData = HeroModel:getHero(heroId)
    	if heroData then
            table.insert(heros, heroData)
    	else
    		return false
    	end 
    end
    local lvId = PlayerModel.info.cjg[skillId] or 1
    if lvId < #cjgdevelopConf then ---检查是否可升级
    	local canUpgrade = true
        for i,v in ipairs(cjgdevelopConf[lvId].consume) do
        	if v.caseid == index then
                local myCnt = ItemModel:getItem(v.id) and ItemModel:getItem(v.id).number or 0
                if v.n > myCnt then
                	canUpgrade = false
                end 
        	end
        end
        if canUpgrade then
        	return true
        end
    else---检查英雄是否可激活技能
    	for i,data in ipairs(heros) do
    	    if not data.aoyi then
    	    	local limit = cjgskillConf[skillId].aoYiUnlockCond
    	    	if (lvId >= limit[1]) and (data.star >= limit[2]) and (data.cls >= limit[3]) then 
    	    		return true   	    		
    	    	end
    	    end
        end
    end
   
    return false
end

function ValleyModel:checkAoYiRedTips(index)
	for i,id in pairs(cjgConf[index].aoyiSkill) do
	 	if self:checkSkillRedTips(id, index) then
			return true
		end
	end 
	return false
end

function ValleyModel:checkSutraRedTips()
	if Helper.getOpenState(141, true) then
		for i,v in pairs(cjgConf) do
			if self:checkAoYiRedTips(v.id) then
				return true
			end
		end
	end
	return false
end


function ValleyModel:setKingFightStage(data)
    if data and data.Stage and data.LeftSec then
        local tData = {}
        tData.time = data.LeftSec
        tData.stage = data.Stage
        self.kingFightStage = tData
    end
end

function ValleyModel:getKingFightStage()
    return self.kingFightStage
end


function ValleyModel:checkTrialRedTips(data)
    local hhsslhitAchieveConf = require "app.configs.hhsslhitAchieve"
    local hhsslBattleConf = require "app.configs.hhsslBattle"
    local enums = require "app.network.enums"
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local infoData = data or self.trialData 
    if not infoData then return false end
    self.trialData = infoData
    ---- 检查宝箱
    for k,v in pairs(hhsslhitAchieveConf) do
        if not self.trialData.TakenAchv[v.id] and (self.trialData.KillCnt >= v.hit) then
            return true
        end
    end
    -----检查体力和奖励
    for k,v in pairs(hhsslBattleConf) do
        if v.id == self.trialData.Stage then
            if self.trialData.MaxHp <= self.trialData.DecHp then 
                return true
            else
                local number = PlayerModel:getCounterByID(enums.Cnt_Hhssl_StrengthPoint)
                if number > 0 then
                    return true
                end
            end
        end 
    end
   
    return false      
end

return ValleyModel
