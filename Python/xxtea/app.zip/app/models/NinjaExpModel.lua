local NinjaExpModel = class("NinjaExpModel")
local Helper = require "app.Helper"
local msgids = require "app.network.msgids"
local ninjaExpQuestConf = require "app.configs.ninjaExpQuest"
local ninjaExpShopConf = require "app.configs.ninjaExpShop"

NinjaExpModel.STATE = {
	PREPARE = 1, --助力
	OPEN = 2,--开启
	END = 3,--结束
	CLOSE = 4, --关闭
}

NinjaExpModel.LOGSAVECNT = 50

function NinjaExpModel:ctor()
	self:reset()
end

function NinjaExpModel:reset()
	self.state = self.STATE.CLOSE
	self.openTimes = 1

	self.worshipCnt = 0 --今日膜拜次数
	self.signIn = false --是否助力

	self.questDone = 0 --任务完成数
	self.questTaken = {} --任务已领取

	self.buyCnt = {} --已购买物品次数

	self.fightData = {} --战斗相关数据
	self.svrData = {} --服务器每阶段时间

	self.team = {} --阵容

	self.myFightLogs = {} --我的日志
	self.allFightLogs = {} --所有日志

	self.myConRank = 0
	self.myTotalRank = 0
end

function NinjaExpModel:init(data)
	self.openTimes = self:getCurOpenTimes()
	self.worshipCnt = data.WorshipCnt or 0
	self.signIn = data.Signin or false
	self.questDone = data.QuestDone or 0
	self.questTaken = data.QuestTaken or {}

	self.buyCnt = data.BuyCnt or {}

	self.fightData = data.Fight or {}
	self.svrData = data.Svr or {}

	-- self.svrData.OpenTick = Helper.getFixedTime() + 3000
	-- self.svrData.StartTick = Helper.getFixedTime() + 3000
	-- self.svrData.EndTick = Helper.getFixedTime() + 3000
	-- self.svrData.CloseTick = Helper.getFixedTime() + 3000

	self.team = data.Team or {}

	self.myConRank = data.ConWinIdx
	self.myTotalRank = data.TotalCWIdx

	self:loadFightState(self.fightData)
	self:loadBuyCntState(self.buyCnt)
end

function NinjaExpModel:getCurState()
	local curTime = Helper.getFixedTime()
	if curTime < self.svrData.OpenTick then
		self.state = self.STATE.CLOSE
	elseif curTime < self.svrData.StartTick then
		self.state = self.STATE.PREPARE
	elseif curTime < self.svrData.EndTick then
		self.state = self.STATE.OPEN
	elseif curTime < self.svrData.CloseTick then
		self.state = self.STATE.END
	else
		self.state = self.STATE.CLOSE
	end

	return self.state
end

function NinjaExpModel:getCurSvrPoint()
	return self.svrData.SvrPoint or 0
end

function NinjaExpModel:addFightLogs(data)
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local myName = PlayerModel.info.name

	if #self.allFightLogs > self.LOGSAVECNT then
		table.remove(self.allFightLogs, 1)
	end
	self.allFightLogs[#self.allFightLogs + 1] = data

	for k,v in ipairs(data) do
		if v.Name == myName then
			if #self.myFightLogs > self.LOGSAVECNT then
				table.remove(self.myFightLogs, 1)
			end
			self.myFightLogs[#self.myFightLogs + 1] = data
			break
		end
	end
end

function NinjaExpModel:getAllFightLogs()
	return self.allFightLogs
end

function NinjaExpModel:getMyFightLogs()
	return self.myFightLogs
end

function NinjaExpModel:handleMsg(op, data)
	if op == msgids.GS_NinjaExpInfo_R then
		self:init(data.Data)
	elseif op == msgids.GS_NinjaExpAllReset then
		self:init(data.Data)
	elseif op == msgids.GS_NinjaExpSign_R then
		self.signIn = true
		self.svrData.SvrPoint = data.SvrPoint
	elseif op == msgids.GS_NinjaExpDailyReset then
		self.worshipCnt = data.WorshipCnt
		self.signIn = data.Signin
	elseif op == msgids.GS_NinjaExpBattle then
		self:addFightLogs(data.Data)
	elseif op == msgids.GS_NinjaExpWorship_R then
		self.worshipCnt = self.worshipCnt + 1
	elseif op == msgids.GS_NinjaExpSetTeam_R then
		self.team = data.Team
	elseif op == msgids.GS_NinjaExpFight then
		self.fightData = data.Fight or {}
	elseif op == msgids.GS_NinjaExpMatch_R then
		if data.TiredVal then
			self.fightData.TiredVal = data.TiredVal
		end
	elseif op == msgids.GS_NinjaExpMatchQuit_R then
		if data.ConWin then
			self.fightData.ConWin = data.ConWin
		end
		if data.TiredVal then
			self.fightData.TiredVal = data.TiredVal
		end
		if data.TiredCnt then
			self.fightData.TiredCnt = data.TiredCnt
		end
		if data.TiredTick then
			self.fightData.TiredTick = data.TiredTick
		end
	elseif op == msgids.GS_NinjaExpGSInfo_R then
		self.svrData = data.Data or {}
		self.worshipCnt = data.WorshipCnt or 0
		self.signIn = data.Signin or false
		-- self.svrData.OpenTick = Helper.getFixedTime() + 3000
		-- self.svrData.StartTick = Helper.getFixedTime() + 3000
		-- self.svrData.EndTick = Helper.getFixedTime() + 3000
		-- self.svrData.CloseTick = Helper.getFixedTime() + 3000

	elseif op == msgids.GS_NinjaExpConWinRank_R then
		if data.Data then
			self.myConRank = data.Data.Idx
		end
	elseif op == msgids.GS_NinjaExpTotalRank_R then
		if data.Data then
			self.myTotalRank = data.Data.Idx
		end
	elseif op == msgids.GS_NinjaExpPointNew then
		self.svrData.SvrPoint = data.SvrPoint
	elseif op == msgids.GS_NinjaExpQuestTake_R then
		local item = ninjaExpQuestConf[data.Id]
        if item.type ~= 1 then
			self.questDone = self.questDone + 1
		end
		table.insert(self.questTaken,data.Id)
	end
end

function NinjaExpModel:loadFightState(data)
	local FIGHT = {
		FightCnt = 10,
		WinCnt = 11,
		MaxConWin = 12,
	}
	if not self.fightState then
		self.fightState  = {}
	end
	for k,v in pairs(data) do
		if FIGHT[k] then
			self.fightState[FIGHT[k]] = v
		end
	end
end

function NinjaExpModel:loadBuyCntState(data)
	if not self.buyCntState then
		self.buyCntState = {}
	end
	for _,v in pairs(data) do
		local Id = v.Id
		local N = v.N
		self.buyCntState[Id] = N
	end
	for _,v in pairs(ninjaExpShopConf) do
		if not self.buyCntState[v.id] then
			self.buyCntState[v.id] = 0
		end
	end
end

function NinjaExpModel:getFightState()
	return self.fightState or {}
end

function NinjaExpModel:getBuyCntState()
	return self.buyCntState or {}
end

function NinjaExpModel:refreshNinjaExpRedTips()
	local ninjaExpWorshipConf = require "app.configs.ninjaExpWorship"
	local ninjaExpConf = require "app.configs.ninjaExp"
	local c = require "app.configs.constants"

	local curState = self:getCurState()
	local redTips = false
	local timePlayState = c.TIMEPLAY_STATUS.Lock
	local nextStageTime = 0
	if curState == NinjaExpModel.STATE.PREPARE  then
		redTips = not self.signIn
		timePlayState = c.TIMEPLAY_STATUS.SoonOpen

		local openArr = string.split(ninjaExpConf[self.openTimes].dayOpen, ':')
	    local openHour, openMin = openArr[1], openArr[2]
	    local startTs = os.date("*t", self.svrData.StartTick)
	    local firstStartTime = os.time({year = startTs.year, month = startTs.month, day = startTs.day, hour = openHour, min = openMin, sec = 0})
		-- nextStageTime = self.svrData.StartTick - Helper.getFixedTime()
		nextStageTime = firstStartTime - Helper.getFixedTime() --第一次开的时间
	elseif curState == NinjaExpModel.STATE.OPEN then
	    local openArr = string.split(ninjaExpConf[self.openTimes].dayOpen, ':')
	    local endArr = string.split(ninjaExpConf[self.openTimes].dayClose, ':')
	    local openHour, openMin = openArr[1], openArr[2]
	    local endHour, endMin = endArr[1], endArr[2]
	    
	    local startTs = os.date("*t", self.svrData.StartTick)
	    local firstStartTime = os.time({year = startTs.year, month = startTs.month, day = startTs.day, hour = openHour, min = openMin, sec = 0})
	    local firstEndTime = os.time({year = startTs.year, month = startTs.month, day = startTs.day, hour = endHour, min = endMin, sec = 0})
	    local curTime = Helper.getFixedTime()
	    local curCanFight = false
	    while true do
	        if curTime < firstStartTime then
	            curCanFight = false
	            nextStageTime = firstStartTime - curTime
	            break
	        elseif curTime < firstEndTime then
	            curCanFight = true
	            nextStageTime = firstEndTime - curTime
	            break
	        end
	        firstStartTime = firstStartTime + 24*3600
	        firstEndTime = firstEndTime + 24*3600
	        if firstStartTime >= self.svrData.EndTick then--最后一天打完 距离EndTick的时间
	            nextStageTime = self.svrData.EndTick - curTime
	            break
	        end
	    end
	    redTips = curCanFight

	    timePlayState = curCanFight and c.TIMEPLAY_STATUS.Open or c.TIMEPLAY_STATUS.NotOpen
	elseif curState == NinjaExpModel.STATE.END then
		redTips = self.worshipCnt < ninjaExpWorshipConf[self.openTimes].worship
		timePlayState = c.TIMEPLAY_STATUS.SoonClose
		nextStageTime = self.svrData.CloseTick - Helper.getFixedTime()
	elseif curState == NinjaExpModel.STATE.CLOSE then
		timePlayState = c.TIMEPLAY_STATUS.Close
	end

	return redTips, nextStageTime, timePlayState
end

function NinjaExpModel:getTimePlayTimeStr()
	local ninjaExpConf = require "app.configs.ninjaExp"
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	local openTimeTab = os.date("*t", PlayerModel.info.svrOpenTs)
	local openSvrTs = os.time({year = openTimeTab.year, month = openTimeTab.month, day = openTimeTab.day, hour = 0, min = 0, sec = 0})
	local curTime = Helper.getFixedTime()

	local getTime = function(t)
		local time = string.split(t, '@')[2]
		local timeArr = string.split(time, '-')
		local day = timeArr[1] or 0
		local hour = timeArr[2] or 0
		local min = timeArr[3] or 0
		return day, hour, min
	end

	local openD, closeD, openH, closeH = nil, nil, nil, nil
	for k,v in ipairs(ninjaExpConf) do
		local openDay, openHour, openMin = getTime(v.start)
		local closeDay, closeHour, closeMin = getTime(v.close)
		local endDay, endHour, endMin = getTime(v.endTime)
		local closeTs = openSvrTs + (closeDay+1) * 24 * 3600 + closeHour * 3600 + closeMin * 60
		if curTime < closeTs or k == #ninjaExpConf then
			openD = openDay + 1
			closeD = endDay + 1
			openH = v.dayOpen
			closeH = v.dayClose
			break
		end
	end

	return openD, closeD, openH, closeH
end

function NinjaExpModel:getCurOpenTimes()
	local ninjaExpConf = require "app.configs.ninjaExp"
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	local openTimeTab = os.date("*t", PlayerModel.info.svrOpenTs)
	local openSvrTs = os.time({year = openTimeTab.year, month = openTimeTab.month, day = openTimeTab.day, hour = 0, min = 0, sec = 0})
	local curTime = Helper.getFixedTime()
	local openTimes = 1
	for k,v in ipairs(ninjaExpConf) do
		local time = string.split(v.hotOpen, '@')[2]
		local timeArr = string.split(time, '-')
		local day = timeArr[1] or 0
		local hour = timeArr[2] or 0
		local min = timeArr[3] or 0

		local hotOpenT = openSvrTs + day * 24*3600 + hour * 3600 + min * 60
		if curTime < hotOpenT then
			break
		else
			openTimes = k
		end
	end
	return openTimes
end

function NinjaExpModel:checkNinjaTaskRedTips()
	local ninjaExpQuestConf = require "app.configs.ninjaExpQuest"
	if not self.fightState then
		self:loadFightState(self.fightData)
	end
	local takens = {}
	local addtips = false
	for k,v in pairs(self.questTaken) do
        takens[v] = v
	end
	local confs = {}
	for _,v in pairs(ninjaExpQuestConf) do
		if v.confkey == self.openTimes then
			table.insert(confs,v)
		end
	end
	for _,v in pairs(confs) do
		if v.type == 1 then
			if not takens[v.id] and self.questDone >= v.cond then
				addtips = true
				break
			end
		else
			if not takens[v.id] and self.fightState[v.type] and self.fightState[v.type] >= v.cond then
				addtips = true
				break
			end
		end
	end
	Helper.sendEvent("refreshNinjaTaskRedTips", {addtips= addtips})
end

return NinjaExpModel