--
-- Author: hexianxiong
-- Date: 2018-03-07 11:42:51
--

local msgids = require "app.network.msgids"
local network = require "app.network.network"
local Helper = require "app.Helper"
local c = require "app.configs.constants"

local PayModel = class("PayModel")

function PayModel:ctor()
	self.billProduct = {}
	self.billCard = nil
end

function PayModel:updateConf(conf)
	self.billProduct = conf

	--default ShowPrice
	for i, conf in pairs(self.billProduct) do
		self.billProduct[i].ShowPrice = c.CURRENCY_TYPE[conf.Ccy]..conf.Price/100
	end
end

function PayModel:getConfById(id)
	for _, conf in pairs(self.billProduct) do
		if conf.Id == id then
			return conf
		end
	end
	return nil
end
--目前仅用于获取挂机加速卡
function PayModel:getConfTypeId(typeId)
	for _, conf in pairs(self.billProduct) do
		if conf.TypeId == typeId then
			return conf
		end
	end
	return nil
end

function PayModel:getConfByIdAndPayPlatform(ids)
	for _,id in ipairs(ids or {}) do
		for _, conf in pairs(self.billProduct) do
			if conf.Id == id and conf.PlatformId == PAY_PLATFORM then
				return conf
			end
		end
	end
	return nil
end

function PayModel:getConfByGiftId(giftId)
	for _, conf in pairs(self.billProduct) do
		if conf.GiftId == giftId and conf.PlatformId == PAY_PLATFORM then
			return conf
		end
	end
	return nil
end

function PayModel:updateCardInfo(data)
	self.billCard = data.Cards
end

---获取月卡购买状态---
function PayModel:getCardBuyState(Id)
	for i,v in ipairs(self.billCard or {}) do
		if v.TypeId == Id then
			if v.EndTs > Helper.getFixedTime() then
				local endTimeTs = os.date("*t",v.EndTs)
				local curTimeTs = os.date("*t",Helper.getFixedTime())
				--开始活动 0时时间
				local endDayTime = os.time({year = endTimeTs.year, month = endTimeTs.month, day = endTimeTs.day, hour = 0, min = 0, sec = 0})
				--当前天 0时时间
				local curDayTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
				
				local day = (endDayTime - curDayTime)/(24*60*60)
				return day
			else
				return false
			end
		end
	end
	return false
end

--获取奖励领取状态---
function PayModel:getCardRewardState(Id)
	for i,v in ipairs(self.billCard or {}) do
		if v.TypeId == Id then
			if v.RewardTs == 0 then
				return false
			end
			local rewardTimeTs = os.date("*t",v.RewardTs)
			local curTimeTs = os.date("*t",Helper.getFixedTime())
			--开始活动 0时时间
			local rewardDayTime = os.time({year = rewardTimeTs.year, month = rewardTimeTs.month, day = rewardTimeTs.day, hour = 0, min = 0, sec = 0})
			--当前天 0时时间
			local curDayTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})

			if rewardDayTime ~= curDayTime then
			    return false
			else
				return true
			end
		end
	end
	return true
end
--- 改变领取领取时间---
-- function PayModel:changeRewardTime(Id)
-- 	for i,v in ipairs(self.billCard) do
-- 		if v.TypeId == Id then
--             v.RewardTs = Helper.getFixedTime()
-- 		end 
-- 	end
-- end

--检查月卡活动红点--
function PayModel:checkCardRedTips(Id)
	if self:getCardBuyState(Id) then
		if self:getCardRewardState(Id) then
			return false
		else
			return true
		end
	else
		return false
	end
end

--sdk回传支付信息
function PayModel:updateBillProduct(sdkBillInfo)
	for i, conf in pairs(self.billProduct) do
		if conf.StoreId and sdkBillInfo[conf.StoreId] then
			local showPrice = sdkBillInfo[conf.StoreId]
			self.billProduct[i].ShowPrice = showPrice
		end
	end
end

return PayModel