
local wfObjvConf = require "app.configs.wfObjv"

local WorldFightModel = class("WorldFightModel")

function WorldFightModel:ctor()
	self.briefs = {}
	self.goals = {}
	self.boxGoals = {}
	self.hasRewards = false
	self.grade = nil
	self.upgrade = false
end

function WorldFightModel:resetUpgrade()
	self.upgrade = false
end

function WorldFightModel:addFightBriefing(data)
	table.insert(self.briefs, 1, data)

	while(#self.briefs > 5) do
		table.remove(self.briefs, #self.briefs)
	end
end

function WorldFightModel:updatePlrWData(data)
	local completeCnt = 0
	local taken = {}
	self.goals = {}
	self.boxGoals = {}
	self.hasRewards = false

	local grade = data.Grade
	if self.grade and self.grade > grade then
		self.upgrade = true
	end
	self.grade = grade

	for _, id in pairs(data.RwdTaken or {}) do
		taken[id] = true
	end

	for key, v in pairs(wfObjvConf) do
		local tp = math.floor(key / 1000)

		if tp == 99 then
			table.insert(self.boxGoals, {id = key, taken = taken[key]})
		else
			local cnt = 0
			if tp == 1 then
				cnt = data.FightN or 0
			elseif tp == 2 then
				cnt = data.WinN or 0
			elseif tp == 3 then
				cnt = data.ComboN or 0
			elseif tp == 4 then
				cnt = data.LikeN or 0
			end
			table.insert(self.goals, {id = key, cnt = cnt, taken = taken[key], finish = (cnt >= v.p1)})

			if cnt >= v.p1 then
				completeCnt = completeCnt + 1
			end
		end
	end

	for _, v in pairs(self.boxGoals) do
		v.cnt = completeCnt
	end

	self.hasRewards = self:checkHasRewards()
end

function WorldFightModel:checkHasRewards()
	for _, v in pairs(self.boxGoals) do
		if not v.taken and v.cnt >= wfObjvConf[v.id].p1 then
			return true
		end
	end

	for _, v in pairs(self.goals) do
		if not v.taken and v.finish then
			return true
		end
	end

	return false
end

function WorldFightModel:sortGoals()
	table.sort(self.boxGoals, function(a, b) return a.id < b.id end)
	table.sort(self.goals, function(a, b)
		if a.taken and b.taken then
			return a.id < b.id
		elseif a.taken then
			return false
		elseif b.taken then
			return true
		end

		if a.finish and b.finish then
			return a.id < b.id
		elseif a.finish then
			return true
		elseif b.finish then
			return false
		end

		return a.id < b.id
	end)
end

function WorldFightModel:refreshTakeReward(id)
	self:takeReward(id)
	self.hasRewards = self:checkHasRewards()
end

function WorldFightModel:takeReward(id)
	for _, v in pairs(self.boxGoals) do
		if v.id == id then
			v.taken = true
			return
		end
	end

	for _, v in pairs(self.goals) do
		if v.id == id then
			v.taken = true
			return
		end
	end
end

return WorldFightModel
