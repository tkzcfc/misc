local msgids = require "app.network.msgids"
local network = require "app.network.network"
local kfbsConf = require "app.configs.kfbs"
local Helper = require "app.Helper"
local RedTipsConfig = require "app.RedTipsConfig"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"

local KfbsModel = class("KfbsModel")

local CS_STAGE = {
    NotStart = 0, --功能未开启
    PreSoonOpen = 1, --预赛待开启
    PreStart = 2, --预赛开始
    PreEnd = 3, --预赛结束
    GroupSoon = 4, --小组赛待开启
    Group = 5, --小组赛开始
    GroupEnd = 6, --小组赛结束
    Champion = 7, --冠军赛开始
    ChaEnd = 8, --冠军赛结束
    Close = 9, ----功能关闭
}

local FIGHT_STATE = {
    NotStart = 1,
    Readying = 2,
    Bets = 3,
    Fighting = 4,
    End = 5,
}

local CS_LEVEL = {
    GEight = 1, --小组赛8强
    GFour = 2, --小组赛4强
    GTwo = 3, --小组赛2强
    GOne = 4, --小组赛冠军
    CFour = 5, --冠军赛4强
    CTwo = 6, --冠军赛2强
    COne = 7, --冠军赛冠军
}

function KfbsModel:ctor()
    self.initInfo = false
	self.info = {}--预赛信息
    self.chaInfo = {}--冠军赛信息
    self.preNewLog = {}--预赛未读战报
    self.chaNewLog = {}--冠军赛赛未读战报
end

function KfbsModel:handleMsg(op, data)
    if op == msgids.GS_KfbsInfo_R then--====预赛=====--
        self.initInfo = true
        self.info = data.Data
        self.info.LadderIdx = data.Data.LadderIdx or 0
        self.info.LadderHisIdx = data.Data.LadderHisIdx or 0
        if self.info.CurStage and self.info.CurStage.Stage >= CS_STAGE.PreEnd then
            network.tcpSend(msgids.C_KfbsChampionInfo)
        end
        self:getLocalLog()
        -- dump(data.Data,"=======杯赛==========",2)
    elseif op == msgids.GS_KfbsSvrStage then
        self.info.CurStage = data.CurStage
        if self.info.CurStage.Stage >= CS_STAGE.PreEnd then
            network.tcpSend(msgids.C_KfbsChampionInfo)
        end
    elseif op == msgids.GS_KfbsLadderGuess_R then
        if not self.info.LadderGuess then
            self.info.LadderGuess = {}
        end
        table.insert(self.info.LadderGuess, data.PlrId)
    elseif op == msgids.GS_KfbsLadderReport then
        if not self.info.LadderRep then
            self.info.LadderRep = {}
        end
        table.insert(self.info.LadderRep, data.Rep)
        self:addNewLog(data.Rep)
        --刷新我的排名
        if data.Rep then
            local init = require "app.models.init"
            local PlayerModel = init.PlayerModel
            if data.Rep.AtkPlrId == PlayerModel.info.userId then
                self.info.LadderIdx = data.Rep.AtkIdx
            elseif data.Rep.DefPlrId == PlayerModel.info.userId then
                self.info.LadderIdx = data.Rep.DefIdx
            end
        end
    elseif op == msgids.GS_KfbsLadderBuyCnt_R then
        self.info.LadderBuyCnt = self.info.LadderBuyCnt + data.Cnt
    elseif op == msgids.GS_KfbsLadderSetTeam_R then
        self.info.LadderTeam = data.Team
    elseif op == msgids.GS_KfbsLadderOneKey_R
    or op == msgids.GS_KfbsLadderFight_R then
        self.info.LadderCnt = self.info.LadderCnt + 1
        if data.IsWin and data.Idx and data.Idx > 0 then
            self.info.LadderIdx = data.Idx
            if data.Idx > self.info.LadderHisIdx then
                self.info.LadderHisIdx = data.Idx
            end
        end
    elseif op == msgids.GS_KfbsResetDaily then
        self.info.LadderCnt = data.LadderCnt
        self.info.LadderBuyCnt = data.LadderBuyCnt
        self.info.LadderLike = data.LadderLike
        self.info.ChampionLike = data.ChampionLike
    elseif op == msgids.GS_KfbsChampionInfo_R then--====冠军赛=====--
        self.chaInfo = data or {}
        self.chaInfo.Guess = data.Guess or 0
        -- self:getLocalLog()
    elseif op == msgids.GS_KfbsChampionGuess_R then
        if not self.info.ChampionGuess then
            self.info.ChampionGuess = {}
        end
        table.insert(self.info.ChampionGuess, data.Data)
    elseif op == msgids.GS_KfbsChampionGuessGet then
        if not self.info.ChampionGuessGet then
            self.info.ChampionGuessGet = {}
        end 
        table.insert(self.info.ChampionGuessGet, data.Data)
    elseif op == msgids.GS_KfbsChampionGrade then
        if not self.chaInfo.Rep then
            self.chaInfo.Rep = {}
        end
        for k,v in pairs(self.chaInfo.Rec or {}) do
            if v.PlrId == data.Grade.PlrId then
                v.Grade = data.Grade.Val
                break
            end
        end
        local hasRepId = false
        for k,v in pairs(self.chaInfo.Rep) do
            if v.ChpFightCnt == data.Rep.ChpFightCnt then
                v = data.Rep
                hasRepId = true
                break
            end
        end
        if not hasRepId then
            table.insert(self.chaInfo.Rep, data.Rep)
        end
        for k,id in pairs(data.Rep.Report or {}) do
            self:addNewLog(id, true)
        end
        self.chaInfo.Guess = data.Guess 
    elseif op == msgids.GS_KfbsChampionChpPos then
        for k,v in pairs(self.chaInfo.Rec or {}) do
            if v.PlrId == data.Data.PlrId then
                v.ChpPos = data.Data.Val
                break
            end
        end
    elseif op == msgids.GS_KfbsChampionIdx then
        for k,v in pairs(self.chaInfo.Rec or {}) do
            if v.PlrId == data.Data.PlrId then
                v.Idx = data.Data.Val
                break
            end
        end
    elseif op == msgids.GS_KfbsChampionSetTeamr_R then
        local teamCnt = table.nums(data.Team)
        self:setMyTeamNum(teamCnt)
    elseif op == msgids.GS_KfbsChampionLike_R then
        for k,v in pairs(self.chaInfo.Rec or {}) do
            if v.PlrId == data.PlrId then
                v.BeLike = v.BeLike + 1
                break
            end
        end
    elseif op == msgids.GS_KfbsLadderHisIdx then
        self.info.LadderHisIdx = data.LadderHisIdx
    elseif op == msgids.GS_KfbsChampionHisIdx then
        self.info.ChampionHisIdx = data.ChampionHisIdx
    end
end

function KfbsModel:getAllStage()
    return CS_STAGE
end

function KfbsModel:getAllFightState()
    return FIGHT_STATE
end

function KfbsModel:getCurStage()
    local stage = self.info.CurStage and self.info.CurStage.Stage or CS_STAGE.Close
    local time = self.info.CurStage and self.info.CurStage.Next or 0
    return stage, time + 2-----延迟2s拉取数据
end

function KfbsModel:getStageStartTime()
    local time = self.info.CurStage and self.info.CurStage.Tick or 0
    return time > 0 and time or 0
end

function KfbsModel:getChampoinGroup()
    local data = {}
    for k,v in pairs(self.chaInfo.Rec or {}) do
        if v.ChpPos > 0 then
            data[v.ChpPos] = v
        end
    end
    return data
end

function KfbsModel:getOrdinaryGroup(group)
    local data = {}
    for k,v in pairs(self.chaInfo.Rec or {}) do
        if v.Group == group then
            data[v.GrpPos] = v
        end
    end
    return data
end

function KfbsModel:getCurRoundState(round, isChampion)
    local conf = kfbsConf[1]
    local readyT = (isChampion and conf.championReady or conf.groupReady) * 60
    local fightT = (isChampion and conf.championFight or conf.groupFight) * 60
    local stage, nextTime = self:getCurStage()

    local fightType = isChampion and CS_STAGE.Champion or CS_STAGE.Group 
    if stage > fightType then
        return FIGHT_STATE.End
    elseif stage < (fightType-1) then
        return FIGHT_STATE.NotStart
    elseif stage == (fightType-1) then
        -- if round <= 4 then
        --     local time = nextTime - Helper.getFixedTime() + (round-1)*(readyT+fightT)
        --     return FIGHT_STATE.Bets, time
        -- else
        --     return FIGHT_STATE.NotStart
        -- end
        if round == 1 then
            local time = nextTime - Helper.getFixedTime()
            return FIGHT_STATE.Bets, time
        elseif round == 2 then
            local time = nextTime - Helper.getFixedTime() + (readyT+fightT)
            return FIGHT_STATE.Readying, time
        else
            return FIGHT_STATE.NotStart
        end
    end
   
    local sTime = Helper.getFixedTime() - self:getStageStartTime()
    sTime = sTime + readyT ---第一场不用准备---
    local curRound = math.ceil(sTime / (readyT+fightT))

    if round == curRound then
        local time = sTime - (readyT+fightT) * (curRound-1)
        if time >= readyT then
            return FIGHT_STATE.Fighting, fightT-(time-readyT)
        else
            return FIGHT_STATE.Bets, readyT-time
        end
    elseif round < curRound then
        return FIGHT_STATE.End
    elseif round > curRound then
        -- if curRound >= 5 then ---curRound只能为5\6
        --     if round == 7 then
        --         return FIGHT_STATE.NotStart
        --     else
        --         local time = (readyT+fightT)*curRound - sTime + readyT
        --         return FIGHT_STATE.Bets, time
        --     end
        -- else
        --     if round <= 4 then
        --         local time = (readyT+fightT)*curRound - sTime + (round-curRound-1)*(readyT+fightT) + readyT
        --         return FIGHT_STATE.Bets, time
        --     else
        --         return FIGHT_STATE.NotStart
        --     end
        -- end
        if round == (curRound + 1) then
            local time = (readyT+fightT)*curRound - sTime + readyT
            return FIGHT_STATE.Readying, time
        end

        return FIGHT_STATE.NotStart
    end
       
end

function KfbsModel:getPlayerByRound(round, group, isChampion)
    local pData = {}
    local groupData = isChampion and self:getChampoinGroup() or self:getOrdinaryGroup(group)
    if table.nums(groupData) < 8 then
        print("-------小组玩家不足8个--------")
        return pData
    end
    if round <= 4 then
        for i = round*2-1, round*2 do
            table.insert(pData, groupData[i])
        end
    elseif round == 5 then
        for i=1,4 do
            if groupData[i].Grade >= (isChampion and CS_LEVEL.CFour or CS_LEVEL.GFour) then
                table.insert(pData, groupData[i])
            end
        end
    elseif round == 6 then
        for i=5,8 do
            if groupData[i].Grade >= (isChampion and CS_LEVEL.CFour or CS_LEVEL.GFour) then
                table.insert(pData, groupData[i])
            end
        end
    elseif round == 7 then
        for i=1,8 do
            if groupData[i].Grade >= (isChampion and CS_LEVEL.CTwo or CS_LEVEL.GTwo) then
                table.insert(pData, groupData[i])
            end
        end
    end
    return pData
end

function KfbsModel:getWinPosByRound(round, group, isChampion)
    local pData = self:getPlayerByRound(round, group, isChampion)
    local tab = isChampion and "ChpPos" or "GrpPos"
    if #pData > 1 then
        if pData[1].Grade > pData[2].Grade then
            return  pData[1][tab], pData[2][tab]
        elseif pData[2].Grade > pData[1].Grade then
            return pData[2][tab], pData[1][tab]
        else
            print("------该回合平局--------", round)
        end
    else
        print("------该回合玩家取不到--------", round)
    end
    return nil
end

--======战报========
function KfbsModel:getLocalLog()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local lastPreLog = RedTipsConfig.getSetting("CSPreLog", {})
    for k,v in pairs(self.info.LadderRep or {}) do
        if not lastPreLog[v.Id] and v.DefPlrId == PlayerModel.info.userId then
            table.insert(self.preNewLog, v.Id)
        end
    end
    local lastChaLog = RedTipsConfig.getSetting("CSChaLog", {})
    for _,v in pairs(self.chaInfo.Rep or {}) do
        for _,k in pairs(v.Reportv or {}) do
            if not lastChaLog[k.Id] then
                table.insert(self.chaNewLog, v.Id)
            end
        end
    end
end

function KfbsModel:addNewLog(data, isChampion)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    
    if isChampion then
        table.insert(self.chaNewLog, data)
    else
        if PlayerModel.info.userId == data.DefPlrId then
            table.insert(self.preNewLog, data.Id)
        end
    end
end

function KfbsModel:removeNewLog(isChampion)
    local logs = {}
    if isChampion then
        for _,v in pairs(self.chaInfo.Rep or {}) do
            for _,k in pairs(v.Reportv or {}) do
                logs[k.Id] = true
            end
        end
        RedTipsConfig.setSetting("CSChaLog", logs)
        self.chaNewLog = {}
    else
        for k,v in pairs(self.info.LadderRep or {}) do
            logs[v.Id] = true
        end
        RedTipsConfig.setSetting("CSPreLog", logs)
        self.preNewLog = {}
    end
end

function KfbsModel:checkIsNewLog(id, isChampion)
    local logs = isChampion and self.chaNewLog or self.preNewLog
    for k,v in pairs(logs or {}) do
        if v == id then
            return true
        end
    end
    return false
end

function KfbsModel:getFgithType(fightCnt)
    local str = ""
    local num = fightCnt%7 + 1
    if num <= 4 then
        if fightCnt >= 56 then
            str = WordDictionary[24328]
        else
            str = WordDictionary[24325]
        end
    elseif num <= 6 then
        if fightCnt >= 56 then
            str = WordDictionary[24329]
        else
            str = WordDictionary[24326]
        end
    else
        if fightCnt >= 56 then
            str = WordDictionary[24327]
        else
            str = WordDictionary[24330]
        end
    end
    return str
end


function KfbsModel:getCurFightCnt(round, group, isChampion)
    local fightCnt = isChampion and 8 * 7 or (group-1) * 7
    fightCnt = fightCnt + round - 1
    return fightCnt
end

function KfbsModel:setMyTeamNum(num)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    for k,v in pairs(self.chaInfo.Rec or {}) do
        if v.PlrId == PlayerModel.info.userId then
            v.TeamNum = num 
            break
        end
    end
end

function KfbsModel:checkGotoChampion()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local Grade = nil
    for k,v in pairs(self.chaInfo.Rec or {}) do
        if v.PlrId == PlayerModel.info.userId then
            Grade = v.Grade
            break
        end
    end
    if Grade and Grade >= CS_LEVEL.GOne then
        return true
    end
    return false
end

function KfbsModel:getSelfGroup()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    for k,v in pairs(self.chaInfo.Rec or {}) do
        if v.PlrId == PlayerModel.info.userId then
            return v.Group
        end
    end
end

function KfbsModel:getReplayByFightTime(round, group, isChampion, time)
    local replayInfo = nil
    local curIndex = 0
    local nextTime = nil
    local conf = kfbsConf[1]

    local fightCnt = self:getCurFightCnt(round, group, isChampion) 
    for k,v in pairs(self.chaInfo.Rep or {}) do
        if v.ChpFightCnt == fightCnt then
            replayInfo = v
            break
        end
    end
    if replayInfo then----根据平均战斗时间获得当前场次
        local fightTime = (isChampion and conf.championFight or conf.groupFight) * 60
        local replayCnt = table.nums(replayInfo.Report)
        if replayCnt > 0 then
            local average = fightTime/replayCnt
            curIndex =  math.ceil((fightTime-time)/average)
            nextTime = time%average
        end
    end
    return replayInfo, curIndex, nextTime
end

function KfbsModel:getFuncOpenState()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local curTime = Helper.getFixedTime()

    local svrOpenTs = os.date("*t", PlayerModel.info.svrOpenTs)
    local svrTs = os.time({year = svrOpenTs.year, month = svrOpenTs.month, day = svrOpenTs.day, hour = 0, min = 0, sec = 0})
    local openTs = svrTs + (kfbsConf[1].openServer-1) * 24 * 60 * 60
    if curTime < openTs then
        return c.TIMEPLAY_STATUS.Lock, 0
    else
        return c.TIMEPLAY_STATUS.Open, 0 
    end 
    -- local openWeek = os.date("%w",openTs)
    -- openWeek = tonumber(openWeek) == 0 and 7 or tonumber(openWeek) 
    -- local funcOpenTs = string.split(kfbsConf[1].open, "/")
    -- local funcOpenWeek = tonumber(funcOpenTs[1])
    -- if openWeek > funcOpenWeek then
    --     openTs = openTs + (7 - openWeek + funcOpenWeek) * 24 * 60 * 60
    -- else
    --     openTs = openTs + (funcOpenWeek - openWeek) * 24 * 60 * 60
    -- end
    -- local timeInfo = string.split(funcOpenTs[2], ":")
    -- local hour, minute = tonumber(timeInfo[1]), tonumber(timeInfo[2])
    -- openTs = openTs + hour * 60 * 60 + minute * 60
    -- if curTime < openTs then
    --     return c.TIMEPLAY_STATUS.SoonOpen, openTs-curTime
    -- else
    --     return c.TIMEPLAY_STATUS.Open, 0
    -- end
end

function KfbsModel:getFuncState()
    if not self.initInfo then
        network.tcpSend(msgids.C_KfbsInfo)
        return c.TIMEPLAY_STATUS.Lock, 0
    end
    local curTime = Helper.getFixedTime()
    local state, delayTime = self:getFuncOpenState()
    local stageName = ""
    if state == c.TIMEPLAY_STATUS.Open then
        local stage, time = self:getCurStage()
        if self.info.Open then
            if stage == CS_STAGE.PreSoonOpen then
                state = c.TIMEPLAY_STATUS.SoonOpen
                stageName = WordDictionary[24361]
                delayTime = time - curTime
            elseif stage == CS_STAGE.PreStart then
                local rank = self.info.LadderIdx
                stageName = WordDictionary[24361] .. (rank > 0 and string.format(WordDictionary[24362], rank) or "")
                state = c.TIMEPLAY_STATUS.Open
                delayTime = time - curTime
            elseif stage == CS_STAGE.PreEnd then
                stageName = WordDictionary[24372] 
                state = c.TIMEPLAY_STATUS.Open
                delayTime = time - curTime
            elseif stage == CS_STAGE.GroupSoon then
                local group = self:getSelfGroup()
                stageName = WordDictionary[24360] .. (group and string.format(WordDictionary[24359], group) or "")
                state = c.TIMEPLAY_STATUS.SoonOpen
                delayTime = time - curTime
            elseif stage == CS_STAGE.Group then
                local group = self:getSelfGroup()
                stageName = WordDictionary[24360] .. (group and string.format(WordDictionary[24359], group) or "")
                state = c.TIMEPLAY_STATUS.Open
                delayTime = time - curTime
            elseif stage == CS_STAGE.GroupEnd then
                local hasMy = self:checkGotoChampion()
                stageName = WordDictionary[24330] .. (hasMy and WordDictionary[24358] or "")
                state = c.TIMEPLAY_STATUS.SoonOpen
                delayTime = time - curTime
            elseif stage == CS_STAGE.Champion then
                local hasMy = self:checkGotoChampion()
                stageName = WordDictionary[24330] .. (hasMy and WordDictionary[24358] or "")
                state = c.TIMEPLAY_STATUS.Open
                delayTime = time - curTime
            elseif stage == CS_STAGE.ChaEnd then
                state = c.TIMEPLAY_STATUS.SoonClose
                delayTime = time - curTime
            elseif stage == CS_STAGE.Close then
                state = c.TIMEPLAY_STATUS.SoonOpen
                delayTime = time - curTime
            elseif stage == CS_STAGE.NotStart then
                state = c.TIMEPLAY_STATUS.SoonOpen
                delayTime = time - curTime
                if (delayTime > 0) and (delayTime <= kfbsConf[1].soonOpen * 60) then
                    stageName = WordDictionary[24361]
                end
            else
                state = c.TIMEPLAY_STATUS.NotOpen
                delayTime = time - curTime
            end
        else
            state = c.TIMEPLAY_STATUS.NotOpen
        end
    end
    delayTime = delayTime or 0
    return state, delayTime, stageName
end

function KfbsModel:getOpenTimeStr()
    local timeStr = string.format(WordDictionary[24523], kfbsConf[1].openServer)
    local preStartTime = string.split(kfbsConf[1].open, "/")
    local preEndTime = string.split(kfbsConf[1].ladderEnd, "/")
    timeStr = timeStr .. WordDictionary[24503] .. WordDictionary[24505 + tonumber(preStartTime[1])].. preStartTime[2].."-"..preEndTime[2].."、"
    local grpStartTime = string.split(kfbsConf[1].groupStart, "/")
    local grpEndTime = string.split(kfbsConf[1].groupEnd, "/")
    timeStr = timeStr .. WordDictionary[24503] .. WordDictionary[24505 + tonumber(grpStartTime[1])].. grpStartTime[2].."-"..grpEndTime[2].."、"
    local chpStartTime = string.split(kfbsConf[1].championStart, "/")
    local chpEndTime = string.split(kfbsConf[1].championEnd, "/")
    timeStr = timeStr .. WordDictionary[24503] .. WordDictionary[24505 + tonumber(chpStartTime[1])].. chpStartTime[2].."-"..chpEndTime[2]
    return timeStr
end

function KfbsModel:getTimedate(time)
    local year = os.date("%Y", time)
    local month = os.date("%m", time)
    local day = os.date("%d", time)
    local str = year.."."..month.."."..day
    return str
end


function KfbsModel:getMyInfoData(isRank)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local data = {}
    for k,v in pairs(self.chaInfo.Rec or {}) do
        if v.PlrId == PlayerModel.info.userId then
            data = v
            break
        end
    end
    if isRank then
        return data.Idx or 0
    else
        return data
    end
    
end

return KfbsModel
