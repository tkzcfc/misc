--推送商城
local RewardRecallModel = class("RewardRecallModel")
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local network = require "app.network.network"

local c = require "app.configs.constants"


function RewardRecallModel:ctor()
    self.RecData = {} -- 奖励列表
end

function RewardRecallModel:initData(data)
    -- dump(data, "self.RecData", 10)
    self.RecData = {}
    for _,info in ipairs(data.ReList or {}) do -- and info.Rewards and #info.Rewards ~= 0
        if Helper.getOpenState(info.OpenId, true) and info.Status == 0 and info.Rewards and #info.Rewards ~= 0 then -- 未开启 或者 已找回 或者 昨日已领取 不在找回列表中存在
            self.RecData[#self.RecData + 1] = info
        end
    end
end
function RewardRecallModel:getRecallData()
    return self.RecData
end
function RewardRecallModel:sendGetRecallData()
    network.tcpSend(msgids.C_ActRewardRecallInfo)
end
function RewardRecallModel:handleMsg(op, msg)
    if op == msgids.GS_ActRewardRecallInfo_R then
        self:initData(msg.Info)
        self:getRecStatus()
    elseif op == msgids.GS_ActRewardRecallTake_R or op == msgids.GS_ActRewardRecallTakeAll_R then
        self:sendGetRecallData()
    end
end

function RewardRecallModel:oneKeyGetCost()
    local getAllCost = 0
    local getHalfCost = 0
    for k,v in ipairs(self.RecData) do
        -- local recData = rewardRecallConf[v.Id]
        getHalfCost = getHalfCost + v.RateList[1].N
        getAllCost = getAllCost + v.RateList[2].N
    end
    return getHalfCost, getAllCost
end

function RewardRecallModel:getRecStatus()
    if (#self.RecData == 0) and (not self.recDataGet) then
        self.recDataGet = true
        network.tcpSend(msgids.C_ActRewardRecallInfo)
    else
        if #self.RecData ~= 0 then
            return true
        end
    end
    return false
end

function RewardRecallModel:getRecRedTips()
    local PlayerConfig = require "sandglass.core.PlayerConfig"
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local check = self:getRecStatus()
    if check then
        return true
    else
        return false
    end
end

return RewardRecallModel