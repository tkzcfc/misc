local MineConf = require "app.configs.mine"
local MineWarConf = require "app.configs.mineWar"
local Helper = require "app.Helper"
local MineWarModel = class("MineWarModel")
function MineWarModel:ctor()
    self:reset()
    self.fightLog = true
end

function MineWarModel:reset()
    self.init = false
    self.mines = {}
    self.superSec = 0
    self.myMine = 1
    self.myModel = 0
    self.myOutput = {}
    self.myTeam = {}

    self.logIdx = -1
    self.log = {}
    self.curLogIdx = 0
end

function MineWarModel:initData(data)
    self:reset()
    self.init = true
    for k,v in ipairs(data.Mines) do
        self:addMine(v)
    end
    self.superSec = data.SuperSec
    self.myMine = data.SelfMine
    self.myModel = data.SelfModel
    self.myOutput = data.SelfOutput or {}
    self.myTeam = data.SelfTeam
end

function MineWarModel:addMine(mine)
    local data = {
        Id = mine.Id,
        State = mine.State,
        Owner = mine.Owner,
        OccupyCD = mine.OccupyCD,
        MinerCnt = mine.MinerCnt,
        Miners = {}
    }
    table.insert(self.mines, data)
end

function MineWarModel:updateMineBaseInfo(data)
    for k,v in ipairs(self.mines) do
        if v.Id == data.Mine.Id then
            v.State = data.Mine.State
            v.Owner = data.Mine.Owner
            v.MinerCnt = data.Mine.MinerCnt
            break
        end
    end
end

function MineWarModel:updateMineDetailInfo(data)
    if data.Mine then
        for k,v in ipairs(self.mines) do
            if v.Id == data.Mine.Id then
                v.State = data.Mine.State
                v.Owner = data.Mine.Owner
                v.OccupyCD = data.Mine.OccupyCD
                v.Miners = data.Mine.Miners or {}
                v.MinerCnt = #v.Miners
                break
            end
        end
    end
end

function MineWarModel:updateSuperMineState(data)
    self.superSec = data.SuperSec
    -- if data.State == 0 then --close
        for k,v in ipairs(self.mines) do
            if MineConf[v.Id].mineType == 5 then
                --self.mines[k] = nil
                local data = {
                    Id = v.Id,
                    State = data.State,
                    Owner = "",
                    OccupyCD = 0,
                    MinerCnt = 0,
                    Miners = {}
                }
                self.mines[k] = data
            end
        end
    -- else
        -- for k,v in ipairs(MineConf) do
        --     if v.mineType == 5 then
        --         local data = {
        --             Id = v.id,
        --             State = 0,
        --             Owner = "",
        --             OccupyCD = 0,
        --             MinerCnt = 0,
        --             Miners = {}
        --         }
        --         table.insert(self.mines, data)
        --     end
        -- end
    --end
end

function MineWarModel:updateMyTeam(data)
    self.myTeam = data.MTeam
end

function MineWarModel:updateMyModel(data)
    self.myModel = data.Model
end

function MineWarModel:updateFightLog(data)
    self.logIdx = data.Idx
    self.curLogIdx = data.Idx
    for k,v in ipairs(data.Log or {}) do
        table.insert(self.log, v)
    end
end

function MineWarModel:updateFightLogIdx(data)
    self.curLogIdx = data.Idx
end

function MineWarModel:onTransMine(data)
    self:updateMineDetailInfo(data)
    self.myMine = data.Mine.Id
end

function MineWarModel:getSuperlMineState()
    local func = function(str,interval) 
        local timeTb = {}
        local timeStr = string.split(str,"|")
        for _,m in ipairs(timeStr) do
            local time = string.split(m,":")
            local hour = time[1] or 0
            local min = time[2] or 0
            local sec = time[3] or 0
            local startTime = tonumber(hour) * 60 * 60 + tonumber(min) * 60 + tonumber(sec)
            local endTime = startTime + interval
            table.insert(timeTb,{startTime = startTime,endTime = endTime})
        end
        return timeTb,timeStr
    end
    local timeTb,timeStr = func(MineWarConf[1].superMineRenovate,MineWarConf[1].superMineTime)
    local open,time,leftTime = false,nil,0
    local nowTimeTb = os.date("*t",Helper.getFixedTime())
    local nowTime = nowTimeTb.hour * 60 * 60 + nowTimeTb.min * 60 + nowTimeTb.sec
    for k,v in ipairs(timeTb) do
        if nowTime < v.startTime then
            open = false
            time = timeStr[k]
            leftTime = v.startTime - nowTime
            break
        elseif nowTime < v.endTime then
            open = true
            time = v.endTime - nowTime 
            break
        else
            open = false
            time = timeStr[1]
        end
    end
    return open,time,leftTime
end

function MineWarModel:getMines()
    return self.mines
end

function MineWarModel:getMineInfoById(id)
    for k,v in pairs(self.mines) do
        if v.Id == id then
            return v
        end
    end
    return nil
end

function MineWarModel:getMyDefendTeam()
    return self.myTeam
end

function MineWarModel:getFightLogInfo()
    return self.log, self.logIdx, self.curLogIdx
end

function MineWarModel:updateMyOutput(data)
    self.myOutput = data.SelfOutput or {}
end

function MineWarModel:onTakeMyOutput()
    self.myOutput = {}
end

return MineWarModel