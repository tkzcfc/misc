-- SpecShopModel.lua 独立商店
local SpecShopModel = class("SpecShopModel")
local specialShopConf = require "app.configs.specialShop"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
function SpecShopModel:ctor()
    self.shopData = {}
end

function SpecShopModel:initShopData(data)
	if not data or not data.Shop then
		return
	end
	for k,v in ipairs(data.Shop or {}) do
		self.shopData[v.Type] = v
	end
end

function SpecShopModel:getShopDataBuyType(curtype)
	return self.shopData[curtype]
end

function SpecShopModel:addOrUpdateShopData(data)
	if self.shopData[data.Type] then
		self.shopData[data.Type].Day = data.Day
		self.shopData[data.Type].Bill = data.Bill
		self.shopData[data.Type].Taken = data.Taken
	else
		self.shopData[data.Type] = {Day = data.Day, Type = data.Type, Bill = data.Bill, Taken = data.Taken}
	end
end

function SpecShopModel:updateShopData(data)
	if not data then
		return
	end
	if data.Type then
		if self.shopData[data.Type] then
			local hasId = false
			for k,v in ipairs(self.shopData[data.Type].Bill) do
				if v.Id == data.Bill then
					v.N = v.N + 1
					hasId = true
				end
			end
			if not hasId then
				table.insert(self.shopData[data.Type].Bill, {Id = data.Bill, N = 1})
			end
		end
	elseif data.Id then
		local curType = specialShopConf[data.Id].type
		if self.shopData[curType] then
			local hasId = false
			for k,v in ipairs(self.shopData[curType].Taken) do
				if v.Id == data.Id then
					v.N = v.N + 1
					hasId = true
				end
			end
			if not hasId then
				table.insert(self.shopData[curType].Taken, {Id = data.Id, N = 1})
			end
		end
	end
end

function SpecShopModel:getCurBuyItemInfo(curType)
	local shopConf = {}
	for k,v in pairs(specialShopConf or {}) do
		if v.type == curType then
			table.insert(shopConf, v)
		end
	end
	table.sort(shopConf, function(a,b)
		return a.id < b.id
	end)
	local curShopData = shopConf[#shopConf]
	for k,v in ipairs(shopConf or {}) do
		if v.limit > self:getTakenCnt(curType,v.id) then
			curShopData = v
			break
		end
	end
	return curShopData
end

function SpecShopModel:checkRedTips(curType)
	local shopInfo = self:getCurBuyItemInfo(curType)
	if shopInfo.limit > self:getTakenCnt(self.curType,shopInfo.id) and Helper.getItemOrCurrencyCnt(shopInfo.costItem[1].id) >= shopInfo.costItem[1].n and shopInfo.giftId == 0 then
		return true
	end
	return false
end

function SpecShopModel:getTakenCnt(curType,id)
	local shopInfo = self:getShopDataBuyType(curType)
	local cnt = 0
	if shopInfo then
		for k,v in ipairs(shopInfo.Taken or {}) do
			if v.Id == id then
				cnt = v.N
			end
		end
	end
	return cnt
end

return SpecShopModel