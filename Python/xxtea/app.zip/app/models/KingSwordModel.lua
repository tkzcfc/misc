--
-- Author: qiaomingwu
-- Date: 2018-11-21 16:42:00
--
local wzzjBoxConf = require "app.configs.wzzjBox"
local wzzjRankTowerConf = require "app.configs.wzzjRankTower"
local wzzjDonateRankConf = require "app.configs.wzzjDonateRank"
local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local c = require "app.configs.constants"
local C = require "app.network.enums"
local buyConf = require "app.configs.buy"
local wzzjDonateConf = require "app.configs.wzzjDonate"

local KingSwordModel = class("KingSwordModel")

local msgnames = {}
for k, v in pairs(msgids) do
    msgnames[v] = k
end

function KingSwordModel:ctor()
	self.kingSword = {}
	self.donationData = nil
	self.thinkPlayers = {}
	self.redBag = {}
	--当前箱子id
	self.boxId = 1
	--未读战报条数
	self.unRead = 0
	self.rankList = {}
	self.warZone = {}
	self.serverInfo = {}
	--每一种类型箱子对应的总个数
	self:initwzzjBox()
	for inx, info in ipairs(buyConf) do
		if info.wzzjTowerBossResist == 0 then
			self.bossRefreshCnt = inx - 1
			break
		end
	end

end

function KingSwordModel:handleMsg(op, data)
	local funcName = "on_" .. (msgnames[op] or "")
    local func = self[funcName]

    if func ~= nil then
        func(self, data)
    end
end

function KingSwordModel:initwzzjBox()
	self.boxInfo = {}
	for _, info in ipairs(wzzjBoxConf) do
		if not self.boxInfo[info.boxType] then
			self.boxInfo[info.boxType] = 1
		else
			self.boxInfo[info.boxType] = self.boxInfo[info.boxType] + 1
		end
	end
end

function KingSwordModel:updateDonationData(data)
	self.donationData = data
	self:updateDonRewardTimes()
end

function KingSwordModel:updateDonRewardTimes()
	if table.nums(self.serverInfo) == 0 
		or self.serverInfo.Rank ~= 1 then
		self.serverInfo.donRewardTimes = 0
	else	
		for _, info in ipairs(wzzjDonateRankConf) do
			if self.donationData.Item.DRank >= info.highestRanking
				and self.donationData.Item.DRank <= info.lowestRanking then
				self.serverInfo.donRewardTimes = info.rewardTime
			end
		end
	end
end

function KingSwordModel:isTakenDonRewards(id)
	for _, takenId in pairs(self.donationData.Taken or {}) do
		if takenId == id then
			return true
		end
	end
	return false
end

function KingSwordModel:getDonData()
	return clone(self.donationData)
end

function KingSwordModel:on_GS_WzzjDonationGrab_R(data)
	if self.donationData.Taken == nil then
		self.donationData.Taken = {}
	end 
	if data.Id then
		table.insert(self.donationData.Taken, data.Id)
	end
end

function KingSwordModel:on_GS_WzzjDonate_R(data)
	self.donationData.Item.DScore = data.Score
	self.donationData.SvrScore = data.SvrScore
end

function KingSwordModel:on_GS_WzzjDonationFeedbackGrab_R(data)
	self.donationData.Item.FbT = data.FbT
end

function KingSwordModel:on_GS_WzzjBGroupInfo_R(data)
	self.warZone.Bid = data.Bid
	self.warZone.Sid = data.Sid
	local zones = {}
	for _, info in pairs(data.Items or {}) do
		zones[info.Sid] = info
	end
	self.warZone.Zones = zones
end

function KingSwordModel:getWarZoneData()
	return clone(self.warZone)
end

function KingSwordModel:getMyServerDoaScores()
	return self.donationData.SvrScore or 0
end

function KingSwordModel:on_GS_WzzjFighterInfo_R(data)	
	self.towerInfo = data.Info
	self:checkUpdate(data)
end

function KingSwordModel:on_GS_WzzjPlayGoNext_R(data)
	self.towerInfo = data.Info
	self:checkUpdate(data)
end

function KingSwordModel:on_GS_WzzjPlayOperate_R(data)
	self.towerInfo = data.Info
	self:checkUpdate(data)
end

function KingSwordModel:on_GS_WzzjNextFloor_R(data)
	self.towerInfo = data.Info
	self:checkUpdate(data)
end

function KingSwordModel:on_GS_WzzjChestGrab_R(data)
	self.towerInfo.FInfo.CInfo.Rank = data.Rank
end

function KingSwordModel:on_GS_WzzjChestInfo(data)
	if self.towerInfo then
		self.towerInfo.FInfo.CInfo.Cnt = data.Cnt
	end
end

function KingSwordModel:on_GS_wzzjUpdateScore(data)
	self.towerInfo.Rank = data.Seq
	self.towerInfo.Score = data.Score
end

function KingSwordModel:on_GS_WzzjUpdateRPack(data)
	network.tcpSend(msgids.C_WzzjRPackInfo)
end

function KingSwordModel:on_GS_WzzjRPackInfo_R(data)
	self.redBag = {}
	self.redBag.Cnt = data.Cnt
	self.redBag.Amount = data.Amount 
	self.redBag.Last = data.Last 
	self.redBag.List = data.List or {} 
	self:setRedGotMsg()
end

function KingSwordModel:on_GS_WzzjBossResistFresh_R(data)
	self.towerInfo.FInfo.BInfo.Boss = data.Boss
end

function KingSwordModel:on_GS_WzzjServerInfo_R(data)
	self.serverInfo = data.Info or {}
	self:updateDonRewardTimes()
end

function KingSwordModel:on_GS_WzzjRepGrab_R(data)
	if data.Info then
		self.unRead = data.Info.Unread
	else
		self.unRead = 0
	end
end

function KingSwordModel:on_GS_WzzjRepUnread(data)
	self.unRead = data.Unread
end

function KingSwordModel:getUnRead()
	return self.unRead
end

function KingSwordModel:getServerInfo()
	return clone(self.serverInfo)
end

function KingSwordModel:on_GS_WzzjBossBattle_R(data)
	self.towerInfo.FInfo.BInfo.Boss = data.Boss
end

function KingSwordModel:on_GS_WzzjBossBoxGrab_R(data)
	self.towerInfo.FInfo.BInfo.Boss = data.Boss
end

function KingSwordModel:setRedGotMsg()
	self.redBag.canGet = true
	if self.redBag.Cnt == nil then
		return
	end
	self.redBag.GotNum = table.nums(self.redBag.List)
	local scores = 0
	--已经领取完
	if self.redBag.GotNum >= self.redBag.Cnt then
		self.redBag.canGet = false
	else--自己已领取
		for _, info in pairs(self.redBag.List or {}) do
			scores = scores + info.Amount
			local init = require "app.models.init"
			local PlayerModel = init.PlayerModel
			if info.Pid == PlayerModel.info.userId then
				self.redBag.canGet = false
			end
		end
	end
	self.redBag.GotScore = scores
end

function KingSwordModel:on_GS_WzzjRPackGrab_R(data)
	self.towerInfo.Score = self.towerInfo.Score + data.Score
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	for inx, info in pairs(self.redBag.List or {}) do
		if info.Name == PlayerModel.info.name then
			self.redBag.List[inx] = {Name = PlayerModel.info.name, Amount = data.Score}
			return
		end
	end
	self.redBag.List[#self.redBag.List + 1] = {Name = PlayerModel.info.name, Pid = PlayerModel.info.userId, Amount = data.Score}
	self:setRedGotMsg()
end

function KingSwordModel:getOwnGetRedScore()
	for _, info in pairs(self.redBag.List or {}) do
		local init = require "app.models.init"
		local PlayerModel = init.PlayerModel
		if info.Name == PlayerModel.info.name then
			return info.Amount
		end
	end
	return 0
end

function KingSwordModel:checkUpdate(data)
	self.thinkPlayers = {}
	--刷新最终宝箱信息
	self:updateBox()
	if self.towerInfo.FInfo.HInfo == nil then
		return
	end 
	for _, info in pairs(self.towerInfo.FInfo.HInfo.Holes or {}) do
		if info.Plr then
			self.thinkPlayers[info.Plr.Hid] = info
		end
	end
end

function KingSwordModel:getPlayerByPos(idx)
	if not self.thinkPlayers[idx] then
		return nil
	else
		--服务器坑位id从0开始
		return self.thinkPlayers[idx].Plr
	end
end

function KingSwordModel:getPosData(idx)
	return self.thinkPlayers[idx]
end

function KingSwordModel:updateBox()
	self.boxId = self:calculateBoxId()
end

function KingSwordModel:getKingSwordData()
	return clone(self.towerInfo)
end

function KingSwordModel:calculateBoxId()
	local getCnt = self.towerInfo.FInfo.CInfo.Cnt or 0
	local boxId = self.boxInfo[#self.boxInfo]
	for k, num in ipairs(self.boxInfo) do
		getCnt = getCnt - num
		if getCnt < 0 then
			boxId = num + getCnt
			break
		end
	end
	return boxId
end
--获取每个阶段宝箱领取上限
function KingSwordModel:getBoxInfo()
	return self.boxInfo
end

--获取当前可以领取的宝箱次数
function KingSwordModel:getBoxInx()
	return self.boxId
end

function KingSwordModel:getRedBag()
	return clone(self.redBag)
end

function KingSwordModel:getKingSwordOpenTime()
	local curTime = Helper.getFixedTime()
	local curTimeTs = os.date("*t", curTime)
	local curWeek = (curTimeTs.wday-1 == 0) and 7 or (curTimeTs.wday-1)
	--距离开启时间的天数
	local bWeek = wzzjRankTowerConf[1].wdays[1]
	if curWeek < bWeek then
		local info_ = string.split(wzzjRankTowerConf[1].desOpen, "-")
		local timeSlot = string.split(info_[1], ":")
		local openHour, openMinute = tonumber(timeSlot[1]), tonumber(timeSlot[2])
	    local desWeek = bWeek >= curWeek and 0 or 7
        return (bWeek - curWeek + desWeek) * 86400 + (openHour - curTimeTs.hour) * 3600 + (openMinute - curTimeTs.min) * 60 - curTimeTs.sec
	else
	 	return 0
	end 
end

function KingSwordModel:getKingSwordEndTime()
	local curTime = Helper.getFixedTime()
	local curTimeTs = os.date("*t", curTime)
	local curWeek = (curTimeTs.wday-1 == 0) and 7 or (curTimeTs.wday-1)
	local endStr = wzzjRankTowerConf[1].open
	local bWeek = tonumber(string.split(endStr, "/")[1])
	local endTimeStr = string.split(endStr, "/")[2]
	local timeSlot = string.split(endTimeStr, ":")
	local endHour, endMinute = tonumber(timeSlot[1]), tonumber(timeSlot[2])
    local desWeek = bWeek >= curWeek and 0 or 7
    return (bWeek - curWeek + desWeek) * 86400 + (endHour - curTimeTs.hour) * 3600 + (endMinute - curTimeTs.min) * 60 - curTimeTs.sec
end

function KingSwordModel:getCurDoaNum()
	return self.warZone[self.warZone.Sid].DScore
end

function KingSwordModel:getDonAttrByScore(score)
	local donAttr = {}
    for _, info in pairs(wzzjDonateConf) do
    	if score >= info.property[1].n then
    		if not donAttr[info.property[1].id] then
				donAttr[info.property[1].id] = info.property[1].val
			else
				donAttr[info.property[1].id] = donAttr[info.property[1].id] + info.property[1].val
    		end
    	end
    end
    return donAttr
end

function KingSwordModel:getFightBoss()
	if self.towerInfo.FInfo.BInfo == nil then
		return nil
	end
	return self.towerInfo.FInfo.BInfo.Boss
end

return KingSwordModel