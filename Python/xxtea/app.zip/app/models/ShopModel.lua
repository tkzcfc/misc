local ShopModel = class("ShopModel")
local shopConf = require "app.configs.shop"
local msgids = require "app.network.msgids"
function ShopModel:ctor()
    self.shops = {}
    self.buyData = nil
    self.opShopId = nil
end

function ShopModel:updateShop(shopData)
    self.shops[self.opShopId] = shopData
end

function ShopModel:setCurShopId(opShopId)
    self.opShopId = opShopId
end
-- ShopId int32
-- ItemId int32 //商品id
-- Num    int32 //购买数量
function ShopModel:setBuyData(data)
    self.buyData = data
end

function ShopModel:getShopData(shopId)
    return self.shops[shopId]
end

function ShopModel:updateBuy()
    local shopId = self.buyData.ShopId
    for idx,info in ipairs(self.shops[shopId].Goods or {}) do
        if info.Id == self.buyData.ItemId then
            self.shops[shopId].Goods[idx].BuyCnt = self.shops[shopId].Goods[idx].BuyCnt + self.buyData.Num
        end
    end
end

function ShopModel:getOpenShopConf()
    local init = require "app.models.init"
    local Helper = require "app.Helper"
    local PlayerModel = init.PlayerModel
    
    local svrOpenTs = os.date("*t", PlayerModel.info.svrOpenTs)
    local svrTs = os.time({year = svrOpenTs.year, month = svrOpenTs.month, day = svrOpenTs.day, hour = 0, min = 0, sec = 0})
    local secs = Helper.getFixedTime() - svrTs

    local confs = {}
    for _,info in pairs(shopConf) do
        if (info.openState == 0) and (secs >= info.openDay*24*60*60) then
            table.insert(confs, info)
        end
    end
    table.sort(confs, function (fir, sec)
        return fir.list < sec.list
    end)
    return confs
end

function ShopModel:getShopTotalBuy(shopId)
    local cnt = 0
    local goods = self.shops[shopId] and self.shops[shopId].Goods or {}
    for _,info in pairs(goods) do
        cnt = cnt + info.BuyCnt
    end
    return cnt
end

function ShopModel:handleMsg(op, data)
    if op == msgids.GS_ShopGetInfo_R
        or op == msgids.GS_ShopRefresh_R then
        self:updateShop(data.Shop)
    elseif op == msgids.GS_ShopBuy_R then
        self:updateBuy()
    end
end

return ShopModel