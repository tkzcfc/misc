--
-- Author: hexianxiong
-- Date: 2018-01-25 16:49:10
--
local Helper = require "app.Helper"
local ChatModel = class("ChatModel")

function ChatModel:ctor()
	self.msgList = {}
	self.msgList[0] = {}
	self.msgList[1] = {}
	self.msgList[3] = {}
	self.lastMsgId = {}
	self.prevIndex = {}
	self.nextIndex = {}
	self.nextIndex[0] = 0
	self.nextIndex[1] = 0
	self.nextIndex[3] = 0
	self.lampMsg = {}
end

function ChatModel:resetMessage()
	for channel,msgs in pairs(self.msgList) do
		self.nextIndex[channel] = #msgs
		if #msgs > 4 then
			self.nextIndex[channel] = #msgs - 4
		end
		-- for index, msg in pairs(msgs) do
		-- 	if msg.Ts > self.lastMsgId[channel] then
		-- 		self.nextIndex[channel] = index
		-- 		break
		-- 	end
		-- end
		self.prevIndex[channel] = math.max(self.nextIndex[channel]-1,0)
	end
end

function ChatModel:hasNewChat()
	for channel,msg in pairs(self.msgList) do
		if self:haveMessage(channel) then
			return true
		end
	end
	return false
end

function ChatModel:initHistroyMsg(ChatHistroyMsgData)
	if ChatHistroyMsgData and ChatHistroyMsgData.Data then
		for i, data in pairs(ChatHistroyMsgData.Data) do
			self:addMessage(data)
		end
	end
	local PlayerConfig = require "sandglass.core.PlayerConfig"
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	self.lastMsgId[0] = tonumber(PlayerConfig.getSetting(PlayerModel.info.userId .. "chat"..0,0))
	self.lastMsgId[1] = tonumber(PlayerConfig.getSetting(PlayerModel.info.userId .. "chat"..1,0))
	self.lastMsgId[3] = tonumber(PlayerConfig.getSetting(PlayerModel.info.userId .. "chat"..3,0))
end

function ChatModel:addMessage(data)
	if not self.msgList[data.ChatType] then
		self.msgList[data.ChatType] = {}
	end
	table.insert(self.msgList[data.ChatType],data)
	while #self.msgList[data.ChatType] > 100 do
		table.remove(self.msgList[data.ChatType], 1)
		if self.nextIndex[data.ChatType] and self.nextIndex[data.ChatType] > #self.msgList[data.ChatType] then
			self.nextIndex[data.ChatType] = #self.msgList[data.ChatType]
		end
		if not self.prevIndex[data.ChatType] then
			self.prevIndex[data.ChatType] = 0
		end
		self.prevIndex[data.ChatType] = math.max(self.prevIndex[data.ChatType] - 1,0)
	end
	if self.nextIndex[data.ChatType] <= 0 then
		self.nextIndex[data.ChatType] = #self.msgList[data.ChatType]
	end
end

function ChatModel:getNextMessage(channel)
	if not self.msgList[channel] or self.nextIndex[channel] <= 0 or self.nextIndex[channel] > #self.msgList[channel] then
		self:saveLastMsg(channel)
		return nil
	end
	local data = self.msgList[channel][self.nextIndex[channel]]
	if self.lastMsgId[channel] < data.Ts then
		self.lastMsgId[channel] = data.Ts
	end
	self.nextIndex[channel] = self.nextIndex[channel] + 1
	if self.nextIndex[channel] > #self.msgList[channel] then
		self:saveLastMsg(channel)
	end
	return data
end

function ChatModel:getLastMessage(channel)
	local data = self.msgList[channel][#self.msgList[channel]]
	return data
end

function ChatModel:getPrevMessage(channel)
	if not self.msgList[channel] or self.prevIndex[channel] <= 0 then
		return nil
	end
	local data = self.msgList[channel][self.prevIndex[channel]]
	self.prevIndex[channel] = self.prevIndex[channel] - 1
	return data
end

function ChatModel:havePrevMessage(channel)
	if not self.msgList[channel] or self.prevIndex[channel] <= 0 then
		return false
	end
	return true
end

function ChatModel:getMessage(channel)
	if not self.msgList[channel] or #self.msgList[channel] <= 0 then
		self:saveLastMsg(channel)
		return nil
	end
	local data = self.msgList[channel][1]
	if self.lastMsgId[channel] < data.Ts then
		self.lastMsgId[channel] = data.Ts
	end
	table.remove(self.msgList[channel], 1)
	if #self.msgList[channel] <= 0 then
		self:saveLastMsg(channel)
	end
	return data
end

function ChatModel:saveLastMsg(channel)
	local PlayerConfig = require "sandglass.core.PlayerConfig"
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	if self.lastMsgId[channel] then
		PlayerConfig.setSetting(PlayerModel.info.userId .. "chat"..channel,self.lastMsgId[channel])
	end
end

function ChatModel:haveMessage(channel)
	if not self.msgList[channel] or #self.msgList[channel] <= 0 then
		return false
	end
	for _, msg in pairs(self.msgList[channel]) do
		if msg.Ts > self.lastMsgId[channel] then
			return true
		end
	end
	return false
end

function ChatModel:getRecentlyMessage()
	local msg = nil
	local time = 0
	for channel,msgs in pairs(self.msgList) do
		if #msgs > 0 and msgs[#msgs].Ts > time then
			time = msgs[#msgs].Ts
			msg = msgs[#msgs]
		end
	end
	return msg
end

function ChatModel:addLampMessage(data)
	local msg = data
	if #self.lampMsg <= 0 then
		table.insert(self.lampMsg,msg)
		return
	end
	for i = #self.lampMsg, 1, -1 do
		if self.lampMsg[i].Type >= msg.Type then
			table.insert(self.lampMsg,i,msg)
			break
		end
	end
end

--获取跑马灯
function ChatModel:getLampMessage()
	local curTime = Helper.getFixedTime()
	local lampMsg_ = {}
	for i,v in ipairs(self.lampMsg) do
		local endTs = v.Ts + (v.Num-1) * v.Gap
		if curTime <= endTs then
			table.insert(lampMsg_, v)
		end
	end
	self.lampMsg = nil
	self.lampMsg = lampMsg_
	if #self.lampMsg > 0 then
		--self.lampMsg[1].Num = self.lampMsg[1].Num - 1
		--local lampData = clone(self.lampMsg[1])
		--if self.lampMsg[1].Num <= 0 then
		--	table.remove(self.lampMsg, 1)
		--end
		local miniTs = nil
		local lampData = {}
		for i,v in ipairs(self.lampMsg) do
			for k=1,v.Num do
				if curTime <= ((k-1) * v.Gap + v.Ts) then
					local nextTs = ((k-1) * v.Gap + v.Ts) - curTime
					if miniTs then
						miniTs = nextTs < miniTs and nextTs or miniTs
					else
						miniTs = nextTs
					end
					break
				end
			end
			if miniTs == 0 then
				table.insert(lampData, clone(v))
			end
		end
		table.sort(lampData, function(a, b)
			return a.Type > b.Type
		end)

		return lampData[1], miniTs
	end
	return nil
end

function ChatModel:addCacheLampMessag(data)
	for i,v in ipairs(data or {}) do
		table.insert(self.lampMsg, v)
	end
	table.sort(self.lampMsg, function(a, b)
		return a.Type > b.Type
	end)
end

return ChatModel