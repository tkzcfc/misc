--专属礼包
local PushGiftModel = class("PushGiftModel")
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"

function PushGiftModel:ctor()
    self.gifts = {}
    self.hasNew = false
end

function PushGiftModel:initData(data)
    self.gifts = data.Gifts or {}
    -- dump(data, "xxxxxxxx", 10)
end

function PushGiftModel:isOpen()
    local lastTime = self:getLastMenusEndTs()
    return lastTime > Helper.getFixedTime()
end

function PushGiftModel:hasRed()
    return self.hasNew
end

function PushGiftModel:setNew(new)
    self.hasNew = new
end

function PushGiftModel:getAllMenus()
    return self.gifts
end
-- 时间到了不应该消失吗
function PushGiftModel:updateMenusWhenTimeEnd()
    for idx,info in ipairs(self.gifts) do
        if info.End <= Helper.getFixedTime() then
            table.remove(self.gifts, idx)
        end
    end
end

function PushGiftModel:getGiftDataById(id)
    for _,info in ipairs(self.gifts) do
        if info.Id == id then
            return info
        end
    end
    return nil
end

function PushGiftModel:getLastMenusEndTs()
    local lastTs = 0
    for _,info in ipairs(self.gifts) do
        if info.End > lastTs then
            if info.Id ~= 45 and info.Id ~= 54 then -- 韶华礼包不在总界面显示
                lastTs = info.End
            end
        end
    end
    return lastTs
end

function PushGiftModel:getLeastMenusEndTs()
    local leaseTs = 0
    for _,info in ipairs(self.gifts) do
        if leaseTs == 0 or info.End < leaseTs then
            if info.Id ~= 45 and info.Id ~= 54 then -- 韶华礼包不在总界面显示
                leaseTs = info.End
            end
        end
    end
    return leaseTs
end

function PushGiftModel:handleMsg(op, msg)
    if op == msgids.GS_PushGiftGetInfo_R then
        self:initData(msg.Data)
    elseif op == msgids.GS_PushGiftBill then
        for idx,info in ipairs(self.gifts) do
            if info.Id == msg.Id then
                table.remove(self.gifts, idx)
                break
            end
        end
    elseif op == msgids.GS_PushGiftNew then
        self.hasNew = true
        table.insert(self.gifts, msg.Data)
        local drawWin = display.getRunningScene().winManager:findWinByName("DrawWin")
        local dungeonWin = display.getRunningScene().winManager:findWinByName("DungeonWin")
        local win = drawWin or dungeonWin
        if win then
            win.openWinId = msg.Data.Id
        else
            if msg.Data.Id ~= 45 and msg.Data.Id ~= 54 then -- 韶华礼包不在总界面显示
                display.getRunningScene():getChildByName("ViewBase"):openWin("PushGiftWin", msg.Data.Id)
            end 
        end
    end
end

return PushGiftModel