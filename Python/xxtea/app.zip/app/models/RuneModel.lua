--符文

local RuneModel = class("RuneModel")
local itemConf = require "app.configs.item"
local runeConf = require "app.configs.rune"
local rollSkillConf = require "app.configs.rollSkill"

local attributes = {
    ["seq"] = 0, -- 序号
    ["id"] = 0, -- 道具Id
    ["heroId"] = 0, -- 穿戴英雄Id
    ["slot"] = 0, --穿戴位置
    ["RProp"] = {}, --随机属性
    ["skill"] = {}, --技能
    ["locked"] = 0, --锁定状态(高32位对应技能，低32位对应属性)
    ["recastCnt"] = 0, --重铸次数(触发保底后清空)
}

local skillColor = {
    "GREEN",
    "BLUE",
    "PURPLE",
    "ORANGE",
}

function RuneModel:ctor()
    self.Runes = {}
    self.RuneBroken = 0--破碎值

    self.confs = {}
    for id,v in pairs(runeConf) do
        table.insert(self.confs, v)
    end
    table.sort(self.confs, function(a,b)
        return a.level < b.level
    end)

    self.maxLevel = self.confs[#self.confs].level
end

function RuneModel:removeRunes(runesDel)
    for _,seq in pairs(runesDel or {}) do
        self.Runes[seq] = nil
    end
end

function RuneModel:addRunes(Runes)
    for _, rune in pairs(Runes or {}) do
        self:addRune(rune)
    end
end

function RuneModel:addRune(data)
    local attr = clone(attributes)

    attr.seq = data.Seq
    attr.id = data.Id
    attr.heroId = data.HeroId or 0
    attr.slot = data.Slot or 0
    attr.RProp = {}
    attr.skill = data.Skill or {}
    attr.locked = data.Locked or 0
    attr.recastCnt = data.RecastCnt or 0

    for _, props in ipairs(data.RProp or {}) do
        table.insert(attr.RProp,{id = props.Id,val = props.Val})
    end

    self.Runes[data.Seq] = attr
end

function RuneModel:updateRunes(runes)
    for _, rune in pairs(runes or {}) do
        self:updateRune(rune)
    end
end

function RuneModel:updateRune(data)
    local rune = self:getRune(data.Seq)
    if not rune then
        self:addRune(datas)
        return
    end

    rune.seq = data.Seq
    rune.id = data.Id
    rune.heroId = data.HeroId or 0
    rune.slot = data.Slot or 0
    rune.RProp = {}
    rune.skill = data.Skill or {}
    rune.locked = data.Locked or 0
    rune.recastCnt = data.RecastCnt or 0

    for _, props in ipairs(data.RProp or {}) do
        table.insert(rune.RProp,{id = props.Id,val = props.Val})
    end
end

function RuneModel:setRuneBroken(val)
    self.RuneBroken = val or 0
end

function RuneModel:getRuneBroken()
    return self.RuneBroken
end

function RuneModel:getRune(seq)
    return self.Runes[seq]
end

function RuneModel:getRunes()
    return self.Runes
end

function RuneModel:getEmptyRunes()
    local runes = {}
    for _, rune in pairs(self.Runes) do
        if rune.heroId == 0 then
            table.insert(runes, rune)
        end
    end

    return runes
end

function RuneModel:getComposeRunes()
    local runes = {}
    for _, rune in pairs(self.Runes) do
        local lv = runeConf[itemConf[rune.id].type].level
        if rune.heroId == 0 and lv < self.maxLevel then
            table.insert(runes, rune)
        end
    end

    return runes
end

function RuneModel:getHeroRunes(heroId)
    local runes = {}
    for _, rune in pairs(self.Runes) do
        if rune.heroId ~= 0 and rune.heroId == heroId then
            runes[rune.slot] = rune
        end
    end
    return runes
end

function RuneModel:updateLocked(data)
    self.Runes[data.seq].locked = data.locked
end

function RuneModel:getOnekeyComposeByNum(cnt)
    local emptyRunes = self:getEmptyRunes()
    for _,v in ipairs(self.confs) do
        local seqs = {}
        if v.onekeyAdd == 1 then
            local lv = v.level
            for _, rune in pairs(emptyRunes) do
                local level = runeConf[itemConf[rune.id].type].level
                if level == lv then
                    table.insert(seqs, rune.seq)
                end

                if #seqs >= cnt then
                    return seqs
                end
            end
        end
    end

    return {}
end

function RuneModel:getOnekeyDeCompose()
    local emptyRunes = self:getEmptyRunes()
    for _,v in ipairs(self.confs) do
        local seqs = {}
        if v.onekeyAdd == 1 then
            local lv = v.level
            for _, rune in pairs(emptyRunes) do
                local level = runeConf[itemConf[rune.id].type].level
                if level == lv then
                    table.insert(seqs, rune.seq)
                end

                if #seqs >= 5 then
                    break
                end
            end
        end

        if #seqs > 0 then
            return seqs
        end
    end

    return {}
end

function RuneModel:getRuneSkillColor(skillId)
    local lv = 1
    for _,v in pairs(rollSkillConf) do
        if v.id == skillId then
            lv = v.skillLevel
            break
        end
    end

    return skillColor[lv] or skillColor[1]
end

return RuneModel
