local HallModel = class("HallModel")
local HallSpecialConf = require "app.configs.zzzdnightmareBattle"

function HallModel:ctor()
	self:reset()
end

function HallModel:reset()
	self.normalLevel = 0
	self.passSpecialCnt = 0
	self.totalStar = 0
	self.specialInfo = {}
	self.takenIds = {}
	self.init = false
	--噩梦关卡额外购买次数
	--噩梦关卡额外使用次数
	self.nmExtraBuyCnt = 0
	self.nmExtraUseCnt = 0
end

function HallModel:initData(data)
	self:reset()
	self.normalLevel = data.LevelId or 0
	for k,v in ipairs(data.Nightmare or {}) do
		self.specialInfo[v.Id] = {
			id = v.Id,
			cnt = v.Cnt or 0,
			isPass = v.IsPass,
			firstPassPlrId = v.FirstPassPlrId,
			firstPassPlrName = v.FirstPassPlrName,
			firstPassTeam = v.FirstPassPlrTeam,
		}
		if v.Cnt and v.Cnt > 0 then
			self.passSpecialCnt = self.passSpecialCnt + 1
		end
	end
	for k,v in ipairs(data.TakenIds or {}) do
		self.takenIds[v] = true
	end
	self.init = true
	self.nmExtraBuyCnt = data.NMExtraBuyCnt or 0
	self.nmExtraUseCnt = data.NMExtraUseCnt or 0
end

function HallModel:getNormalLevel()
	return self.normalLevel
end

function HallModel:onFightNormal(data)
	self.normalLevel = data.LevelId or self.normalLevel
end

function HallModel:onFightSpecial(data)
	local PlayerConfig = require "sandglass.core.PlayerConfig"
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	if data.IsWin then
		if self.specialInfo[data.Id] then
			self.specialInfo[data.Id].isPass = true
			if self.specialInfo[data.Id].star == 0 then
				self.passSpecialCnt = self.passSpecialCnt + 1
			end
		else
			self.specialInfo[data.Id] = {
				id = data.Id,
				cnt = 0,
				isPass = true,
			}
			self.passSpecialCnt = self.passSpecialCnt + 1
		end

		if data.IsFirst then
			self.specialInfo[data.Id].firstPassPlrId = PlayerModel.info.userId
			self.specialInfo[data.Id].firstPassPlrName = PlayerModel.info.name
			self.specialInfo[data.Id].firstPassTeam = json.decode(PlayerConfig.getSetting(PlayerModel.info.userId .. "hallFight", "{}")) or {}
		end
		self.specialInfo[data.Id].cnt = self.specialInfo[data.Id].cnt + HallSpecialConf[data.Id].costCounter

		self.nmExtraUseCnt = self.nmExtraUseCnt + HallSpecialConf[data.Id].costCounter
	end
end

function HallModel:getSpecialDataById(id)
	return self.specialInfo[id]
end

function HallModel:getSpecialTotalCnt()
	return self.nmExtraUseCnt
end

function HallModel:getTotalBuyTimes()
	return self.nmExtraBuyCnt
end

function HallModel:checkAchieveTakeStatus(id)
	local HallAchieveConf = require "app.configs.zzzdachieve"
	local confData = HallAchieveConf[id]
	local status = {
		canTake = 1,
		notFinish = 2,
		took = 3,
	}

	if confData.termType == 1 then
		if self.takenIds[id] then
			return status.took, confData.termParameter, confData.termParameter
		elseif self.normalLevel >= confData.termParameter then
			return status.canTake, confData.termParameter, confData.termParameter
		else
			return status.notFinish, self.normalLevel, confData.termParameter
		end
	elseif confData.termType == 2 then
		if self.takenIds[id] then
			return status.took, confData.termParameter, confData.termParameter
		elseif math.floor(self.normalLevel / 5) >= confData.termParameter then
			return status.canTake, confData.termParameter, confData.termParameter
		else
			return status.notFinish, math.floor(self.normalLevel / 5), confData.termParameter
		end
	elseif confData.termType == 3 then
		if self.takenIds[id] then
			return status.took, confData.termParameter, confData.termParameter
		elseif self.passSpecialCnt >= confData.termParameter then
			return status.canTake, confData.termParameter, confData.termParameter
		else
			return status.notFinish, self.passSpecialCnt, confData.termParameter
		end
	elseif confData.termType == 4 then
		if self.takenIds[id] then
			return status.took, confData.termParameter, confData.termParameter
		elseif self.totalStar >= confData.termParameter then
			return status.canTake, confData.termParameter, confData.termParameter
		else
			return status.notFinish, self.totalStar, confData.termParameter
		end
	end
end

function HallModel:onRewardTake(data)
	self.takenIds[data.Id] = true
end

function HallModel:checkHallRedTips()
	local HallAchieveConf = require "app.configs.zzzdachieve"
	local hasRedTips = false
	for k,v in ipairs(HallAchieveConf) do
		if self:checkAchieveTakeStatus(v.id) == 1 then
			hasRedTips = true
			break
		end
	end
	return hasRedTips
end

function HallModel:onSweepNightmare(data)
	self.nmExtraUseCnt = self.nmExtraUseCnt + HallSpecialConf[data.Id].costCounter
	if not self.specialInfo[data.Id] then
		self.specialInfo[data.Id] = {
				id = data.Id,
				cnt = 1
			}
	else
		self.specialInfo[data.Id].cnt = self.specialInfo[data.Id].cnt + HallSpecialConf[data.Id].costCounter
	end
end

function HallModel:onBuyNMCnt(data)
	self.nmExtraBuyCnt = data.NMExtraBuyCnt
end

return HallModel