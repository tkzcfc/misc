local msgids = require "app.network.msgids"
local network = require "app.network.network"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local runefoMapConf = require "app.configs.runefoMap"

local RunePlayModel = class("RunePlayModel")

local TILE_TYPE = {
    ordinary = 0,--普通地块
    boss = 1,--boss地块
    birth = 2,--出生点
    build = 4, --建筑
    shrine = 5,--神社
    statue = 6,--神像
}

local EVENT_TYPE = {
    pve = 1,---普通怪物
    -- mrBox = 2,---怪物符文宝箱
    life = 3,---生命之泉
    shop = 4,---商人
    boss = 5,---boss
    itemBox = 6,---道具宝箱
    windmill = 7,---怪物风车
    stinger = 8,---彩蛋
    dialogue = 9,---对话
}

function RunePlayModel:ctor()
    self.info = {}--全部信息
    self.groups = {} --地块组
    self.tileEvents = {} --地块事件
    self.canWalkIds = {} --可移动地块
    self.stingerList = {} --彩蛋列表
    self.walkIds = {} --走过的地块
    self.canShowIds = {} --可显示地块
    self.bossGroups = {} --boss组
    self.bossTileId = nil--boss地块
    self.curPoint = nil --当前位置
    self.shrineId = nil --神社地块
    self:initData()
end

function RunePlayModel:handleMsg(op, data)
    if op == msgids.GS_GetRunefoInfo_R then
        self.info = data.Data
        self.bossGroups = data.Data.BossPos or {}
        self.tileEvents = {} 
        for i,v in ipairs(data.Data.LvInfos or {}) do
            self.tileEvents[v.Lvid] = v
            if v.EvtType == EVENT_TYPE.boss then
                self.bossTileId = v.Lvid
            end
        end
        self.canWalkIds = {} 
        for k,id in pairs(data.Data.PassLvs or {}) do
            self.canWalkIds[id] = true
        end
        self.stingerList = {}
        for k,v in pairs(data.Data.StingerList or {}) do
            self.stingerList[v.Lvid] = v
        end
        for k,id in pairs(data.Data.RunWindMill or {}) do
            if self.tileEvents[id] and self.tileEvents[id].EvtType == EVENT_TYPE.windmill then
                self.tileEvents[id].EvtCanTri = false
            end
        end
        self.walkIds = {}
        for k,id in pairs(data.Data.ThroughLvs or {}) do
            self.walkIds[id] = true
        end
        self.canShowIds = {}
        self:initCanShowTiles()
        self:setCurPoint(data.Data.MyLvid)
    elseif op == msgids.GS_RunefoMove_R then
        if data.ErrorCode == 0 then
            if #data.Lvids > 0 then
                for i,id in ipairs(data.Lvids) do
                    self.walkIds[id] = true
                end
                local id = data.Lvids[#data.Lvids]
                self:setCurPoint(id, data.Lvids)
            end
            if data.IsStinger then
                for k,v in pairs(data.StingerList or {}) do
                    self.stingerList[v.Lvid] = v
                end
                if self.tileEvents[id] and self.tileEvents[id].EvtType == EVENT_TYPE.stinger then
                    self.tileEvents[id].EvtCanTri = false
                end
            end
        end
    elseif op == msgids.GS_RunefoBox_R then
        self.info.MyRunes = self.info.MyRunes or {}
        table.insert(self.info.MyRunes, {RuIdx = data.RuneIdx})
        if self.tileEvents[data.Lvid] then
            self.tileEvents[data.Lvid].EvtCanTri = false
        end
        self:setCurPoint(data.Lvid)
    elseif op == msgids.GS_RunefoBuy_R then
        if self.tileEvents[data.Lvid] then
            self.tileEvents[data.Lvid].EvtCanTri = false
        end
        self:setCurPoint(data.Lvid)
    elseif op == msgids.GS_RunefoTriSpr_R then
        self.info.MyHeroDecHP = data.MyHeroDecHP
        if self.tileEvents[data.Lvid] then
            self.tileEvents[data.Lvid].EvtCanTri = false
        end
        self:setCurPoint(data.Lvid)
    elseif op == msgids.GS_RunefoLifeSpring_R then
        self.info.MyHeroDecHP = {}
    elseif op == msgids.GS_RunefoBattle_R then
        self.info.MyHeroDecHP = data.HeroDecHP
        local evtData = self.tileEvents[data.Lvid] 
        if evtData then
            evtData.Monster = data.Monster
            if evtData.EvtType == EVENT_TYPE.windmill then
                evtData.EvtCanTri = false
            end
        end
        self:setCurPoint(data.Lvid)
    end
end

function RunePlayModel:initData()
    for k,v in pairs(runefoMapConf) do
        if v.group > 0 then
            if not self.groups[v.group] then
                self.groups[v.group] = {}
            end
            table.insert(self.groups[v.group], v.id)   
        end
        if not self.shrineId and v.stageType == TILE_TYPE.shrine then
            self.shrineId = v.group or v.id
        end
    end
end

function RunePlayModel:initCanShowTiles()
    for id,v in pairs(self.walkIds) do
        local ids = self:getAroundTileByRange(id)
        for i,v in ipairs(ids) do
            self.canShowIds[v] = true
        end
    end
end

function RunePlayModel:tilePosToIndex(pos)
    return (pos.x + 1) * 1000 + (pos.y + 1)
end

function RunePlayModel:tileIndexToPos(tileId)
    return cc.p(math.floor(tileId / 1000) - 1, tileId % 1000 - 1)
end

function RunePlayModel:getEventType()
    return EVENT_TYPE
end

function RunePlayModel:getTileType()
    return TILE_TYPE
end

function RunePlayModel:setCurPoint(tileId, tileIds)
    self.curPoint = tileId
    self.canWalkIds[tileId] = true
    ----boss地快可通过处理----
    local evtData = nil
    for k,v in pairs(self.tileEvents) do
        if v.EvtType == EVENT_TYPE.boss then
            evtData = v
            break
        end
    end
    if not self:checkBossIsOpen() then
        for k,id in pairs(self.bossGroups) do
            if self.tileEvents[id] and self.tileEvents[id].EvtCanTri then 
                if self.tileEvents[id].EvtType == EVENT_TYPE.windmill or self.tileEvents[id].EvtType == EVENT_TYPE.pve then
                else
                    self.canWalkIds[id] = true
                end
            else
                self.canWalkIds[id] = true
            end
        end
        self.groups[evtData.Lvid] = nil
    else
        for k,id in pairs(self.bossGroups) do
            self.canWalkIds[id] = false
        end
        self.groups[evtData.Lvid] = self.bossGroups
    end
    -----可显示地块处理------
    if tileIds then
        for i,id in ipairs(tileIds) do
            self.walkIds[id] = true
            for k,v in pairs(self:getAroundTileByRange(id)) do
                self.canShowIds[v] = true
            end
        end
    else
        self.walkIds[tileId] = true
        for k,id in pairs(self:getAroundTileByRange(tileId)) do
            self.canShowIds[id] = true
        end
    end
end

function RunePlayModel:getAroundTileByRange(tileId, range)
    local range = range or 3
    local pos = self:tileIndexToPos(tileId)
    pos = clone(pos)
    pos.x = pos.x + 1
    pos.y = pos.y + 1
    local ids = {}
    local fun_ = function(x, y)
        if x > 0 and x <= 15 then
            for i=1,range do
                if y + i <= 15 then
                    table.insert(ids, RunePlayModel:tilePosToIndex(cc.p(x-1, y + i -1)))
                end
                if y - i > 0 then
                    table.insert(ids, RunePlayModel:tilePosToIndex(cc.p(x-1, y - i -1)))
                end
            end
            table.insert(ids, RunePlayModel:tilePosToIndex(cc.p(x-1, y-1)))
        end
    end
    for i=1,range do
        fun_(pos.x + i, pos.y)
        fun_(pos.x - i, pos.y)
    end
    fun_(pos.x, pos.y)

    local ids_ = {}
    for i,id in ipairs(ids) do
        if runefoMapConf[id] then
            for _,v in ipairs(self:getGroupIds(id)) do
                table.insert(ids_, v)
            end
        end
    end
    return ids_
end

function RunePlayModel:getCurPoint()
    return self.curPoint 
end

function RunePlayModel:getGroupIds(tileId)
    for k,ids in pairs(self.groups) do
        for _,id in ipairs(ids or {}) do
            if id == tileId then
                return ids
            end
        end
    end
    return {tileId}
end

function RunePlayModel:checkBossIsOpen()
    local isOpen = true
    for k,data in pairs(self.tileEvents or {}) do
        if data.EvtType == EVENT_TYPE.windmill then
            if data.EvtCanTri then
                isOpen = false
            end
        end
        if data.EvtType == EVENT_TYPE.boss then
            if data.EvtCanTri then
                if self:checkIsDie(data.Monster) then
                    isOpen = false
                    break
                end
            else
                isOpen = false
                break
            end
        end
    end 
    return isOpen
end

function RunePlayModel:checkPassBoxIsOpen()
    local isOpen = false
    for k,data in pairs(self.tileEvents or {}) do
        if data.EvtType == EVENT_TYPE.boss then
            if data.EvtCanTri and self:checkIsDie(data.Monster) then
                isOpen = true
            end
            break
        end
    end
    return isOpen
end

function RunePlayModel:checkCanOpenFunc(checkId, curId)
    local aroundTs = self:getAroundTiles(checkId)
    for k,id in pairs(aroundTs) do
        if id == curId then
            return true
        end
    end
    return false
end

function RunePlayModel:checkIsDie(decHps)
    for k,v in pairs(decHps or {}) do
        if (v.Hp < 10000) and (v.Id > 0) then
            return false
        end
    end
    return true
end

function RunePlayModel:getAroundTiles(tileId, checkHinder, specialId)
    local tiles = {}
    local pos = self:tileIndexToPos(tileId)
    local function getTileByPos(x, y)
        local id = self:tilePosToIndex(cc.p(x, y))
        local conf = runefoMapConf[id]
        if conf then
            if checkHinder then
                if self.canShowIds[id] then
                    if self.canWalkIds[id] then
                        table.insert(tiles, id)
                    elseif (not specialId) or (specialId == id) then
                        table.insert(tiles, id)
                    end
                end
            else
                table.insert(tiles, id)
            end
        end
    end
    -----上下左右
    getTileByPos(pos.x, pos.y + 1)
    getTileByPos(pos.x, pos.y - 1)
    getTileByPos(pos.x + 1, pos.y)
    getTileByPos(pos.x - 1, pos.y)
    return tiles
end

------A*-------
function RunePlayModel:getMovePath(startId, endId)
    if not (startId and endId) then 
        return {}
    end
    local startPos = self:tileIndexToPos(startId)
    local endPos = self:tileIndexToPos(endId)

    local index = 0----用于判断加入顺序
    local noPath = false
    local openList = {}
    local closedList = {}
    local autowaylist = {}

    self.func_ = function(parentId)
        closedList[parentId] = openList[parentId]
        openList[parentId] = nil
        if parentId == endId then
            return
        end

        local aroundIds = self:getAroundTiles(parentId, true, endId)
        for k,id in pairs(aroundIds) do
            if not closedList[id] then
                index = index + 1
                local pos = self:tileIndexToPos(id)
                local valF = math.abs(startPos.x - pos.x) + math.abs(startPos.y - pos.y) + math.abs(endPos.x - pos.x) + math.abs(endPos.y - pos.y)
                if openList[id] and openList[id].parentId ~= parentId then---四方向判断没意义
                    local oriPPos = self:tileIndexToPos(openList[id].parentId)
                    local curPPos = self:tileIndexToPos(parentId)
                    local oriG = math.abs(pos.x - oriPPos.x) + math.abs(pos.y - oriPPos.y) 
                    local curG = math.abs(pos.x - curPPos.x) + math.abs(pos.y - curPPos.y) 
                    if oriG > curG then
                        openList[id].parentId = parentId
                        openList[id].index = index
                    end
                else
                    openList[id] = {valF = valF, parentId = parentId, id = id, index = index}
                end
            end
        end
        local minData = nil
        for id,data in pairs(openList) do
            if not minData then
                minData = data
            elseif data.valF < minData.valF then
                minData = data
            elseif data.valF == minData.valF then
                minData = data.index < minData.index and data or minData
            end
        end
        if minData then
            self.func_(minData.id)
        else
            noPath = true
            return 
        end 
    end
    self.func_(startId)

    if noPath then
        return {}
    end
    self.func_path = function(id)
        if id == startId then
            return
        end
        table.insert(autowaylist, id)
        self.func_path(closedList[id].parentId)
    end
    self.func_path(endId)

    local path = {}
    for i=1,#autowaylist do
        table.insert(path, autowaylist[#autowaylist-i+1])
    end

    return path
end

function RunePlayModel:refreshOpenInfo()
    if Helper.getOpenState(300, true) then
        if not self.curPoint then
            network.tcpSend(msgids.C_GetRunefoInfo)
        end
    end
end

return RunePlayModel
