-- LevelModel

local c = require "app.configs.constants"

local initialConf = require "app.configs.initial"
local battleConf = require "app.configs.battle"
local mapConfigs = require "app.configs.10000"
local rankConf = require "app.configs.rank"
local effectConf = require "app.configs.effect"
local openConf = require "app.configs.open"
local SDKController = require "app.sdk.SDKController"
local Helper = require "app.Helper"

local LevelModel = class("LevelModel")

local BASE_NUMBER = 1000

function LevelModel:ctor()
	self.passIds = {}
	self.plevelsCnt = 0
	self.levels = {}
	self.DLevels = {}
	self.GJHeros = {}
	self.theExplore = nil --最强探索
	self.eRwdId = 0
	self.bossReward = {}
	self.buildingRankData = {}--有排行榜的建筑 榜首数据
	self.dungeonBoxIds = {} --地下城奖励
	self.mapBoss = {}--地图boss--

	self:initMapConfigs()
	self:initBattleGroupConfigs()
	self:initOpenByLevel()
end

function LevelModel:initMapConfigs()
	self.mapConfigs = {}

	local tilesets = mapConfigs.tilesets
	for _,layerData in ipairs(mapConfigs.layers) do
		if not layerData.visible then
			local data = layerData.data
			for index, gid in ipairs(data) do
				local info = tilesets[gid]

				if info then
					self.mapConfigs[index-1] = info--tonumber(info.properties.id)
				end
			end
		end
	end
end

function LevelModel:initBattleGroupConfigs()
	self.battleGroupConfigs = {}--关卡组包含的关卡ID
	self.bossGroupConfigs = {} --Boss组

	for id,v in pairs(battleConf) do
		if v.group and v.group ~= 0 then
			if not self.battleGroupConfigs[v.group] then
				self.battleGroupConfigs[v.group] = {}
			end
			if v.stageType and v.stageType == 1 then
				if not self.bossGroupConfigs[v.group] then
					self.bossGroupConfigs[v.group] = {}
				end
				local x = math.floor(v.Id / 1000)
				local y = v.Id - math.floor(v.Id / 1000) * 1000
				local data = {x = x , y = y}
				self.bossGroupConfigs[v.group][v.Id] = data
			end
			table.insert(self.battleGroupConfigs[v.group],v.Id)
		end
	end
end

function LevelModel:initOpenByLevel() --通过等级开启的地块
	self.openByLevel = {}
    for funcId, info in pairs(openConf) do
        if info.cond == 10 and info.openBattle and info.openBattle ~= 0 then
            self.openByLevel[info.openBattle] = info.p2
        end
    end
end

function LevelModel:getGroupIds(group)
	return self.battleGroupConfigs[group]
end

function LevelModel:getMapConfigByIndex(index)
	local id = nil
	if self.mapConfigs[index] then
		id = tonumber(self.mapConfigs[index].properties.id)
	end
	return id
end

function LevelModel:getImgName(index)
	if self.mapConfigs[index] then
		return self.mapConfigs[index].name
	end
	return nil
end

function LevelModel:addDungeonLevel(data)
	self.DLevels[data.DgId] = data.St
end

function LevelModel:getMaxDungeonLevel()
	local maxLevel = 1
	for k,v in pairs(self.DLevels) do
		if k > maxLevel then
			maxLevel = k
		end
	end
	return maxLevel
end

function LevelModel:addDungeonBoxIds(ids, isOne)
	if isOne then
		table.insert(self.dungeonBoxIds, ids)
	else
		self.dungeonBoxIds = ids or {}
	end
	
end

function LevelModel:getDungeonBoxIds()
	return self.dungeonBoxIds 
end

function LevelModel:hasGotBox(id)
	local got = false
	for _,idx in ipairs(self:getDungeonBoxIds()) do
		if idx == id then
			got = true
			break
		end
	end
	return got
end

function LevelModel:getCharpterStarNum(charpterId)
	local starNum = 0
	for i=1,c.DUNGEON_CHARPTER_NUM do
		local id = (charpterId - 1) * 10 + i
		--DLevels:2：星级1级，3：2星，4：3星
		local num = self.DLevels[id] and self.DLevels[id] or 0
		starNum = starNum + num
	end
	return starNum
end

function LevelModel:addLevels(levels)
	for _, levelId in pairs(levels or {}) do
		self:addLevel(levelId)
	end

	if not self.levels[initialConf[1].initialBattle] then
		self.levels[initialConf[1].initialBattle] = c.LevelStatus.CURRENT
	end

	self:addLevelsByLevel()
end

function LevelModel:addLevelsByLevel()
	local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
	local lv = PlayerModel.info.level or 0

    for funcId, info in pairs(openConf) do
        if info.cond == 10 and info.openBattle and info.openBattle ~= 0 then
            if lv >= info.p2 then
            	local group = battleConf[info.openBattle] and battleConf[info.openBattle].group or 0
        		local groupIds = self:getGroupIds(group) or {info.openBattle}
        		for k,id in ipairs(groupIds) do
            		self.levels[id] = c.LevelStatus.CURRENT
            	end
            end
        end
    end
end

function LevelModel:addLevel(levelId,report)
	local localData = battleConf[levelId]

	if not localData then
		return
	end
	self.passIds[levelId] = true
	self.plevelsCnt = table.nums(self.passIds)
	-- if localData.stageType == 1 then
	-- 	self.plevelsCnt = self.plevelsCnt + 4
	-- elseif localData.stageType == 0 then
	-- 	self.plevelsCnt = self.plevelsCnt + 1
	-- else
	-- 	self.plevelsCnt = self.plevelsCnt + 1
	-- end
	if not self.theExplore and battleConf[levelId].type == 1 then
		self.theExplore = levelId
		self:setExploreLevel(self.theExplore,report)
	else
		local perData = battleConf[self.theExplore]
		if perData and localData.playerLevel >= perData.playerLevel and localData.type == 1 then
			self.theExplore = levelId
			self:setExploreLevel(self.theExplore,report)
		end
	end

	if localData.group and localData.group ~= 0 then
		for k,v in pairs(battleConf) do
			if v.group == localData.group then
				self:updateLevel(k, c.LevelStatus.PASSED)
				--更新周围关卡
				self:updateRoundLevel(k)
			end
		end
	else
		self:updateLevel(levelId, c.LevelStatus.PASSED)
		--更新周围关卡
		self:updateRoundLevel(levelId)
	end
end

function LevelModel:setExploreLevel(levelId,report)
	if levelId ~= 0 then
		if self.ELevel then
			self.levels[self.ELevel] = c.LevelStatus.PASSED			
		end

		self.ELevel = levelId
		self:updateLevel(self.ELevel,c.LevelStatus.EXPLORE)
		if report then
			local sdkHelper = SDKController.getSDKHelper()
			sdkHelper:submitData(SDKController.PASS_ORDINARY)
		end
	end
end

function LevelModel:getExploreLevel()
	return self.ELevel
end

function LevelModel:setBossReward(bossReward)
	self.bossReward = bossReward
end

function LevelModel:getBossReward()
	return self.bossReward
end

function LevelModel:addBossReward(levelId)
	table.insert(self.bossReward, levelId)
end

function LevelModel:setExploreReward(id)
	self.eRwdId = id
end

function LevelModel:getCurUnLock()
	return self.curUnlock or {}
end

function LevelModel:updateRoundLevel(levelId)
	self.curUnlock = {}
	local pos = self:getHexByLevelId(levelId)

	--处理解锁组的情况
	local function checkGroup(x, y)
		local id = self:getLevelIdByHex(cc.p(x, y))
		
		if not battleConf[id] then
			return
		end

		if battleConf[id].group and battleConf[id].group ~= 0 and self.battleGroupConfigs[battleConf[id].group] then
			local ids = self.battleGroupConfigs[battleConf[id].group]
			for _,v in pairs(ids) do
				if self:getLevel(v) ~= c.LevelStatus.CURRENT then
					table.insert(self.curUnlock, v)
				end
				self:updateLevel(v,c.LevelStatus.CURRENT)
				
			end
		else
			local index = x + y * mapConfigs.width
    		local value = self:getMapConfigByIndex(index)
			if value and effectConf[value] then
				local tType = effectConf[value].type
				if tType == 1 or tType == 3 then
					if self:getLevel(id) ~= c.LevelStatus.CURRENT then
						table.insert(self.curUnlock, id)
					end
				else
					table.insert(self.curUnlock, id)
				end
			else
				table.insert(self.curUnlock, id)
			end
			self:updateLevel(id,c.LevelStatus.CURRENT)
		end
	end

	--上
	checkGroup(pos.x, pos.y + 1)

	--下
	checkGroup(pos.x, pos.y - 1)

	--左
	checkGroup(pos.x - 1, pos.y)

	--右
	checkGroup(pos.x + 1, pos.y)
end

function LevelModel:updateLevel(levelId, status)
	if not battleConf[levelId] then
		return
	end

	local _status = self.levels[levelId]
	if status == c.LevelStatus.CURRENT then  --如果设置关卡为current 则判断该关卡是否是通过等级开启
		local group = battleConf[levelId] and battleConf[levelId].group or 0
        local groupIds = self:getGroupIds(group) or {levelId}

        local canUpdate = true
		for k,id in ipairs(groupIds) do
			local needLevel = self.openByLevel[id]
			if needLevel then
				canUpdate = false
				break
			end
		end
		
		if not canUpdate then
			return
		end
	end

	if not _status or status > _status then
		self.levels[levelId] = status
	end
end

function LevelModel:updatePlayerLevel(oldLevel, newLevel)
	self.curLevelOpen = {} --记录本次升级开通的关卡，每次升级清空
	if newLevel > oldLevel then
		for k,v in pairs(self.openByLevel) do
			if oldLevel < v and newLevel >= v then
				local group = battleConf[k] and battleConf[k].group or 0
        		local groupIds = self:getGroupIds(group) or {k}

        		for _,id in ipairs(groupIds) do
        			local _status = self.levels[id]
					if not _status or c.LevelStatus.CURRENT > _status then
						self.levels[id] = c.LevelStatus.CURRENT
						self.curLevelOpen[#self.curLevelOpen + 1] = id
					end
        		end
			end
		end
	end
end


function LevelModel:getLevel(levelId)
	return self.levels[levelId] or c.LevelStatus.LOCKED
end

function LevelModel:getHexByLevelId(levelId)
	return cc.p(math.floor(levelId / BASE_NUMBER),levelId % BASE_NUMBER)
end

function LevelModel:getLevelIdByHex(pos)
	return (pos.x * BASE_NUMBER) + pos.y
end

function LevelModel:getLevels()
	return self.levels
end

function LevelModel:setExploreStartTs(baseTime, goldTime, strengthTime)
	if Helper.getOpenState(1, true) then
		if baseTime and baseTime > 0 then
			self.GuaJiTs = {base = baseTime, gold = goldTime or baseTime, strength = strengthTime or baseTime}
		end
	end
end

function LevelModel:getExploreStartTs()
	return self.GuaJiTs or {}
end

function LevelModel:isOpenedByLevelId(levelId,pos)
	if not levelId or not pos then
		return false
	end
	local curPos = self:getHexByLevelId(levelId)
	return (curPos.x == pos.x and math.abs(curPos.y - pos.y) <= 1) or (curPos.y == pos.y and math.abs(curPos.x - pos.x) <= 1)
end

--建筑 有排行榜的 排行榜第一名数据
function LevelModel:updateBuildingRankData(data)
	self.buildingRankData = {}
	for _,v in pairs(data or {}) do
		local conf = rankConf[v.Id]
		if conf and conf.architec then
			self.buildingRankData[conf.architec] = v.No1Name
		end
	end

end

--按照建筑ID  获取第一名数据
function LevelModel:getRankDataByBuildId(id)
	return self.buildingRankData[id]
end

function LevelModel:addGJHeroIds(heros, isAdd)
	if isAdd then
		for i,id in ipairs(heros) do
			table.insert(self.GJHeros, id)
		end
	else
		self.GJHeros = heros or {}
	end
end

function LevelModel:deleteGJHeroId(heros)
	local heros_ = {}
	for i,id in ipairs(heros) do
		heros_[id] = id
	end
	local GJHeros = {}
	for i,id in ipairs(self.GJHeros) do
		if not heros_[id] then
            table.insert(GJHeros, id)
		end
	end
	self.GJHeros = GJHeros
end

function LevelModel:getGJHeroIds()
    return self.GJHeros
end

--==============地图boss=====================

function LevelModel:initMapBossData(data)
	self.mapBoss.StepNum = data.StepNum or 0
	self.mapBoss.CallNum = data.CallNum or 0
	self.mapBoss.BoxNum = data.BoxNum or 0
	self.mapBoss.Box = data.Box or {}
	self.mapBoss.Boss = data.Boss or {}
	-- self.mapBoss.HeroHp = data.HeroHp or {}
	self.mapBoss.HeroHp = {} ---不记录血量
	self.mapBoss.newBoxIds = {}
end

function LevelModel:getMapBossData()
	return self.mapBoss
end

function LevelModel:addMapBox(data)
	self.mapBoss.StepNum = data.StepNum or 0
	self.mapBoss.BoxNum = data.BoxNum or 0
	local hasId = false
	for k,v in pairs(self.mapBoss.Box) do
		if v.StepId == data.StepId then
			hasId = true
			break
		end
	end
	if not hasId then
		table.insert(self.mapBoss.newBoxIds, data.StepId)
		table.insert(self.mapBoss.Box, data)
	end
end

function LevelModel:refreshStepNum()
	self.mapBoss.StepNum = self.mapBoss.StepNum + 1
end

function LevelModel:removeMapBox(id)
	for k,v in ipairs(self.mapBoss.Box) do
		if v.StepId == id then
			table.remove(self.mapBoss.Box, k)
			break
		end
	end
end

function LevelModel:checkHasMapBox(id)
	for i,v in ipairs(self.mapBoss.Box) do
		if v.StepId == id then
			return v 
		end
	end
	return false
end

function LevelModel:addMapBoss(bossData)
	bossData.MonHp = {}---不记录血量
	table.insert(self.mapBoss.Boss, bossData)
	self.mapBoss.CallNum = self.mapBoss.CallNum + 1
end

function LevelModel:checkHasMapBoss(id)
	for i,v in ipairs(self.mapBoss.Boss) do
		if v.StepId == id then
			return v 
		end
	end
	return false
end

function LevelModel:reviveDieHero(ids)
	for k,id in pairs(ids) do
		for i,v in ipairs(self.mapBoss.HeroHp) do
			if v.Id == id then
				table.remove(self.mapBoss.HeroHp, i)
				break
			end
		end
	end
end

function LevelModel:updateMapBossInfo(data)
	---不记录血量
	-- for _,v in pairs(data.SelfDecHp or {}) do
	-- 	local hasId = false
	-- 	for i,k in pairs(self.mapBoss.HeroHp) do
	-- 		if v.Id == k.Id then
	-- 			hasId = true
	-- 			k.DecHp = v.DecHp
	-- 			k.Power = v.Power
	-- 			break
	-- 		end
	-- 	end
	-- 	if not hasId then
	-- 		table.insert(self.mapBoss.HeroHp, v)
	-- 	end
	-- end

	for k,v in pairs(self.mapBoss.Boss) do
		if v.StepId == data.StepId then
			if data.IsWin then
				-- table.remove(self.mapBoss.Boss, k)
				v.isDie = true
				v.rewards = data.Rewards
			else
				-- v.MonHp = data.EmyDecHp
			end
			break
		end
	end
end

function LevelModel:removeMapBoss(levelId)
	for k,v in pairs(self.mapBoss.Boss) do
		if v.StepId == levelId then
			table.remove(self.mapBoss.Boss, k)
			break
		end
	end
end

function LevelModel:updateMapBossDecHp(hpDatas)
	for i,v in pairs(hpDatas or {}) do
		for _, data in pairs(self.mapBoss.HeroHp) do
			if v.Id == data.Id then
				data = v
				break
			end
		end
	end
end


return LevelModel