local sqartifactConf = require "app.configs.sqartifact"

local ArtifactModel = class("artifactModel")

local attributes = {
	["id"] = 0, -- ID
	["lv"] = 0,
	["stage"] = 0,
	["star"] = 0,
	["power"] = 0,
	["runes"] = {},
	["fetters"] = {},
}


function ArtifactModel:ctor()
	self.artifacts = {}
	self.artifactCount = 0

	self.artifactConf = {}

	for k,v in ipairs(sqartifactConf) do
		self.artifactConf[v.artifactId] = v
	end
end

function ArtifactModel:addArtifacts(artifacts)
	for _, artifact in pairs(artifacts or {}) do
		self:addArtifact(artifact)
	end
end

function ArtifactModel:addArtifact(data)
	local attr = clone(attributes)

	attr.id = data.Id
	attr.lv = data.Lv or 1
	attr.stage = data.Stage or 0
	attr.star = data.Stars or 0
	attr.svrLv = data.SvrLv or 1
	attr.power = data.Power or 0
	attr.runes = data.Runes or {}
	attr.fetters = data.Fetters or {}
	self.artifacts[data.Id] = attr

	self.artifactCount = self.artifactCount + 1
end

function ArtifactModel:getArtifactCount()
	return self.artifactCount
end

function ArtifactModel:getArtifact(artifactId)
	return self.artifacts[artifactId]
end

function ArtifactModel:getArtifacts()
	return self.artifacts
end

function ArtifactModel:updateArtifact(data)
	local artifact = self:getArtifact(data.Art.Id)
	if artifact then
		artifact.id = data.Art.Id
		artifact.lv = data.Art.Lv
		artifact.stage = data.Art.Stage or 0
		artifact.star = data.Art.Stars or 0
		artifact.svrLv = data.Art.SvrLv or 1
		artifact.power = data.Art.Power or 0
		artifact.runes = data.Art.Runes or {}
		artifact.fetters = data.Art.Fetters or {}
	else
		self:addArtifact(data.Art)
	end
end

function ArtifactModel:updatePower(data)
	for k,v in ipairs(data.Items) do
		if self.artifacts[v.Id] then
			self.artifacts[v.Id].power = v.Power
		end
	end
end

--神器总属性加成
function ArtifactModel:getArtifactAttr(artifactId)
	local attrTab = {}
	local level = self.artifacts[artifactId].svrLv
	local star = self.artifacts[artifactId].star
	local levelAttr = self:getArtifactLevelAttr(level)
	local starAttr = self:getArtifactStarAttr(artifactId, star)
	local runesAttr = self:getArtifactRunesAttr(artifactId)
	local fetterAttr = self:getArtifactFetterAttr(artifactId)

	local insertAttrToTable = function(attrs, tab)
		for k,attr in ipairs(attrs) do
			local has = false

			for _,tabAttr in ipairs(tab) do
				if attr.id == tabAttr.id then
					tabAttr.val = tabAttr.val + attr.val
					has = true
					break
				end
			end

			if not has then
				table.insert(tab, {id = attr.id, val = attr.val})
			end
		end
	end

	insertAttrToTable(levelAttr, attrTab)
	insertAttrToTable(starAttr, attrTab)
	insertAttrToTable(runesAttr, attrTab)
	insertAttrToTable(fetterAttr, attrTab)

	return attrTab
end

--神器等级属性加成
function ArtifactModel:getArtifactLevelAttr(artifactLevel)
	local sqartifactLvupConf = require "app.configs.sqartifactLvup"
	local globalPublicConf = require "app.configs.globalPublic"
	local attrTab = {}

	if artifactLevel > globalPublicConf[1].sqartifactLvupMax then
		return attrTab
	end

	for _,v in ipairs(sqartifactLvupConf) do
		if v.svrlv <= artifactLevel then
			for _,levelAttr in ipairs(v.nature) do
				local has = false

				for k,attr in ipairs(attrTab) do
					if attr.id == levelAttr.id then
						attr.val = attr.val + levelAttr.val
						has = true
						break
					end
				end

				if not has then
					table.insert(attrTab, {id = levelAttr.id, val = levelAttr.val})
				end
			end
		else
			break
		end
	end
	return attrTab
end

--神器升星属性加成
function ArtifactModel:getArtifactStarAttr(artifactId, artifactStar)
	local sqartifactStarConf = require "app.configs.sqartifactStar"
	local globalPublicConf = require "app.configs.globalPublic"

	local attrTab = {}

	if artifactStar > globalPublicConf[1].sqartifactStarMax then
		return attrTab
	end

	local artifactStarData = sqartifactStarConf[artifactId]

	for k,v in ipairs(artifactStarData.nature) do
		if artifactStar >= v.star then
			local id = v.id
			local val = v.val + (artifactStar - v.star) * v.ratio
			table.insert(attrTab, {id = id, val = val})
		end
	end

	return attrTab
end

--神器符文属性加成
function ArtifactModel:getArtifactRunesAttr(artifactId)
	local sqrunesConf = require "app.configs.sqrunes"
	
	local attrTab = {}

	local cData = self.artifactConf[artifactId]

	local isRunesTerm = self:checkRunesTerm(artifactId, cData)
	if isRunesTerm then --符文之歌
		attrTab = cData.maxNature
	else
		for _,runeId in pairs(self.artifacts[artifactId].runes or {}) do
			if runeId ~= 0 then
				local runeData = sqrunesConf[runeId]

				for _,attr in ipairs(runeData.nature) do
					local has = false
					for k,tabAttr in ipairs(attrTab) do
						if attr.id == tabAttr.id then
							attrTab[k].val = attrTab[k].val + attr.val
							has = true
							break
						end
					end

					if not has then
						table.insert(attrTab, {id = attr.id, val = attr.val})
					end

				end
			end
		end
	end

	return attrTab, isRunesTerm
end

function ArtifactModel:getRunesTermAttr(artifactId)
	local sqrunesConf = require "app.configs.sqrunes"

	local attrTab = self.artifactConf[artifactId].maxNature

	return attrTab
end


function ArtifactModel:checkRunesTerm(artifactId, cData)
	local isRunesTerm = true
	if not cData.runesTerm or #cData.runesTerm == 0 or not self.artifacts[artifactId] then
		return false
	end

	for k,v in ipairs(cData.runesTerm or {}) do
		if self.artifacts[artifactId].runes[k] ~= v then
			isRunesTerm = false
			break
		end
	end

	return isRunesTerm
end


--神器羁绊属性加成
function ArtifactModel:getArtifactFetterAttr(artifactId)
	local sqartifactFettersConf = require "app.configs.sqartifactFetters"

	local cData = self.artifactConf[artifactId]


	local fetterData = {}

	for k,v in ipairs(self.artifacts[artifactId].fetters) do
		fetterData[v.Id] = v.Lv
	end

	local attrTab = {}

	for k,v in ipairs(cData.fetters or {}) do
		local cData = sqartifactFettersConf[v]
		local fetterLv = fetterData[cData.heroFetter] or 0
		if fetterLv >= cData.actStar then
			for _,attr in ipairs(cData.starProperty) do
				if fetterLv == attr.n then
					table.insert(attrTab, {id = attr.id, val = attr.val})
					break
				end
			end
		end
	end
	return attrTab
end

function ArtifactModel:checkUpgrade(artifactId)
	local sqartifactLvupConf = require "app.configs.sqartifactLvup"
	local itemConf = require "app.configs.item"
	local currencyConf = require "app.configs.currency"
	local init = require "app.models.init"
	local globalPublicConf = require "app.configs.globalPublic"

	local ItemModel = init.ItemModel
	local PlayerModel = init.PlayerModel

	if not self.artifacts[artifactId] or self.artifacts[artifactId].svrLv >= globalPublicConf[1].sqartifactLvupMax then
		return false
	end

	local consume = sqartifactLvupConf[self.artifacts[artifactId].svrLv].consume
	local enough = true
	for k,v in ipairs(consume) do
		if v.id > 0 then
			local useNum = 0
			if itemConf[v.id] then
				local item = ItemModel:getItem(v.id)
				useNum = item and item.number or 0
			elseif currencyConf[v.id] then
				useNum = PlayerModel:getPlayerCurrency(v.id)
			end
			local needNum = v.n or 0
			if needNum > useNum then
				enough = false
				break
			end
		end
	end
	return enough
end

function ArtifactModel:checkUpStar(artifactId)
	local sqartifactStarConf = require "app.configs.sqartifactStar"
	local sqartifactLvupConf = require "app.configs.sqartifactLvup"
	local globalPublicConf = require "app.configs.globalPublic"
	local itemConf = require "app.configs.item"
	local currencyConf = require "app.configs.currency"
	local init = require "app.models.init"
	local ItemModel = init.ItemModel
	local PlayerModel = init.PlayerModel

	if not self.artifacts[artifactId] or self.artifacts[artifactId].star >= globalPublicConf[1].sqartifactStarMax then
		return false
	end

	local maxStar, stage = 0, sqartifactLvupConf[self.artifacts[artifactId].svrLv].state
	for k,v in ipairs(sqartifactStarConf[artifactId].clearTerm or {}) do
		if stage >= v.state then
			maxStar = v.star
		end
	end

	if maxStar <= self.artifacts[artifactId].star then
		return false
	end

	local consume = {}
	for k,v in ipairs(sqartifactStarConf[artifactId].consume) do
		if self.artifacts[artifactId].star + 1 == v.star then
			table.insert(consume, {id = v.id, n = v.n})
		elseif self.artifacts[artifactId].star + 1 < v.star then
			break
		end
	end

	local enough = true
	for k,v in ipairs(consume) do
		local useNum = 0
		if itemConf[v.id] then
			local item = ItemModel:getItem(v.id)
			useNum = item and item.number or 0
		elseif currencyConf[v.id] then
			useNum = PlayerModel:getPlayerCurrency(v.id)
		end
		local needNum = v.n
		if needNum > useNum then
			enough = false
			break
		end
	end
	return enough
end

function ArtifactModel:checkFetterAct(artifactId)
	local sqartifactFettersConf = require "app.configs.sqartifactFetters"
	local canAct = false
	local fetterData = {}

	if not self.artifacts[artifactId] then
		return false
	end

	for k,v in ipairs(self.artifacts[artifactId].fetters) do
		fetterData[v.Id] = v.Lv
	end

	for k,v in ipairs(self.artifactConf[artifactId].fetters or {}) do
		local fetterStar = 0
		if self.artifacts[sqartifactFettersConf[v].heroFetter] then
			fetterStar = self.artifacts[sqartifactFettersConf[v].heroFetter].star
		end
		local fetterLv = fetterData[sqartifactFettersConf[v].heroFetter] or 0
		local actStar = sqartifactFettersConf[v].actStar

		if fetterStar > fetterLv and fetterStar >= actStar then
			canAct = true
			break
		end
	end
	return canAct
end

return ArtifactModel