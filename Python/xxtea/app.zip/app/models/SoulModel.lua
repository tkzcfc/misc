

local SoulModel = class("SoulModel")
local itemConf = require "app.configs.item"

local attributes = {
	["seq"] = 0,
	["id"] = 0,
	["lv"] = 0,
	["exp"] = 0,
	["slot"] = 0,
}

function SoulModel:ctor()
	self.Souls = {}
	self.SoulCount = 0
	self.unlockSlot = 0
end

function SoulModel:removeSoul(soulsDel)
	for _,seq in pairs(soulsDel or {}) do
		if self.Souls[seq] then
			self.SoulCount = self.SoulCount - 1
		end
		self.Souls[seq] = nil
	end
end

function SoulModel:addSouls(souls)
	for _,soul in pairs(souls or {}) do 
		self:addSoul(soul)
	end
end

function SoulModel:addSoul(soul)
	local attr = clone(attributes)

	attr.seq = soul.Seq
	attr.id = soul.Id
	attr.level = soul.Lv
	attr.exp = soul.Exp
	attr.slot = soul.Slot

	attr.heroId = soul.HeroId or 0
	attr.locked = soul.Locked or false
	attr.atkPwr = soul.AtkPwr or 0

	self.Souls[soul.Seq] = attr
	self.SoulCount = self.SoulCount + 1
end


function SoulModel:getSoul(seq)
	return self.Souls[seq]
end

function SoulModel:getSouls()
	return self.Souls
end

function SoulModel:updateLevel(data)
	self.Souls[data.Seq].level = data.Lv
	self.Souls[data.Seq].exp = data.Exp 
end

function SoulModel:updateHeroId(data)
	local soulData = self.Souls[data.seq]
	soulData.heroId = data.heroId
	soulData.slot = data.slot
end

function SoulModel:getSoulCount()
	return self.SoulCount
end

function SoulModel:getSoulsBox(heroId)  ---获取英雄已装备护灵
	local soulsData = self:getSouls()
	local soulsBox = {}
	for _,soul in pairs(soulsData) do
		if heroId == soul.heroId then
			soulsBox[soul.slot] = soul
		end
	end
	return soulsBox
end

function SoulModel:GetSealLevel(soulsBox) ---获取七像封印等级
	local itemConf = require "app.configs.item"
	local sevenImageSealConf = require "app.configs.sevenImageSeal"
	local colorNum = {}
	for i,data in ipairs(sevenImageSealConf) do
		local num = 0
		for _,soul in pairs(soulsBox) do
			local soulColor = itemConf[soul.id].color
			if soulColor >= data.unlockColor then
				num = num + 1
			end
		end
		if num >= data.unlockNum then
            table.insert(colorNum, data.unlockColor)
		end
	end
	if #colorNum == 0 then return 1 end
    table.sort(colorNum, function(a, b)
   		return a > b
   	end)
    
    return colorNum[1]
end


function SoulModel:checkHaveSoul(heroID)  ---检查是否有可装备护灵
	local allSouls = self:getSouls()
	local notEquipNum = {}
	local equipNum = {}
	for k,v in pairs(allSouls) do
		local typeNum = itemConf[v.id].type
		if v.heroId == 0 and typeNum ~= 511 then
			notEquipNum[typeNum] = 0
		elseif v.heroId == heroID then
            equipNum[typeNum] = 0
		end
	end
	for type_,v in pairs(notEquipNum) do
		if not equipNum[type_] then
			return true
		end
	end
	return false
end

function SoulModel:soulAltarInfo(data)
	self.unlockSlot = data.EquipSlot or 0
end

function SoulModel:getSoulUnlockSlot()
	return self.unlockSlot
end


return SoulModel