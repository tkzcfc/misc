local FamilyModel = class("FamilyModel")
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local guildConf = require "app.configs.guild"
local c = require "app.configs.constants"
local globalPublicConf = require "app.configs.globalPublic"
local guildPositionConf = require "app.configs.guildPosition"
local guildTaskConf = require "app.configs.guildTask"
local guildGainConf = require "app.configs.guildGain"
function FamilyModel:ctor()
    self.myFamily = {}
    self.appliedList = {}--已申请列表
    self.applyList = {}--申请列表
    self.guildId = ""
    self.guildName = ""
    self.guildRank = 0
    self.plrData = {}
    self.fightingBoss = {}
    --1-15个位置对应的 等级、占位、rank（2.4.6为活跃区）
    self.posData = {
        [1] = {lv = 1, pos = 1, rank = 1},
        [2] = {lv = 2, pos = 1, rank = 2},
        [3] = {lv = 2, pos = 1, rank = 3},
        [4] = {lv = 3, pos = 1, rank = 4},
        [5] = {lv = 3, pos = 2, rank = 4},
        [6] = {lv = 3, pos = 3, rank = 4},
        [7] = {lv = 3, pos = 1, rank = 5},
        [8] = {lv = 3, pos = 2, rank = 5},
        [9] = {lv = 3, pos = 3, rank = 5},
        [10] = {lv = 4, pos = 1, rank = 6},
        [11] = {lv = 4, pos = 2, rank = 6},
        [12] = {lv = 4, pos = 3, rank = 6},
        [13] = {lv = 4, pos = 1, rank = 7},
        [14] = {lv = 4, pos = 2, rank = 7},
        [15] = {lv = 4, pos = 3, rank = 7},
    }

    self.myHelpData = {}
    self.helpList = {}
    self.inviteCnt = 0
end

function FamilyModel:initData(data)
    self.guildId = data.GuildId
    self.guildName = data.GuildName
    self.guildRank = data.GuildRank
    if self.guildId ~= "" then--有家族，拉取自己的家族信息
        network.tcpSend(msgids.C_GuildInfoFull)
        network.tcpSend(msgids.C_GuildHelpSelfList)
        network.tcpSend(msgids.C_GuildHelpList)
    else--没有家族拉取已申请列表
        network.tcpSend(msgids.C_GuildPlrApplyList)
    end
end

function FamilyModel:initPlrData(data)
    self.plrData.leaveTs = data.LeaveTs--上次离开家族，下次加入时间
    self.plrData.leaveCnt = data.LeaveCnt--离开家族次数
    self.plrData.lirstJoinReward = data.LirstJoinReward--是否领取首次加入家族宝箱
    self.plrData.donateIds = {} --供奉id
    self.plrData.donateTaken = {} --供奉已领取,(对应人数)
    self.plrData.questTaken = {} --工会日常领取id
    self.plrData.actScoreTaken = {} --工会活跃领取id

    for _,id in ipairs(data.DonateIds or {}) do
        self.plrData.donateIds[id] = true --供奉id
    end
    for _,id in ipairs(data.DonateTaken or {}) do
        self.plrData.donateTaken[id] = true --供奉已领取,(对应人数)
    end
    for _,id in ipairs(data.QuestTaken or {}) do
        self.plrData.questTaken[id] = true --工会日常领取id
    end
    for _,id in ipairs(data.ActScoreTaken or {}) do
        self.plrData.actScoreTaken[id] = true --工会活跃领取id
    end
end

function FamilyModel:getPlrData()
    return self.plrData
end

function FamilyModel:getFamilyInfo()
    return self.myFamily
end

function FamilyModel:getFamilyId()
    return self.guildId
end

function FamilyModel:isApply(id)
    return self.appliedList[id] ~= nil
end

function FamilyModel:isApplyFull(id)
    return table.nums(self.appliedList) >= c.MAX_APPLY_FAMILY_CNT
end

function FamilyModel:getAppliedList()
    return self.appliedList
end

function FamilyModel:setApplyData(row)
    self.applyData = row
end

function FamilyModel:getFamilyMemLimit(lv, buyCnt)
    return guildConf[lv].mbLimit + buyCnt
end

function FamilyModel:isMaster(uid)
    return self.myFamily.Master.Id == uid 
end

function FamilyModel:canAccuseMaster()
    local Helper = require "app.Helper"
    return Helper.getFixedTime() - self.myFamily.Master.OfflineTs >= globalPublicConf[1].guildKickHour * 3600
end

function FamilyModel:getMyPosData()
    return self.myFamily.myPosData
end

function FamilyModel:getTargetActScore()
    local conf = guildConf[self.myFamily.Row.Lv].activeReward
    return conf[#conf].score
end

function FamilyModel:getWorshipPop()
    local population = 0
    for _,info in ipairs(self.myFamily.Mbs) do
        if info.Donation > 0 then
            population = population + 1
        end
    end
    return population
end

function FamilyModel:getCurType()
    local scale = 1
    for _,info in ipairs(guildPositionConf) do
        local mineScoreT = info.mineScore
        local lvT = info.guildLv
        local score = self.myFamily.Row.MineOccScore or 0
        if score >= mineScoreT and self.myFamily.Row.Lv >= lvT then
            scale = info.scale
        end
    end
    return scale
end

function FamilyModel:getPosPlayer(i, pos)
    local rank = self.posData[i].rank
    pos = self.posData[i].pos
    for i,info in ipairs(self.myFamily.Mbs) do
        if info.Rank == rank then
            pos = pos - 1
            if pos == 0 then
                return info
            end
        end
    end
end

function FamilyModel:getRankNum(rank)
    local num = 0
    for i, info in ipairs(self.myFamily.Mbs or {}) do
        if info.Rank == rank then
            num = num + 1
        end
    end
    return num
end

function FamilyModel:getGainConf(scale, rank)
    local buffs = {}
    for _,info in ipairs(guildGainConf) do
        if scale == info.scale and rank == info.rk then
            table.insert(buffs, info)
        end
    end
    return buffs
end

function FamilyModel:setDonaId(id)
    self.donaId = id
end

function FamilyModel:getTodayInviteCnt()
    return self.inviteCnt
end

function FamilyModel:handleMsg(op, data)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local RedTipsModel = init.RedTipsModel

    if op == msgids.GS_GuildInfo_R then
        --拉取其他公会数据
    elseif op == msgids.GS_GuildCreate_R then
        network.tcpSend(msgids.C_GuildInfoFull)
    elseif op == msgids.GS_GuildInfoFull_R then
        self.myFamily = data.Info
        self.inviteCnt = self.myFamily.Row.RecruitCnt or 0
        self.guildId = data.Info.Row.Id
        self.guildName = data.Info.Row.Name or ""
        for _,info in pairs(data.Info.Mbs) do
            if info.Rank == 1 then
                self.myFamily.Master = info
                break
            end
        end
        for _,info in pairs(data.Info.Mbs) do
            if info.Id == PlayerModel:getInfo().userId then
                self.myFamily.myPosData = info
                break
            end
        end

        self:initPlrData(data.Info.GuildPlrData or {})
    elseif op == msgids.GS_GuildPlrApplyList_R then
        self.appliedList = {}
        for _,info in ipairs(data.Rows or {}) do
            self.appliedList[info.Id] = info
        end
    elseif op == msgids.GS_GuildApply_R then
        self.appliedList[data.GuildId] = self.applyData
        self.applyData = nil
    elseif op == msgids.GS_GuildApplyCancel_R then
        self.appliedList[data.GuildId] = nil
    elseif op == msgids.GS_GuildQuestTaken_R then
        self.plrData.questTaken[data.Id] = true
        -- self.myFamily.Row.ActScore = self.myFamily.Row.ActScore + guildTaskConf[data.Id].activeAdd
    elseif op == msgids.GS_GuildActScoreReward_R then
        self.plrData.actScoreTaken[data.ActScore] = true
    elseif op == msgids.GS_Guild_Leave then
        for idx,info in pairs(self.myFamily.Mbs or {}) do
            if data.PId == PlayerModel:getInfo().userId then
                self.guildId = ""
                self.guildName = ""
                self.guildRank = 0
            end
            if info.Id == data.PId then
                table.remove(self.myFamily.Mbs, idx)
            end
        end
    elseif op == msgids.GS_Guild_Rank then
        if self.myFamily and self.myFamily.Mbs then
            for idx,info in pairs(self.myFamily.Mbs) do
                if info.Id == data.PId then
                    self.myFamily.Mbs[idx].Rank = data.Rank
                    self.myFamily.Mbs[idx].Name = data.PName
                    if data.Rank == 1 then
                        self.myFamily.Master = info
                        self.myFamily.Row.OwnerName = info.Name
                    end
                    if info.Id == PlayerModel:getInfo().userId then
                        self.myFamily.myPosData = info
                        break
                    end
                    break
                end
            end
        end
    elseif op == msgids.GS_Guild_Join then
        if data.Mb.Id == PlayerModel:getInfo().userId then
            network.tcpSend(msgids.C_GuildInfoFull)
        else
            if data.GuildId == self.myFamily.Row.Id then
                table.insert(self.myFamily.Mbs, data.Mb)
            end
        end
    elseif op == msgids.GS_GuildChangeSetting_R then
        if self.myFamily then
            self.myFamily.Row.Head = data.Head
            self.myFamily.Row.AMode = data.AMode
            self.myFamily.Row.RKMode = data.RKMode
            self.myFamily.Row.NeedLv = data.NeedLv
            self.myFamily.Notice = data.Notice
            self.myFamily.SNotice = data.SNotice
        else
            network.tcpSend(msgids.C_GuildInfoFull)
        end
    elseif op == msgids.GS_GuildChangeName_R then
        self.myFamily.Row.Name = data.Name
    elseif op == msgids.GS_GuildDonateBox_R then
        self.plrData.donateTaken[data.Cnt] = true
    elseif op == msgids.GS_GuildDonate_R then
        for idx,info in pairs(self.myFamily.Mbs) do
            if info.Id == PlayerModel:getInfo().userId then
                info.Donation = data.Donation
                break
            end
        end
        self.plrData.donateIds[self.donaId] = true
        self.donaId = nil
    elseif op == msgids.GS_Guild_Lv then
        self.myFamily.Exp = data.Exp
        if data.Level > 0 then
            self.myFamily.Row.Lv = data.Level
        end
        self.myFamily.Row.DonateCnt = data.DonateCnt
    elseif op == msgids.GS_GuildActScore then
        self.myFamily.Row.ActScore = data.ActScore
    elseif op == msgids.GS_GuildSetting then
        self.myFamily.Row.RKMode = data.RkMode
    elseif op == msgids.GS_GuildMineOccScore then
        if self.myFamily and self.myFamily.Row then
            self.myFamily.Row.MineOccScore = data.MineOccScore
        end
    elseif  op == msgids.GS_GuildBossUpdate or op == msgids.GS_GuildBossEnter_R then
        self.fightingBoss = data.Boss
        if not self.fightingBoss.ListTop.List then
            self.fightingBoss.ListTop.List ={}
        end
    elseif op == msgids.GS_GuildHelpSelfList_R then
        self.myHelpData = data
    elseif op == msgids.GS_GuildHelpList_R then
        self.helpList = data.List or {}
    elseif op == msgids.GS_GuildHelpGive_R then
        if data.Id then
            for k,v in ipairs(self.helpList) do
                if v.Id == data.Id then
                    v.N = v.N + 1
                    break
                end
            end
        end
        RedTipsModel:refreshFamilyTips()
        RedTipsModel:refreshFamilyHelpTips()
    elseif op == msgids.GS_GuildHelpTake_R then
        for k,v in ipairs(self.myHelpData.HelpAward or {}) do
            if v.Id == data.Id then
                v.N = 0
                break
            end
        end
        RedTipsModel:refreshFamilyTips()
        RedTipsModel:refreshFamilyHelpTips()
    elseif op == msgids.GS_GuildHelpTakeBox_R then
        self.myHelpData.HelpBoxAward = true
        RedTipsModel:refreshFamilyTips()
        RedTipsModel:refreshFamilyHelpTips()
    elseif op == msgids.GS_GulidRecruitCntSend then
        self.inviteCnt = data.RecruitCnt or 0
    elseif op == msgids.GS_GuildDestroy_R then
        self.myFamily = {}
    end
end

return FamilyModel