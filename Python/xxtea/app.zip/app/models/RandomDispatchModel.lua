--
-- Author: hexianxiong
-- Date: 2018-01-04 10:18:03
--
local missionConf = require "app.configs.mission"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local RandomDispatchModel = class("RandomDispatchModel")

local STATUS_CHANGE = {
	[0] = 2, -- 未派遣
	[1] = 3, -- 派遣中
	[2] = 1, -- 已完成
	[3] = 4, -- 已领取
}
function RandomDispatchModel:ctor()
	self.list = {}
	self.info = {}
end

--初始化随机派遣列表
function RandomDispatchModel:initRandomDispatchList(list)
	local data = {}
	self.list = {}
	if list and list.TaskList then
		data = list.TaskList
	end
	if list then
		self.info.curLevel = list.MissionLv or 1
		self.info.experience = list.MissionExp or 0
		self.info.oldLevel = list.MissionLv
	end
	for k,dispatch in pairs(data) do
		self.list[dispatch.Id] = dispatch
	end
end

--新的随机派遣事件
function RandomDispatchModel:addNewDispatch(dispatch)
	local Data = {
		Id = dispatch.Id,
		BegTime = dispatch.BegTime or 0,
		Lock = dispatch.Lock or false,
		Status = dispatch.Status or 0,
		Team = dispatch.Team or {},
	}
	self.list[dispatch.Id] = Data
end

function RandomDispatchModel:getDispatchInfo()
	return self.info
end

--随机派遣完成
function RandomDispatchModel:finishDispatch(data)
	if not self.list[data.Id] then
		return
	end
	self.list[data.Id].Status = c.REvtStatus_Finish
end

--随机派遣失败
function RandomDispatchModel:failedDispatch(data)
	if not self.list[data.Id] then
		return
	end
	self.list[data.Id].Status = c.REvtStatus_Failed
end

--随机派遣放弃
function RandomDispatchModel:dispatchGiveUp(dispatchId)
	if not self.list[dispatchId] then
		return
	end
	self.list[dispatchId].Status = c.REvtStatus_Taken
	self.list[dispatchId].Team = {}
	self.list[dispatchId].BegTime = 0
end

--随机派遣领取
function RandomDispatchModel:dispatchTaken(dispatchId)
	if not self.list[dispatchId] then
		return
	end
	self.list[dispatchId].Status = c.REvtStatus_Taken
	self.list[dispatchId].Team = {}
end

function RandomDispatchModel:updateDispatch(data)
	if not self.list[data.Id] then
		return
	end
	self.list[data.Id] = data
end

function RandomDispatchModel:updateDispatchLock(data)
	if not self.list[data.Id] then
		return
	end
	self.list[data.Id].Lock = data.Lock
end

function RandomDispatchModel:updateMissionExp(data)
	if not self.info then
		return
	end
	self.info.curLevel = data.MissionLv or 1
	self.info.experience = data.MissionExp or 0
	if self.info.curLevel > self.info.oldLevel then
		self.info.hasLvUp = true
		self.info.oldLevel = self.info.curLevel
	else
		self.info.hasLvUp = false
	end
end

function RandomDispatchModel:getDispatchsList()
	local resultList = {}
	for _, dispatch in pairs(self.list) do
		if dispatch.Status ~= c.REvtStatus_Taken and missionConf[dispatch.Id] then
			table.insert(resultList,dispatch)
		end
	end
	table.sort(resultList, function(a, b)
		local conf_a = missionConf[a.Id]
		local conf_b = missionConf[b.Id]
 		if a.Status ~= b.Status then
			return STATUS_CHANGE[a.Status] < STATUS_CHANGE[b.Status]
		end
		if conf_a.color ~= conf_b.color then
			return conf_a.color > conf_b.color
		end
		if a.Status == c.REvtStatus_Start or a.Status == c.REvtStatus_Create then
			local leftTimeA = a.BegTime + missionConf[a.Id].times - Helper.getFixedTime()
			local leftTimeB = b.BegTime + missionConf[b.Id].times - Helper.getFixedTime()
			return leftTimeA < leftTimeB
		end
		return a.Id < b.Id
	end)
	return resultList
end

function RandomDispatchModel:getDispatch(mapId)
	for _, dispatch in pairs(self.list) do
		if dispatch.MapId == mapId then
			return dispatch
		end
	end
	return nil
end

function RandomDispatchModel:clearTeam(id)
	if not self.list[id] then
		return 
	end
	self.list[id].Team = {}
	self.list[id].Pct = 0
end

--英雄是否已经派遣
function RandomDispatchModel:isHeroDispatched(dispatchId,heroId)
	for _, dispatch in pairs(self.list) do
		for i = 1, #dispatch.Team do
			if dispatchId ~= dispatch.Id and dispatch.Team[i] == heroId then
				return true
			end
		end
	end
	return false
end

return RandomDispatchModel