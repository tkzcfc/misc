--押镖

local escortPvpConf = require "app.configs.escortPvp"

local Helper = require "app.Helper"
local EscortModel = class("EscortModel")

function EscortModel:ctor()
	self.escortCnt = 0
	self.robCnt = 0
	self.carRefrCnt = 0
	self.robTeam = nil--镖车抢劫队伍
	self.wScore = 0--积分
	self.nextTs = 0--下次视野刷新时间

	self.myCar = {}--我的镖车
	self.sight = {}--视野
	self.log = {}--记录

	self.sightCnt = escortPvpConf[1].viewCnt
end

function EscortModel:setMaxFreeCnt()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	self.maxFreeRefresh = PlayerModel:getCounterByID(2010001)--刷新免费上限
	self.maxFreeEscort = PlayerModel:getCounterByID(2010002)--押送免费上限
	self.maxRob = PlayerModel:getCounterByID(2010003)--抢夺上限
end


function EscortModel:setSchedInfo(s_msg)
	self.sched = s_msg.Sched
	self.lockMinute = s_msg.LockMinute
end

function EscortModel:getEndUnix()
	local endTime = 0
	local serverTime = Helper.getFixedTime()

	if not self.sched then
		return endTime
	end

	for i=2,100,2 do
		local time = self.sched[i]
		if not time then
			break
		end

		if serverTime < time and serverTime > self.sched[i-1] then
			endTime = time
			break
		end
	end

	return endTime
end

function EscortModel:setMyCar(s_msg)
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local info = PlayerModel:getInfo()
	self.myCar.PlrId = info.userId
	self.myCar.SvrId = "1"
	self.myCar.Name = info.name
	self.myCar.Head = info.head
	self.myCar.HFrame = info.hFrame
	self.myCar.AtkPwr = info.atkPwr
	self.myCar.CarColor = s_msg.CarColor

	if s_msg.CarInfo then
		self:updateEscortInfo(s_msg.CarInfo)
	end

	self.escortCnt = s_msg.EscortCnt
	self.robCnt = s_msg.RobCnt
	self.carRefrCnt = s_msg.CarRefrCnt
end

function EscortModel:getMyCar()
	return self.myCar
end

function EscortModel:updateMyCar(s_msg)
	if self.myCar.CarColor and self.myCar.CarColor ~= 0 then
		self.carRefrCnt = self.carRefrCnt + 1
	end

	if s_msg.CarColor then
		self.myCar.CarColor = s_msg.CarColor
	end
end

function EscortModel:updateEscortInfo(s_msg, addCnt)
	local addCnt = addCnt or 0
	self.escortCnt = self.escortCnt + addCnt

	self.myCar.CarLv = s_msg.CarLv or 0
	self.myCar.End_Ts = s_msg.End_Ts or 0
	self.myCar.BRCnt = s_msg.BRCnt or 0
	self.myCar.BRLeft = s_msg.BRLeft or 0
	self.myCar.Ratio = s_msg.Ratio or 1
	self.myCar.Locked = false

	self:updateMyCarSight()
end

function EscortModel:updateMyCarSight()
	if self.myCar and self.myCar.End_Ts and self.myCar.End_Ts > Helper.getFixedTime() then
		self.sight[self.sightCnt] = self.myCar
	else
		local init = require "app.models.init"
		local PlayerModel = init.PlayerModel
		local userId = PlayerModel:getInfo().userId
		for k,v in pairs(self.sight) do
			if v.PlrId == userId then
				self.sight[k] = nil
				break
			end
		end
	end
end

function EscortModel:finishMyCar(s_msg)
	self.wScore = s_msg.WScore

	self.myCar.CarColor = 0
	self:updateEscortInfo({})
end

function EscortModel:isDriving()
	local driving = false
	if self.myCar and self.myCar.End_Ts and self.myCar.End_Ts > Helper.getFixedTime() then
		driving = true
	end

	return driving
end

function EscortModel:updatePlayerCnt(s_msg)
	--积分处理
	self.wScore = s_msg.WScore

	if s_msg.Win and s_msg.TarId then
		for k,v in pairs(self.sight) do
			if v.PlrId == s_msg.TarId then
				self.sight[k].BRCnt = self.sight[k].BRCnt + 1
				self.sight[k].BRLeft = self.sight[k].BRLeft - 1
			end
		end
	end
end

function EscortModel:addRobCnt()
	self.robCnt = self.robCnt + 1
end

function EscortModel:setSight(s_msg)
	self.sight = s_msg.Sight or {}
	self.nextTs = s_msg.NextTs

	self:updateMyCarSight()
end

function EscortModel:getSight()
	return self.sight
end

function EscortModel:addLog(s_msg, isRob)
	local Helper = require "app.Helper"
	local data = {
		srcName = s_msg.SrcName or nil,
		tarName = s_msg.TarName or nil,
		carColor = s_msg.CarColor,
		time = os.time(),
		isRob = isRob,
		score = s_msg.Score or 0,
	}
	self.log[#self.log + 1] = data
	Helper.sendEvent("refreshEscortLog", {addtips = true})
end

function EscortModel:getLog()
	return self.log
end

function EscortModel:setRobTeam(team)
	self.robTeam = team
end

function EscortModel:getRobTeam()
	return self.robTeam
end

function EscortModel:getRemainEscortCnt()
	local cnt = self.maxFreeEscort - self.escortCnt
	return cnt < 0 and 0 or cnt
end

function EscortModel:getRemainRobCnt()
	local cnt = self.maxRob - self.robCnt
	return cnt < 0 and 0 or cnt
end

function EscortModel:getRemainCarRefrCnt()
	local cnt = self.maxFreeRefresh - self.carRefrCnt
	return cnt < 0 and 0 or cnt
end

function EscortModel:getRefreshCost()
	if self.maxFreeRefresh - self.carRefrCnt > 0 then
		return 0
	else
		local cnt = (self.carRefrCnt - self.maxFreeRefresh) + 1
		local refresh = escortPvpConf[1].colorRefreshConsume or {}
		return refresh[cnt] or refresh[#refresh]
	end
end

function EscortModel:getEscortCost()
	if self.maxFreeEscort - self.escortCnt > 0 then
		return 0
	else
		local cnt = (self.escortCnt - self.maxFreeEscort) + 1
		local consume = escortPvpConf[1].escortConsume or {}
		return consume[cnt] or consume[#consume]
	end
end

function EscortModel:getOrangeCost()
	return escortPvpConf[1].onekeyColor
end

function EscortModel:getFinishCost()
	local costs = escortPvpConf[1].onekeyFinish or {}
	return costs[self.myCar.CarColor] or 0
end

return EscortModel
