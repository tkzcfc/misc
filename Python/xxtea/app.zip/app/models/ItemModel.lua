--ItemModel.lua

local ItemModel = class("ItemModel")

local attributes = {
	["number"] = 0, -- 拥有数量
	["id"] = 0, -- ID
}


function ItemModel:ctor()
	self.items = {}
end

function ItemModel:addItems(items)
	for _, item in pairs(items or {}) do
		self:addItem(item)
	end
end

function ItemModel:addItem(data)
	local attr = clone(attributes)

	attr.number = data.Num
	attr.id = data.Id
	if data.Num  == 0 then
		self.items[data.Id] = nil
	else
		self.items[data.Id] = attr
	end
end

function ItemModel:getItem(itemID)
	return self.items[itemID]
end

function ItemModel:getItems()
	return self.items
end

function ItemModel:getItemCntById(itemID)
	local cnt = 0

	local item = self.items[itemID]
	if item and item.number then
		cnt = item.number
	end

	return cnt
end

return ItemModel
