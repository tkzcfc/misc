

-- 限购商城模块，主要用于红点显示

local msgids = require "app.network.msgids"
local network = require "app.network.network"
local Helper = require "app.Helper"

-- local signConf = require "app.configs.sign"
-- local cmltConf = require "app.configs.Cmlt"



local SignInModel = class("SignInModel")

local function getCurDay()
    local curTs = Helper.getFixedTime()
    local day = os.date("%d", curTs)
    return tonumber(day)
end

function SignInModel:ctor()
    -- local data = {}
    -- for _,v in pairs(limitShopConf) do
    --     data[v.sheet] = data[v.sheet] or {}
    --     table.insert(data[v.sheet], v)
    -- end
    -- self.confData = data

    self.firstGetInfo = true
end

function SignInModel:refreshSignInData(data)

    self.Info = data.Info or {}

    self:checkSignInRedTips()
end

function SignInModel:getInfo()
    if not self.firstGetInfo then
        self:checkSignInRedTips()
        return
    end
    network.tcpSend(msgids.C_CalendarInfo)
    self.firstGetInfo = false
end

--检查限购商城红点--
function SignInModel:checkSignInRedTips()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local isSigned = false
    local record = self.Info.LoginRec or {}
    for _,v in pairs(record) do
        if v.Id == getCurDay() then
            isSigned = true
        end
    end

    local isCanReceive = false
    if self.Info.Payed then
        for _,v in pairs(record) do
            if v.Id == getCurDay() and v.N ~= 2 then
                isCanReceive = true
            end
        end
    end
    Helper.sendEvent("refreshSignIn", {addtips = (not isSigned) or isCanReceive})
end



return SignInModel