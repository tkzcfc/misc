

-- 限购商城模块，主要用于红点显示

local msgids = require "app.network.msgids"
local network = require "app.network.network"
local Helper = require "app.Helper"

local limitShopConf = require "app.configs.limitShop"



local LimitShopModel = class("LimitShopModel")

function LimitShopModel:ctor()
    local data = {}
    for _,v in pairs(limitShopConf) do
        data[v.sheet] = data[v.sheet] or {}
        table.insert(data[v.sheet], v)
    end
    self.confData = data

    self.firstGetInfo = true
end

function LimitShopModel:refreshLimitShopData(data)
    local Data = data.Data or {}
    local Goods = Data.Goods or {}
    self.goodsData = Goods
    self:checkLimitShopRedTips()
end

function LimitShopModel:getInfo()
	if not self.firstGetInfo then
		self:checkLimitShopRedTips()
		return
	end
	network.tcpSend(msgids.C_LimitShopGetInfo)
	self.firstGetInfo = false
end

--检查限购商城红点--
function LimitShopModel:checkLimitShopRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	for _,conf in pairs(self.confData) do
		for _,data in pairs(conf) do
	        local mustLv = data.levelSection[1].up
	        local isOutRange = (data.levelSection[1].down < PlayerModel.info.level) or (data.levelSection[1].up > PlayerModel.info.level)
	        if isOutRange then
	            break
	        end

	        local maxCnt = data.maxCnt or 1
	        local useNum = 0
	        for _,v in pairs(self.goodsData or {}) do
	            if v.Id == data.id then
	                useNum = v.BuyCnt
	            end
	        end

	        -- 剩余次数
	        if maxCnt-useNum <= 0 then
	        	break
	        end

	        -- 时间显示
	        if data.startTime == "" or data.duration == 0 then
	        	Helper.sendEvent("refreshLimitShop", {addtips = true})
	        	return
	        else
	            -- 开服时间 + 持续时间 = 最终时间
	            -- 最终时间-服务器时间 = 倒计时时间
	            local finalTime = Helper.getParseTime(data.startTime) + data.duration
	            local curTime = Helper.getFixedTime()
	            local sec = finalTime - curTime >= 0 and finalTime - curTime or 0
	            if sec >= 0 then
	            	Helper.sendEvent("refreshLimitShop", {addtips = true})
	            	return
	            end
	        end
	    end
	    Helper.sendEvent("refreshLimitShop", {})
    end
end



return LimitShopModel