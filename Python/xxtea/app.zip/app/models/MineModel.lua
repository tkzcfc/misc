--
-- Author: hexianxiong
-- Date: 2018-01-10 16:35:39
--
local randomMineConf = require "app.configs.randomMine"
local mineLevelLimitConf = require "app.configs.mineLevelLimit"
local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local C = require "app.network.enums"

local MineModel = class("MineModel")

function MineModel:ctor()
	self.mine = {}
end

--同步矿山信息
function MineModel:updateMine(data,force)
	if not data then
		return
	end
	if data.CurId or force then
		self.mine.CurId = data.CurId
	end
	if data.MinerBag or force then
		self.mine.MinerBag = data.MinerBag
	end
	if data.Ids or force then
		self.mine.Ids = {}
		if data.Ids then
			for _, id in pairs(data.Ids) do
				if randomMineConf[id] then
					table.insert(self.mine.Ids,id)
				end
			end
		end
		table.sort(self.mine.Ids,function(id1,id2)
			local conf1 = randomMineConf[id1]
			local conf2 = randomMineConf[id2]
			if conf1.color ~= conf2.color then
				return conf1.color > conf2.color
			end
			return id1 < id2
			end)
	end
	if data.MapIds or force then
		self.mine.MapIds = data.MapIds or {}
	end
	if data.MineData then
		self.mine.MineData = data.MineData
	end
end

function MineModel:addNewMiner(data)
	if not self.mine.MineData then
		return
	end
	if self.mine.MineData.Id ~= data.Id then
		return
	end
	if not self.mine.MineData.Miners then
		self.mine.MineData.Miners = {}
	end
	table.insert(self.mine.MineData.Miners,data.Miner)
end

function MineModel:removeMiner(data)
	if not self.mine.MineData then
		return
	end
	if not self.mine.MineData.Miners then
		return
	end
	for i = #self.mine.MineData.Miners, 1, -1 do
		if self.mine.MineData.Miners[i].Plrid == data.Plrid then
			table.remove(self.mine.MineData.Miners,i)
			break
		end
	end
end

function MineModel:updateCapacity(data)
	if not self.mine.MineData then
		return
	end
	if self.mine.MineData.Id ~= data.Id then
		return
	end
	self.mine.MineData.Capacity = data.Capacity
end

function MineModel:removeMine(data)
	if self.mine.MineData then
		if data.Id == self.mine.MineData.Id then
			self.mine.MineData = nil
		end
	end
	if self.mine.Ids then
		for i = #self.mine.Ids, 1, -1 do
			if self.mine.Ids[i] == data.Id then
				table.remove(self.mine.Ids,i)
				table.remove(self.mine.MapIds,i)
				break
			end
		end
	end
end

--是否可以领取奖励
function MineModel:checkReward()
	--当前占领矿无法领取
	if self.mine.CurId ~= 0 then
		return false
	end
	if self.mine.MinerBag then
		if (self.mine.MinerBag.Ccy and #self.mine.MinerBag.Ccy > 0) 
			or (self.mine.MinerBag.Items and #self.mine.MinerBag.Items > 0) then

			return true
		end
	end
	return false
end

--领完奖励清空MinerBag
function MineModel:clearMinerBag()
	self.mine.MinerBag = {}
end

--检测等级变化是否需要重新获取数据
function MineModel:checkLevelUp(oldLevel,newLevel)
	-- local oldMine = 0
	-- local newMine = 0
	-- for i = 1, #mineLevelLimitConf do
	-- 	local mineLevelLimitConfData = mineLevelLimitConf[i]
	-- 	if oldLevel >= mineLevelLimitConfData.levelDown and oldLevel <= mineLevelLimitConfData.levelUp then
	-- 		oldMine = mineLevelLimitConfData.Id
	-- 	end
	-- 	if newLevel >= mineLevelLimitConfData.levelDown and newLevel <= mineLevelLimitConfData.levelUp then
	-- 		newMine = mineLevelLimitConfData.Id
	-- 	end
	-- end
	-- if newMine > oldMine then
	-- 	network.tcpSend(msgids.C_MinesId)
	-- end
end

--是否是空的矿点
function MineModel:isEmptyMiner(pos)
	if not self.mine.MineData then
		return true
	end
	if not self.mine.MineData.Miners or #self.mine.MineData.Miners <= 0 then
		return true
	end
	for _, miner in pairs(self.mine.MineData.Miners) do
		if miner.Pos == pos then
			return false
		end
	end
	return true
end

function MineModel:getLeftEnergy()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local randomMineConfData = randomMineConf[self.mine.MineData.Id]
	local counterId = randomMineConfData.cost[1].id
	local energy = PlayerModel:getCounterByID(counterId)
    return math.max(0,energy)
end

function MineModel:getLeftRob()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local rob = PlayerModel:getCounterByID(C.Cnt_Mine_Rob)
    local maxRob = PlayerModel:getCounterByID(C.Max_Vip_Cnt_Mine_Rob)
    return math.max(0,maxRob-rob)
end

function MineModel:getCurrencyNum(miner)
	if miner.MinerBag and miner.MinerBag.Ccy and #miner.MinerBag.Ccy > 0 then
		return miner.MinerBag.Ccy[1].Val
	end
	return 0
end

--判断矿点是否易主
function MineModel:checkMinerChange(miner)
	local plrid = miner.Plrid
	local pos = miner.Pos
	local isFind = false
	for _, _Miner in pairs(self.mine.MineData.Miners) do
		if _Miner.Pos == pos and _Miner.Plrid == plrid then
			isFind = true
			break
		end
	end
	return not isFind
end

return MineModel