local ArenaModel = class("ArenaModel")
local pvpTargetConf = require "app.configs.pvpTarget"
function ArenaModel:ctor()
    self.arena = nil
end

function ArenaModel:updateInfo(data)
    self.arena = data
end

function ArenaModel:updateTagTaken(data)
    if self.arena.TagTaken == nil then
        self.arena.TagTaken = {}
    end
    table.insert(self.arena.TagTaken, data.Id)
end

function ArenaModel:getInfo()
    return self.arena
end

function ArenaModel:hasTake(id)
    local exchanged = false
    for i,idx in ipairs(self.arena.TagTaken or {}) do
        if idx == id then
            exchanged = true 
            break
        end
    end
    return exchanged
end

function ArenaModel:canTake()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    if self.arena then
        for _,info in ipairs(pvpTargetConf) do
            if self.arena.HisRankMax <= info.maxRank 
                and not self:hasTake(info.Id)
                and PlayerModel:getCurrencyByID(info.cost[1].id) >= info.cost[1].n then
                return true
            end
        end
    end
    return false
end

function ArenaModel:updateRepsRed()
    self.hasNewReps = true
end

function ArenaModel:disableRepsRed()
    self.hasNewReps = false
end

function ArenaModel:getArenaRepsRed()
    return self.hasNewReps
end

return ArenaModel