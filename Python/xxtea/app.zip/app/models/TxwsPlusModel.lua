
local TxwsPlusModel = class("TxwsPlusModel")

function TxwsPlusModel:ctor()	
	self:reset()
end

function TxwsPlusModel:initData(data)
	self:reset()
	self.verTs = data.VerTs
	self.verStage = data.VerStage
	self.score = data.Score
	for k,v in ipairs(data.Teams or {}) do
		self.teams[k] = v
	end
	self.aliveTs = data.AliveTs
	self.svrScoreRank = data.SvrScoreRank
	self.viewer = data.Viewer
	self.bossValid = data.BossValid or false
	self.bossData = data.BossData or {}
	self.pvpBossCdTs = data.PvpBossCdTs
	self.pvpBossCnt = data.PvpBossCnt
	self.winCnt = data.WinCnt
end

function TxwsPlusModel:reset()
	self.verTs = 0
	self.verStage = 0
	self.score = 0
	self.teams = {}
	for i = 1, 15 do
		self.teams[i] = 0
	end
	self.aliveTs = 0
	self.svrScoreRank = {}
	self.viewer = {}
	self.pvpBossCdTs = 0
	self.pvpBossCnt = 0
	self.bossValid = false
	self.bossData = {}
	self.winCnt = 0
end

function TxwsPlusModel:isDeath()
	local Helper = require "app.Helper"
	return self.aliveTs > Helper.getFixedTime()
end

function TxwsPlusModel:onFightPvpBoss(data)
	self.pvpBossCdTs = data.PvpBossCdTs
	self.pvpBossCnt = self.pvpBossCnt + 1
end

function TxwsPlusModel:getMySvrRank()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	local rank = 0
	local mySvrId = PlayerModel:getMyServerId()
	for k, v in ipairs(self.svrScoreRank or {}) do
		if tonumber(v.Id) == tonumber(mySvrId) then
			rank = k
			break
		end
	end
	return rank
end

function TxwsPlusModel:updateStageInfo(data)
	self.verTs = data.VerTs
	self.verStage = data.VerStage
	self.bossValid = data.BossValid
end

function TxwsPlusModel:updateSvrScoreRank(data)
	self.svrScoreRank = data.SvrScoreRank
end

function TxwsPlusModel:updateTeam(teams)
	self.teams = teams
end

function TxwsPlusModel:isSetTeam()
	for k,v in ipairs(self.teams) do
		if v ~= 0 then
			return true
		end
	end
	return false
end

function TxwsPlusModel:getTeam()
	return self.teams
end

function TxwsPlusModel:onFight(data)
	local Helper = require "app.Helper"
	self.aliveTs = data.AliveTs or self.aliveTs

	if data.Rep and self:checkIsWin(data) then
		self.winCnt = self.winCnt + 1
	end
end

function TxwsPlusModel:checkIsWin(data)
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	local isAtk = PlayerModel.info.userId == data.Rep.AtkPlrId and true or false
	local isAtkWin = data.Rep.AtkWinCnt >= data.Rep.DfdWinCnt

	local isWin = true
	if isAtk then
		isWin = isAtkWin
	else
		isWin = not isAtkWin
	end
	return isWin
end

function TxwsPlusModel:updateBossData(data)
	self.bossData = data.BossData
end

return TxwsPlusModel