local RewardPalaceModel = class("RewardPalaceModel")
local offerTokenConf = require "app.configs.offerToken"
local officialConf = require "app.configs.official"
local msgids = require "app.network.msgids"

function RewardPalaceModel:ctor()
    self.room = {}-- 房间数据
    self.hasChallengeTimes = {}
end

function RewardPalaceModel:initData(data)
    table.sort(data.StepInfos,function(a,b)
        return a.Id < b.Id
    end)
    for _,info in pairs(data.StepInfos or {}) do
        if not self.room[info.TypeId] then
            self.room[info.TypeId] = {}
        end
        table.insert(self.room[info.TypeId] ,info)
        if not self.room[info.TypeId].MaxStep then
            if info.MaxStep == 0 or not info.MaxStep then
                self.room[info.TypeId].MaxStep = info.Id - 1
            else
                self.room[info.TypeId].MaxStep = info.MaxStep
            end
        end
    end
end

function RewardPalaceModel:getRoomMsg(typeId)
    return self.room[typeId]
end

function RewardPalaceModel:handleMsg(op, data)
    if op == msgids.GS_OfferGetInfo_R then
        self:initData(data.Data)
    elseif op == msgids.GS_OfferBattle_R then
        local TABS = self:returnTABS()
        if self.fightTabName and TABS[self.fightTabName] and data.CurMaxStep then
            self.room[TABS[self.fightTabName].typeId].MaxStep =  data.CurMaxStep
        end
    end
end

function RewardPalaceModel:setFightIdx(idx)
    self.fightIdx = idx
end

function RewardPalaceModel:getFightIdx()
    return self.fightIdx
end

function RewardPalaceModel:setFightTabName(tabName)
    self.fightTabName = tabName
end

function RewardPalaceModel:getFightTabName()
    return self.fightTabName
end

function RewardPalaceModel:updateCanChallenge()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    for _,info in pairs(self:returnTABS()) do
        self.hasChallengeTimes[info.typeId] = false
        local totalTimes = PlayerModel:getCounterByID(info.challengeTimesMaxCt)
        local challengeTimes = PlayerModel:getCounterByID(info.challengeTimesCt) - PlayerModel:getCounterByID(info.buyTimesCnt)
        if totalTimes > challengeTimes then
            self.hasChallengeTimes[info.typeId] = true
        end
    end
end

function RewardPalaceModel:canChallenge(typeId)
    return self.hasChallengeTimes
end

function RewardPalaceModel:returnTABS()
    local C = require "app.network.enums"
    local TABS = {
        coin = {
            typeId = 1,
            challengeTimesCt = C.Cnt_OfferToken_Gold,
            challengeTimesMaxCt = C.Max_Vip_Cnt_OfferToken_Gold,
            buyTimesCnt = C.Cnt_OfferToken_Gold_Buy,
        },
        strength = {
            typeId = 2,
            challengeTimesCt = C.Cnt_OfferToken_SP,
            challengeTimesMaxCt = C.Max_Vip_Cnt_OfferToken_SP,
            buyTimesCnt = C.Cnt_OfferToken_SP_Buy,
        },
        exp = {
            typeId = 3,
            challengeTimesCt = C.Cnt_OfferToken_XHS,
            challengeTimesMaxCt = C.Max_Vip_Cnt_OfferToken_XHS,
            buyTimesCnt = C.Cnt_OfferToken_XHS_Buy,
        },
    }
    return TABS
end

return RewardPalaceModel