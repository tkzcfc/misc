--TowerModel.lua

local TowerModel = class("TowerModel")

local attributes = {
	["prevFloor"] = 0,-- 上一层
	["curFloor"] = 0, -- 当前层数
	["actFloor"] = 0, -- 最近激活楼层
	["taken"] = {}, --领取的目标
	["eliteFloor"] = {}, --精英关卡
}

function TowerModel:ctor()
	self.info = {}

	for key, value in pairs(attributes) do
		self.info[key] = value
	end
end

function TowerModel:initInfo(towerData)
	self:updatePrevFloor(towerData.CurFloor)
	self:updateCurFloor(towerData.CurFloor)
	self:updateActFloor(towerData.ActFloor)
	self.info.taken = towerData.Taken or {}
	self.info.eliteFloor = towerData.EliteFloor or {}
end

function TowerModel:onTakeReward(data)
	table.insert(self.info.taken, data.Id)
end

function TowerModel:updatePrevFloor(prevFloor)
	self.info.prevFloor = prevFloor
end

function TowerModel:updateCurFloor(curFloor)
	self.info.curFloor = curFloor
end

function TowerModel:updateActFloor(actFloor)
	self.info.actFloor = actFloor
end

function TowerModel:onFightTowerElite(data)
	self.info.eliteFloor[data.Floor] = data.Star
end

return TowerModel
