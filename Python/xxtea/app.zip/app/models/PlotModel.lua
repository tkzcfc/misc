local Helper = require "app.Helper"
local plotsConf = require "app.configs.plots"

local PlotModel = class("PlotModel")

function PlotModel:ctor()
    self.Journal = {}
    self.Step = {}
    self.Boss = {}
    self.rankDatas = {}
    self.myRank = 0
    self.times = {}--阶段时间
    for _,v in pairs(plotsConf) do
        local time = self:convertToTimestamp(v.time)
        self.times[v.stage] = time
    end
end

--转化为时间戳
function PlotModel:convertToTimestamp(timeStr)
    local _, _, y, m, d, _hour, _min, _sec = string.find(timeStr, "(%d+)-(%d+)-(%d+)%s*(%d+):(%d+):(%d+)");
    local timestamp = os.time({year=y, month = m, day = d, hour = _hour, min = _min, sec = _sec});

    return timestamp 
end

function PlotModel:updateData(data)
    for key,v in pairs(data or {}) do
        self[key] = v
    end
end

--更新宝箱奖励领取状态
function PlotModel:updateJournalTaken(id)
    if not self.Journal.Taken then
        self.Journal.Taken = {}
    end
    table.insert(self.Journal.Taken, id)
end

--更新通关地穴
function PlotModel:updateStep(step)
    self.Step.Step = step or 0
end

--更新二阶段宝箱领取状态
function PlotModel:updateStepBoxTaken()
    self.Step.Taken = true
end

function PlotModel:updateRankData(data)
    self.rankDatas = {}
    self.myRank = data.Idx
    for _,v in pairs(data.Rec or {}) do
        self.rankDatas[v.Idx] = v
    end
end

--是否显示主界面按钮
function PlotModel:checkMainBtnShow()
    local curTime = Helper.getFixedTime()
    if curTime >= self.times[1] and curTime < self:getEndTime(3) then
        return true
    end

    return false
end

--是否弹出宝箱
function PlotModel:checkBoxShow()
    local curTime = Helper.getFixedTime()
    if curTime >= self.times[3] and curTime < self:getEndTime(3) and not self.Step.Taken and self.Step.Step > 0 then
        return true
    end

    return false
end

--NPC开启
function PlotModel:checkNpc()
    local curTime = Helper.getFixedTime()
    local startTime = self.times[2]
    
    return curTime >= startTime
end

--当前阶段开启状态
function PlotModel:checkOpenState(stage)
    local curTime = Helper.getFixedTime()
    local startTime = self.times[stage]
    local endTime = self:getEndTime(stage)

    local state = 0
    if curTime < startTime then
        state = 0 --未开启
    elseif curTime < endTime then
        state = 1--开启
    else
        state = 2 --结束
    end

    return state
end

--当前阶段  第X天
function PlotModel:getCurDay(stage)
    if not self.times[stage] then
        return 0
    end

    local day = Helper.getPassedDay(self.times[stage])

    return day
end

--宝箱积分
function PlotModel:getBoxScore()
    return self.Journal.SvrPoint or 0
end

--当前宝箱是否已开启
function PlotModel:getSpreadTaken(boxId)
    local tanken = self.Journal.Taken or {}
    return table.indexof(tanken, boxId)
end

--当前关卡
function PlotModel:getCurStep()
    return (self.Step.Step or 0) + 1
end

--当前关卡开启倒计时
function PlotModel:getStepOpenTime(stage, openDay)
    local startTime = self.times[stage]
    if not startTime then
        return 0
    end

    local startDate = os.date("*t", startTime)
    local startDayTs = os.time({year = startDate.year, month = startDate.month, day = startDate.day, hour = 0, min = 0, sec = 0})
    local endTime = startDayTs + (openDay - 1) * 86400

    local cutdown = endTime - Helper.getFixedTime()
    if cutdown < 0 then
        cutdown = 0
    end

    return cutdown
end

function PlotModel:getEndTime(stage)
    local nextStage = stage + 1
    if not self.times[nextStage] then
        nextStage = 0
    end

    return self.times[nextStage]
end

--距离当前阶段结束时间
function PlotModel:getEndCutdown(stage)
    local endTime = self:getEndTime(stage)

    local cutdown = endTime - Helper.getFixedTime()
    if cutdown < 0 then
        cutdown = 0
    end

    return cutdown
end

function PlotModel:getBossCnt()
    return self.Boss.RwdCnt or 0
end

--get rank data
function PlotModel:getRankData()
    return self.rankDatas
end

function PlotModel:getMyRankData()
    return self.rankDatas[self.myRank] or {}
end

return PlotModel
