
local ChaseTraitorModel = class("ChaseTraitorModel")

local PhantomTowerConf = require "app.configs.phantomTower"

function ChaseTraitorModel:ctor()
    self.data = {}
end

function ChaseTraitorModel:updateChaseData(data)
	self.data = data or {}
end

function ChaseTraitorModel:getOpenTs()
	return self.data.OpenTs or 0
end

function ChaseTraitorModel:getTower()
	return self.data.Tower or 1
end

function ChaseTraitorModel:getCloseTime()
	local num = table.nums(PhantomTowerConf)
	return PhantomTowerConf[num].closeTime
end

return ChaseTraitorModel
