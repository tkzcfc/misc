local NinjaMasterModel = class("NinjaMasterModel")
local msgids = require "app.network.msgids"

function NinjaMasterModel:ctor()
    self.info = {}
    self.redPack = nil
    self.timeConf = nil 
    self.newLog = {}
end

function NinjaMasterModel:handleMsg(op, data)
    if op == msgids.GS_NinjaMasterInfo_R then
        self.info = data.Data
        -- dump(self.info,"",2)
    elseif op == msgids.GS_NinjaMasterSetTeam_R then
        self.info.Team = data.Team
    elseif op == msgids.GS_NinjaMasterFight_R then
        self.info.Rank = data.Rank 
    elseif op == msgids.GS_NinjaMasterRedPack then
        self.redPack = data.Rewards
    elseif op == msgids.GS_NinjaMasterConf_R then
        self.timeConf = data.Conf
    elseif op == msgids.GS_NinjaMasterMessage_R then
        self.info.Message = data.Message
        self.info.Ts = data.Ts
    elseif op == msgids.GS_NinjaMasterRep then
        table.insert(self.newLog, data.Rep)
    end
end

function NinjaMasterModel:getMasterByIndex(index)
    for k,v in pairs(self.info.Rank or {}) do
        if v.Idx == index then
            return v
        end
    end
    return nil
end

function NinjaMasterModel:getFightTsByIndex(index)
    for k,v in pairs(self.info.FightTs or {}) do
        if v.Id == index then
            return v.Val
        end
    end
    return 0
end

return NinjaMasterModel