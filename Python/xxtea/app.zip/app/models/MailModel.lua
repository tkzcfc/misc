-- MailModel.lua

local mailConf = require "app.configs.mail"

local MailModel = class("MailModel")

function MailModel:ctor()
	self.list = {}
end

--初始化邮件列表
function MailModel:initMailList(list)
	for k,mail in pairs(list or {}) do
		self:checkMailInfo(mail)
		self.list[mail.Id] = mail
	end
end

function MailModel:checkMailInfo(mail)
	if mailConf[mail.Key] then
		local conf = mailConf[mail.Key]
		mail.Sender = conf.send
		mail.Title = conf.title
		mail.Text = conf.text

		for k,v in pairs(mail.Dict or {}) do
			mail.Text = string.gsub(mail.Text, "$"..k, v)
		end
	end
end

--新邮件
function MailModel:addNewMail(mail)
	self:checkMailInfo(mail)
	self.list[mail.Id] = mail
end

--更新邮件信息
function MailModel:updateReadMail(data)
	if not self.list[data.Id] then
		return
	end
	self.list[data.Id].ETs = data.ETs
	self.list[data.Id].Read = true
end

--更新领取邮件
function MailModel:updateTakeMail(data)
	if not self.list[data.Id] then
		return
	end
	self.list[data.Id].ETs = data.ETs
	self.list[data.Id].Taken = true
	self.list[data.Id].Read = true
end

function MailModel:updateTakeAllMail(data)
	for k,v in ipairs(data.ETss) do
		self:updateTakeMail(v)
	end
end

--删除邮件
function MailModel:deleteMails(ids)
	for k,mid in ipairs(ids or {}) do
		self.list[mid] = nil
	end

	local tmp = {}
	for mid,mail in pairs(self.list) do
		if mail then
			tmp[mid] = mail
		end
	end
	self.list = tmp
end

return MailModel