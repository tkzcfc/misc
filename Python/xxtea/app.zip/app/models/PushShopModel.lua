--推送商城
local PushShopModel = class("PushShopModel")
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"

function PushShopModel:ctor()
    self.endTs = 0
    self.buyId = 0
    self.ids = {}
    self.takeId = 0
end

function PushShopModel:initData(data)
    self.ids = data.Gifts or {}
    self.endTs = data.TimeSec or 0
    self.buyId = data.BillId or 0
end

function PushShopModel:isOpen()
    return (#self.ids > 0 and self.endTs > Helper.getFixedTime() or self.buyId ~= 0) and self.takeId == 0
end

function PushShopModel:handleMsg(op, msg)
    if op == msgids.GS_PushShopGetInfo_R then
        self:initData(msg.Data)
    elseif op == msgids.GS_PushShopBill then
        self.buyId = msg.BillId or 0
    elseif op == msgids.GS_PushShopTake_R then
        self.takeId = msg.Id or 0
    end
end

function PushShopModel:getProperty(name)
    return self[name]
end

return PushShopModel