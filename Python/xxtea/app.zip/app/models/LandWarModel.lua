
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local initialConf = require "app.configs.initial"
local landConf = require "app.configs.landPlus"
local mapConfigs = require "app.configs.pvpMap"
local effectConf = require "app.configs.effect"
local globalPublicConf = require "app.configs.globalPublic"
local guildConf = require "app.configs.guild"
local C = require "app.network.enums"

local LandWarModel = class("LandWarModel")

local BASE_NUMBER = 1000
local LAND_TYPE = {
    Invalid = 0,  ---无效地块
    Birth = 1,    ---出生点
    Ordinary = 2, ---普通地块
    Royal = 3,    ---皇庭
    Base = 4,     ---据点
    City = 5,     ---城池
}

function LandWarModel:ctor()
    self.landInfo = {}
    self:initMapConfigs()
    self:initLandGroupConfigs()
end

function LandWarModel:initMapConfigs()
    self.mapConfigs = {}

    local tilesets = mapConfigs.tilesets
    for _,layerData in ipairs(mapConfigs.layers) do
        if not layerData.visible then
            local data = layerData.data
            for index, gid in ipairs(data) do
                local info = tilesets[gid]

                if info then
                    self.mapConfigs[index-1] = info
                end
            end
        end
    end
end

function LandWarModel:initLandGroupConfigs()
    self.landGroupConfigs = {}--关卡组包含的关卡ID

    for id,v in pairs(landConf) do
        if v.group and v.group ~= 0 then
            if not self.landGroupConfigs[v.group] then
                self.landGroupConfigs[v.group] = {}
            end
            table.insert(self.landGroupConfigs[v.group],v.id)
        end
    end
end

function LandWarModel:getGroupIds(group)
    return self.landGroupConfigs[group]
end

function LandWarModel:getMapConfigByIndex(index)
    local id = nil
    if self.mapConfigs[index] then
        id = tonumber(self.mapConfigs[index].properties.id)
    end
    return id
end

function LandWarModel:getImgName(index)
    if self.mapConfigs[index] then
        return self.mapConfigs[index].name
    end
    return nil
end

function LandWarModel:getHexByLevelId(levelId)
    return cc.p(math.floor(levelId / BASE_NUMBER),levelId % BASE_NUMBER)
end

function LandWarModel:getLevelIdByHex(pos)
    return (pos.x * BASE_NUMBER) + pos.y
end

--====================================================
function LandWarModel:handleMsg(op, data)
    if op == msgids.GS_LandplusMapInfo_R then
        self.landInfo.startId = data.BirthBid
        self.landInfo.giveUpTimes = data.Abandon or 0
        self.landInfo.rewardTs = data.GjRewardTs
        self.landInfo.blocks = {}
        for _, block in pairs(data.Blocks) do
            self.landInfo.blocks[block.Bid] = block
        end
        self:updateOwnBlocks()
    elseif op == msgids.GS_LandplusBlockInfo_R then
        if self.landInfo.blocks then
            self.landInfo.blocks[data.Data.Bid] = data.Data
        end
    elseif op == msgids.GS_LandplusTeamList_R then
        self.landInfo.myTeamInfo = data
    elseif op == msgids.GS_LandplusUpdateBlockTeam then
         if self.landInfo.blocks and self.landInfo.blocks[data.Bid] then
            self.landInfo.blocks[data.Bid].NpcCnt = data.NpcCnt
        end
    elseif op == msgids.GS_LandplusRevive_R  or op == msgids.GS_LandplusFighting_R
    or op == msgids.GS_LandplusTeamRecall_R then
        ---更新自己的队伍列表
        network.tcpSend(msgids.C_LandplusTeamList)
    elseif op == msgids.GS_LandplusUrgencyInfo_R or op == msgids.GS_LandplusUrgency_R then
        self.landInfo.gather = data.Bids 
    elseif op == msgids.GS_LandplusUpdateBlock then
        for i,v in ipairs(data.Blocks or {}) do
            if self.landInfo.blocks and self.landInfo.blocks[v.Bid] then
                self.landInfo.blocks[v.Bid] = v
            end
        end
        self:updateOwnBlocks()
    elseif op == msgids.GS_LandplusPassed_R then
        self.landInfo.passedId = data.Blocks or {}
    elseif op == msgids.GS_LandplusPassedReward_R then
        for k,id in pairs(data.Bids or {}) do
            for i,v in ipairs(self.landInfo.passedId or {}) do
                if id == v.Bid then
                    v.Got = true 
                    break
                end
            end
        end
    elseif op == msgids.GS_LandplusBirthBid then
        self.landInfo.startId = data.Bid
    elseif op == msgids.GS_LandplusAbandon_R then
        self.landInfo.giveUpTimes = data.Abandon or 0
    elseif op == msgids.GS_LandplusTips_R then
        self.landInfo.redTipsInfo = data 
    elseif op == msgids.GS_LandplusRankRewardGet_R or op == msgids.GS_LandplusRankGJGet_R then
        if data.GjRewardTs and data.GjRewardTs > 0 then
            self.landInfo.rewardTs = data.GjRewardTs
        end
        network.tcpSend(msgids.C_LandplusTips)
    end
end


--判断地块是否可以争夺，四周是否有已占领地块或出生点
function LandWarModel:isBlockCanOcc(id)
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel

    local block = self:getBlockById(id)
    if block and block.Gid == PlayerModel.info.guildId then
        return true
    end
    local pos = self:getHexByLevelId(id)
    local id1 = self:getLevelIdByHex(cc.p(pos.x-1,pos.y))
    local id2 = self:getLevelIdByHex(cc.p(pos.x+1,pos.y))
    local id3 = self:getLevelIdByHex(cc.p(pos.x,pos.y-1))
    local id4 = self:getLevelIdByHex(cc.p(pos.x,pos.y+1))
    local ids = {id1,id2,id3,id4}
    for i = 1, #ids do
        if ids[i] == self.landInfo.startId then
            return true
        end
        local block_ = self:getBlockById(ids[i])
        if block_ and block_.Gid == PlayerModel.info.guildId then
            return true
        end
    end
    return false
end

--刷新自己的地块
function LandWarModel:updateOwnBlocks()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local myGId = PlayerModel.info.guildId 

    self.landInfo.own = {}
    self.landInfo.other = {}
    for id, block in pairs(self.landInfo.blocks or {}) do
        if block.Gid and block.Gid ~= "" then
            if landConf[id] and (landConf[id].mark ~= LAND_TYPE.Invalid) and (landConf[id].mark ~= LAND_TYPE.Birth) then
                if block.Gid == myGId then
                    table.insert(self.landInfo.own, id)
                else
                    table.insert(self.landInfo.other, id)
                end
            end
        end
    end
end

--获取指定地块的信息
function LandWarModel:getBlockById(id)
    if self.landInfo.blocks then
        return self.landInfo.blocks[id]
    end
    return nil
end

--获取公会出生点
function LandWarModel:getStartId()
    return self.landInfo.startId
end


--获取自己公会占领的地块
function LandWarModel:getOwnBlocks()
    return self.landInfo.own or {}
end

--获取其他公会占领的地块
function LandWarModel:getOtherBlocks()
    return self.landInfo.other or {}
end

--获取自己的队伍列表
function LandWarModel:getMyTeamInfo()
    local teams = self.landInfo.myTeamInfo and self.landInfo.myTeamInfo.Teams or {}
    return teams
end

--获取已经死亡队伍列表
function LandWarModel:getKillHeroIds()
    local heroId = {}
    for i,v in ipairs(self.landInfo.myTeamInfo and self.landInfo.myTeamInfo.Graves or {}) do
        table.insert(heroId, v.HeroId)
    end
    return heroId
end


----获取集火地块
function LandWarModel:getGatherBlockIds()
    return self.landInfo.gather or {}
end

----获取集火状态
function LandWarModel:getGatherStage(blockId)
    for k,id in pairs(self.landInfo.gather or {}) do
        if id == blockId then
            return true
        end
    end 
    return false
end

----获取占领地块类型数
function LandWarModel:getOccupyIdsByType(blockType)
    local init = require "app.models.init"
    local GuildModel = init.GuildModel
    
    local max = 0
    local guildLv = GuildModel.row.Lv or 1
    for i,v in ipairs(guildConf[guildLv].landToplimit) do
        if v.mark == blockType then
            max = v.n
            break
        end
    end

    local data = {}
    local ids = self:getOwnBlocks()
    for k,id in pairs(ids) do
        if landConf[id] and landConf[id].mark == blockType then
            table.insert(data, id)
        end
    end

    return data, max
end

----获取首通数据
function LandWarModel:getMyOccBlocks()
   return self.landInfo.passedId or {}
end

----获取今日已放弃次数
function LandWarModel:getGiveUpTimes()
   return self.landInfo.giveUpTimes or 0
end

----获取红点数据
function LandWarModel:getRedTipInfo()
   return self.landInfo.redTipsInfo or {}
end

----获取领取挂机奖励时间
function LandWarModel:getRewardTs()
    local time = nil
    if self.landInfo.rewardTs > 0 then
        time = self.landInfo.rewardTs
    end
   return time
end

return LandWarModel