-- NinjaLegendModel.lua 忍界传说
local NinjaLegendModel = class("SpeCardModel")
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local ninjaLegendConf = require "app.configs.ninjaLegend"

function NinjaLegendModel:ctor()
    self.info = {}
    self.newRep = {}
    self.downRedTips = false
    self.ARank = 0
end

function NinjaLegendModel:initData(data)
	if not data or #data.Pos <= 0 then
		return
	end
    self.ARank = data.ARank or 0
	for k,v in ipairs(data.Pos or {}) do
		self.info[v.Id] = v
	end
end

function NinjaLegendModel:handleMsg(op, data)
    if op == msgids.GS_NinjaLegendInfo_R then
        self:initData(data.Data)
    elseif op == msgids.GS_NinjaLegendRep_R then
        table.insert(self.newRep, data.Rep)
    elseif op == msgids.GS_NinjaLegendCont_R then
        network.tcpSend(msgids.C_NinjaLegendInfo)
    elseif op == msgids.GS_NinjaLegendNew then
        local init = require "app.models.init"
        local RedTipsModel = init.RedTipsModel
        network.tcpSend(msgids.C_NinjaLegendInfo)
        self.downRedTips = true
        RedTipsModel:refreshNinjaLegendRedTips()
    end
end

function NinjaLegendModel:getCurStep()
    local init = require "app.models.init"
    local PlayerModel = init.PlayerModel
    local curStep = 0
    if self.info and #self.info > 0 then
        for k,v in ipairs(self.info) do
            if v.Plr and v.Plr.PlrId == PlayerModel.info.userId then
                curStep = v.Id
            end
        end
    end
    return curStep
end


function NinjaLegendModel:getInofById(id)
    return self.info[id] or nil
end

return NinjaLegendModel
