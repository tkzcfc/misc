
local DrawModel = class("DrawModel")

function DrawModel:ctor()   
    self:reset()
end

function DrawModel:initData(data)
    self:reset()
    self.init = true
    self.draw = data
end

function DrawModel:reset()
    self.draw = {}
    self.init = false
end

function DrawModel:getData()
    return self.draw
end

function DrawModel:getInfoByTp(tp)
    for k, v in pairs(self.draw.Types) do
        if v.Tp == tp then
            return v
        end
    end
    return {}
end

function DrawModel:onDrawTp(data)
    for k,v in pairs(self.draw.Types) do
        if v.Tp == data.Tp then
            self.draw.Types[k] = data
            break
        end
    end
end

return DrawModel