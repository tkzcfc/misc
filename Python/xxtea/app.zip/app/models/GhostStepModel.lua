local msgids = require "app.network.msgids"

local GhostStepModel = class("GhostStepModel")

function GhostStepModel:ctor()
    self.infoData = {}
end

function GhostStepModel:initData(data)
	self.infoData = data
end

function GhostStepModel:getInfoData()
    return self.infoData
end

function GhostStepModel:refreshRedTips()
    local init = require "app.models.init"
    local RedTipsModel = init.RedTipsModel

    RedTipsModel:refreshGhostStepTips()
end

function GhostStepModel:handleMsg(op, data)
    if op == msgids.GS_GhostStepInfo_R 
    or op == msgids.GS_GhostStepFight_R
    or op == msgids.GS_GhostStepReset_R
    or op == msgids.GS_GhostStepBuyReset_R
    or op == msgids.GS_GhostStepSweep_R then
        self:initData(data.Data)
        self:refreshRedTips()
    elseif op == msgids.GS_GhostStepTakeBox_R then
        if not self.infoData.Taken then
            self.infoData.Taken = {}
        end
        table.insert(self.infoData.Taken, data.Id) 
        self:refreshRedTips()
    end
end

return GhostStepModel