local network = require "app.network.network"
local msgids = require "app.network.msgids"
local c = require "app.configs.constants"
local Helper = require "app.Helper"
local msgPack = require "app.network.MessagePack"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local enums = require 'app.network.enums'
local WordDictionary = require "app.configs.WordDictionary"
local Scheduler = require "sandglass.core.Scheduler"


local ActivityModel = class("ActivityModel")

--Confs存放配表
--UserData存放活动数据
function ActivityModel:ctor()
	self.activityCalendars = {}
	self.sendGetMsgids = {}
	--超值礼包每次
	self.showSuperPurchaseRed = true
end
-- 双倍奖励进入界面就需要检查是否有配置
function ActivityModel:checkDoubleGainsConfig()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActDoubleGains) or {}
	act.UserData = {}
	if not act.Confs then
		network.tcpSend(msgids.C_ActConfGet, {Id = c.ACTIVITY_NAME.ActDoubleGains})
	end
end

-- 限时掉落检查是否有配置
function ActivityModel:checkTimeDropConfig()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActTimeDrop) or {}
	if not act.Confs then
		network.tcpSend(msgids.C_ActConfGet, {Id = c.ACTIVITY_NAME.ActTimeDrop})
	end
end

--活动相关消息处理，统一更新活动数据
function ActivityModel:handleMsg(op, data)
	if op == msgids.GS_ActCalendarChange then
		network.tcpSend(msgids.C_ActCalendarGet)
	elseif op == msgids.GS_ActCalendarGet_R then
		self:updateActivityCalendars(data.Acts)
		for _,v in pairs(data.Acts) do
			if v.Id == c.ACTIVITY_NAME.ActDoubleGains then
        		self:checkDoubleGainsConfig()
			elseif v.Id == c.ACTIVITY_NAME.ActTimeDrop then
        		self:checkTimeDropConfig()
			elseif v.Id == c.ACTIVITY_NAME.ActRewardRecall then
				local curTimeTs = os.date("*t",Helper.getFixedTime())
    			local time = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
    			local init = require "app.models.init"
    			local RewardRecallModel = init.RewardRecallModel
    			if RewardRecallModel.commonScheduler then
    				Scheduler.unscheduleGlobal(RewardRecallModel.commonScheduler)
    			end
    			RewardRecallModel.commonScheduler = Scheduler.scheduleGlobal(function()
    				if Helper.getFixedTime() > time + ((24 * 3600) + 10) then
				    	RewardRecallModel:sendGetRecallData()
				    	Scheduler.unscheduleGlobal(RewardRecallModel.commonScheduler)
				    end
				end, 60)
    		elseif v.Id == c.ACTIVITY_NAME.ActSignInReward then -- 签到福利需要每天0点拉下数据,与其同一期的签到转盘也需要拉下数据
				local curTimeTs = os.date("*t",Helper.getFixedTime())
    			local time = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
    			if self.commonScheduler then
    				Scheduler.unscheduleGlobal(self.commonScheduler)
    			end
    			self.commonScheduler = Scheduler.scheduleGlobal(function()
    				if Helper.getFixedTime() > time + ((24 * 3600) + 10) then
				    	self:sendGetActivityData(c.ACTIVITY_NAME.ActSignInReward)
				    	Scheduler.unscheduleGlobal(self.commonScheduler)
				    end
				end, 60)
    		elseif v.Id == c.ACTIVITY_NAME.ActSignInRoulette then -- 签到福利需要每天0点拉下数据,与其同一期的签到转盘也需要拉下数据
				local curTimeTs = os.date("*t",Helper.getFixedTime())
    			local time = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
    			if self.commonScheduler2 then
    				Scheduler.unscheduleGlobal(self.commonScheduler2)
    			end
    			self.commonScheduler2 = Scheduler.scheduleGlobal(function()
    				if Helper.getFixedTime() > time + ((24 * 3600) + 10) then
				    	self:sendGetActivityData(c.ACTIVITY_NAME.ActSignInRoulette)
				    	Scheduler.unscheduleGlobal(self.commonScheduler2)
				    end
				end, 60)
    		end
    			
		end
	elseif op == msgids.GS_ActStageChange then ---活动状态变化
		if data.Act then
			self.activityCalendars[data.Id] = data.Act
		elseif self.activityCalendars[data.Id] then
			self.activityCalendars[data.Id].Stage = data.Stage
		end
		self:updateActivityBtn(data.Id)
	elseif op == msgids.GS_ActConfGet_R then ----活动配置
		if not self.activityCalendars[data.Id] then
			return
		end
		local confData = {}
		for k,v in pairs(data.Confs or {}) do
			local unpackData = {}
			if v.Data then 
				unpackData = msgPack.unpack(v.Data)
			end
			confData[v.Name] = unpackData
		end
		self.activityCalendars[data.Id].Confs = confData
		self:updateActivityBtn(data.Id)
	elseif op == msgids.GS_ActConfChange then ----配置变化
		if self.activityCalendars[data.Id] then
			if data.Force or (data.ConfKey and data.ConfKey ~= self.activityCalendars[data.Id].ConfKey) then
				network.tcpSend(msgids.C_ActConfGet, {Id = data.Id})
				self.activityCalendars[data.Id].ConfKey = data.ConfKey
				self:sendGetActivityData(data.Id)
			end
		end
    elseif op == msgids.GS_ActWishInfo_R then
    	self.sendGetMsgids[c.ACTIVITY_NAME.ActWish] = nil
    	if not self.activityCalendars[c.ACTIVITY_NAME.ActWish] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActWish].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActWish)
	elseif op == msgids.GS_ActWishAward_R or op == msgids.GS_ActWishChange_R
		or op == msgids.GS_ActWishBox_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActWish] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActWish].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActWish)
	elseif op == msgids.GS_ActWishNum then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActWish] or not self.activityCalendars[c.ACTIVITY_NAME.ActWish].UserData then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActWish].UserData.Num = data.Num
		self:updateActivityBtn(c.ACTIVITY_NAME.ActWish)
    elseif op == msgids.GS_ActBillFirstInfo_R or op == msgids.GS_ActBillFirstNew then -- 首充信息
    	self.sendGetMsgids[c.ACTIVITY_NAME.ActFirstRecharge] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFirstRecharge)
		if op == msgids.GS_ActBillFirstNew then
	    	if self:getActivityState(c.ACTIVITY_NAME.ActAddGift) then
	    		self:sendGetActivityData(c.ACTIVITY_NAME.ActAddGift)
	    	end
		end
	elseif op == msgids.GS_ActBillFirstDailyAward_R then -- 首充获得
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFirstRecharge] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge] then
			return
		end
		local data_ = self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge].UserData
		if not data_.Days then
			data_.Days = {}
		end
		table.insert(data_.Days, data.Day)
		self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge].UserData = data_
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFirstRecharge)
	elseif op == msgids.GS_ActBillFirstAward_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFirstRecharge] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge] then
			return
		end
		local data_ = self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge].UserData
		if not data_.Taken then
			data_.Taken = {}
		end
		table.insert(data_.Taken, data.Id)
		self.activityCalendars[c.ACTIVITY_NAME.ActFirstRecharge].UserData = data_
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFirstRecharge)
	elseif op == msgids.GS_ActLevelShopInfo_R then -- 冲级商店信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.ActLevelShop] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelShop] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLevelShop].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLevelShop)
	elseif op == msgids.GS_ActLevelShopBuy_R then -- 冲级商店购买
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelShop] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActLevelShop].UserData.Goods, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLevelShop)
	elseif op == msgids.GS_Act7DayLoginInfo_R then -- 七日登陆信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.Act7DayLogin] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.Act7DayLogin] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act7DayLogin].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.Act7DayLogin)
	elseif op == msgids.GS_Act7DayLoginTake_R then -- 七日登陆奖励领取信息
		if not self.activityCalendars[c.ACTIVITY_NAME.Act7DayLogin] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act7DayLogin].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.Act7DayLogin)
	elseif op == msgids.GS_ActCostReturnInfo_R then -- 消费返利信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.ActCostRebate] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCostRebate] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActCostRebate].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCostRebate)
	elseif op == msgids.GS_ActOccultRouletteInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRoulette] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActRoulette].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActRoulette)
	elseif op == msgids.GS_ActOccultRoulette_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRoulette] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRoulette].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActRoulette].UserData = {Round = 1}
		else
			self.activityCalendars[c.ACTIVITY_NAME.ActRoulette].UserData.Round = self.activityCalendars[c.ACTIVITY_NAME.ActRoulette].UserData.Round + 1
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActRoulette)
	elseif op == msgids.GS_ActLimitGiftInfo_R then -- 限购礼包信息
		self.sendGetMsgids[c.ACTIVITY_NAME.ActLimitBuy] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitBuy)
	elseif op == msgids.GS_ActLimitGiftTake_R then -- 限购礼包领奖
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy] then
			return
		end
		local uData = self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy].UserData
		if not uData.RecGift then uData.RecGift = {} end
		local hasId = false
		for k,v in pairs(uData.RecGift) do
			if v.Id == data.Id then
				hasId = true
				v.N = v.N + 1
				break
			end
		end
		if not hasId then
			table.insert(uData.RecGift, {Id = data.Id, N = 1})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy].UserData = uData
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitBuy)
	elseif op == msgids.GS_ActLimitGiftNewGift then-- 限购礼包购买推送
       	if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy] then
			return
		end
		local uData = self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy].UserData
		if not uData.BuyGift then uData.BuyGift = {} end
		local hasId = false
		for k,v in pairs(uData.BuyGift) do
			if v.Id == data.GiftId then
				hasId = true
				v.N = v.N + 1
				break
			end
		end
		if not hasId then
			table.insert(uData.BuyGift, {Id = data.GiftId, N = 1})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitBuy].UserData = uData
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitBuy)
	elseif op == msgids.GS_ActRechargeBackInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActRechargeBack)
	elseif op == msgids.GS_ActRechargeBackTake_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData = {DailyRwdCnt = 1, DailyDiamond = 0}
		else
			self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData.DailyRwdCnt = self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData.DailyRwdCnt+1
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActRechargeBack)
	elseif op == msgids.GS_ActRechargeBackNew then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData = {DailyDiamond = data.DailyDiamond, DailyRwdCnt = 0} 
		else
			self.activityCalendars[c.ACTIVITY_NAME.ActRechargeBack].UserData.DailyDiamond = data.DailyDiamond
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActRechargeBack)
	elseif op == msgids.GS_ActTimeTurntableInfo_R then -- 限时宝库信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.ActLimitTreasury] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitTreasury)
    elseif op == msgids.GS_ActTimeTurntableReward_R then -- 限时宝库抽取信息获取
    	local cData = self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury]
		if not cData then
			return
		end
		local uData = cData.UserData
		if uData.TurnCnt == 0 then
			uData.TurnCnt = (data.Type == 1) and 1 or 10
		else
			local num = (data.Type == 1) and 1 or 10
			uData.TurnCnt = uData.TurnCnt + num
		end
		local lucky = cData.Confs.actTimeTurntable[1].Lucky
		if uData.Lucky == 0 then
			uData.Lucky = (data.Type == 1) and lucky or 10 * lucky
		else
			local num = (data.Type == 1) and lucky or 10 * lucky
			uData.Lucky = uData.Lucky + num
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury].UserData.TurnCnt = uData.TurnCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury].UserData.Lucky = uData.Lucky
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitTreasury)
    elseif op == msgids.GS_ActTimeTurntableNew then -- 限时宝库推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury].UserData.FreeCnt = data.FreeCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitTreasury)
	elseif op == msgids.GS_ActTimeTurntableTake_R then -- 限时宝库抽取信息获取
    	local cData = self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury]
		if not cData then
			return
		end
		local uData = cData.UserData
		local hasId = false
		if uData.CntRwd then
			for _, v in ipairs(uData.CntRwd) do
				if  v == data.Cnt then
					hasId = true
					break
				end
			end
			if not hasId then
				table.insert(uData.CntRwd, data.Cnt)
			end
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitTreasury].UserData.CntRwd = uData.CntRwd
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitTreasury)
	elseif op == msgids.GS_ActFundInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFund] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFund] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFund].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFund)
	elseif op == msgids.GS_ActFundNewSucc then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFund] then
			return
		end
		local uData = self.activityCalendars[c.ACTIVITY_NAME.ActFund].UserData
		if not uData.Fund then uData.Fund = {} end
		table.insert(uData.Fund, data.Fund)
		self.activityCalendars[c.ACTIVITY_NAME.ActFund].UserData = uData
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFund)
	elseif op == msgids.GS_ActFundTakeRewards_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFund] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActFund].UserData.TokenIds,data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFund)
	elseif op == msgids.GS_ActFundWelfareInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFundWelfare] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFundWelfare] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFundWelfare].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFundWelfare)
	elseif op == msgids.GS_ActFundWelfareTake_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFundWelfare] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFundWelfare] then
			return
		end
		local uData = self.activityCalendars[c.ACTIVITY_NAME.ActFundWelfare].UserData or {}
		if not uData.TakenIds then uData.TakenIds = {} end 
		table.insert(uData.TakenIds, data.Id)
		self.activityCalendars[c.ACTIVITY_NAME.ActFundWelfare].UserData = uData
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFundWelfare)
	elseif op == msgids.GS_ActConBillInfo_R then -- 天天好礼（连续充值）信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.ActConRecharge] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActConRecharge)
	elseif op == msgids.GS_ActConBillTakeRewards_R then  -- 天天好礼（连续充值）获取奖励
		if not self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData = {DailyCnt=0,ConDay=0,TokenIds={}}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData.TokenIds,data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActConRecharge)
	elseif op == msgids.GS_ActConBillChange then   ---天天好礼（连续充值）消息推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData = {DailyCnt=0,ConDay=0,TokenIds={}}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData.DailyCnt = data.DailyCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData.ConDay = data.ConDay
		self:updateActivityBtn(c.ACTIVITY_NAME.ActConRecharge)
	elseif op == msgids.GS_ActConBillBuy_R then   ---天天好礼（连续充值）购买商品
		local act = self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge]
		if not act then
			return
		end
		if not act.UserData or not act.UserData.BuyCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData = {DailyCnt=0,BuyCnt={},TokenIds={}}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActConRecharge].UserData.BuyCnt,{Id = data.Id,N = 1})
		self:updateActivityBtn(c.ACTIVITY_NAME.ActConRecharge)
	elseif op == msgids.GS_Act3DayTargetInfo_R then -- 3日狂欢信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.Act3DayTarget] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.Act3DayTarget)
    elseif op == msgids.GS_Act3DayTargetSign_R then -- 3日狂欢登陆奖励获取
		local act = self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget]
		if not act then
			return
		end
		if not act.UserData.SignTaken then
			self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.SignTaken = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.SignTaken, act.UserData.CurDay)
		self:updateActivityBtn(c.ACTIVITY_NAME.Act3DayTarget)
    elseif op == msgids.GS_Act3DayTargetBuy_R then -- 3日狂欢登陆兑换
		if not self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget] then
			return
		end
		local buyCnt = self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.BuyCnt or {}
		local hasItem = false
		if buyCnt then
			for _,v in ipairs(buyCnt) do
				if v.Id == data.Id then
					hasItem = true
					break
				end
			end
		end

		if not hasItem then
			table.insert(buyCnt, {Id = data.Id, N = 1})
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.BuyCnt = buyCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.Act3DayTarget)
	elseif op == msgids.GS_Act3DayTargetTask_R then -- 3日狂欢任务奖励获取
		if not self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget] then
			return
		end
		local taskTaken = self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.TaskTaken or {}
		if not table.indexof(taskTaken, tonumber(data.Id)) then
			table.insert(taskTaken, data.Id)
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.TaskTaken = taskTaken
		self:updateActivityBtn(c.ACTIVITY_NAME.Act3DayTarget)
    elseif op == msgids.GS_Act3DayTargetTake_R then -- 3日狂欢目标达成奖励获取
		if not self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget] then
			return
		end
		local rewardTaken = self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.RewardTaken or {}
		if not table.indexof(rewardTaken, tonumber(data.Id)) then
			table.insert(rewardTaken, data.Id)
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.RewardTaken = rewardTaken
		self:updateActivityBtn(c.ACTIVITY_NAME.Act3DayTarget)
	elseif op == msgids.GS_Act3DayTargetCondVal then   ---3日狂欢推送
		if not self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData = {}
		end
		local CondCntData = self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.CondCnt or {}
		local hasId = false
		for k,v in pairs(CondCntData) do
			if v.CondId == data.CondId and v.P1 == data.P1 then
				hasId = true
				v.Val = data.Val
				break
			end
		end
		if not hasId then
			table.insert(CondCntData, data.CondCnt)
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act3DayTarget].UserData.CondCnt = CondCntData

		if not self.refresh3Day then
	        self.refresh3Day = true
	        local scheduler = require "sandglass.core.Scheduler"
	        self.refresh3DayTimer = scheduler.scheduleGlobal(function()
	            self.refresh3Day = false
				self:updateActivityBtn(c.ACTIVITY_NAME.Act3DayTarget)
	            scheduler.unscheduleGlobal(self.refresh3DayTimer)
	            scheduler = nil
	        end, 0.5)
	    end
	elseif op == msgids.GS_ActIntegralShopInfo_R then ---
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPointShop] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActPointShop].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActPointShop)
	-- elseif op == msgids.GS_ActIntegralShopTake_R then
		-- 服务器没有回传消耗兑换CNT,粗暴的重新发送(C_ActIntegralShopInfo,GS_ActIntegralShopInfo_R)
	elseif op == msgids.GS_ActTimeRecruitInfo_R then ---召唤奖励信息回复
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitSummon)
	elseif op == msgids.GS_ActTimeRecruitTake_R then
		-- if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon].UserData then
		-- 	self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon].UserData = {}
		-- end
		-- if not self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon].UserData.Token then
		-- 	self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon].UserData.Token = {}
		-- end
		-- table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActLimitSummon].UserData.Token, data.Cnt)
		-- self:updateActivityBtn(c.ACTIVITY_NAME.ActLimitSummon)
		network.tcpSend(msgids.C_ActTimeRecruitInfo)
		-- 服务器没有回传消耗兑换CNT,粗暴的重新发送(C_ActIntegralShopInfo,GS_ActIntegralShopInfo_R)
	elseif op == msgids.GS_ActIntegralShopNew then ---积分商城推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPointShop] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPointShop].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActPointShop].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActPointShop].UserData.Integral = data.Integral
		self:updateActivityBtn(c.ACTIVITY_NAME.ActPointShop)
	elseif op == msgids.GS_ActBillSumInfo_R then
-- 累计充值	
		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge] then
			return
		end

		self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActAccumulativeRecharge)
	elseif op == msgids.GS_ActBillSumTakeRewards_R then
-- 累计充值	(领取奖励)		
			if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge] then
				return
			end
			table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge].UserData.TokenIds,data.Id)
			self:updateActivityBtn(c.ACTIVITY_NAME.ActAccumulativeRecharge)
--=====================================================================================================================
	elseif op == msgids.GS_ActDailyBillSumInfo_R then
-- 每日累计充值	
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDailyCumulativeRecharge)
	elseif op == msgids.GS_ActDailyBillSumTakeRewards_R then
-- 每日累计充值	(领取奖励)		
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge].UserData.TokenIds,data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDailyCumulativeRecharge)
	elseif op == msgids.GS_ActDailyBillSumNew then	
-- 每日累计充值	(消息推送)
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge].UserData = {SumDiamond=0,TokenIds={}}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDailyCumulativeRecharge].UserData.SumDiamond = data.SumDiamond
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDailyCumulativeRecharge)
--每日首充=====================================================================================================
	elseif op == msgids.GS_ActDailyBillFirstInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDailyRecharge)
	elseif op == msgids.GS_ActDailyBillFirstTakeRewards_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge].UserData.TokenIds,data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDailyRecharge)
	elseif op == msgids.GS_ActDailyBillFirstNew then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge].UserData = {SumDiamond=0,TokenIds={}}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDailyRecharge].UserData.SumDiamond = data.SumDiamond
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDailyRecharge)
--============================================================================================================
--幸运翻牌
	elseif op == msgids.GS_ActCardInfo_R or op == msgids.GS_ActCardPick_R or op == msgids.GS_ActCardGetCounter_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData = {}
		end
		if op == msgids.GS_ActCardInfo_R then
			self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.lastTime =  data.Data.LastCounterTs
			if data.Data.PickCards then
				self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.pickedFlop = #data.Data.PickCards
			else
				self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.pickedFlop = 0
			end
		elseif op == msgids.GS_ActCardGetCounter_R then
			self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.lastTime =  data.LastCounterTs
		else
			self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.pickedFlop = self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.pickedFlop + 1
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.openTime = {}
		local activityConfData = self:getActivityCalendar(c.ACTIVITY_NAME.ActLuckyFlop)
    	local curTime = os.date('*t', Helper.getFixedTime())
    	for k, v in pairs(activityConfData.Confs.globalPublic_CardTimes) do
        	local t = os.time({year = curTime.year, month = curTime.month, day = curTime.day, hour = v.H, min = 0, sec = 0})
        	local value = {time = t, num = v.N, hour = v.H}
        	table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.openTime, value)
    	end
    	table.sort(self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.openTime,function(a, b)
        	return a.time < b.time
		end)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLuckyFlop)
--等级好礼
	elseif op == msgids.GS_ActLevelRewardInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData = {}
		end
		if data.Data.TakenIds then
            self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward = data.Data.TakenIds
            --if #self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward >= 2 then
                --table.sort(self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward, function(a,b)
                    --return a < b
                --end)
            --end
        else
            self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward = {}
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLevelGift)
--=====================================================================================================限购商城
	elseif op == msgids.GS_ActSaleShopGetInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData = {}
			self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.Goods = {}
			self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.BuyCount = {}
		end
		if data.Data and data.Data.Goods then
			self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.Goods = data.Data.Goods
			if data.Data.BuyCount then
				for _,v in pairs(data.Data.BuyCount) do
					self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.BuyCount[v.Id] = v.N
				end
			end
			table.sort(self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.Goods,function(a,b)
				return a.Id < b.Id
			end)
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActRebateShop)
	elseif op == msgids.GS_ActSaleShopBuy_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData then
			return
		end
		local taken = self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.BuyCount[data.Id]
		if taken then
			taken = taken + 1
		else
			taken = 1
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActRebateShop].UserData.BuyCount[data.Id] = taken

--=====================================================================================================
--===============================================节日限购商城======================================================
	elseif op == msgids.GS_ActFesDiShopGetInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData = {}
			self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.Goods = {}
			self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.BuyCount = {}
		end
		if data.Data and data.Data.Goods then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.Goods = data.Data.Goods
			if data.Data.BuyCount then
				for _,v in pairs(data.Data.BuyCount) do
					self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.BuyCount[v.Id] = v.N
				end
			end
			table.sort(self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.Goods,function(a,b)
				return a.Id < b.Id
			end)
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestDiShop)
	elseif op == msgids.GS_ActFesDiShopBuy_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData then
			return
		end
		local taken = self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.BuyCount[data.Id]
		if taken then
			taken = taken + 1
		else
			taken = 1
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestDiShop].UserData.BuyCount[data.Id] = taken

--=====================================================================================================
	elseif op == msgids.GS_ActLevelRewardTake_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward then
			self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward, data.Id)
		--if #self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward >= 2 then
        --    table.sort(self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward, function(a,b)
        --        return a < b
        --    end)
        --end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLevelGift)
	elseif op == msgids.GS_ActBillSumNew then	
-- 累计充值	(消息推送)
		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge].UserData = {SumDiamond=0,TokenIds={}}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeRecharge].UserData.SumDiamond = data.SumDiamond
		self:updateActivityBtn(c.ACTIVITY_NAME.ActAccumulativeRecharge)
	elseif op == msgids.GS_ActSumCostInfo_R or op == msgids.GS_ActSumCostTake_R then--累计消费
		self.sendGetMsgids[c.ACTIVITY_NAME.ActAccumulativeCost] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData = data.Data or {}
		self:updateActivityBtn(c.ACTIVITY_NAME.ActAccumulativeCost)
	elseif op == msgids.GS_ActSumCostValueChanged then--累计消费(改变消费钻石数)
		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost] then
			return
		end

		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData = {}
		end	

		if not self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData.Items then
			local item = {
				Id = data.Id,
				Objs = {
					{
						ObjId = data.ObjId,
						Completed = data.completed,
						Val = data.Val
					},
				},
				Taken = false,
			}
			self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData.Items = {item}
		else
			local has = false
			for k,v in ipairs(self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData.Items or {}) do
				if v.Id == data.Id then
					has = true
					for m,n in ipairs(v.Objs) do
						if n.ObjId == data.ObjId then
							n.Val = data.Val
							n.Completed = data.Completed
							break
						end
					end
					break
				end
			end
			if not has then
				local item = {
					Id = data.Id,
					Objs = {
						{
							ObjId = data.ObjId,
							Completed = data.completed,
							Val = data.Val
						},
					},
					Taken = false,
				}
				table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActAccumulativeCost].UserData.Items, item)
			end
		end
	elseif op == msgids.GS_Act4DayTargetInfo_R then -- 4日狂欢信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.Act4DayTarget] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.Act4DayTarget)
    elseif op == msgids.GS_Act4DayTargetSign_R then -- 4日狂欢登陆奖励获取
    	local act = self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget]
		if not act then
			return
		end
		if not act.UserData.SignTaken then
			self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.SignTaken = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.SignTaken, act.UserData.CurDay)
		self:updateActivityBtn(c.ACTIVITY_NAME.Act4DayTarget)
    elseif op == msgids.GS_Act4DayTargetBuy_R then -- 4日狂欢兑换
		if not self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget] then
			return
		end
		local buyCnt = self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.BuyCnt or {}
		local hasItem = false
		if buyCnt then
			for _,v in ipairs(buyCnt) do
				if v.Id == data.Id then
					hasItem = true
					break
				end
			end
		end

		if not hasItem then
			table.insert(buyCnt, {Id = data.Id, N = 1})
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.BuyCnt = buyCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.Act4DayTarget)
	elseif op == msgids.GS_Act4DayTargetTask_R then -- 4日狂欢任务奖励获取
		if not self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget] then
			return
		end
		local taskTaken = self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.TaskTaken or {}
		if not table.indexof(taskTaken, tonumber(data.Id)) then
			table.insert(taskTaken, data.Id)
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.TaskTaken = taskTaken
		self:updateActivityBtn(c.ACTIVITY_NAME.Act4DayTarget)
    elseif op == msgids.GS_Act4DayTargetTake_R then -- 4日狂欢目标达成奖励获取
		if not self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget] then
			return
		end
		local rewardTaken = self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.RewardTaken or {}
		if not table.indexof(rewardTaken, tonumber(data.Id)) then
			table.insert(rewardTaken, data.Id)
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.RewardTaken = rewardTaken
		self:updateActivityBtn(c.ACTIVITY_NAME.Act4DayTarget)
	elseif op == msgids.GS_Act4DayTargetCondVal then   ---4日狂欢推送
		if not self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData = {}
		end
		local CondCntData = self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.CondCnt or {}
		local hasId = false
		for k,v in pairs(CondCntData) do
			if v.CondId == data.CondId and v.P1 == data.P1 then
				hasId = true
				v.Val = data.Val
				break
			end
		end
		if not hasId then
			table.insert(CondCntData, data.CondCnt)
		end
		self.activityCalendars[c.ACTIVITY_NAME.Act4DayTarget].UserData.CondCnt = CondCntData

		if not self.refresh4Day then
	        self.refresh4Day = true
	        local scheduler = require "sandglass.core.Scheduler"
	        self.refresh4DayTimer = scheduler.scheduleGlobal(function()
	            self.refresh4Day = false
				self:updateActivityBtn(c.ACTIVITY_NAME.Act4DayTarget)
	            scheduler.unscheduleGlobal(self.refresh4DayTimer)
	            scheduler = nil
	        end, 0.5)
	    end
	elseif op == msgids.GS_ActNewSvrRankInfo_R then -- 新服比拼
		self.sendGetMsgids[c.ACTIVITY_NAME.ActNewServerRank] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData = data.Data or {}
		self:updateActivityBtn(c.ACTIVITY_NAME.ActNewServerRank)
    elseif op == msgids.GS_ActNewSvrRankTake_R then -- 新服比拼达成奖励领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData.Taken = true
		self:updateActivityBtn(c.ACTIVITY_NAME.ActNewServerRank)
	elseif op == msgids.GS_ActNewSvrShopBuy_R then -- 新服比拼购买
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData.TakenShop then
			self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData.TakenShop = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData.TakenShop, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActNewServerRank)
    elseif op == msgids.GS_ActNewSvrRankScoreChange then -- 新服比拼推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData = {MyScore = 0}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActNewServerRank].UserData.MyScore = data.MyScore or {}
		self:updateActivityBtn(c.ACTIVITY_NAME.ActNewServerRank)
	elseif op == msgids.GS_ActEggsInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActGashapon] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActGashapon] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActGashapon].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActGashapon)
	elseif op == msgids.GS_ActValueGiftInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActSuperPurchase] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSuperPurchase] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSuperPurchase].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSuperPurchase)
	elseif op == msgids.GS_ActValueGiftSignTake_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSuperPurchase] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSuperPurchase].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSuperPurchase].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSuperPurchase].UserData.Sign = true
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSuperPurchase)
    elseif op == msgids.GS_ActTimeExchangeInfo_R then -- 挂机掉落
		self.sendGetMsgids[c.ACTIVITY_NAME.ActTimeDrop] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop].UserData = data.Data or {}
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTimeDrop)
	elseif op == msgids.GS_ActTimeExchangeItem_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop] then
			return
		end
		local objs = self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop].UserData.Objs
		local hasItem = false
		if objs then
			for _,v in ipairs(objs) do
				if v.Id == data.Id then
					v.N = v.N + 1
					hasItem = true
					break
				end
			end
		else
			objs = {}
		end

		if not hasItem then
			table.insert(objs, {Id = data.Id, N = 1})
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop].UserData.Objs then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop].UserData = {Objs = {}}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActTimeDrop].UserData.Objs = objs
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTimeDrop)
	elseif op == msgids.GS_ActMassiveDiamondInfo_R then -- 十万钻石信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.ActTenDiamond] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTenDiamond] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActTenDiamond].UserData = data.Data
		if data.Data.Token == nil then
			self.activityCalendars[c.ACTIVITY_NAME.ActTenDiamond].UserData.Token = {}
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTenDiamond)
	elseif op == msgids.GS_ActMassiveDiamondTake_R then -- 十万钻石奖励领取信息
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTenDiamond] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActTenDiamond].UserData.Token, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTenDiamond)
	elseif op == msgids.GS_ActTimeChallengeInfo_R then  --- 限时挑战信息获取
		self.sendGetMsgids[c.ACTIVITY_NAME.ActTimeChallenge] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData = data.SelData
		self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SrvData = data.SrvData
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTimeChallenge)
	elseif op == msgids.GS_ActTimeChallengeTakeReward_R then  --- 限时挑战领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.Taken then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.Taken = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.Taken, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTimeChallenge)
	elseif op == msgids.GS_ActTimeChallengeBattle_R then  --- 限时挑战挑战返回
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.ChallengeCount then
			self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.ChallengeCount = 0
		end
		local chaCnt = self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.ChallengeCount
		self.activityCalendars[c.ACTIVITY_NAME.ActTimeChallenge].UserData.SelData.ChallengeCount = chaCnt + 1
		self:updateActivityBtn(c.ACTIVITY_NAME.ActTimeChallenge)
	elseif op == msgids.GS_ActAddGiftInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActAddGift] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActAddGift] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActAddGift].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActAddGift)
	-- elseif op == msgids.GS_ActAddGiftNew then
	-- 	if not self.activityCalendars[c.ACTIVITY_NAME.ActAddGift] then
	-- 		return
	-- 	end
	-- 	table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActAddGift].UserData.Taken, data.Id)
	-- 	self:updateActivityBtn(c.ACTIVITY_NAME.ActAddGift)
	elseif op == msgids.GS_ActSumOnlineInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActSumOnline] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSumOnline] then
			return
		end
		data.Data.curTime = Helper.getFixedTime()
		self.activityCalendars[c.ACTIVITY_NAME.ActSumOnline].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSumOnline)
	elseif op == msgids.GS_ActSumOnlineTakeRewards_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSumOnline] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActSumOnline].UserData.TokenIds,data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSumOnline)
	elseif op == msgids.GS_ActDayGiftInfo_R then --- 每日礼包信息
		self.sendGetMsgids[c.ACTIVITY_NAME.ActDayGift] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDayGift] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDayGift].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDayGift)
	elseif op == msgids.GS_ActWeekGiftInfo_R then --- 每周礼包信息
		self.sendGetMsgids[c.ACTIVITY_NAME.ActWeekGift] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActWeekGift] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActWeekGift].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActWeekGift)
	elseif op == msgids.GS_ActFesGiftInfo_R then --- 节日礼包信息
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestGiftBuy] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestGiftBuy] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestGiftBuy].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestGiftBuy)
	elseif op == msgids.GS_ActDayGiftBuy_R or op == msgids.GS_ActDayGiftNewGift then --- 每日礼包购买
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDayGift] then
			return
		end
		local buyCnt = self.activityCalendars[c.ACTIVITY_NAME.ActDayGift].UserData.DayGift
		if not buyCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActDayGift].UserData.DayGift = {}
		end 
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActDayGift].UserData.DayGift, {Id = data.Id, N = 1})
	elseif op == msgids.GS_ActWeekGiftBuy_R or op == msgids.GS_ActWeekGiftNewGift then --- 每周礼包购买
		if not self.activityCalendars[c.ACTIVITY_NAME.ActWeekGift] then
			return
		end
		local buyCnt = self.activityCalendars[c.ACTIVITY_NAME.ActWeekGift].UserData.WeekGift
		if not buyCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActWeekGift].UserData.WeekGift = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActWeekGift].UserData.WeekGift, {Id = data.Id, N = 1})
	elseif op == msgids.GS_ActFesGiftBuy_R or op == msgids.GS_ActFesGiftNewGift then --- 节日礼包购买或推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestGiftBuy] then
			return
		end
		local buyCnt = self.activityCalendars[c.ACTIVITY_NAME.ActFestGiftBuy].UserData.FesGift
		if not buyCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestGiftBuy].UserData.FesGift = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActFestGiftBuy].UserData.FesGift, {Id = data.Id, N = 1})
	elseif op == msgids.GS_ActRecruitRewardInfo_R then --- 召唤奖励信息
		self.sendGetMsgids[c.ACTIVITY_NAME.ActSummonReward] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSummonReward] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSummonReward].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSummonReward)
	elseif op == msgids.GS_ActRecruitRewardTake_R then -- 召唤奖励领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSummonReward] then
			return
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActSummonReward].UserData.Token, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSummonReward)
	elseif op == msgids.GS_ActTimeUtageInfo_R then -- 餐饮
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData.Token = data.Data.Taken
		self:updateActivityBtn(c.ACTIVITY_NAME.ActPhysicalStrength)
	elseif op == msgids.GS_ActTimeUtageTake_R then -- 餐饮
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData.Token then
			self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData.Token = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActPhysicalStrength].UserData.Token, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActPhysicalStrength)
	elseif op == msgids.GS_ActSuperRouleGetInfo_R then --- 至尊轮盘信息
		self.sendGetMsgids[c.ACTIVITY_NAME.ActSupremeRoulette] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSupremeRoulette)
	elseif op == msgids.GS_ActSuperRouleDrawReward_R then -- 至尊轮盘转动
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.SurplusCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.SurplusCnt = 0
		end
		local drawCnt = self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.DrawCnt
		if not drawCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.DrawCnt = 0
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.DrewList then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.DrewList = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.DrewList, data.Index)
		self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.SurplusCnt = data.SurplusCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.DrawCnt = drawCnt + 1
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSupremeRoulette)
	elseif op == msgids.GS_ActSuperRouleTakeReward_R then -- 至尊轮盘奖励领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.TakenCntList then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.TakenCntList = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.TakenCntList, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSupremeRoulette)
	elseif op == msgids.GS_ActSuperRouleBuyPush then -- 至尊轮盘购买推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.SurplusCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.SurplusCnt = 0
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSupremeRoulette].UserData.SurplusCnt = data.SurplusCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSupremeRoulette)
	elseif op == msgids.GS_ActFesLoginInfo_R then --- 节日登陆
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestLogin] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestLogin] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestLogin].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestLogin)
	elseif op == msgids.GS_ActFesLoginTake_R then --- 节日登陆领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestLogin] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestLogin].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestLogin].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestLogin].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestLogin)
	elseif op == msgids.GS_ActFestBillSumInfo_R then --- 节日累充
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestRecharge] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestRecharge)
	elseif op == msgids.GS_ActFestBillSumTakeRewards_R then --- 节日累充领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData.TokenIds then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData.TokenIds = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData.TokenIds, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestRecharge)
	elseif op == msgids.GS_ActFestBillSumNew then --- 节日累充推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData.SumDiamond then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData.SumDiamond = 0
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestRecharge].UserData.SumDiamond = data.SumDiamond
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestRecharge)
	elseif op == msgids.GS_ActFestPointsInfo_R then --- 圣诞雪人
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestPoint] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestPoint)
	elseif op == msgids.GS_ActFestPointsDonate_R then --- 圣诞雪人捐献
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].Confs then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData = {}
		end
		local Point = self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Point or 0
		local SvrPoint = self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrPoint or 0
		for k,v in ipairs(self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].Confs.actFestPoints) do
			if v.Id == data.Id then
				Point = Point + v.Points
				SvrPoint = SvrPoint + v.Points
				break
			end
		end
		local donate = self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Donate or {}
		local hasId = false
		for k,v in ipairs(donate) do
			if v.Id == data.Id then
				hasId = true
				v.N = v.N + 1
				break
			end
		end
		if not hasId then
			table.insert(donate, {Id = data.Id, N = 1})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Donate = donate
		self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Point = Point
		self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrPoint = SvrPoint
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestPoint)
	elseif op == msgids.GS_ActFestPointsTake_R or op == msgids.GS_ActFestPointsTakeSvr_R then --- 积分达成领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Taken then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Taken = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrTaken then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrTaken = {}
		end
		if op == msgids.GS_ActFestPointsTake_R then
			table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Taken, data.Id)
		elseif op == msgids.GS_ActFestPointsTakeSvr_R then
			table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrTaken, data.Id)
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestPoint)
	elseif op == msgids.GS_ActFestPointsPlr or op == msgids.GS_ActFestPointsSvr then --- 积分推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Point then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Point = 0
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrPoint then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrPoint = 0
		end
		if op == msgids.GS_ActFestPointsPlr then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.Point = data.Point
		elseif op == msgids.GS_ActFestPointsSvr then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestPoint].UserData.SvrPoint = data.Point
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestPoint)
	elseif op == msgids.GS_ActFestBlessInfo_R then --- 元旦祈福
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestBless] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestBless] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestBless].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestBless)
	elseif op == msgids.GS_ActFestBlessDraw_R then --- 元旦祈福
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestBless] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestBless].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestBless].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestBless].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestBless)
	elseif op == msgids.GS_ActFesQuestInfo_R then --- 新年任务
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestMission] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestMission)
	elseif op == msgids.GS_ActFesQuestGetReward_R then --- 新年任务
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Taken then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Taken = false
		end 
		self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Taken = true
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestMission)
	elseif op == msgids.GS_ActFesQuestGetQueseReward_R then --- 新年任务
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData = {}
		end
		local quests = self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Quests or {}
		local hasId = false
		for k,v in ipairs(quests) do
			if v.Id == data.Id then
				v.Taken = true
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(quests, {Id = data.Id,Fin = true,Taken = true})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Quests = quests
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestMission)
	elseif op == msgids.GS_ActFesQuestComplete then --- 新年任务
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData = {}
		end
		local quests = self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Quests or {}
		local hasId = false
		for k,v in ipairs(quests) do
			if v.Id == data.Id then
				v.Fin = true
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(quests, {Id = data.Id,Fin = true})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestMission].UserData.Quests = quests
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestMission)
	elseif op == msgids.GS_ActHappyRotInfo_R then
		self.sendGetMsgids[c.ACTIVITY_NAME.ActHappySlots] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActHappySlots)
	elseif op == msgids.GS_ActHappyRotRoll_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActHappySlots)
	elseif op == msgids.GS_ActHappyRotTake_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActHappySlots].UserData.Taken = {data.Id}
		self:updateActivityBtn(c.ACTIVITY_NAME.ActHappySlots)
	elseif op == msgids.GS_ActFesRichManInfo_R then --- 大富翁
		self.sendGetMsgids[c.ACTIVITY_NAME.ActCNYMonopoly] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYMonopoly)
	elseif op == msgids.GS_ActFesRichManDice_R then --- 大富翁
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData = {}
		end
		local surpirseCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.SurpirseCnt or 0
		local cycleCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CycleCnt or 0
		local allSurpirseCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.AllSurpirseCnt or 0
		local canDiceCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CanDiceCnt or 0
		canDiceCnt = (canDiceCnt == 0) and 0 or (((canDiceCnt - data.DiceCnt) <= 0) and 0 or (canDiceCnt - data.DiceCnt))
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.SurpirseCnt = data.SurpriseCnt or surpirseCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CycleCnt = data.CycleCnt or cycleCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.AllSurpirseCnt = data.AllSurpirseCnt or allSurpirseCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CanDiceCnt = canDiceCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYMonopoly)
	elseif op == msgids.GS_ActFesRichManGetSurprise_R or op == msgids.GS_ActFesRichManCycle_R then --- 大富翁
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData = {}
		end
		local surpirseCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.SurpirseCnt or 0
		local cycleCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CycleCnt or 0
		if op == msgids.GS_ActFesRichManCycle_R then
			cycleCnt = (cycleCnt == 0) and 0 or (((cycleCnt - data.GetCnt) <= 0) and 0 or (cycleCnt - data.GetCnt))
		elseif op == msgids.GS_ActFesRichManGetSurprise_R then
			surpirseCnt = (surpirseCnt == 0) and 0 or (((surpirseCnt - data.GetCnt) <= 0) and 0 or (surpirseCnt - data.GetCnt))
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.SurpirseCnt = surpirseCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CycleCnt = cycleCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYMonopoly)
	elseif op == msgids.GS_ActFesRichManDiceCntR then --- 大富翁可掷骰子次数推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CanDiceCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CanDiceCnt = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYMonopoly].UserData.CanDiceCnt = data.CanDiceCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYMonopoly)
	elseif op == msgids.GS_ActFesMonsterInfo_R then --- 打年兽
		self.sendGetMsgids[c.ACTIVITY_NAME.ActCNYYearBeast] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYYearBeast)
	elseif op == msgids.GS_ActFesMonsterAtk_R then --- 打年兽
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData = {}
		end
		local plrDmg = self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.PlrDmg or 0
		local monsterLife = self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.MonsterLife or 0
		local actConfsData = self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].Confs.actfestivalmonster[1]
		local hurtVal = 0
		for k,v in ipairs(actConfsData.ItemHp) do
			if v.Id == data.Type then
				hurtVal = v.Dmg * data.Num
				break
			end
		end
		-- print("11111111111",plrDmg)
		plrDmg = (((plrDmg + hurtVal) >= actConfsData.Life) and actConfsData.Life or (plrDmg + hurtVal))
		monsterLife = (monsterLife >= actConfsData.Life) and actConfsData.Life or (((monsterLife + hurtVal) >= actConfsData.Life) and actConfsData.Life or (monsterLife + hurtVal))
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.PlrDmg = plrDmg
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.MonsterLife = monsterLife
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYYearBeast)
	elseif op == msgids.GS_ActFesMonsterPlrRwd_R or op == msgids.GS_ActFesMonsterSvrLife_R then --- 打年兽全服领取，个人领取
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.PlrTaken then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.PlrTaken = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.SvrTaken then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.SvrTaken = {}
		end
		if data.Dmg then
			table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.PlrTaken, data.Dmg)
		elseif data.Life then
			table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.SvrTaken, data.Life)
		end
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYYearBeast)
	elseif op == msgids.GS_ActFesMonsterLogR then --- 打年兽日志推送
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.SvrLogL then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.SvrLogL = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActCNYYearBeast].UserData.SvrLogL, data.SvrLog)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYYearBeast)
	elseif op == msgids.GS_ActFesRedGiftGetInfo_R then --- 红包雨
		self.sendGetMsgids[c.ACTIVITY_NAME.ActCNYRedPack] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData = {}
		end
		-- dump(data, "GS_ActFesRedGiftGetInfo_R", 10)
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData.CanGetCnt = data.Data.CanGetCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYRedPack)
	elseif op == msgids.GS_ActFesRedGiftTake_R then --- 红包雨
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData = {}
		end
		local canGetCnt = self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData.CanGetCnt or {}
		for k,v in ipairs(canGetCnt) do
			if v.Id == data.Id then
				v.N = (v.N == 0) and 0 or (v.N - 1)
				break
			end
		end
		-- 如果hasId为false要不就是领完了或者未达到领取条件
		self.activityCalendars[c.ACTIVITY_NAME.ActCNYRedPack].UserData.CanGetCnt = canGetCnt
		--暂时先不刷新按钮，等蒙版关闭再刷新
		self.delayRefresh = true
		-- self:updateActivityBtn(c.ACTIVITY_NAME.ActCNYRedPack)
	elseif op == msgids.GS_ActFesAddResetGetInfo_R then --- 首充重置
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestAddReset] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestAddReset] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestAddReset].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestAddReset)
	elseif op == msgids.GS_ActFestExcGetInfo_R then --- 节日兑换
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestExchange] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestExchange)
	elseif op == msgids.GS_ActFestExcItem_R then --- 节日兑换
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange].UserData = {}
		end
		local excCount = self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange].UserData.ExcCount or {}
		local hasId = false
		for k,v in ipairs(excCount) do
			if v.Id == data.Id then
				hasId = true
				v.N = v.N + 1
				break
			end
		end
		if not hasId then
			table.insert(excCount, {Id = data.Id, N = 1})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestExchange].UserData.ExcCount = excCount
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestExchange)
	elseif op == msgids.GS_ActFestLotteryGetInfo_R then --- 刮刮卡
		self.sendGetMsgids[c.ACTIVITY_NAME.ActFestCard] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestCard] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestCard)
	elseif op == msgids.GS_ActFestLotteryDraw_R then --- 刮刮卡
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestCard] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData = {}
		end
		local integral = self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.Integral or 0
		local surplusInte = self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.SurplusInte or 0
		
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.LastDraw = data.DrawNum
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.LastLucky = data.LuckyNum
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.LastIntegral = data.Integral
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.Integral = integral + data.Integral
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.SurplusInte = surplusInte + data.Integral
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestCard)
	elseif op == msgids.GS_ActFestLotteryItem_R then --- 刮刮卡
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestCard] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData = {}
		end
		local surplusInte = self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.SurplusInte or 0
		local getItemCnt = self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.GetItemCnt or {}
		local actConfsData = self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].Confs.actFestCardShop or {}
		local price = 0
		for k,v in ipairs(actConfsData) do
			if v.Id == data.Id then
				price = v.Integral
				break
			end
		end
		local hasId = false
		for k,v in ipairs(getItemCnt) do
			if data.Id == v.Id then
				hasId = true
				v.N = v.N + data.Cnt
			end
		end
		if not hasId then
			table.insert(getItemCnt, {Id = data.Id, N = data.Cnt})
		end
		surplusInte = ((surplusInte - (price * data.Cnt)) > 0)  and (surplusInte - (price * data.Cnt)) or 0
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.SurplusInte = surplusInte
		self.activityCalendars[c.ACTIVITY_NAME.ActFestCard].UserData.GetItemCnt = getItemCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActFestCard)
	elseif op == msgids.GS_ActSignWelfareGetInfo_R then --- 签到福利
		self.sendGetMsgids[c.ACTIVITY_NAME.ActSignInReward] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSignInReward)
	elseif op == msgids.GS_ActSignWelfareSign_R then --- 签到福利
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData.GetSignRewards = data.GetSignRewards
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData.SignCnt = data.SignCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData.TodaySign = true
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSignInReward)
	elseif op == msgids.GS_SignWelfareGetRewards_R then --- 签到福利
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData = {}
		end
		local getTotalRewards = self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData.GetTotalRewards or {}
		local hasCnt = false
		for k,v in ipairs(getTotalRewards) do
			if v == data.Cnt then
				hasCnt = true
			end
		end
		if not hasCnt then
			table.insert(getTotalRewards, data.Cnt)
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInReward].UserData.GetTotalRewards = getTotalRewards
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSignInReward)
	elseif op == msgids.GS_ActDispatchWelfareGetInfo_R then --- 派遣福利
		self.sendGetMsgids[c.ACTIVITY_NAME.ActDispatchReward] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDispatchReward)
	elseif op == msgids.GS_ActDispatchWelfareTakeWel_R then --- 派遣福利
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData = {}
		end
		local disWelS = self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.DisWelS or {}
		local hasId = false
		for k,v in ipairs(disWelS) do
			if v.Id == data.Id then
				v.Taken = true
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(disWelS, {Id = data.Id,Fin = true,Taken = true})
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.DisWelS = disWelS
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDispatchReward)
	elseif op == msgids.GS_ActDispatchWelfareTakeTotalWel_R then --- 派遣福利
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData = {}
		end
		local takenCompDisWel = self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.TakenCompDisWel or {}
		local hasCnt = false
		for k,v in ipairs(takenCompDisWel) do
			if v == data.Cnt then
				hasCnt = true
			end
		end
		if not hasCnt then
			table.insert(takenCompDisWel, data.Cnt)
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.TakenCompDisWel = takenCompDisWel
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDispatchReward)
	elseif op == msgids.GS_ActDispatchWelfareComplete then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData = {}
		end
		local disWelS = self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.DisWelS or {}
		local compDisWelCnt = self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.CompDisWelCnt or 0
		local hasId = false
		for k,v in ipairs(disWelS) do
			if v.Id == data.Id then
				v.Fin = true
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(disWelS, {Id = data.Id,Fin = true})
		end

		self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.DisWelS = disWelS
		self.activityCalendars[c.ACTIVITY_NAME.ActDispatchReward].UserData.CompDisWelCnt = compDisWelCnt + 1
		self:updateActivityBtn(c.ACTIVITY_NAME.ActDispatchReward)
	elseif op == msgids.GS_ActSignRouletteGetInfo_R then --- 签到轮盘
		self.sendGetMsgids[c.ACTIVITY_NAME.ActSignInRoulette] = nil
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSignInRoulette)
	elseif op == msgids.GS_ActSignRouletteDrawReward_R then --- 签到轮盘
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData = {}
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.SurplusCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.SurplusCnt = 0
		end
		local drawCnt = self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.DrawCnt
		if not drawCnt then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.DrawCnt = 0
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.DrewList then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.DrewList = {}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.DrewList, data.Index)
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.SurplusCnt = data.SurplusCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.DrawCnt = drawCnt + 1
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSignInRoulette)
	elseif op == msgids.GS_ActSignRouletteTakeReward_R then --- 签到轮盘
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData = {}
		end
		local takenCntList = self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.TakenCntList or {}
		local hasId = false
		for k,v in ipairs(takenCntList) do
			if v == data.Cnt then
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(takenCntList, data.Cnt)
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSignInRoulette].UserData.TakenCntList = takenCntList
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSignInRoulette)
	elseif op == msgids.GS_ActWeekCardInfo_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActMysteryStore)
	elseif op == msgids.GS_ActWeekCardTake_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData = {Taken = {}}
		end
		table.insert(self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData.Taken, data.Id)
		self:updateActivityBtn(c.ACTIVITY_NAME.ActMysteryStore)
	elseif op == msgids.GS_ActWeekCardClick_R then
		if not self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData.Click = data.Click or 0
		self.activityCalendars[c.ACTIVITY_NAME.ActMysteryStore].UserData.Super = data.Super or false
	elseif op == msgids.GS_ActSmashEggsGetInfo_R then --砸蛋
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSmashEggs)
	elseif op == msgids.GS_ActSmashEggsBreak_R then --砸蛋
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData = {}
		end
		local getRewards = self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.GetRewards or {}
		local rewards = self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.Rewards or {}
		local hasId = false
		for k,v in ipairs(getRewards) do
			if v == data.BreakId then
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(getRewards, data.BreakId)
		end
		if table.indexof(rewards, data.BreakId) then
			table.remove(rewards,table.indexof(rewards, data.BreakId))
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.CanBreakCnt = data.CanBreakCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.GetRewards = getRewards
		self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.Rewards = rewards
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSmashEggs)
	-- elseif op == msgids.GS_ActSmashEggsUpdate_R then --砸蛋
	-- 	if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs] then
	-- 		return
	-- 	end
	-- 	if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData then
	-- 		self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData = {}
	-- 	end
	-- 	dump(data.Cost, "xxxCostxx", 10)
	-- 	self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.FreshCnt = data.FreshCnt
	-- 	self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.Rewards = data.Cost
	-- 	self:updateActivityBtn(c.ACTIVITY_NAME.ActSmashEggs)
	elseif op == msgids.GS_ActSmashEggsAdd then --砸蛋
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSmashEggs].UserData.CanBreakCnt = data.CanBreakCnt
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSmashEggs)
	elseif op == msgids.GS_ActFestSelectGiftInfo_R then --自选
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSelectGift)
	elseif op == msgids.GS_ActFestSelectGiftBuy then --自选
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData.BuyCnt = data.BuyCnt
		self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData.SelectGift = {}
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSelectGift)
	elseif op == msgids.GS_ActFestSelectGiftChoose_R then --自选
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData = {}
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActSelectGift].UserData.SelectGift = data.SelectGift
		self:updateActivityBtn(c.ACTIVITY_NAME.ActSelectGift)
	elseif op == msgids.GS_ActFestExpShopInfo_R then -- 飞升
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift] then
			return
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift].UserData = data.Data
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLevelUpGift)
	elseif op == msgids.GS_ActFestExpShopBuy then --飞升
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift] then
			return
		end
		if not self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift].UserData then
			self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift].UserData = {}
		end
		local buyGifts = self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift].UserData.BuyGifts or {}
		local hasId = false
		for k,v in ipairs(buyGifts) do
			if v == data.BuyGift then
				hasId = true
				break
			end
		end
		if not hasId then
			table.insert(buyGifts, data.BuyGift)
		end
		self.activityCalendars[c.ACTIVITY_NAME.ActLevelUpGift].UserData.BuyGifts = buyGifts
		self:updateActivityBtn(c.ACTIVITY_NAME.ActLevelUpGift)
	end
end

function ActivityModel:updateActivityCalendars(acts)
	for k,v in ipairs(acts or {}) do
		self.activityCalendars[v.Id] = v
	end
	local SDKController = require("app.sdk.SDKController")
	local serverInfo = SDKController.getServerInfo()
	--if SDK_PARAMS.DELETE_TEST ==  1 or (SDK_PARAMS.DELETE_TEST == 2 and serverInfo.id == 1) then
	if SDK_PARAMS.DELETE_TEST ==  1 then
		self.activityCalendars[100] = {Id = 100, Sort = 100, Name = WordDictionary[71040], Desc = WordDictionary[71040], Open = 0, Start = 0, End = 0, Close = 0, Stage = 2}
	end
	-- self.activityCalendars[c.ACTIVITY_NAME.ActLifeCard] = {Id = c.ACTIVITY_NAME.ActLifeCard, Sort = 104, Name = WordDictionary[25265], Desc = WordDictionary[25265], Open = 0, Start = 0, End = 0, Close = 0, Stage = 2}
end

function ActivityModel:getActivityCalendar(id)
	return self.activityCalendars[id]
end

function ActivityModel:checkGoodsDoubleGains(sourceId, itemId)
	local actData = self:getActivityCalendar(c.ACTIVITY_NAME.ActDoubleGains) or {}
	if not actData.Confs then
		return false
	end
	local confData = actData.Confs.actProfitDouble or {}

	table.sort(confData, function (a,b)
		return a.Id < b.Id
	end)

	local timeData = {}
	for _,v in pairs(confData) do
		table.insert(timeData,v.LastTime)
	end

    local deadline = actData.Start
    local ret = false
	for index,v in pairs(confData) do
		local function Check()
	    	for i=1,index do
	    		deadline = deadline + timeData[i]
	    	end
	    	local startTime = deadline - timeData[index]

	    	local curTime = Helper.getFixedTime()

	    	if curTime < startTime then
	    		return false
	    	elseif startTime <= curTime and curTime < deadline then
	    		return true
	    	else
	    		return false
	    	end
		end

		if sourceId then
			if sourceId == v.SourceId then
				ret = Check()
				if ret and itemId then
					local isExist = false
					for _,v2 in pairs(v.Times) do
						if v2.Id == itemId then
							isExist = true
						end
					end
					ret = isExist
				end
				if ret then
					break
				end
			end
		else
			ret = Check()
			if ret and itemId then
				for _,v2 in pairs(v.Times) do
					if v2.Id == itemId then
						ret = true
					end
				end
			end
			if ret then
				break
			end
		end
	end

	return ret
end

--根据活动id发送请求数据协议
function ActivityModel:sendGetActivityData(id)
	if self.sendGetMsgids[id] then
		return
	end
	self.sendGetMsgids[id] = true
	if id == c.ACTIVITY_NAME.ActFirstRecharge then
		network.tcpSend(msgids.C_ActBillFirstInfo)
	elseif id == c.ACTIVITY_NAME.ActLevelShop then
		network.tcpSend(msgids.C_ActLevelShopInfo)
	elseif id == c.ACTIVITY_NAME.Act7DayLogin then
		network.tcpSend(msgids.C_Act7DayLoginInfo)
	elseif id == c.ACTIVITY_NAME.ActCostRebate then
		network.tcpSend(msgids.C_ActCostReturnInfo)
	elseif id == c.ACTIVITY_NAME.ActLimitBuy then
		network.tcpSend(msgids.C_ActLimitGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActRoulette then
		network.tcpSend(msgids.C_ActOccultRouletteInfo)
	elseif id == c.ACTIVITY_NAME.ActLimitTreasury then
		network.tcpSend(msgids.C_ActTimeTurntableInfo)
	elseif id == c.ACTIVITY_NAME.ActFund then
		network.tcpSend(msgids.C_ActFundInfo)
	elseif id == c.ACTIVITY_NAME.ActFundWelfare then
		network.tcpSend(msgids.C_ActFundWelfareInfo)
	elseif id == c.ACTIVITY_NAME.ActConRecharge then
		network.tcpSend(msgids.C_ActConBillInfo)
	elseif id == c.ACTIVITY_NAME.Act3DayTarget then
		network.tcpSend(msgids.C_Act3DayTargetInfo)
	elseif id == c.ACTIVITY_NAME.Act4DayTarget then
		network.tcpSend(msgids.C_Act4DayTargetInfo)
	elseif id == c.ACTIVITY_NAME.ActAccumulativeRecharge then
		network.tcpSend(msgids.C_ActBillSumInfo)
	elseif id == c.ACTIVITY_NAME.ActWish then
		network.tcpSend(msgids.C_ActWishInfo)
	elseif id == c.ACTIVITY_NAME.ActAccumulativeCost then
		network.tcpSend(msgids.C_ActSumCostInfo)
	elseif id == c.ACTIVITY_NAME.ActNewServerRank then
		network.tcpSend(msgids.C_ActNewSvrRankInfo,{Func = 0})
	elseif id == c.ACTIVITY_NAME.ActLimitSummon then
		network.tcpSend(msgids.C_ActTimeRecruitInfo)
	elseif id == c.ACTIVITY_NAME.ActLuckyFlop then
		network.tcpSend(msgids.C_ActCardInfo)
	elseif id == c.ACTIVITY_NAME.ActTimeDrop then
		network.tcpSend(msgids.C_ActTimeExchangeInfo)
	elseif id == c.ACTIVITY_NAME.ActGashapon then
		network.tcpSend(msgids.C_ActEggsInfo)
	elseif id == c.ACTIVITY_NAME.ActTenDiamond then
		network.tcpSend(msgids.C_ActMassiveDiamondInfo)
	elseif id == c.ACTIVITY_NAME.ActSuperPurchase then--幸运翻牌
		network.tcpSend(msgids.C_ActValueGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActLevelGift then--等级好礼
		network.tcpSend(msgids.C_ActLevelRewardInfo)
	elseif id == c.ACTIVITY_NAME.ActRechargeBack then
		network.tcpSend(msgids.C_ActRechargeBackInfo)
	elseif id == c.ACTIVITY_NAME.ActPointShop then
		network.tcpSend(msgids.C_ActIntegralShopInfo)
	elseif id == c.ACTIVITY_NAME.ActTimeChallenge then
		network.tcpSend(msgids.C_ActTimeChallengeInfo)
	elseif id == c.ACTIVITY_NAME.ActAddGift then
		network.tcpSend(msgids.C_ActAddGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActSumOnline then
		network.tcpSend(msgids.C_ActSumOnlineInfo)
	elseif id == c.ACTIVITY_NAME.ActDailyCumulativeRecharge then --每日累计充值
		network.tcpSend(msgids.C_ActDailyBillSumInfo)
	elseif id == c.ACTIVITY_NAME.ActDailyRecharge then --每日首充
		network.tcpSend(msgids.C_ActDailyBillFirstInfo)
	elseif id == c.ACTIVITY_NAME.ActDayGift then --每日礼包
		network.tcpSend(msgids.C_ActDayGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActWeekGift then --每周礼包
		network.tcpSend(msgids.C_ActWeekGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActFestGiftBuy then --每周礼包
		network.tcpSend(msgids.C_ActFesGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActSummonReward then -- 召唤奖励
		network.tcpSend(msgids.C_ActRecruitRewardInfo)
	elseif id == c.ACTIVITY_NAME.ActPhysicalStrength then -- 餐饮
		network.tcpSend(msgids.C_ActTimeUtageInfo)
	elseif id == c.ACTIVITY_NAME.ActRebateShop then
		network.tcpSend(msgids.C_ActSaleShopGetInfo)
	elseif id == c.ACTIVITY_NAME.ActSupremeRoulette then
		network.tcpSend(msgids.C_ActSuperRouleGetInfo)
	elseif id == c.ACTIVITY_NAME.ActFestLogin then -- 节日登陆
		network.tcpSend(msgids.C_ActFesLoginInfo)
	elseif id == c.ACTIVITY_NAME.ActFestRecharge then -- 节日累充
		network.tcpSend(msgids.C_ActFestBillSumInfo)
	elseif id == c.ACTIVITY_NAME.ActFestPoint then -- 圣诞雪人
		network.tcpSend(msgids.C_ActFestPointsInfo)
	elseif id == c.ACTIVITY_NAME.ActFestBless then -- 元旦祈福
		network.tcpSend(msgids.C_ActFestBlessInfo)
	elseif id == c.ACTIVITY_NAME.ActFestMission then -- 新年任务
		network.tcpSend(msgids.C_ActFesQuestInfo)
	elseif id == c.ACTIVITY_NAME.ActHappySlots then --欢乐掷点
		network.tcpSend(msgids.C_ActHappyRotInfo)
	elseif id == c.ACTIVITY_NAME.ActCNYMonopoly then -- 新年大富翁
		network.tcpSend(msgids.C_ActFesRichManInfo)
	elseif id == c.ACTIVITY_NAME.ActCNYYearBeast then -- 新年打年兽
		network.tcpSend(msgids.C_ActFesMonsterInfo)
	elseif id == c.ACTIVITY_NAME.ActFestDiShop then --节日限购商城
		network.tcpSend(msgids.C_ActFesDiShopGetInfo)
	elseif id == c.ACTIVITY_NAME.ActFestAddReset then -- 首充重置
		network.tcpSend(msgids.C_ActFesAddResetGetInfo)
	elseif id == c.ACTIVITY_NAME.ActFestExchange then -- 节日兑换
		network.tcpSend(msgids.C_ActFestExcGetInfo)
	elseif id == c.ACTIVITY_NAME.ActFestCard then -- 刮刮卡
		network.tcpSend(msgids.C_ActFestLotteryGetInfo)
	elseif id == c.ACTIVITY_NAME.ActSignInReward then -- 签到福利
		network.tcpSend(msgids.C_ActSignWelfareGetInfo)
	elseif id == c.ACTIVITY_NAME.ActDispatchReward then -- 派遣福利
		network.tcpSend(msgids.C_ActDispatchWelfareGetInfo)
	elseif id == c.ACTIVITY_NAME.ActSignInRoulette then -- 签到轮盘
		network.tcpSend(msgids.C_ActSignRouletteGetInfo)
	elseif id == c.ACTIVITY_NAME.ActMysteryStore then
		network.tcpSend(msgids.C_ActWeekCardInfo)
	elseif id == c.ACTIVITY_NAME.ActSmashEggs then
		network.tcpSend(msgids.C_ActSmashEggsGetInfo)
	elseif id == c.ACTIVITY_NAME.ActSelectGift then
		network.tcpSend(msgids.C_ActFestSelectGiftInfo)
	elseif id == c.ACTIVITY_NAME.ActLevelUpGift then
		network.tcpSend(msgids.C_ActFestExpShopInfo)
	end
end

function ActivityModel:isFirstRecharge()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFirstRecharge)
	if act and act.UserData and act.UserData.FirstTs > 0 then
		return true
	end
	return false
end

function ActivityModel:getActivityState(id)
	local act = self:getActivityCalendar(id)
	local filter = false
	if act and act.BanServer then
		local SDKController = require "app.sdk.SDKController"
		local serverInfo = SDKController.getServerInfo()
		for _, serverId in pairs(act.BanServer) do
			if serverInfo.id == serverId then
				filter = true
				break
			end
		end
	end
	if act and act.Stage ~= c.ACTIVITY_STAGE.CLOSE and not filter then
		if id == c.ACTIVITY_NAME.ActFirstRecharge then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	if not (act.UserData.Days and #act.UserData.Days >= #act.Confs.actFirstrechargeDaily 
            		and act.UserData.Taken and #act.UserData.Taken >= (#act.Confs.actFirstrecharge-1)) then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.ActLevelShop then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
			else
				if act.UserData.Goods and #act.UserData.Goods < 1 then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.Act7DayLogin then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
			else
				--根据领取天数已经登陆天数判断 
				local data = act.UserData
				local canTake = false
				if data.SumLoginCnt >= #data.TokenIds and #data.TokenIds < 7 then
					canTake = true
				end
				return canTake
			end
		elseif id == c.ACTIVITY_NAME.ActCostRebate then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
			else
				-- 判断活动结束条件 
				if not act.UserData.Objs or #act.UserData.Objs < 1 then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.ActFund then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	if table.nums(act.UserData.TokenIds or {}) < table.nums(act.Confs.actFund or {}) then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.Act3DayTarget then
			if not act.UserData or (not act.UserData.CurDay) then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.Act4DayTarget then
			if not act.UserData or (not act.UserData.CurDay) then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActNewServerRank then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	return true
			end
		elseif id == c.ACTIVITY_NAME.ActWish then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	-- if act.UserData.ConfId ~= 0 then
					return true
				-- end
			end
		elseif id == c.ACTIVITY_NAME.ActGashapon then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	if act.UserData.ConfId ~= 0 then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.ActSuperPurchase then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	if act.UserData.ConfId ~= 0 then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.ActTimeDrop then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	if not act.UserData.Objs or #act.UserData.Objs < 1 then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.ActConRecharge then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	if act.ConTp and (not act.TokenIds or (#act.ConTp > #act.TokenIds)) then
					return true
				end
			end
		elseif id == c.ACTIVITY_NAME.ActAddGift then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	local taken = act.UserData.Taken or {}
            	local addGift = act.Confs.actAddGift or {}
				local isContinueShow = table.nums(taken) < table.nums(addGift)
				if isContinueShow and self:isFirstRecharge() then
					return true
				end
            end
        elseif id == c.ACTIVITY_NAME.ActSumOnline then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	local tableLen = 0
            	for k,v in pairs(act.Confs.actSumOnline or {}) do
            		tableLen = tableLen + 1
            	end
            	if #act.UserData.TokenIds<tableLen then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActSummonReward then
			if not act.UserData then
				self:sendGetActivityData(id)
			end
			if not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
			end
            if act.UserData and act.Confs then
            	local tableLen = 0
            	for k,v in pairs(act.Confs.actRecruitReward or {}) do
            		tableLen = tableLen + 1
            	end
            	if #act.UserData.Token < tableLen then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActDayGift then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	-- local tableLen = 0
            	-- for k,v in pairs(act.Confs.actSumOnline) do
            	-- 	tableLen = tableLen + 1
            	-- end
            	-- if #act.UserData.TokenIds<tableLen then
            		return true
            	-- end
			end
		elseif id == c.ACTIVITY_NAME.ActWeekGift then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	-- local tableLen = 0
            	-- for k,v in pairs(act.Confs.actSumOnline) do
            	-- 	tableLen = tableLen + 1
            	-- end
            	-- if #act.UserData.TokenIds<tableLen then
            		return true
            	-- end
			end
		elseif id == c.ACTIVITY_NAME.ActFestGiftBuy then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	-- local tableLen = 0
            	-- for k,v in pairs(act.Confs.actSumOnline) do
            	-- 	tableLen = tableLen + 1
            	-- end
            	-- if #act.UserData.TokenIds<tableLen then
            		return true
            	-- end
			end
		elseif id == c.ACTIVITY_NAME.ActTimeChallenge then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActCNYMonopoly then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActCNYYearBeast then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActCNYRebate then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActFestExchange then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActFestCard then
			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	if act.End - Helper.getFixedTime() > 0 then
            		return true
            	end
			end
		elseif id == c.ACTIVITY_NAME.ActRewardRecall then
   			local init = require "app.models.init"
			local RewardRecallModel = init.RewardRecallModel
        	--TODO 判断活动状态条件
        	if RewardRecallModel:getRecStatus() then
				return true
			end
		elseif id == c.ACTIVITY_NAME.ActLevelUpGift then
   			if not act.UserData then
				self:sendGetActivityData(id)
			elseif not act.Confs then
				network.tcpSend(msgids.C_ActConfGet, {Id = id})
            else
            	--TODO 判断活动结束条件
            	local tableLen = 0
            	for k,v in pairs(act.Confs.actFestExpShop or {}) do
            		tableLen = tableLen + 1
            	end
            	if act.UserData.BuyGifts and #act.UserData.BuyGifts < tableLen then
            		return true
            	end
			end
		else
			return true
		end
	end
	return false
end

--根据活动id检查是否有红点
function ActivityModel:checkRedTips(id)
	if id == c.ACTIVITY_NAME.ActFirstRecharge then
		return self:checkFirstRechargeRedTips()
	elseif id == c.ACTIVITY_NAME.ActLevelShop then
		return self:checkActLevelShopRedTips()
	elseif id == c.ACTIVITY_NAME.Act7DayLogin then
		return self:checkActSevenDayLoginRedTips()
	elseif id == c.ACTIVITY_NAME.ActCostRebate then
		return self:checkActCostRebateRedTips()
	elseif id == c.ACTIVITY_NAME.ActLimitBuy then
		return self:checkActLimitBuyRedTips()
	elseif id == c.ACTIVITY_NAME.ActRoulette then
		return self:checkActRouletteRedTips()
	elseif id == c.ACTIVITY_NAME.ActLimitTreasury then
		return self:checkActLimitTreasuryRedTips()
	elseif id == c.ACTIVITY_NAME.ActAccumulativeRecharge then
		return self:checkActAccumulativeRechargeRedTips()
	elseif id == c.ACTIVITY_NAME.Act3DayTarget then
		return self:checkActAct3DayTargetRedTips()
	elseif id == c.ACTIVITY_NAME.ActAccumulativeCost then
		return self:checkActAccumulativeCostRedTips()
	elseif id == c.ACTIVITY_NAME.Act4DayTarget then
		return self:checkActAct4DayTargetRedTips()
	elseif id == c.ACTIVITY_NAME.ActNewServerRank then
		return self:checkActNewServerRankRedTips()
	elseif id == c.ACTIVITY_NAME.ActLuckyFlop then
		return self:checkActLuckyFlopRedTips() --幸运翻牌小红点
	elseif id == c.ACTIVITY_NAME.ActTimeDrop then
		return self:checkActTimeRedTips()
	elseif id == c.ACTIVITY_NAME.ActSummonReward then
		return self:checkActActSummonRewardRedTips()
	elseif id == c.ACTIVITY_NAME.ActLimitSummon then
		return self:checkActLimitSummonRedTips()()
	elseif id == c.ACTIVITY_NAME.ActRechargeBack then
		return self:checkActRechargeBackRedTips()
	elseif id == c.ACTIVITY_NAME.ActPointShop then
		return self:checkActPointShopRedTips()
	elseif id == c.ACTIVITY_NAME.ActTenDiamond then
		return self:checkActTenDiamondRedTips()
	elseif id == c.ACTIVITY_NAME.ActTimeChallenge then
		return self:checkActTimeChallengeRedTips()
	elseif id == c.ACTIVITY_NAME.ActWish then
		return self:checkActWishGarretRedTips()
	elseif id == c.ACTIVITY_NAME.ActLevelGift then
		return self:checkActLevelGiftRedTips() --等级好礼小红点
	elseif id == c.ACTIVITY_NAME.ActSuperPurchase then
		return self:checkActSuperPurchaseRedTips() --超值礼包红点
	elseif id == c.ACTIVITY_NAME.ActFund then
		return self:checkActFundRedTips()
	elseif id == c.ACTIVITY_NAME.ActFundWelfare then
		return self:checkActFundWelfareTips()
	elseif id == c.ACTIVITY_NAME.ActConRecharge then
		return self:checkActConRechargeTips()
	elseif id == c.ACTIVITY_NAME.ActSumOnline then  
		return self:checkActSumOnlineRedTips()
	elseif id == c.ACTIVITY_NAME.ActDailyCumulativeRecharge then --每日累计充值
		return self:checkActDailyCumulativeRechargeRedTips()
	elseif id == c.ACTIVITY_NAME.ActDailyRecharge then --每日首充
		return self:checkActActDailyRechargeRedTips()
	elseif id == c.ACTIVITY_NAME.ActDayGift then --每日礼包
		return self:checkActActDayGiftRedTips()
	elseif id == c.ACTIVITY_NAME.ActWeekGift then --每周礼包
		return self:checkActActWeekGiftRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestGiftBuy then --每周礼包
		return self:checkActActFestGiftBuyRedTips()
	elseif id == c.ACTIVITY_NAME.ActPhysicalStrength then --c=餐饮
		return self:checkActPhysicalStrengthRedTips()
	-- elseif id == c.ACTIVITY_NAME.ActRewardRecall then --资源找回
	-- 	return self:checkActRewardRecallRedTips()
	elseif id == c.ACTIVITY_NAME.ActRebateShop then --限购商店
		return self:checkActRebateShopRedTips()
	elseif id == c.ACTIVITY_NAME.ActSupremeRoulette then --限购商店
		return self:checkActSupremeRouletteRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestRecharge then --节日累充
		return self:checkActFestRechargeRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestLogin then --节日登陆
		return self:checkActFestLoginRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestPoint then --圣诞雪人
		return self:checkActFestPointRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestBless then --元旦祈福
		return self:checkActActFestBlessRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestMission then -- 新年任务
		return self:checkActActFestMissionRedTips()
	elseif id == c.ACTIVITY_NAME.ActHappySlots then
		return self:checkActHappySlotsRedTips()
	elseif id == c.ACTIVITY_NAME.ActCNYMonopoly then -- 新年大富翁
		return self:checkActCNYMonopolyRedTips()
	elseif id == c.ACTIVITY_NAME.ActCNYYearBeast then -- 打年兽
		return self:checkActCNYYearBeastTips()
	elseif id == c.ACTIVITY_NAME.ActFestDiShop then --限购商店
		return self:checkActFestDiShopRedTips()
	elseif id == c.ACTIVITY_NAME.ActFestExchange then -- 节日兑换
		return self:checkActFestExchangeTips()
	elseif id == c.ACTIVITY_NAME.ActFestCard then -- 刮刮乐
		return self:checkActFestCardTips()
	elseif id == c.ACTIVITY_NAME.ActSignInReward then -- 签到福利
		return self:checkActSignInRewardTips()
	elseif id == c.ACTIVITY_NAME.ActDispatchReward then -- 派遣福利
		return self:checkActActDispatchRewardRedTips()
	elseif id == c.ACTIVITY_NAME.ActSignInRoulette then -- 签到转盘
		return self:checkActActSignInRouletteRedTips()
	elseif id == c.ACTIVITY_NAME.ActMysteryStore then
		return self:checkActMysteryStoreRedTips()
	elseif id == c.ACTIVITY_NAME.ActSmashEggs then
		return self:checkActActSmashEggsRedTips()
	elseif id == c.ACTIVITY_NAME.ActSelectGift then
		return self:checkActSelectGiftRedTips()
	elseif id == c.ACTIVITY_NAME.ActLevelUpGift then
		return self:checkActLevelUpGiftRedTips()
	end
	return false
end

function ActivityModel:checkActRebateShopRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local key = "ActRebateShop" .. PlayerModel.info.userId
	local time = cc.UserDefault:getInstance():getIntegerForKey(key, 0)
	if time == 0 or Helper.getFixedTime() > time then
		return true
	end
	return false
end

function ActivityModel:checkActFestDiShopRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestDiShop)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local key = "ActFestDiShop" .. PlayerModel.info.userId
	local time = cc.UserDefault:getInstance():getIntegerForKey(key, 0)
	if time == 0 or Helper.getFixedTime() > time then
		return true
	end

	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if userData.Goods and #userData.Goods > 0 then
		for k,v in ipairs(userData.Goods) do
			if PlayerModel:getCurrencyByID(v.BuyCost[1].Id) >= v.BuyCost[1].N then -- 消耗足够
				if userData.BuyCount then
					if not userData.BuyCount[v.Id] or (userData.BuyCount[v.Id] and v.Count - userData.BuyCount[v.Id] > 0) then
						canTake = true
					end
				end
			end
		end
	end

	return canTake
end

function ActivityModel:checkActSupremeRouletteRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSupremeRoulette)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local BTN_TYPE = {
	    BUY = 1,--购买
	    FREE = 2,--免费转动
	    ROUND = 3,--转动
	    NOTCLICK = 4, -- 不能转动也不能购买次数
	}
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local round = 0 -- 转动次数
	local canTake = false
	local btnType = BTN_TYPE.FREE
    if not userData.DrawCnt or userData.DrawCnt == 0 then
        round = 1
    elseif userData.DrawCnt >= 8 then
        round = userData.DrawCnt
        btnType = (btnType == BTN_TYPE.NOTCLICK) and btnType or BTN_TYPE.NOTCLICK
    else
        round = userData.DrawCnt + 1
    end
    local rouletteData = {}
    -- 添加道具
    for k,v in ipairs(actConf.actSuperemeRoulette or {}) do
        if v.Round == round then
            rouletteData = v
        end
    end
    if rouletteData.GiftId then
	    if rouletteData.GiftId == 0 then
	        btnType = (btnType == BTN_TYPE.NOTCLICK) and btnType or BTN_TYPE.FREE
	    else
	        if not userData.SurplusCnt or userData.SurplusCnt == 0 then -- TODO判断可转动次数
	            btnType = (btnType == BTN_TYPE.NOTCLICK) and btnType or BTN_TYPE.BUY
	        else
	            btnType = (btnType == BTN_TYPE.NOTCLICK) and btnType or BTN_TYPE.ROUND
	        end
	    end
	end
	for k,v in ipairs(actConf.actSuperemeRouletteRewa or {}) do
        if userData.DrawCnt and userData.DrawCnt >= v.Count then
            if userData.TakenCntList and (not table.indexof(userData.TakenCntList, v.Id)) then
                canTake = true
                break
            end
        end
    end
	return (btnType == BTN_TYPE.FREE) or (btnType == BTN_TYPE.ROUND) or canTake
end

function ActivityModel:checkActFestRechargeRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestRecharge)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end

	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if actConf.actTotalrecharge then
		for i,v in ipairs(actConf.actTotalrecharge or {}) do
			if userData.SumDiamond and userData.SumDiamond ~= 0 and userData.SumDiamond >= v.TotalCcy then --满足领去条件
				if not userData.TokenIds or (userData.TokenIds and (not table.indexof(userData.TokenIds, v.Id))) then --未领取
					canTake = true
				end
			end
		end
	end
	return canTake
end

function ActivityModel:checkActFestLoginRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestLogin)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if actConf.actFesLogin then
		for i,v in ipairs(actConf.actFesLogin or {}) do
			if userData.SumLoginCnt and userData.SumLoginCnt ~= 0 and userData.SumLoginCnt >= v.Day then --满足领去条件
				if not userData.TokenIds or (userData.TokenIds and (not table.indexof(userData.TokenIds, v.Id))) then --未领取
					canTake = true
				end
			end
		end
	end
	return canTake
end

function ActivityModel:checkActFestPointRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestPoint)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local checkGetReward = function(Id,isPlr)
		local taken = isPlr and userData.Taken or userData.SvrTaken or {}
	    if #taken == 0 then
	        return false
	    end
	    for i, id_ in ipairs(taken) do
	        if id_ == Id then
	            return true
	        end
	    end
	    return false
	end
	local plrboxData = {}
	local svrboxData = {}
	if actConf.actFestPointsAwards then
		for k,v in ipairs(actConf.actFestPointsAwards or {}) do
	        table.insert(plrboxData, {Id = v.Id, PBox = v.PBox, PPoints = v.PPoints})
	        table.insert(svrboxData, {Id = v.Id, ABox = v.ABox, APoints = v.APoints})
	    end
		for i,v in ipairs(plrboxData) do
			if userData.Point and userData.Point >= v.PPoints and (v.PPoints ~= 0) and (not checkGetReward(v.Id,true)) then
				canTake = true
			end
		end
		for i,v in ipairs(svrboxData) do
			if userData.SvrPoint and userData.SvrPoint >= v.APoints and (v.APoints ~= 0) and (not checkGetReward(v.Id,false)) then
				canTake = true
			end
		end
	end
	return canTake
end

function ActivityModel:checkActHappySlotsRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActHappySlots)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData

	if not userData then
		return false
	end

	if #userData.Taken > 0 then
		return false
	end

	for i = 1, 2 do
		if i <= userData.Day and userData.Roll[i].N == 0 then
			return true
		end
	end
	if userData.Day >= 3 and #userData.Taken == 0 then
		return true
	end
	return false
end

function ActivityModel:checkActCNYYearBeastTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local ItemModel = init.ItemModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActCNYYearBeast)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if actConf.actfestivalmonster[1] then
	    for i, v in ipairs(actConf.actfestivalmonster[1].PlayerDmg or {}) do
	        if userData.PlrDmg and userData.PlrDmg >= v.Dmg then
	        	local receiveState = false
	        	for _,k in ipairs(act.UserData.PlrTaken or {}) do
					if v.Dmg == k then
		               receiveState = true
		               break
					end
			    end
			    if not receiveState then
			    	canTake = true
			    end
	        end
	    end
	    for i, v in ipairs(actConf.actfestivalmonster[1].BossLife or {}) do
	        if userData.MonsterLife and userData.MonsterLife >= v.Life then
	        	local receiveState = false
	        	for _,k in ipairs(act.UserData.SvrTaken or {}) do
					if v.Life == k then
		               receiveState = true
		               break
					end
			    end
			    if not receiveState then
			    	canTake = true
			    end
	        end
	    end
	    if userData.MonsterLife and actConf.actfestivalmonster[1].Life and userData.MonsterLife < actConf.actfestivalmonster[1].Life then
	    	local costId1 = actConf.actfestivalmonster[1].ItemHp[1].Id
	    	local myGoods1 = Helper.getItemOrCurrencyCnt(costId1)
	    	local costId2 = actConf.actfestivalmonster[1].ItemHp[2].Id
	    	local myGoods2 = Helper.getItemOrCurrencyCnt(costId2)
	    	if myGoods1 > 0 or myGoods2 > 0 then
	    		canTake = true
	    	end
	    end
	end

	return canTake
end

function ActivityModel:checkActFestExchangeTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestExchange)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if actConf.actFestExchange then
		local exchangeData = {}
		for k,v in ipairs(userData.ExcCount or {}) do
			exchangeData[v.Id] = v.N
		end
		for k, v in ipairs(actConf.actFestExchange or {}) do
			local exchangeNum = exchangeData[v.Id] or 0
			if v.ExchangeMax > exchangeNum then
				local canExchange = true
				for _,needItem in ipairs(v.CostItem) do
					local hasNum = Helper.getItemOrCurrencyCnt(needItem.Id)
					if hasNum < needItem.N then
						canExchange = false
						break
					end
				end
				if canExchange then
					canTake = true
					break
				end
			end
		end
	end
	return canTake
end

function ActivityModel:checkActFestCardTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestCard)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local shopRedTips = false
	if actConf.actFestCardShop then
		local exchangeData = {}
		for k,v in ipairs(userData.GetItemCnt or {}) do
			exchangeData[v.Id] = v.N
		end
		for k, v in ipairs(actConf.actFestCardShop or {}) do
			local exchangeNum = exchangeData[v.Id] or 0
			if v.ExchangeMax > exchangeNum then
				local hasNum = userData.SurplusInte or 0
				if hasNum > v.Integral then
					canTake = true
					shopRedTips = true
					break
				end
			end
		end
	end
	if actConf.actFestCardBuy then
		local costId = actConf.actFestCardBuy[1].CardCount[1].Id
		local costNum = Helper.getItemOrCurrencyCnt(costId)
		if costNum > 0 then
			canTake = true
		end
	end

	return canTake,shopRedTips
end

function ActivityModel:checkActActFestBlessRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestBless)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local getTakenCnt = function(Id)
		local taken = userData.Taken
		local cnt = 0
		if not taken or (#taken == 0) then
			return cnt, sumCnt
		end
		for k,v in ipairs(taken) do
			if Id then
				if Id == v.Id then
					cnt = cnt + v.N
				end
			end
		end
		return cnt
	end
	local getRwdCntAndTakenByBonusId = function(bonusId)
		local dropCnt = 0
		local takenCnt = 0
		if actConf.actFestBlessRewards then
			for k,v in ipairs(actConf.actFestBlessRewards or {}) do
				for _,val in ipairs(v) do
					if val.BonusId == bonusId then
						dropCnt = dropCnt + val.DropsNumber
						takenCnt = takenCnt + getTakenCnt(val.Id)
					end
				end
			end
		end
		return dropCnt, takenCnt
	end
	if actConf.actFestBless then
		for k,v in ipairs(actConf.actFestBless or {}) do
			local dropCnt, takenCnt = getRwdCntAndTakenByBonusId(v.Limit)
			local enable = dropCnt <= takenCnt
			if enable then
		        local canBlessCnt = math.floor(Helper.getItemOrCurrencyCnt(v.Cost[1].Id)/v.Cost[1].N)
				local rwdCnt, takenCnt= getRwdCntAndTakenByBonusId(v.BonusId)
				if canBlessCnt >= 10 then -- 拥有的道具足够抽10次
					if (rwdCnt - takenCnt) >= 10 then -- 剩余抽奖次数也大于等于10次
						canBlessCnt = 10
					else -- 剩余抽奖次数小于10
						canBlessCnt = (rwdCnt - takenCnt)
					end
				else -- 拥有的道具不足抽十次
					if (rwdCnt - takenCnt) < canBlessCnt then --剩余抽奖次数不足拥有道具可抽取的次数
						canBlessCnt = rwdCnt - takenCnt 
					end
				end
				if canBlessCnt >= 1 then
					canTake = true
					break
				end
			end
	    end
	end
	return canTake
end

function ActivityModel:checkActActFestMissionRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestMission)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local checkHasFinishOrTaken = function(Id,str)
		local finOrTaken = false
		if userData.Quests and #userData.Quests > 0 then
			for k,v in ipairs(userData.Quests or {}) do
				if v.Id == Id and v[str] then
		            return true
		        end
		    end
		end
		return false
	end
	if actConf.actfestivalquest then
		local finishCnt = 0
		for k,v in ipairs(actConf.actfestivalquest or {}) do
			if checkHasFinishOrTaken(v.Id,"Fin") then -- 已完成
				finishCnt = finishCnt + 1
				if (not checkHasFinishOrTaken(v.Id,"Taken")) then -- 未领取
					canTake = true
				end
			end
		end
		-- 箱子可领取
		if finishCnt >= table.nums(actConf.actfestivalquest or {}) and (not userData.Taken) then -- 完成任务条数达成
			canTake = true
		end
	end
	return canTake
end

function ActivityModel:checkActActDispatchRewardRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActDispatchReward)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local checkHasFinishOrTaken = function(Id,str)
		local finOrTaken = false
		if userData.DisWelS and #userData.DisWelS > 0 then
			for k,v in ipairs(userData.DisWelS or {}) do
				if v.Id == Id and v[str] then
		            return true
		        end
		    end
		end
		return false
	end
	local getConfDataByType = function(confData,curtype)
	    local signInData = {}
	    for k,v in ipairs(confData) do    
	        if v.Type == curtype then
	            table.insert(signInData, v)
	        end
	    end
	    return signInData
	end
	if actConf.actDispatchWelfare then
		local finishCnt = 0
		local dispatchData = getConfDataByType(actConf.actDispatchWelfare,1)
		for k,v in ipairs(actConf.actDispatchWelfare or {}) do
			if checkHasFinishOrTaken(v.Id,"Fin") then -- 已完成
				finishCnt = finishCnt + 1
				if (not checkHasFinishOrTaken(v.Id,"Taken")) then -- 未领取
					canTake = true
				end
			end
		end
		-- 箱子可领取
		local boxData = getConfDataByType(actConf.actDispatchWelfare,2)
		for k,v in ipairs(boxData) do
			if finishCnt >= v.Value then
				if userData.TakenCompDisWel and #userData.TakenCompDisWel > 0 and (not table.indexof(userData.TakenCompDisWel, v.Value)) then
					canTake = true
				end
			end
		end
	end
	return canTake
end

function ActivityModel:checkActActSignInRouletteRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSignInRoulette)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if userData.SurplusCnt and userData.SurplusCnt > 0 and userData.DrawCnt and actConf.actSignRoulette and (userData.DrawCnt < #actConf.actSignRoulette[1].Item) then
		canTake = true
	end
	if actConf.actSignRouletteRewa then
		for k,v in ipairs(actConf.actSignRouletteRewa or {}) do
			if userData.DrawCnt and userData.DrawCnt >= v.Count then
				if userData.TakenCntList and #userData.TakenCntList > 0 and not table.indexof(userData.TakenCntList, v.Count) then
					canTake = true
				end
			end
		end
	end
	return canTake
end

function ActivityModel:checkActActSmashEggsRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSmashEggs)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local time = PlayerConfig.getSetting(PlayerModel.info.userId.."ActSmashEggsRedTips", 0) --每日兑换点击后红点消失，每天出现一次
	if Helper.getFixedTime() > time + 24 * 3600 then
		canTake = true
	end
	return canTake
end

function ActivityModel:checkActSelectGiftRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSelectGift)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local time = PlayerConfig.getSetting(PlayerModel.info.userId.."ActSelectGiftRedTips", 0) --每日兑换点击后红点消失，每天出现一次
	if Helper.getFixedTime() > time + 24 * 3600 then
		canTake = true
	end
	return canTake
end

function ActivityModel:checkActLevelUpGiftRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActLevelUpGift)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	local time = PlayerConfig.getSetting(PlayerModel.info.userId.."ActLevelUpGiftRedTips", 0) --每日兑换点击后红点消失，每天出现一次
	if Helper.getFixedTime() > time + 24 * 3600 then
		canTake = true
	end
	return canTake
end

function ActivityModel:checkActMysteryStoreRedTips()
	local init = require 'app.models.init'
	local PlayerModel = init.PlayerModel

	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActMysteryStore)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	if (not act.UserData) or (not act.Confs) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}

	local reTabConf = {}
	for k,v in ipairs(actConf.actWeekCard) do
		reTabConf[v.GiftId] = reTabConf[v.GiftId] or {}
		reTabConf[v.GiftId][v.Day] = v
	end

	local redTips = false
	for k,v in pairs(reTabConf) do
		local hasBuy = false
		for _,buyId in pairs(userData.Bill or {}) do
			if k == buyId then
				hasBuy = true
				break
			end
		end

		if hasBuy then
			for day = 1, math.min(userData.Day, 7) do
				local taked = false
				for k, takenId in ipairs(userData.Taken or {}) do
					if takenId == v[day].Id * 100 + 1 or takenId == v[day].Id * 100 + 2 then
						taked = true
						break
					end
				end
				if not taked then
					redTips = true
					break
				end
			end
		else
			local lastTips = PlayerConfig.getSetting(PlayerModel.info.userId .. "mysteryStore" .. k, 0)
			local curTimeTs = os.date("*t",Helper.getFixedTime())
    		local time = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = 0, min = 0, sec = 0})
    		if time - lastTips >= 24 * 3600 then
    			redTips = true
    		end
		end

		if redTips then
			break
		end
	end

	return redTips
end

function ActivityModel:checkActSignInRewardTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSignInReward)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false
	if not userData.TodaySign then
		canTake = true
	end
	local getConfDataByType = function(confData,curtype)
	    local signInData = {}
	    for k,v in ipairs(confData) do    
	        if v.Type == curtype then
	            table.insert(signInData, v)
	        end
	    end
	    return signInData
	end
	if actConf.actSignWelfare then
		--	箱子可领取
		local boxData = getConfDataByType(actConf.actSignWelfare,2)
		for k,v in ipairs(boxData) do
			if userData.SignCnt and userData.SignCnt >= v.Value then
				if userData.GetTotalRewards and #userData.GetTotalRewards > 0 and (not table.indexof(userData.GetTotalRewards, v.Value)) then
					canTake = true
				end
			end
		end
	end

	return canTake
end

function ActivityModel:checkActCNYMonopolyRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActCNYMonopoly)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local userData = act.UserData or {}
	local actConf = act.Confs or {}
	local canTake = false

	if userData.CanDiceCnt and userData.CanDiceCnt > 0 then
		canTake = true
	end
	if userData.CycleCnt and userData.CycleCnt > 0 then
		canTake = true
	end
	if userData.SurpirseCnt and userData.SurpirseCnt > 0 then
		canTake = true
	end
	return canTake
end

function ActivityModel:checkActRewardRecallRedTips()
	local init = require "app.models.init"
	local RewardRecallModel = init.RewardRecallModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActRewardRecall)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
    return false
end

function ActivityModel:checkActActDayGiftRedTips()  
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActDayGift)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local dayRed = false
	local fuc = function(id)
		local buyCnt = act.UserData.DayGift or {}
	    local cnt = 0
	    for _, v in ipairs(buyCnt) do
	        if v.Id == id then
	            cnt = cnt + v.N
	        end
	    end
	    return cnt
	end
	for i, v in pairs(act.Confs.actDayGift or {}) do
		if v.Value[1].N == 0 and fuc(v.Id) < v.Limit then
            dayRed = true
            break
        end 
    end

    return dayRed
end
function ActivityModel:checkActPhysicalStrengthRedTips()
	local tokens = self:getActivityCalendar(c.ACTIVITY_NAME.ActPhysicalStrength).UserData.Token
	local strengthConf = self:getActivityCalendar(c.ACTIVITY_NAME.ActPhysicalStrength).Confs.actTimeUtage
	local nowTime = os.date("*t",Helper.getFixedTime())
    local nowSec = nowTime.hour * 60 * 60 + nowTime.min * 60 + nowTime.sec
	local canToken = false
	local sendId = 0
	for k,v in pairs(strengthConf) do
        if nowSec >= v.StartTime * 60 * 60 and nowSec <= v.StartTime * 60 * 60 + v.LastTime then
			canToken = true
			sendId = v.Id
            for k,v in pairs(tokens) do
                if v == sendId then
                    canToken = false
                    break
                end
            end
            break
        end
	end
	return canToken
end
function ActivityModel:checkActActWeekGiftRedTips()  
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActWeekGift)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local weekRed = false
	local fuc = function(id)
		local buyCnt = act.UserData.WeekGift or {}
	    local cnt = 0
	    for _, v in ipairs(buyCnt) do
	        if v.Id == id then
	            cnt = cnt + v.N
	        end
	    end
	    return cnt
	end
	for i, v in pairs(act.Confs.actWeekGift or {}) do
		if v.Value[1].N == 0 and fuc(v.Id) < v.Limit then
            weekRed = true
            break
        end 
    end

    return weekRed
end

function ActivityModel:checkActActFestGiftBuyRedTips()  
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFestGiftBuy)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local giftRed = false
	local fuc = function(id)
		local buyCnt = act.UserData.WeekGift or {}
	    local cnt = 0
	    for _, v in ipairs(buyCnt) do
	        if v.Id == id then
	            cnt = cnt + v.N
	        end
	    end
	    return cnt
	end
	for i, v in pairs(act.Confs.FesGift or {}) do
		if v.Value[1].N == 0 and fuc(v.Id) < v.Limit then
            giftRed = true
            break
        end 
    end

    return giftRed
end

function ActivityModel:getNextOnlineConf()
	local activityData = self:getActivityCalendar(c.ACTIVITY_NAME.ActSumOnline)
	local actConfData = activityData.Confs.actSumOnline
	local userData = activityData.UserData
	local leftActConfData = {}
	for _, conf in pairs(actConfData) do
		local isFind = false
		for _, id in pairs(userData.TokenIds) do
			if id == conf.SumOnline then
				isFind = true
				break
			end
		end
		if not isFind then
			table.insert(leftActConfData,conf)
		end
	end
	table.sort(leftActConfData,function(a,b)
		return a.SumOnline < b.SumOnline
	end)
	if #leftActConfData > 0 then
		return leftActConfData[1]
	end
	return nil
end

function ActivityModel:getNextRedPacksConf()
	local activityData = self:getActivityCalendar(c.ACTIVITY_NAME.ActCNYRedPack)
	local actConfData = activityData.Confs.actfesredgift
	local userData = activityData.UserData
	local leftActConfData = {}
	local showTimeConfData = {} -- 需要显示时间的是未达到领取条件的和达到条件但领取次数不为0的
	local isInCanGetList = function(Id)
		for _, _V in pairs(userData.CanGetCnt or {}) do
			if _V.Id == Id then
				return true
			end
		end
	end
	-- dump(userData.CanGetCnt, "userData.CanGetCnt", 10)
	for _, conf in pairs(actConfData) do
		local canShowTime = true
		local curTimeTs = Helper.getFixedTime() 
	    local _, _, y, m, d, _hour, _min, _sec = string.find(conf.Date, "(%d+)-(%d+)-(%d+)%s*(%d+):(%d+):(%d+)");
	    local time = os.time({year=y, month = m, day = d, hour = _hour, min = _min, sec = _sec})
		for _, val in pairs(userData.CanGetCnt or {}) do
			if val.Id == conf.Id and val.N > 0 then
				if val.N == conf.Times then
					table.insert(leftActConfData,conf)
				else
					canShowTime = false
				end
				break
			elseif val.Id == conf.Id and val.N == 0 then
				canShowTime = false
				break
	        end
		end
		if (curTimeTs > time and (not isInCanGetList(conf.Id))) then -- 时间没到，或者是时间到了但可领取里没有 ====(curTimeTs < time) or 
	        canShowTime = false
	    end
		if canShowTime then
			table.insert(showTimeConfData,conf)
		end
	end
	table.sort(leftActConfData,function(a,b)
		return a.Date < b.Date
	end)
	table.sort(showTimeConfData,function(a,b)
		return a.Date < b.Date
	end)
	if #showTimeConfData > 0 or (#leftActConfData > 0) then
		return showTimeConfData[1], leftActConfData[1], #leftActConfData
	end
	return nil,nil,nil
end

function ActivityModel:checkActSumOnlineRedTips()  
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSumOnline)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	if not act.UserData.OnlineDur or act.UserData.OnlineDur == 0 then
		return false
	else
		for i, v in pairs(act.Confs.actSumOnline or {}) do
			local receiveState = false
			for _,sumTime_ in ipairs(act.UserData.TokenIds) do
				if v.SumOnline == sumTime_ then
                   receiveState = true
                   break
				end
			end
			if not receiveState then
				if act.UserData.OnlineDur >= v.SumOnline*60 then
					return true
				end
			end    
        end
	end
    return false
end

-- 基金福利
function ActivityModel:checkActFundRedTips()
	local init = require 'app.models.init'
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFund)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
    local types = {}
    for _,k in ipairs(act.Confs.actFund or {}) do
        if not types[k.FundType] then
            types[k.FundType] = {}
        end
        table.insert(types[k.FundType], k)   
    end
    for k,data in pairs(types) do
    	local buyTime = false
    	for _,v in ipairs(act.UserData.Fund or {}) do
    		if v.FundType == k then
    			buyTime = (v.BuyTs>0) and v.BuyTs or false
    			break
    		end
    	end
    	if buyTime then
    		local timeTab = os.date("*t", buyTime)
            local recTime = os.time({year = timeTab.year, month = timeTab.month, day = timeTab.day, hour = 0, min = 0, sec = 0})
    		for _,v in ipairs(data) do
				if v.Day ~= 0 and v.Level == 0 then
	    			if Helper.getFixedTime() >= (recTime + (v.Day - 1)*24*60*60) then
			    		local hasId = false
			    		for _,h in ipairs(act.UserData.TokenIds or {}) do
			    			if v.Id == h then
			    				hasId = true
			    				break
			    			end
			    		end
			    		if not hasId then
			    			return true
			    		end
			    	end
			    elseif v.Level ~= 0 and v.Day == 0 then
			    	if PlayerModel.info.level >= v.Level then
			    		local hasId = false
			    		for _,h in ipairs(act.UserData.TokenIds or {}) do
			    			if v.Id == h then
			    				hasId = true
			    				break
			    			end
			    		end
			    		if not hasId then
			    			return true
			    		end
			    	end
			    end
    		end
    	end
    end

    return false
end

function ActivityModel:checkActFundWelfareTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFundWelfare)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local types = {}
    for _,k in ipairs(act.Confs.fundWelfare or {}) do
        if not types[k.FundType] then
            types[k.FundType] = {}
        end
        table.insert(types[k.FundType], k)   
    end
    for k,v in pairs(types) do
    	local number = 0
    	for _,data in ipairs(act.UserData.SumFund or {}) do
    		if k == data.FundType then
    			number = data.Cnt
    			break
    		end
    	end
    	for _,data in ipairs(v) do
    		if number >= data.Count then
	    		local hasId = false
	    		for _,h in ipairs(act.UserData.TakenIds or {}) do
	    			if data.Id == h then
	    				hasId = true
	    				break
	    			end
	    		end
	    		if not hasId then
	    			return true
	    		end
	    	end
    	end
    	
    end

	return false
end

function ActivityModel:checkActLimitBuyRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActLimitBuy)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end

	for i,conf in ipairs(act.Confs.actLimitGift or {}) do
		local buyNum = 0
		for _,data in ipairs(act.UserData.BuyGift or {}) do
			if conf.Id == data.Id then
				buyNum = data.N
				break
			end
		end
		if buyNum < conf.BuyCount and not act.UserData.openWin then
			return true
		end
	end

	return false
end

function ActivityModel:checkActConRechargeTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActConRecharge)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local hasRed = false
	local dailyCnt = act.UserData.DailyCnt
	local superShop = act.Confs.actSuperShop or {}
	local conRecharge = act.Confs.actConRecharge or {}
	table.sort(superShop, function(a,b)
		return a.Id < b.Id
	end)
	local minPrice = superShop[1].Price[1]
	for k, v in ipairs(superShop) do
		local buyCnt = self:checkHasBuy2(act, v.Id)
		if not buyCnt[v.Id] or buyCnt[v.Id] <= 0 or buyCnt[v.Id] <= v.BuyLimit then
			if v.Price[1].N < minPrice.N then
				minPrice = v.Price[1]
			end
		end
	end

	local conTp = act.UserData.ConTp
	local tokenIds = act.UserData.TokenIds or {}
	if PlayerModel:getCurrencyByID(minPrice.Id) >= minPrice.N then   ----货币足以购买(积分商店的红点)---
		hasRed = true
	end
	local ConDay = {}
	for k,v in ipairs(conRecharge) do
		if dailyCnt and conTp and dailyCnt >= conTp[#conTp].Tp then  ----当天充值，并且当天充值数量足够
			if conTp[#conTp].ConDay == v.Day then --- 判断当天是第几天，从而获取当天的数据
				ConDay = v
			end
		end
	end
	if dailyCnt and conTp and dailyCnt >= conTp[#conTp].Tp then --- 当天充值，并且当天充值数量足够
		if not table.indexof(tokenIds, ConDay.Id) then --- 未领取
			hasRed = true
		end
	end

	return hasRed
end

function ActivityModel:checkFirstRechargeRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActFirstRecharge)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local tData = act.UserData
    local actConfData = act.Confs.actFirstrecharge or {}
    local actRechargeData = act.Confs.actFirstrechargeDaily or {}
    if tData and tData.FirstTs > 0 then
	    for i,v in ipairs(actConfData) do
	    	if tData.SumBill >= v.TotalValue then
	    		if i == 1 then
    				local timeTab = os.date("*t", tData.FirstTs)
    				local firstTime = os.time({year = timeTab.year, month = timeTab.month, day = timeTab.day, hour = 0, min = 0, sec = 0})
    				local curTime = Helper.getFixedTime()
    				for _,k in ipairs(actRechargeData) do
    					if curTime >= (firstTime + (k.Day-1)*24*60*60) then
    						local hasDay = false
	                        for _,day in ipairs(tData.Days) do
	                        	if k.Day == day then
	                        		hasDay = true
	                        		break
	                        	end
	                        end
	                        if not hasDay then
	                        	return true
	                        end
	                    end
    				end
    			else
    				local hasId = false
		    		for _,id in ipairs(tData.Taken or {}) do
		    			if id == v.Id then
		    				hasId = true
		    				break
		    			end
		    		end
		    		if not hasId then
		    			return true
		    		end
    			end
	    	end
	    end
    end
	return false
end

function ActivityModel:checkActAccumulativeCostRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActAccumulativeCost)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end

	local data = act.UserData
	local confData = act.Confs.actsumcost or {}
	local canTake = false
	for i,v in ipairs(data.Items or {}) do
		for m,n in ipairs(confData) do
			if v.Id == n.Id then
				if v.Objs[1].Val >= n.P2 and v.Taken == false then
					canTake = true
				end
				break
			end
		end
		if canTake then
			break
		end
	end
	return canTake
end

function ActivityModel:checkActNewServerRankRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActNewServerRank)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local curFunc = data.Func
	local svrShop = act.Confs.actNewSvrShop or {}
	local buyCnt = data.TakenShop
	local canTake = false
	local hasRedTips = false
	local goodsData = {}
	local checkActHasEnd = function(day)
		local daySec = 24 * 60 * 60
		local startTime = act.Start
		local endTime = startTime + (daySec * day)
		local curTime = Helper.getFixedTime()
		if curTime >= endTime then
			return true
		end
		return false
	end

	for k,v in ipairs(svrShop) do
		if v.Func == curFunc then
			goodsData[#goodsData + 1] = v
		end
	end
	for k,v in ipairs(goodsData) do
		if PlayerModel:getCurrencyByID(v.Cost[1].Id) >= v.Cost[1].N then
			if not buyCnt or not table.indexof(buyCnt, v.Id) then
				canTake = true
			end
		end
	end
	for k,v in ipairs(act.Confs.actNewSvrRankFunc or {}) do
		if canTake and curFunc == v.Func and (not checkActHasEnd(v.Day)) then
			hasRedTips = true
		end
	end
	return hasRedTips
end
function ActivityModel:checkActTimeRedTips()
	local init = require "app.models.init"
	local ItemModel = init.ItemModel
	local PlayerModel = init.PlayerModel
	local itemConf = require "app.configs.item"
	local currencyConf = require "app.configs.currency"
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActTimeDrop)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end

 --    if not act.UserData.Objs or #act.UserData.Objs < 1 then
	-- 	return true
	-- end

	if not act.Confs or not act.Confs.actTimeExchange then
		return false
	end

	local actTimeExchange = act.Confs.actTimeExchange or {}
	local function HasExchangeCnt(dataId)
		local cnt = 0
		if not act.UserData.Objs or #act.UserData.Objs < 1 then
			return cnt
		end
		for k, v in ipairs(act.UserData.Objs) do
			if dataId == v.Id then
				cnt = cnt + v.N
			end
		end
		return cnt
	end

	local function CheckItemEnough(costItem)
		local enough = 0
		for k,v in ipairs(costItem) do
			local ownNum = 0
			if itemConf[v.Id] then
				ownNum = ItemModel:getItemCntById(v.Id)
			elseif currencyConf[v.Id] then
				ownNum = PlayerModel:getCurrencyByID(v.Id)
			end
			if ownNum >= v.N then
				enough = enough + 1
			end
		end
		return enough
	end

	for _,data in pairs(actTimeExchange) do
	    if data.ExchangeMax - HasExchangeCnt(data.Id) > 0 and CheckItemEnough(data.CostItem) == table.nums(data.CostItem) then
	    	return true
	    end
	end
	
	
	return false
end

function ActivityModel:checkActTimeChallengeRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActTimeChallenge)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local selData = act.UserData.SelData or {}
    local srvData = act.UserData.SrvData or {}
    local confRewardData = act.Confs.actTimeChallengeReward or {}
    local confChallengData = act.Confs.actTimeChallenge[1] or {}
    local challengeLimit = confChallengData.ChallengeLimit or 0
    local hasRed = false
    local canTake = false
    if selData.ChallengeCount and selData.ChallengeCount < challengeLimit then
    	hasRed = true
    end
    for k,v in ipairs(confRewardData) do
    	if srvData.TotalDmg and srvData.TotalDmg ~= 0 then
    		if v.HurtValue <= srvData.TotalDmg then -- 判断是否有达到可领取条件的
    			if selData.Taken and not table.indexof(selData.Taken, v.Id) then -- 判断是否领取
    				canTake = true
    			end
	        end
	    end
	end

	return hasRed or canTake
end

function ActivityModel:checkActAccumulativeRechargeRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActAccumulativeRecharge)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local confData = act.Confs.actTotalrecharge or {}
	local canTake = false
	local canGetRewardIds = 0
	for i,v in ipairs(confData) do
		if data.SumDiamond >= v.TotalCcy then
			canGetRewardIds = canGetRewardIds + 1
		end
	end

	if canGetRewardIds > #data.TokenIds then
		canTake = true
	end

	return canTake
end

function ActivityModel:checkActDailyCumulativeRechargeRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActDailyCumulativeRecharge)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local confData = act.Confs.actDailyBillSum or {}
	local canTake = falses
	local canGetRewardIds = 0
	for i,v in ipairs(confData) do
		if data.SumDiamond >= v.TotalCcy then
			canGetRewardIds = canGetRewardIds + 1
		end
	end

	if canGetRewardIds > #data.TokenIds then
		canTake = true
	end
	return canTake
end

function ActivityModel:checkActLevelShopRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActLevelShop)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
    if (not act.UserData.Goods or #act.UserData.Goods < 1) and not act.UserData.openWin then
		return true
	end
	return false
end

function ActivityModel:checkActSevenDayLoginRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.Act7DayLogin)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local confData = act.Confs.actSevenDayLogin or {}
	local canTake = false
	if data.SumLoginCnt >= #data.TokenIds and #data.TokenIds < 7 then
		for k,v in ipairs(confData) do
			if (#data.TokenIds == 0 or not table.indexof(data.TokenIds, v.Id)) and data.SumLoginCnt >= v.Id then
				canTake = true
			end
		end
	end
	return canTake
end

function ActivityModel:checkActTenDiamondRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActTenDiamond)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local token = act.UserData.Token
	local sumDay = act.UserData.SumDay
	local confData = act.Confs.actMassiveDiamond or {}
	local hasTake = false
	for k,data in ipairs(confData) do
		if data.Day <= sumDay and not table.indexof(token, data.Id) then
	        hasTake = true
	    end
	end
	return hasTake
end

function ActivityModel:checkActCostRebateRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActCostRebate)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local canTake = false
	-- TODO 判断条件
	if not data.Objs or #data.Objs < 1 then
		canTake = true
	end
	return canTake
end

function ActivityModel:checkActAct3DayTargetRedTips()
	-- local Act3DayTargetWin = require "app.views.activity.Act3DayTargetWin"
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.Act3DayTarget)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local curDay = data.CurDay
	local canTake = false
	local redTipDay = {}

	if not curDay or curDay == 0 then
		return false
	end
	if not self:checkSignTaken(act,curDay) then
		canTake = true
	end
	local sinExcData = clone(act.Confs.act3TargetSinExc or {})
	table.sort(sinExcData, function(a, b)
		return a.Days < b.Days 
	end)
	
	for i = 1, curDay do
		local taskData = {}
		for k,v in ipairs(act.Confs.act3TargetTask or {}) do
			if v.Days == i then
				table.insert(taskData, v)
			end
		end
		table.sort(taskData, function(a, b)
			return a.Id < b.Id
		end)
		for k,v in ipairs(sinExcData) do -- 判断每日兑换是否有红点,包括当天和之前是否有可领取的
			local time = PlayerConfig.getSetting(PlayerModel.info.userId..v.Days.."T_sinExc", 0) --每日兑换点击后红点消失，每天出现一次
    		if Helper.getFixedTime() > time + 24 * 3600 then
				if v.VipLimit <= PlayerModel.info.vip 
					and v.Days <= curDay 
					and PlayerModel:getCurrencyByID(v.Price[1].Id) >= v.Price[1].N 
					and not self:checkHasBuy(act, v.Id) then
					canTake = true
					if not table.indexof(redTipDay, v.Days) then
						table.insert(redTipDay, v.Days)
					end
				end
			end
		end
		for k,v in ipairs(taskData) do
			if self:TaskCntEnough(act, v) and not self:checkTaskTaken(act, v.Id) then
				-- print(v.Id,"dddddd---v.id")
				canTake = true
				if not table.indexof(redTipDay, v.Days) then
					table.insert(redTipDay, v.Days)
				end
			end
		end
	end
	return canTake, redTipDay
end

function ActivityModel:checkActAct4DayTargetRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.Act4DayTarget)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local data = act.UserData
	local curDay = data.CurDay
	local canTake = false
	local redTipDay = {}
	if not self:checkSignTaken(act,curDay) then
		canTake = true
	end
	if not curDay or curDay == 0 then
		return false
	end
	local sinExcData = clone(act.Confs.act4TargetSinExc or {})
	table.sort(sinExcData, function(a, b)
		return a.Days < b.Days 
	end)
	
	for i = 1, curDay do
		local taskData = {}
		for k,v in ipairs(act.Confs.act4TargetTask or {}) do
			if v.Days == i then
				table.insert(taskData, v)
			end
		end
		table.sort(taskData, function(a, b)
			return a.Id < b.Id
		end)
		for k,v in ipairs(sinExcData) do -- 判断每日兑换是否有红点,包括当天和之前是否有可领取的
			local time = PlayerConfig.getSetting(PlayerModel.info.userId..v.Days.."F_sinExc", 0)
    		if Helper.getFixedTime() > time + 24 * 3600 then
				if v.VipLimit <= PlayerModel.info.vip 
					and v.Days <= curDay
					and PlayerModel:getCurrencyByID(v.Price[1].Id) >= v.Price[1].N 
					and not self:checkHasBuy(act, v.Id) then
					canTake = true
					if not table.indexof(redTipDay, v.Days) then
						table.insert(redTipDay, v.Days)
					end
				end
			end
		end
		for k,v in ipairs(taskData) do
			if self:TaskCntEnough(act, v) and not self:checkTaskTaken(act, v.Id) then
				-- print(v.Id,"dddddd---v.id")
				canTake = true
				if not table.indexof(redTipDay, v.Days) then
					table.insert(redTipDay, v.Days)
				end
			end
		end
	end
	return canTake, redTipDay
end

function ActivityModel:checkActRouletteRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActRoulette)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local nextRound = act.UserData.Round + 1
	local canRoll = false
	for k,v in ipairs(act.Confs.actOccultRoulette or {}) do
		if v.Round == nextRound then
			if v.VipLimit <= PlayerModel.info.vip and PlayerModel:getCurrencyByID(v.CostNumber[1].Id) >= v.CostNumber[1].N then
				canRoll = true
				break
			end
		end
	end
	return canRoll
end

function ActivityModel:checkActLimitTreasuryRedTips()
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActLimitTreasury)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local TurnCnt = act.UserData.TurnCnt
	local CntRwd = act.UserData.CntRwd
	local canRoll = false
	if not TurnCnt or TurnCnt == 0 then
		return true
	end
	local confData = act.Confs.actTimeTurntable[1].CountReward or {}
	for k,v in ipairs(confData) do
		if TurnCnt and TurnCnt > 0 then
			if TurnCnt >= v.Cnt then
				if not CntRwd or #CntRwd < 1 or not table.indexof(CntRwd, v.Cnt) then
					canRoll = true
				end
			end
		end
	end
	return canRoll
end
--幸运翻牌小红点
function ActivityModel:checkActLuckyFlopRedTips()
	local openTime = self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.openTime
	local lastTime = self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.lastTime
	local nowTime = Helper:getFixedTime()
	local canGet = false
	local init = require 'app.models.init'
	local PlayerModel = init.PlayerModel
	local actLuckyFlop = require "app.views.activity.ActLuckyFlop"

	if self.activityCalendars[c.ACTIVITY_NAME.ActLuckyFlop].UserData.pickedFlop >= 8 then
		return false
	end

	for k,v in pairs(openTime) do
        if lastTime < v.time and nowTime >= v.time then
            canGet = true
			break
		end
	end

	if not canGet then
		if PlayerModel:getCounterByID(enums.Cnt_Act_RemainderCardPickCnt) > 0 then
			canGet = true
		else
			canGet = false
		end
	end
	return canGet
end

--等级好礼小红点检测
function ActivityModel:checkActLevelGiftRedTips()
	local init = require 'app.models.init'
	local PlayerModel = init.PlayerModel
	local myLevel = PlayerModel:getInfo().level
	local receivedReward = self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].UserData.receivedReward
	local allReward = self.activityCalendars[c.ACTIVITY_NAME.ActLevelGift].Confs.actLevelReward
	table.sort(allReward, function(a,b)
        return a.Id < b.Id
    end)

    local hasRed = false
	for k,v in ipairs(allReward) do
		if v.Lv <= myLevel then
			local hasId = false
			for _,id in pairs(receivedReward) do
				if id == v.Id then
					hasId = true
					break
				end
			end
			if not hasId then
				hasRed = true
				break
			end
		else
			break
		end
	end
    return hasRed
end

-- 限时召唤红点
function ActivityModel:checkActLimitSummonRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActLimitSummon)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local confData = act.Confs.actTimeRecruit[1] or {}
    local userData = act.UserData
    local token = userData.Token or {}
	for _,data in pairs(confData.WeightUp) do
    	-- 未领取
        if data.N > 0 and not table.indexof(token, data.N) then
        	-- 达到条件
        	if userData.RecruitCnt >= data.N then
        		return true
        	end
        end
	end
	return false
end

-- 召唤奖励红点
function ActivityModel:checkActActSummonRewardRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActSummonReward)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
	local confData = act.Confs.actRecruitReward or {}
    local userData = act.UserData
    local token = userData.Token or {}
	for _,data in pairs(confData) do
        -- 已领取
        if not table.indexof(token, data.Id) then
        	-- 未领取
        	if userData.RecruitCnt >= data.CondTimes then
        		return true
        	end
        end
	end

	return false
end

-- 充值回馈红点
function ActivityModel:checkActRechargeBackRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActRechargeBack)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
    local userData = act.UserData
	local confData = act.Confs.actRechargeBack or {}
	local dailyMax = 0
	for _,v in pairs(confData) do
		if v.DailyMax then
			dailyMax = v.DailyMax
			break
		end
	end

    if math.floor(userData.DailyDiamond/(10*100)) > userData.DailyRwdCnt and dailyMax > userData.DailyRwdCnt then
    	return true
    end
	return false
end

-- 积分商城红点
function ActivityModel:checkActPointShopRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActPointShop)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
    local userData = act.UserData
	local confData = act.Confs.actIntegralShop or {}

	table.sort(confData, function (a,b)
		return a.Need < b.Need
	end)

	for _,data in pairs(confData) do
        local count = 0
		local useCount = userData.Count or {}
        for _,v in pairs(useCount) do
        	if v.Id == data.Id then
        		count = v.N
        	end
        end

		if data.Limit-count <= 0 then -- 数量到达上限
		else
			if userData.Integral >= data.Need then
				return true
			else --积分不足
			end
		end
	end

	return false
end

-- 许愿阁红点
function ActivityModel:checkActWishGarretRedTips()
	local act = self:getActivityCalendar(c.ACTIVITY_NAME.ActWish)
	if not act or (act.Stage ~= c.ACTIVITY_STAGE.START and act.Stage ~= c.ACTIVITY_STAGE.END) then
		return false
	end
    local userData = act.UserData
	local confData = act.Confs.actWish or {}
	-- 可以领取宝箱
	local needWish = act.Confs.actWishReachReward and act.Confs.actWishReachReward.NeedWish or 0
	--print(isBoxAward,userData.WishNum,needWish,"======isBoxAward and userData.WishNum >= needWish========")
	if not isBoxAward and userData.WishNum >= needWish then
		return true
	end
	-- 判断是否能领取奖励
	--print(#userData.AwardIds,"========#userData.AwardId======")
	if #userData.AwardIds > 0 then
		local number = 0
		local bonus = {}
	    for _, v in pairs(confData) do
			if v.Id == userData.AwardConfId then
				bonus = v.Bonus
				break
			end
		end
		for i,v in ipairs(bonus) do
			if userData.ChargeMnt/10 >= v.N then
				if v.Mult > userData.AwardRate then
					number = number + 1
				end
			end
		end
		--print("number=====",number)
		if number > 0 then
			return true
		end
	end
	-- 判断是否有许愿次数
	if userData.ConfId > 0 then
		local num = userData.Num > 8 and 8 or userData.Num
		--print(num,#userData.PickIds,"======num - #userData.PickIds======")
		if num - #userData.PickIds > 0 then
			return true
		end
	end

	return false
end

-- 超值礼包红点
function ActivityModel:checkActSuperPurchaseRedTips()
	--每次登录显示红点，点开后取消红点
	return self.showSuperPurchaseRed
end

-- 超值礼包红点
function ActivityModel:setActSuperPurchaseRedTips(red)
	--每次登录显示红点，点开后取消红点
	self.showSuperPurchaseRed = red
end

function ActivityModel:checkActActDailyRechargeRedTips()
	local userData = self:getActivityCalendar(c.ACTIVITY_NAME.ActDailyRecharge).UserData
	local allReward = self:getActivityCalendar(c.ACTIVITY_NAME.ActDailyRecharge).Confs.actDailyBillFirst
    local canToken = userData.SumDiamond >= allReward[1].TotalCcy and #userData.TokenIds == 0
	return canToken
end

function ActivityModel:checkHasBuy(act,buyId)
	local buyCnt = act.UserData.BuyCnt
	if not buyCnt then
		return false
	end
	for _,v in ipairs(buyCnt) do
		if v.Id == buyId then
			return v.N
		end
	end
	return false
end

function ActivityModel:checkHasBuy2(act,buyId)
	local buyCnt = {}
	if not act.UserData.BuyCnt or #act.UserData.BuyCnt == 0 then
		return buyCnt
	end
	for k,v in ipairs(act.UserData.BuyCnt) do
		if dataId == v.Id then
			if not buyCnt[v.Id] then
				buyCnt[v.Id] = 0
			end
			buyCnt[v.Id] = buyCnt[v.Id] + v.N
			return buyCnt
		end
	end
	return buyCnt
end

function ActivityModel:TaskCntEnough(act,data)
    local condCnt = act.UserData.CondCnt
    if not condCnt  then
    	return false
    end
    for _, v in ipairs(condCnt) do
		if v.CondId == data.CondId and v.P1 >= data.P1 then
    		if v.Val >= data.P2 then
    			-- print("v.CondId:",v.CondId)
    			-- print("v.P1:",v.P1)
    			-- print("data.P1:",data.P1)
    			-- print("v.Val:",v.Val)
    			-- print("data.P2:",data.P2)
    			-- print("=========================")
    			return true
    		end
    	end
    end
    return false
end

function ActivityModel:checkTaskTaken(act,id)
	local taskTaken = act.UserData.TaskTaken
	if not taskTaken or #taskTaken == 0 then
		return false
	end
	for i, id_ in ipairs(taskTaken) do
		if id_ == id then
			return true
		end
	end
end

function ActivityModel:checkSignTaken(act,day)
	local taken = act.UserData.SignTaken
	if not taken or #taken == 0 then
		return false
	end
	for i, day_ in ipairs(taken) do
		if day_ == day then
			return true
		end
	end
end

function ActivityModel:updateActivityBtn(actId)
	Helper.sendEvent("refreshActivity", {actId = actId})
end

return ActivityModel
