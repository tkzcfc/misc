--GuildModel
local guildBossConf = require "app.configs.guildBoss"

local GuildModel = class("GuildModel")

local BUILD_NAME = {
	shengong	= 101, -- 神宫
	wushifu		= 201, -- 武侍府
	yushouge	= 202, -- 御守阁

	renwusuo	= 301, -- 任务所
	qiyuange	= 302, -- 祈愿阁
	shenshe		= 303, -- 神社
	bingying	= 304, -- 兵营
	renzheting	= 305, -- 忍者厅
	baoku		= 306, -- 宝库
}

function GuildModel:ctor()
	self.row = {}
	self.exp = 0
	self.notice = nil
	self.mbs = {}
	self.bosses = {}
	self.monsterInfo = {}
	self.isInit = false

	------guildHome-------
	self.isInitBuild = false
	self.buildInfo = {}
	self.buildRes = {}
	self.dailyRewardInfo = nil
end

function GuildModel:initData(data)
	local data = data.Info
	self:reset()
	self.row = data.Row or {}
	self.exp = data.Exp or 0
	self.notice = data.Notice or ""
	self.mbs = data.Mbs or {}
	self:initBoss(data.Bosses)
	self:initGuildBuild(data.Build)
	self:initMonsterInfo(data.Monster)
	self.isInit = true
end

function GuildModel:initBoss(bosses)
	for _,boss in pairs(guildBossConf) do
		local initBoss = {}
		initBoss.Id = boss.Id
		initBoss.Status = 4 --lock
		for k,v in pairs(bosses) do
			if v.Id == initBoss.Id then
				initBoss = v
				break
			end
		end
		table.insert(self.bosses, initBoss)
	end

	table.sort(self.bosses, function(a,b)
		return a.Id < b.Id
	end)
end

function GuildModel:initMonsterInfo(data)
	self.monsterInfo = data
end

function GuildModel:reset()
	self.row = {}
	self.exp = 0
	self.notice = nil
	self.mbs = {}
	self.bosses = {}
	self.isInit = false
end
	
function GuildModel:guildJoin(data)
	if not self.isInit then return end
	if data.GuildId == self.row.Id then
		table.insert(self.mbs, data.Mb)
	end
end

function GuildModel:guildLeave(data)
	if not self.isInit then return end
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	if data.PId == PlayerModel.info.userId then
		self:reset()
	else
		for k,v in ipairs(self.mbs) do
			if v.Id == data.PId then
				table.remove(self.mbs,k)
				break
			end
		end
	end
end

function GuildModel:updateRank(data)
	if not self.isInit then return end
	for k,v in ipairs(self.mbs) do
		if v.Id == data.PId then
			v.Rank = data.Rank
			break
		end
	end
end

function GuildModel:updateLevel(data)
	if not self.isInit then return end
	if data.Level and data.Level > 0 then
		self.row.Lv = data.Level
	end
	if data.Exp then
		self.exp = data.Exp
	end
end

function GuildModel:updateSetting(data)
	if not self.isInit then return end
	self.row.Head = data.Head
	self.row.AMode = data.AMode
	self.row.NeedLv = data.NeedLv
	self.row.Notice = data.Notice
end

function GuildModel:bossUnlock(data)
	if not self.isInit then return end
	for k,v in ipairs(self.bosses) do
		if v.Id == data.One.Id then
			v.DonateCnt = data.One.DonateCnt
			v.Hp = data.One.Hp
			v.LastCDTs = data.One.LastCDTs
			v.MaxHp = data.One.MaxHp
			v.Status = data.One.Status
			break
		end
	end
end

function GuildModel:bossDonate(data)
	if not self.isInit then return end
	for k,v in ipairs(self.bosses) do
		if v.Id == data.Id then
			v.DonateCnt = data.DonateCnt
			break
		end
	end
end

function GuildModel:bossActAtk(data)
	if not self.isInit then return end
	for k,v in ipairs(self.bosses) do
		if v.Id == data.Id then
			v.Status = data.Status
			break
		end
	end
end

function GuildModel:bossFight(data)
	if not self.isInit then return end
	for k,v in ipairs(self.bosses) do
		if v.Id == data.Id then
			v.Hp = data.Hp
			v.DmgList = data.DmgList
			break
		end
	end
end

function GuildModel:bossDead(data)
	if not self.isInit then return end
	for k,v in ipairs(self.bosses) do
		if v.Id == data.Id then
			v.LastCDTs = data.LastCDTs
			v.DmgList = data.DmgList
			break
		end
	end
end

function GuildModel:bossRelive(data)
	if not self.isInit then return end
	for k,v in ipairs(self.bosses) do
		if v.Id == data.One.Id then
			v = data.One
			break
		end
	end
end

function GuildModel:changeSetting(data)
	if not self.isInit then return end
	self.row.AMode = data.AMode
	self.row.Head = data.Head
	if data.NeedLv then
		self.row.NeedLv = data.NeedLv
	end
	self.notice = data.Notice
end

function GuildModel:changeName(data)
	if not self.isInit then return end
	if data.Name then
		self.row.Name = data.Name
	end
end

function GuildModel:updateMyDonation(donation)
	local init = require "app.models.init"
	local PlayerModel = init.PlayerModel

	for k,v in ipairs(self.mbs) do
		if v.Id == PlayerModel.info.userId then
			v.Donation = donation
			break
		end
	end
end

-----------guildHome--------------
function GuildModel:initGuildBuild(data)
	self.isInitBuild = true
	self.buildInfo = data.Builds or {}
	self.buildRes = data.ResData or {}
	-- GuildPlrData
	local Helper = require "app.Helper"
	self.initGuildTime = Helper.getFixedTime()
	self.taskData = data.PlrData or {}
	self.giftData = data.Gift or {}
	-- dump(self.buildRes, "self.buildRes -------------")
end

function GuildModel:updateGuildRes(data)
	if not self.isInitBuild then return end
	for _,updateV in ipairs(data.Res) do
		local has = false
		for k,v in pairs(self.buildRes.Res or {}) do
			if v.Id == updateV.Id then
				v.N = v.N + updateV.N
				has = true
				break
			end
		end
		if not has then
			if not self.buildRes.Res then
				self.buildRes.Res = {}
			end
			table.insert(self.buildRes.Res, {Id = updateV.Id, N = updateV.N})
		end
	end
end

function GuildModel:updateBuildInfo(data)
	if not self.isInitBuild then return end
	for k,v in pairs(self.buildInfo) do
		if v.Id == data.One.Id then
			self.buildInfo[k] = data.One
			break
		end
	end
end

function GuildModel:getBuildInfoById(buildId)
	if not self.isInitBuild then return nil end

	for k,v in pairs(self.buildInfo) do
		if v.Id == buildId then
			return v
		end
	end
	
	return nil
end

function GuildModel:getBuildResNumById(resId)
	for k,v in ipairs(self.buildRes.Res or {}) do
		if v.Id == resId then
			return v.N
		end
	end
	return 0
end

-- 宝库转盘，如果中了某个则减1（排除第一个）
function GuildModel:reduceBuildResNumById(resId)
	for k,v in ipairs(self.buildRes.Res or {}) do
		if v.Id == resId then
			if v.N > 0 then
				v.N = v.N - 1
			end
		end
	end
end

--返回flagIndex, iconIndex
function GuildModel:getGuildHeadIndex(id)
	local guildHeadConf = require "app.configs.guildHead"
	local iconIndex = id%10000
    local flagIndex = id - iconIndex
    if flagIndex <= 0 or not guildHeadConf[flagIndex] then
        flagIndex = 10000
    end
    if not guildHeadConf[iconIndex] then
        iconIndex = 1
    end
    return flagIndex, iconIndex
end

function GuildModel:updateGuildInpire(data)
	self.monsterInfo.GldInsp = data.GldInsp
end

function GuildModel:updateGuildMonsterDmg(data)
	self.monsterInfo.GldDmg = data.GldDmg
end

function GuildModel:updatePlayerInpire(data)
	self.monsterInfo.PlrInsp = data.PlrInsp
end

function GuildModel:updateDailyRewardInfo(data)
	self.dailyRewardInfo = data
end

function GuildModel:getDailyRewardInfo()
	return self.dailyRewardInfo
end
-- 宝箱
function GuildModel:getGiftData()
	return self.giftData and self.giftData or {}
end

function GuildModel:updateGiftData(data)
	self.giftData = data
end

-- 英雄
function GuildModel:getNinjaHeroData()
	return self.ninjaHeroInfo
end

function GuildModel:updateNinjaHeroData(data)
	self.ninjaHeroData = data
end

function GuildModel:getTaskInfo()
	return self.taskData and self.taskData.Quests or {}
end

function GuildModel:updateTaskInfoById(idx, data)
	if type(data) == "table" then
		self.taskData.Quests[idx] = data
	elseif type(data) == "boolean" then
		self.taskData.Quests[idx].F = data
	end
end

function GuildModel:updateTaskInfo(data)
	self.taskData.Quests = data
end

function GuildModel:getBuildsNames()
	return BUILD_NAME
end

return GuildModel