local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local RichLabel = require "sandglass.ui.RichLabel"
local ui = require "sandglass.ui.ui"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"

local DanMuWin = class("DanMuWin", WinBase)
DanMuWin.RESOURCE_FILENAME = "chat/danMu.csb"

function DanMuWin:onCreate(callback, maxLength)
	self.priority = c.WIN_ZORDER.POPUP
    self.callback = callback
    self.maxLength = maxLength or 20
end

function DanMuWin:initialView()
	-- 关闭
	UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
		self:closeSelf()
	end)

    local imgBg = self.resourceNode_:getChildByName("Image_6")
    imgBg:setVisible(false)
    local inputSize = imgBg:getContentSize()
    local editLabel = RichLabel.new({
        fontColor = CoreColor.WHITE,
        fontSize = 20,
        charSpace = 1,
        maxWidth = inputSize.width-20
    })
    editLabel.text = ""
    editLabel:setString("")
    display.align(editLabel, display.LEFT_TOP, 10, inputSize.height-10)
    self.resourceNode_:getChildByName("node_edit"):addChild(editLabel, 3)

    local signatureEditLb = ui.newEditBox({
        size = cc.size(inputSize.width,inputSize.height),
        image = "public/tongyong-shurukuang.png",
    })
    signatureEditLb:setFontSize(20)
    signatureEditLb:setPlaceholderFontSize(20)
    signatureEditLb:setPlaceHolder(string.format(WordDictionary[22710], self.maxLength))
    signatureEditLb:setPlaceholderFontColor(cc.c3b(67,53,41))
    display.align(signatureEditLb,display.LEFT_TOP, 0, inputSize.height)
    signatureEditLb:setInputMode(cc.EDITBOX_INPUT_MODE_ANY)--单行
    
    signatureEditLb:setText("")
    signatureEditLb:setInputFlag(cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_WORD)
    signatureEditLb:setMaxLength(self.maxLength)
    self.resourceNode_:getChildByName("node_edit"):addChild(signatureEditLb)
    
    signatureEditLb:registerScriptEditBoxHandler(function (strEventName,pSender)
        if strEventName == "open" then
            signatureEditLb:setText(editLabel.text)
            editLabel:setString("")
            editLabel.text = ""
        elseif strEventName == "ended" then
            local text = signatureEditLb:getText()
            text = string.trim(text)
            text = string.gsub(text, "[\r\n\t]+", "")
            editLabel:setString(Helper.convertStringToExpression(text))
            editLabel.text = text
            signatureEditLb:setText("")
            if string.len(text) > 0 then
                signatureEditLb:setPlaceHolder("")
            else
                signatureEditLb:setPlaceHolder(string.format(WordDictionary[22710], self.maxLength))
            end
        end
    end)

    --表情
    UIImageBox.new(self.resourceNode_:getChildByName('btn_emotion'),function()
        self:openWin("DanMuEmotionWin",function(str)
            local text = editLabel.text .. str
            if string.utf8len(text) > self.maxLength then
                text = string.utf8sub(text, 1, self.maxLength)
            end
            editLabel:setString(Helper.convertStringToExpression(text))
            editLabel.text = text
        end)
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_ok"), function()
        Helper.checkFilterTextBySDK(editLabel.text, function(result, newText)
            if result then
                if self.callback then
                    self.callback(newText)
                end
                self:closeSelf()
            else
                MoveLabel.new(WordDictionary[22208])
            end
        end)
    end)
end


function DanMuWin:getActionIn()
    Helper.enterWinAction1(self)
end

return DanMuWin