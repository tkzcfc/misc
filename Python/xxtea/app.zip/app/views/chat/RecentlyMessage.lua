--
-- Author: hexianxiong
-- Date: 2018-04-20 11:59:48
--
local c = require "app.configs.constants"
local init = require "app.models.init"
local RichLabel = require "sandglass.ui.RichLabel"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local WordDictionary = require "app.configs.WordDictionary"
local RichLabel = require "sandglass.ui.RichLabel"
local royalFightJobConf = require"app.configs.royalFightJob"
local forceLeaderShowConf = require"app.configs.forceLeaderShow"

local ChatModel = init.ChatModel

local RecentlyMessage = class("RecentlyMessage")

function RecentlyMessage:ctor(layer_chat)
	self.layer_chat = layer_chat
end

function RecentlyMessage:updateRecentlyMessage()
	local maxWidth = 350
  local data = ChatModel:getRecentlyMessage()

  self.layer_chat:setOpacity(255)  
  if not data then
    self.layer_chat:setVisible(false)
    return
  else
   self.layer_chat:setVisible(true)
 end

 local job = nil
 if data.SendPlr.RoyalRank and royalFightJobConf[data.SendPlr.RoyalRank] then
  job = data.SendPlr.RoyalRank
end
local leader = nil
if data.SendPlr.Camp and forceLeaderShowConf[data.SendPlr.Camp] then
     leader = data.SendPlr.Camp
end

local img_job = self.layer_chat:getChildByName("img_job")
local txt_job = self.layer_chat:getChildByName("txt_job")
local img_leader = self.layer_chat:getChildByName("img_leader")
local desBg = self.layer_chat:getChildByName("img_content")
local panel = self.layer_chat:getChildByName("panel")
local txt_content =  panel:getChildByName("txt_content")
local txt_name =  self.layer_chat:getChildByName("txt_name")
local txt_vip = self.layer_chat:getChildByName("txt_vip")

txt_vip:setString(WordDictionary[22706]..data.SendPlr.Vip)

--官衔
img_job:setVisible(job ~= nil)
txt_job:setVisible(job ~= nil)
if job then
  txt_job:setString(royalFightJobConf[job].job)
  img_job:loadTexture("chat/"..royalFightJobConf[job].talkPic..".png",ccui.TextureResType.plistType)
end
----势力领袖
img_leader:setVisible(leader ~= nil)
if leader then
    img_leader:getChildByName("txt_leader"):setString(forceLeaderShowConf[leader].job)
    img_leader:loadTexture("chat/"..forceLeaderShowConf[leader].talkPic..".png",ccui.TextureResType.plistType)
end

txt_name:setVisible(false)
local nameStr = ""
local patternStr = "<div fontname='%s' fontsize=18 fontcolor=#64e8ec outline=1,#000000>[%s]</div><div fontname='%s' fontsize=18 fontcolor=#ffffff outline=1,#000000>%s</div>"
if data.ChatType == 0 then
 local unionName = WordDictionary[21203]
 if data.SendPlr.GName and data.SendPlr.GName ~= "" then
  unionName = data.SendPlr.GName
end
nameStr = string.format(patternStr,c.NORMALFONT,unionName,c.NORMALFONT,data.SendPlr.Name)
else
 local gRank = data.SendPlr.GRank
 local gRandStr = WordDictionary[21450]
 if gRank == c.GUILD_RK.owner then
   gRandStr = WordDictionary[21448]
 elseif gRank == c.GUILD_RK.vice then
   gRandStr = WordDictionary[21449]
 else
   gRandStr = WordDictionary[21450]
 end
 nameStr = string.format(patternStr,c.NORMALFONT,gRandStr,c.NORMALFONT,data.SendPlr.Name)
end
if self.layer_chat:getChildByName("nameLable") then
 self.layer_chat:getChildByName("nameLable"):setString(nameStr)
else
 local nameLable = RichLabel.new({
  fontSize = 18,
  maxWidth = maxWidth,
})
 nameLable:setString(nameStr)
 nameLable:setName("nameLable")
 display.align(nameLable, display.TOP_LEFT, txt_name:getPositionX(), txt_name:getPositionY())
 self.layer_chat:addChild(nameLable)
end
if not job then
     img_leader:setPositionX(img_job:getPositionX())
end
local offset = (job and img_job:getContentSize().width or 0) + (leader and img_leader:getContentSize().width or 0)
self.layer_chat:getChildByName("nameLable"):setPositionX(txt_name:getPositionX() + offset)

local txt_size = 14 
txt_content:setVisible(false)
if panel:getChildByName("editLabel") then
 panel:removeChildByName("editLabel")
end
local editLabel = RichLabel.new({
  fontColor = CoreColor.WHITE,
  fontSize = txt_size,
  maxWidth = maxWidth,
  lineSpace = 10,
})

local str = data.Content

editLabel:setString(Helper.convertStringToExpression(str,"#030000",txt_size,0.5))
editLabel:setName("editLabel")
display.align(editLabel, display.TOP_LEFT, txt_content:getPositionX(), txt_content:getPositionY())
panel:addChild(editLabel)
local size = editLabel:getContentSize()

local desId = "1"
if leader then
  desId = tostring(forceLeaderShowConf[leader].talkFrame) 
elseif job then 
  desId = tostring(royalFightJobConf[job].talkFrame) 
end
desBg:loadTexture("chat/"..desId..".png",ccui.TextureResType.plistType)

local rect = desBg:getContentSize()
rect.height = rect.height
rect.width = size.width + 50
desBg:setContentSize(rect)

self.layer_chat:runAction(cc.Sequence:create(
  cc.DelayTime:create(5),
  cc.FadeOut:create(0.5),
  cc.CallFunc:create(function()
    self.layer_chat:setVisible(false)
  end)
  ))

end
return RecentlyMessage