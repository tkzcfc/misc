local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UILabel = require "sandglass.ui.UILabel"
local RichLabel = require "sandglass.ui.RichLabel"
local WordDictionary = require "app.configs.WordDictionary"
local MoveLabel = require "sandglass.ui.MoveLabel"
local CoreColor = require "sandglass.core.CoreColor"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local ui = require "sandglass.ui.ui"
local c = require "app.configs.constants"
local itemConf = require "app.configs.item"
local globalPublicConf = require "app.configs.globalPublic"

local init = require "app.models.init"
local ItemModel = init.ItemModel
local PlayerModel = init.PlayerModel

local SendTrumpetWin = class("SendTrumpetWin", WinBase)

SendTrumpetWin.RESOURCE_FILENAME = "chat/sendTrumpet.csb"

local SendTimeLimit = 10
local ChatType = {
	World = 0,
	Union = 1,
}
function SendTrumpetWin:onCreate()
    self.priority = c.WIN_ZORDER.PERMANENT
	self.lastSendTime = 0
	local msgList = {
		msgids.GS_ChatSendMsg_R,
        msgids.GS_ItemExchange_R,
	}
	network.addListener(self, msgList, handler(self, self.messageHandler))
end

function SendTrumpetWin:messageHandler(op,data)
	if op == msgids.GS_ChatSendMsg_R then
		self:closeSelf()
    elseif op == msgids.GS_ItemExchange_R then
        local num = Helper.getItemOrCurrencyCnt(self.itemId)
        self.resourceNode_:getChildByName('txt_content'):setString(num.."/1")
        MoveLabel.new(WordDictionary[21613])
	end
end

function SendTrumpetWin:initialView()
    self:setAutoClose(self.resourceNode_:getChildByName("bg"))
    self.itemId = 30126
	local maxLength = 50
    local num = Helper.getItemOrCurrencyCnt(self.itemId)
    self.resourceNode_:getChildByName('txt_content'):setString(num.."/1")
    self.resourceNode_:getChildByName('txt_word'):setString("0/"..maxLength)
	--表情
	UIImageBox.new(self.resourceNode_:getChildByName('btn_emotion'),function()
		local win = self:openWin("EmotionWin",function(str)
			local text = self.editLb.text .. str
            if string.utf8len(text) > maxLength then
                text = string.utf8sub(text, 1, maxLength)
            end
            self.editLb:setString(Helper.convertStringToExpression(text))
            self.editLb.text = text
		end)
	end)

	--发送
	UIImageBox.new(self.resourceNode_:getChildByName('btn_2'),function()
        if PlayerModel.info.vip >= globalPublicConf[1].trumpetVipLevel then
            self:sendMessage()
        else
            MoveLabel.new(string.format(WordDictionary[22709], globalPublicConf[1].trumpetVipLevel))
        end
	end)

    UIImageBox.new(self.resourceNode_:getChildByName('btn_add'),function()
        local currency, price = Helper.getExchangeItemCurrencyAndPirce(self.itemId)
        local myCurrency = Helper.getItemOrCurrencyCnt(currency)
        local data = {
            maxNum = math.floor(myCurrency/price),
            price = price,
            costId = currency,
        }
        self:openWin("BuyItemWin",data, function(number)
            if number and number > 0 then
                if Helper.getOpenState(17) then
                    local data_ = {{
                        Id = self.itemId,
                        N = number,
                    },}
                    network.tcpSend(msgids.C_ItemExchange, {ObjFrom = "LiaoTian", Items = data_})
                end
            end
        end)
    end)

	self.panel_input = self.resourceNode_:getChildByName('panel_input')
	local panel_view = self.panel_input:getChildByName("panel_view")
    local inputSize = self.panel_input:getContentSize()
    local editLabel = RichLabel.new({
        fontColor = CoreColor.WHITE,
        fontSize = 20,
        charSpace = 1,
        maxWidth = inputSize.width,
    })
    display.align(editLabel, display.LEFT_CENTER, 0, inputSize.height / 2)
    panel_view:addChild(editLabel)
    panel_view:setLocalZOrder(3)
    editLabel.text = ""

    local signatureEditLb = ui.newEditBox({
        size = cc.size(inputSize.width,inputSize.height),
        image = "public/public_slat_09.png",
    })
    display.align(signatureEditLb,display.LEFT_CENTER,0,inputSize.height / 2)
    signatureEditLb:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)--单行
    signatureEditLb:setInputFlag(cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_WORD)
    signatureEditLb:setPlaceHolder("")
    signatureEditLb:setFont(c.NORMALFONT, 20)
    signatureEditLb:setMaxLength(maxLength)
    signatureEditLb:setText("")


    self.panel_input:addChild(signatureEditLb,0)
    self.editLb = editLabel
    self.editBox = signatureEditLb

    signatureEditLb:registerScriptEditBoxHandler(function (strEventName,pSender)
        if strEventName == "open" then
        	self.isInput = true
            signatureEditLb:setText(editLabel.text)
            editLabel:setString("")
            editLabel.text = ""
        elseif strEventName == "ended" then
            local text = signatureEditLb:getText()
            text = string.trim(text)
            text = string.gsub(text, "[\r\n\t]+", "")
            editLabel:setString(Helper.convertStringToExpression(text))
            editLabel.text = text
            signatureEditLb:setText("")

            local _,count = string.gsub(text, "[^\128-\193]", "")
            self.resourceNode_:getChildByName('txt_word'):setString(count.."/"..maxLength)
        end
    end)
end

function SendTrumpetWin:sendMessage()
    local text = self.editLb.text
    if string.len(text) <= 0 then
        return
    end
    if self.lastMessage == text then
        MoveLabel.new(WordDictionary[22704])
        return
    end
    local curTime = Helper.getFixedTime()
    local cd = curTime - self.lastSendTime
    if cd < SendTimeLimit then
        MoveLabel.new(string.format(WordDictionary[22705], SendTimeLimit - cd))
        return
    end

    Helper.checkFilterTextBySDK(self.editLb.text, function(result, newText)
        if result then
            self.lastSendTime = curTime
            self.lastMessage = self.editLb.text
            network.tcpSend(msgids.C_ChatSendMsg,{ChatType=ChatType.World,Content=newText,IsTrumpet=true})
            self.editLb:setString("")
            self.editLb.text = ""
        else
            MoveLabel.new(WordDictionary[22208])
        end
    end)
end

return SendTrumpetWin


