--
-- Author: hexianxiong
-- Date: 2018-01-25 15:15:06
--
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local RichLabel = require "sandglass.ui.RichLabel"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local MoveLabel = require "sandglass.ui.MoveLabel"
local init = require "app.models.init"
local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local CoreColor = require "sandglass.core.CoreColor"
local ui = require "sandglass.ui.ui"
local royalFightJobConf = require"app.configs.royalFightJob"
local forceLeaderShowConf = require"app.configs.forceLeaderShow"

local PlayerModel = init.PlayerModel

local ChatSystemItem = class("ChatSystemItem", function ()
    return cc.Node:create()
end)

function ChatSystemItem.create(info)
    return ChatSystemItem.new(info)
end

function ChatSystemItem:ctor(info)
    self.info = info
    self:createTalk(info)
end

function ChatSystemItem:createTalk(info)
    local fileName = "chat/chatSystemItem.csb"
    local node = cc.CSLoader:createNode(fileName)
    local panel_bg = node:getChildByName('panel_bg')
    self:addChild(node)

    local high = 10
    local maxWidth = 370

    local desBg = panel_bg:getChildByName("img_content")
    local txt_content =  panel_bg:getChildByName("txt_content")
    local txt_time =  panel_bg:getChildByName("txt_time")
    txt_time:setString(os.date("%H:%M",info.Ts))
    txt_content:setVisible(false)
    local editLabel = RichLabel.new({
        fontColor = cc.c3b(236,225,204),
        fontSize = 18,
        maxWidth = maxWidth,
    })
    editLabel:setString(info.Content)
    panel_bg:addChild(editLabel)
    local size = editLabel:getContentSize()
    local x = txt_content:getPositionX()
    display.align(editLabel, display.TOP_LEFT, x, txt_content:getPositionY())
    high = size.height + high + 10

    local desBg = panel_bg:getChildByName("img_content")
    local rect = desBg:getContentSize()
    rect.height = high
    rect.width = size.width + 50
    desBg:setContentSize(rect)

    self.height = 20 + high
end

function ChatSystemItem:getHeight()
    return self.height
end

return ChatSystemItem
