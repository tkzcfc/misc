local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UILabel = require "sandglass.ui.UILabel"
local RichLabel = require "sandglass.ui.RichLabel"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local C = require "app.network.enums"
local MoveLabel = require "sandglass.ui.MoveLabel"
local init = require "app.models.init"
local Helper = require "app.Helper"
local CoreColor = require "sandglass.core.CoreColor"
local SpineManager = require "sandglass.core.SpineManager"
local UIAniButton = require "sandglass.ui.UIAniButton"
local emotionConf = require "app.configs.emotion"
local ui = require "sandglass.ui.ui"
local PlayerModel = init.PlayerModel

local DanMuEmotionWin = class("DanMuEmotionWin", WinBase)

DanMuEmotionWin.RESOURCE_FILENAME = "chat/emotion.csb"

function DanMuEmotionWin:onCreate(callback)
    self.priority = c.WIN_ZORDER.POPUP
    
	self.callback = callback
	self.shieldLayer_:setVisible(false)
    
end

function DanMuEmotionWin:initialView()
    self.resourceNode_:getChildByName("panel_emotion"):setPosition(390, 5)
	local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
    self.resourceNode_:runAction(moveAction)
    moveAction:play("animation0", false)
	local panel_emotion = self.resourceNode_:getChildByName('panel_emotion')
	local node_emotion = panel_emotion:getChildByName('node_emotion')
	local size = panel_emotion:getContentSize()
	local gridX = (size.width/6-2)
	local gridY = (size.height/4-4)
	local startX = -2.5 * gridX
	local startY = 1.5 * gridY
	local row = 1
	local col = 1
	for i = 1, #emotionConf do
		local emotionConfData = emotionConf[i]
		local action = emotionConfData.idle
		local code = emotionConfData.code
    	local btn = UIAniButton.new("public/ui_biaoqingcangshu", function (eventType)
    		if eventType == "ended" and self.callback then
    			self.callback(code)
    			self:closeSelf()
    		end
    	end,{idle=action,skin=""})
    	local x = startX + (col-1)* gridX
    	local y = startY + (row-1)* gridY
    	col = col + 1
    	if col % 7 == 0 then
    		col = 1
    		row = row - 1
    	end
    	btn:setPosition(x,y)
     	btn:setAnchorPoint(0.5, 0.5)
        node_emotion:addChild(btn)
    end
	self:setAutoClose(panel_emotion)
end

return DanMuEmotionWin