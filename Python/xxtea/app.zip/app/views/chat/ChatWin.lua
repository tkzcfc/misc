--
-- Author: hexianxiong
-- Date: 2018-01-24 15:28:27
--
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UILabel = require "sandglass.ui.UILabel"
local RichLabel = require "sandglass.ui.RichLabel"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local MoveLabel = require "sandglass.ui.MoveLabel"
local init = require "app.models.init"
local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local CoreColor = require "sandglass.core.CoreColor"
local ui = require "sandglass.ui.ui"
local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local ChatModel = init.ChatModel
local FamilyModel = init.FamilyModel

local ChatItem = require "app.views.chat.ChatItem"
local ChatSystemItem = require "app.views.chat.ChatSystemItem"
local globalPublicConf = require "app.configs.globalPublic"
local PlayerConfig = require "sandglass.core.PlayerConfig"

local ChatWin = class("ChatWin", WinBase)

ChatWin.RESOURCE_FILENAME = "chat/chat.csb"

local SendTimeLimit = 10
local SendWorldTimeLimit = 1
local MaxItemCount = 50
local HistoryCount = 5
local ChatType = {
	World = 0,
	Union = 1,
    UnionInvite = 3,
}

function ChatWin:onCreate()
    self.priority = c.WIN_ZORDER.PERMANENT
	self.lastSendTime = PlayerConfig.getSetting("lastSendTime", 0)
    self.lastSendWorldTime = PlayerConfig.getSetting("lastSendWorldTime", 0)
	self.lockTalk = false
	self.nextTime = {}
	self.prevTime = {}
	local msgList = {
        msgids.GS_ChatMsg,
        msgids.GS_ChatSendMsg_R,
        msgids.GS_PlayerInfo_R,
        msgids.GS_GulidInviteRecruit_R, 
        msgids.GS_GuildApply_R,
        msgids.GS_GuildInfoFull_R,
        msgids.GS_BagUpdate,
        msgids.GS_GuildDestroy_R,
	}
	network.addListener(self, msgList, handler(self, self.messageHandler))
    self.curSelectItemData = nil--当前选择的Item数据

    self.lastMessage = {}
    self.recordMessageCnt = 5
    self.checkTextLenth = 30
    self.repeatCnt = 0
    self.repeatCntLimit = 5

    local vipLevel = PlayerModel.info.vip
    if vipLevel == 0 then
        vipLevel = 1
    end
    SendTimeLimit = globalPublicConf[1].guildChatCD[vipLevel]
    SendWorldTimeLimit = globalPublicConf[1].wordChatCD[vipLevel]
end

function ChatWin:messageHandler(op,data)
	if op == msgids.GS_ChatMsg or op == msgids.GS_ChatSendMsg_R then
		if self:isVisible() then
			self:refreshRedTips()
			local data = ChatModel:getNextMessage(self.channel)
			if data then
				self:addMessage(data,true)
			end
		end
    elseif op == msgids.GS_PlayerInfo_R then
        if self.isShow then
            local info = data.Info
            for key,val in pairs(self.curSelectItemData or {}) do
                info[key] = val
            end
            self:openWin("PlayerInfoWin",info)
        end
    elseif op == msgids.GS_GulidInviteRecruit_R then
        if self.isShow then 
            MoveLabel.new(WordDictionary[23727])
            self:updateGuildInvite()
        end
    elseif op == msgids.GS_GuildApply_R then
        if self.isShow then 
            if data.ErrorCode == 0 then
                MoveLabel.new(WordDictionary[23729])
            end
        end
    elseif  op == msgids.GS_GuildInfoFull_R then
        if self.isShow then 
            self:openWin("FamilyLandWin")
            self:hide()
        end
    elseif op == msgids.GS_BagUpdate then
        if self.isShow then 
            self:updateGuildInvite()
        end
    elseif op == msgids.GS_GuildDestroy_R then
        self:updateGuildInvite()
	end
end

function ChatWin:refreshRedTips()
    local btns = {
        [1] = {cType = 0, btnName = "page_1"},
        [2] = {cType = 1, btnName = "page_2"},
        [3] = {cType = 3, btnName = "page_3"},
    }
	local panel_bg = self.resourceNode_:getChildByName('panel_bg')
    for i,v in ipairs(btns) do
        local btn = panel_bg:getChildByName(v.btnName)
        if self.channel == v.cType then
            RedTipsModel:removeRedTip(btn)
        else
            if ChatModel:haveMessage(v.cType) then
                RedTipsModel:addRedTip(btn, cc.p(55, 80))
            else
                RedTipsModel:removeRedTip(btn)
            end
        end
    end
end

function ChatWin:initialView()
	local maxLength = 50
	local panel_bg = self.resourceNode_:getChildByName('panel_bg')
	local worldList = panel_bg:getChildByName('scroll_world')
    worldList:setScrollBarWidth(8)
    worldList:setScrollBarColor(cc.c3b(225,213,199))
    worldList:setScrollBarPositionFromCornerForVertical(cc.p(12,20))
    worldList:onEvent(handler(self, self.onScroll))
    worldList.lastY = worldList:getInnerContainerSize().height
    self.worldList = worldList
    self.worldItemList = {}

    local unionList = panel_bg:getChildByName('scroll_union')
    unionList:setScrollBarWidth(8)
    unionList:setScrollBarColor(cc.c3b(225,213,199))
    unionList:setScrollBarPositionFromCornerForVertical(cc.p(12,20))
    unionList:onEvent(handler(self, self.onScroll))
    unionList.lastY = unionList:getInnerContainerSize().height
    self.unionList = unionList
    self.unionItemList = {}

    local inviteList = panel_bg:getChildByName('scroll_invite')
    inviteList:setScrollBarWidth(8)
    inviteList:setScrollBarColor(cc.c3b(225,213,199))
    inviteList:setScrollBarPositionFromCornerForVertical(cc.p(12,20))
    inviteList:onEvent(handler(self, self.onScroll))
    inviteList.lastY = inviteList:getInnerContainerSize().height
    self.inviteList = inviteList
    self.inviteItemList = {}

	UIImageBox.new(panel_bg:getChildByName('page_1'),function()
		self:onChangeChannel(ChatType.World)
		end,{playEffect = "ui_button1.mp3"})
	UIImageBox.new(panel_bg:getChildByName('page_2'),function()
		if FamilyModel:getFamilyId() == "" then
			MoveLabel.new(WordDictionary[22701])
			return
		end
		self:onChangeChannel(ChatType.Union)
	end,{playEffect = "ui_button1.mp3"})

    UIImageBox.new(panel_bg:getChildByName('page_3'),function()
        self:onChangeChannel(ChatType.UnionInvite)
    end,{playEffect = "ui_button1.mp3"})

	--表情
	UIImageBox.new(panel_bg:getChildByName('node_chat'):getChildByName('btn_emotion'),function()
		self:openWin("EmotionWin",function(str)
			local text = self.editLb.text .. str
            if string.utf8len(text) > maxLength then
                text = string.utf8sub(text, 1, maxLength)
            end
            self.editLb:setString(self:convertStringToExpression(text))
            self.editLb.text = text
			end)
		end)

	--发送
	UIImageBox.new(panel_bg:getChildByName("node_chat"):getChildByName('btn_send'),function()
		self:sendMessage()
		end)

    --发送弹幕
    UIImageBox.new(panel_bg:getChildByName("node_chat"):getChildByName('btn_trumpet'),function()
        self:openWin("SendTrumpetWin")
    end)

	--锁屏
	UIImageBox.new(panel_bg:getChildByName('btn_lock'),function()
		self:setLock(not self.lockTalk)
	end)

	self.panel_input = panel_bg:getChildByName('node_chat'):getChildByName("panel_input")
	local panel_view = self.panel_input:getChildByName("panel_view")
    local inputSize = self.panel_input:getContentSize()
    local editLabel = RichLabel.new({
        fontColor = cc.c3b(235,219,193),
        fontSize = 20,
        charSpace = 1,
    })
    display.align(editLabel, display.LEFT_CENTER, 0, inputSize.height / 2)
    panel_view:addChild(editLabel)
    panel_view:setLocalZOrder(3)
    editLabel.text = ""

    local signatureEditLb = ui.newEditBox({
        size = cc.size(inputSize.width,inputSize.height),
        image = "chat/liaotian-zidi2.png",
    })
    display.align(signatureEditLb,display.LEFT_CENTER,0,inputSize.height / 2)
    signatureEditLb:setInputFlag(cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_WORD)
    signatureEditLb:setPlaceHolder("")
    signatureEditLb:setFont(c.NORMALFONT, 20)
    signatureEditLb:setMaxLength(maxLength)
    signatureEditLb:setText("")
    signatureEditLb:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)--单行

    self.panel_input:addChild(signatureEditLb,0)
    self.editLb = editLabel
    self.editBox = signatureEditLb

    signatureEditLb:registerScriptEditBoxHandler(function (strEventName,pSender)
        if strEventName == "open" then
        	self.isInput = true
            signatureEditLb:setText(editLabel.text)
            editLabel:setString("")
            editLabel.text = ""
        elseif strEventName == "ended" then
            local text = signatureEditLb:getText()
            text = string.trim(text)
            text = string.gsub(text, "[\r\n\t]+", "")
            editLabel:setString(self:convertStringToExpression(text))
            editLabel.text = text
            signatureEditLb:setText("")
        end
    end)
    ChatModel:resetMessage()
	self:onChangeChannel(ChatType.World)
	self:show()
    self:updateGuildInvite()
end

function ChatWin:checkPlayerLevel()
    local lv = PlayerModel.info.level or 1
    if PlayerModel.info.vip < globalPublicConf[1].chatVip and lv < globalPublicConf[1].chatLevel then
        --self.editBox:setPlaceHolder(string.format(WordDictionary[22708], globalPublicConf[1].chatLevel))
        self.editBox:setEnabled(false)
        self.resourceNode_:getChildByName('panel_bg'):getChildByName("node_chat"):getChildByName("btn_emotion"):setEnabled(false)
        self.resourceNode_:getChildByName('panel_bg'):getChildByName("node_chat"):getChildByName("btn_send"):setEnabled(false)

        local tipsLabel = RichLabel.new({
            fontSize = 18,
            maxWidth = maxWidth,
        })
        tipsLabel:setString(string.format(WordDictionary[22708], globalPublicConf[1].chatLevel))
        local panel_bg = self.resourceNode_:getChildByName('panel_bg')
        local img_tips = panel_bg:getChildByName("node_chat"):getChildByName("img_tips")
        img_tips:addChild(tipsLabel)
        tipsLabel:setAnchorPoint(display.CENTER)
        tipsLabel:setPosition(img_tips:getContentSize().width*0.5,img_tips:getContentSize().height*0.5)


    else
        self.resourceNode_:getChildByName('panel_bg'):getChildByName("node_chat"):getChildByName("img_tips"):setVisible(false)
        self.editBox:setPlaceHolder("")
        self.editBox:setEnabled(true)
        self.resourceNode_:getChildByName('panel_bg'):getChildByName("node_chat"):getChildByName("btn_emotion"):setEnabled(true)
        self.resourceNode_:getChildByName('panel_bg'):getChildByName("node_chat"):getChildByName("btn_send"):setEnabled(true)
    end
end

function ChatWin:onScroll(event)
    if event.name == "SCROLL_TO_TOP" 
        or event.name == "SCROLL_TO_BOTTOM" 
        or event.name == "BOUNCE_TOP" 
        or event.name == "BOUNCE_BOTTOM" 
        or event.name == "SCROLLING" then
        local list = event.target
        local curOffset = list:getInnerContainerPosition()
        if curOffset.y < -30 then
        	self:setLock(true)
        else
        	self:setLock(false)
        end
    end
    if event.name == "SCROLL_TO_TOP" then
        local list = event.target
        local curOffset = list:getInnerContainerPosition()
        if curOffset.y+list:getInnerContainerSize().height-list:getContentSize().height > -15 then
            return
        end
        local panel_bg = self.resourceNode_:getChildByName('panel_bg')
        if panel_bg:getActionByTag(0x12) then
            return
        end
    	if self.prevCount and self.prevCount > 0 then
    		return
    	end
        if ChatModel:havePrevMessage(self.channel) == false then
            MoveLabel.new(WordDictionary[22707])
            return
        end
        local action = cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(function()end))
        action:setTag(0x12)
        panel_bg:runAction(action)
    	Helper.lockWindow(true)
    	self.prevCount = HistoryCount
    	self:startLoadPrevMsg()
    end
end

function ChatWin:startLoadPrevMsg()
	for i = 1, self.prevCount do
		local data = ChatModel:getPrevMessage(self.channel)
		if not data then
			break
		end
		self:addMessage(data)
	end
	self.prevCount = 0
	Helper.unlockWindow()
end

function ChatWin:setLock(lock)
	self.lockTalk = lock
	local panel_bg = self.resourceNode_:getChildByName('panel_bg')
	local btn_lock = panel_bg:getChildByName('btn_lock')
	if self.lockTalk then
		btn_lock:loadTexture("chat/liaotian-suopin1.png",ccui.TextureResType.plistType)
	else
		btn_lock:loadTexture("chat/liaotian-suopin2.png",ccui.TextureResType.plistType)
	end
end

-- 界面选择
function ChatWin:onChangeChannel(channel)
    if self.channel == channel then
        return
    end
    self:getHistoryMsg()
    self.channel = channel
    self:refreshRedTips()

    local selectPage = 0
    local showInput = true
    if channel == ChatType.World then
        self.worldList:setVisible(true)
        self.unionList:setVisible(false)
        self.inviteList:setVisible(false)
        selectPage = 1
    elseif channel == ChatType.Union then
        self.unionList:setVisible(true)
        self.worldList:setVisible(false)
        self.inviteList:setVisible(false)
        selectPage = 2
    elseif channel == ChatType.UnionInvite then
        self.unionList:setVisible(false)
        self.worldList:setVisible(false)
        self.inviteList:setVisible(true)
        selectPage = 3
        showInput = false
    end

    local panel_bg = self.resourceNode_:getChildByName("panel_bg")
    panel_bg:getChildByName("node_chat"):setVisible(showInput)
    self:updateGuildInvite()

    local page_1 = panel_bg:getChildByName("page_1")
    local page_2 = panel_bg:getChildByName("page_2")
    local txt_title_1 = page_1:getChildByName("txt_title")
    local txt_title_2 = page_2:getChildByName("txt_title")

    local p1 = "public/anniu_fenye_xuanzhong.png"
    local p2 = "public/anniu_fenye.png"

    local c1 = cc.c3b(77,77,77)
    local c2 = cc.c3b(235,215,188)
    
    for i=1,3 do
        local page = panel_bg:getChildByName("page_"..i)
        local txt_title = page:getChildByName("txt_title")
        if i == selectPage then
            page:loadTexture(p1, ccui.TextureResType.plistType)
            -- txt_title:setTextColor(c1)
        else
            page:loadTexture(p2, ccui.TextureResType.plistType)
            -- txt_title:setTextColor(c2)
        end
    end

end

function ChatWin:show()
	if self.isAction then
		return
	end
	self.isAction = true
    local panel_bg = self.resourceNode_:getChildByName("panel_bg")
    panel_bg:setPositionX(-panel_bg:getContentSize().width - 20)
    local action = cc.Sequence:create(
        cc.EaseSineIn:create(cc.MoveTo:create(0.3, cc.p(0, display.height))),
        cc.CallFunc:create(function()
            self.isAction = false
        end)
    )
    panel_bg:runAction(action)

    self:setAutoClose(self.resourceNode_:getChildByName("panel_bg"),function()
    	if self.isInput then
    		self.isInput = false
    		return
    	end
		self:hide()
	end)
    self:setTouchListenerEnable(true)
    self.shieldLayer_:setVisible(true)
    self.isShow = true
    self:setVisible(true)
   	self:getHistoryMsg()
	self:refreshRedTips()

    self:checkPlayerLevel()
end

function ChatWin:getHistoryMsg()
	if self.resourceNode_:getActionByTag(0x11) then
		return
	end
	 self.resourceNode_:actionScheduleInterval(function()
		local data = ChatModel:getNextMessage(self.channel)
		if data then
			self:addMessage(data,true)
		else
			self.resourceNode_:stopActionByTag(0x11)
		end
	end,0.1,0x11)
end

function ChatWin:hide()
	if self.isAction then
		return
	end
	self.isAction = true
    local panel_bg = self.resourceNode_:getChildByName("panel_bg")
    local action = cc.Sequence:create(
        cc.EaseSineIn:create(cc.MoveTo:create(0.1, cc.p(-panel_bg:getContentSize().width - 20, display.height))),
        cc.CallFunc:create(function()
            local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
            eventDispatcher:removeEventListenersForTarget(setPositionX)
            self:setTouchListenerEnable(false)
            -- moveAction:clearFrameEndCallFuncs()
            self.shieldLayer_:setVisible(false)
            self:setVisible(false)
            self.isAction = false
        end)
    )
    panel_bg:runAction(action)

	-- local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
 --    self.resourceNode_:runAction(moveAction)
 --    moveAction:setAnimationEndCallFunc("animation1",function()
    	
 --    end)
    self:clear(0)
    self:clear(1)
    -- moveAction:play("animation1", false)
    self:setLock(false)
    RedTipsModel:refreshChatTips()
   	self.resourceNode_:stopActionByTag(0x11)
    self.isShow = false
end

function ChatWin:clear(channel)
    local list = self.worldList
    local itemList = self.worldItemList
    if channel == ChatType.Union then
        list = self.unionList
        itemList = self.unionItemList
    end

    local size = list:getInnerContainerSize()
    while #itemList > MaxItemCount do
        local removeItem = itemList[1]
        local removeHeight = removeItem:getHeight()
        if removeItem then
            size.height = size.height - removeHeight
            removeItem:removeFromParent()
            table.remove(itemList, 1)
        end
    end
    list:setInnerContainerSize(size)

    list:jumpToBottom()
end

function ChatWin:convertStringToExpression(str)
	return Helper.convertStringToExpression(str)
end

function ChatWin:addMessage(_ChatData, isNext)
	local channel = _ChatData.ChatType
	local list = self.worldList
    local itemList = self.worldItemList
    local lastTime = self.nextTime[channel]
    if not isNext then
    	lastTime = self.prevTime[channel]
    end
    if channel == ChatType.Union then
        list = self.unionList
        itemList = self.unionItemList
    elseif channel == ChatType.UnionInvite then
        list = self.inviteList
        itemList = self.inviteItemList
    end
    local dateItem = nil
    local tempDate = os.date("*t", _ChatData.Ts)
	local tempTime = os.time({year=tempDate.year, month=tempDate.month, day=tempDate.day, hour=0})
    if (isNext and (lastTime == nil or tempTime > lastTime))
        or (not isNext and lastTime > tempTime) then
    	local nowDate = os.date("*t", Helper.getFixedTime())
    	local nowTime = os.time({year=nowDate.year, month=nowDate.month, day=nowDate.day, hour=0})
        if isNext then
            self.nextTime[channel] = tempTime
        end
        if not self.prevTime[channel] then
            self.prevTime[channel] = tempTime
        end
		local dateItem = cc.CSLoader:createNode("chat/chatDateItem.csb")
        dateItem.time = tempTime
		dateItem.getHeight = function(item) 
			local panel_bg = item:getChildByName('panel_bg')
			return panel_bg:getContentSize().height
		end
		local panel_bg = dateItem:getChildByName('panel_bg')
		local txt_time = panel_bg:getChildByName('txt_time')
		if nowTime == tempTime then
			txt_time:setString(WordDictionary[22702])
		elseif nowTime - tempTime == 86400 then
			txt_time:setString(WordDictionary[22703])
		else
			txt_time:setString(string.format(WordDictionary[22700],tempDate.month,tempDate.day))
		end
		local height = panel_bg:getContentSize().height
		display.align(dateItem, display.TOP_LEFT, 0, list.lastY)      
	    list:addChild(dateItem)
	    if isNext then
	    	table.insert(itemList,dateItem)
	    else
	    	table.insert(itemList,1,dateItem)
	    end
	    list.lastY = list.lastY - height
    end
    if not isNext then
    	self.prevTime[channel] = tempTime
    end

    local item = nil
    if _ChatData.SendPlr.Plrid == "0" then
        item = ChatSystemItem.create(_ChatData)
    else
        item = ChatItem.create(_ChatData)
        UIImageBox.new(item.playerHead, function()
            self.curSelectItemData = _ChatData.SendPlr
            network.tcpSend(msgids.C_PlayerInfo, {PlrId = _ChatData.SendPlr.Plrid})
        end,{swallowTouches = false})
    end

    local height = item:getHeight()
    display.align(item, display.TOP_LEFT, 0, list.lastY)
    list:addChild(item)
    if isNext then
    	table.insert(itemList,item)
    else
    	table.insert(itemList,1,item)
    end
    list.lastY = list.lastY - height

    local curOffset = list:getInnerContainerPosition()
    local size = list:getInnerContainerSize()
    if list.lastY < 0 then
        local resetY = 5 - list.lastY
        size.height = size.height + resetY
        list.lastY = list.lastY + resetY
        list:setInnerContainerSize(size)

        if self.lockTalk then
            curOffset.y = curOffset.y - height
            list:setInnerContainerPosition(curOffset)
        else
            list:setInnerContainerPosition(cc.p(0, 0))
        end

        for i,v in ipairs(itemList) do
            local y = v:getPositionY()
            v:setPositionY(y + resetY)
        end        if self:isVisible() == false then
            self:clear(channel)
        end
    end
    if not isNext then
        local startIndex = 2
        local height = itemList[1]:getHeight()
        if itemList[2].time and itemList[3].time then
            height = height + itemList[2]:getHeight()
            itemList[1]:setPositionY(itemList[4]:getPositionY())
            itemList[2]:setPositionY(itemList[3]:getPositionY())
            startIndex = 3
            local tempItem = itemList[2]
            table.remove(itemList,2)
            table.insert(itemList,1,tempItem)
        elseif itemList[2].time == tempTime then
            itemList[1]:setPositionY(itemList[3]:getPositionY())
            startIndex = 3
            local tempItem = itemList[2]
            table.remove(itemList,2)
            table.insert(itemList,1,tempItem)
        end
        for i = startIndex, #itemList do
            local v = itemList[i]
            local y = v:getPositionY()
            v:setPositionY(y-height)
        end
    end
end

function ChatWin:sendMessage()
    local text = self.editLb.text
    if string.len(text) <= 0 then
        return
    end

    local lastTime = self.lastSendTime
    local limitTime = SendTimeLimit
    if self.channel == ChatType.World then
        limitTime = SendWorldTimeLimit
        lastTime = self.lastSendWorldTime
    end

    local curTime = Helper.getFixedTime()
    local cd = curTime - lastTime

    if cd < limitTime then
        MoveLabel.new(string.format(WordDictionary[22705], limitTime - cd))
        return
    end
    if self.channel == ChatType.World then
        self.lastSendWorldTime = curTime
        PlayerConfig.setSetting("lastSendWorldTime", curTime)
    else
        self.lastSendTime = curTime
        PlayerConfig.setSetting("lastSendTime", curTime)
    end
    local limit = PlayerConfig.getSetting("chatLimit", 0)
    if limit == 0 then
        if string.len(text) > self.checkTextLenth then
            if self:checkSimilarText(text) then
                limit = 1
                self.repeatCnt = self.repeatCnt + 1

                if self.repeatCnt >= self.repeatCntLimit then
                    PlayerConfig.setSetting("chatLimit", 1)
                end
            end

            if #self.lastMessage >= self.recordMessageCnt then
                for i = 2, #self.lastMessage do
                    self.lastMessage[i - 1] = self.lastMessage[i]
                end
            end
            self.lastMessage[#self.lastMessage + 1] = text
        end
    end

    Helper.checkFilterTextBySDK(self.editLb.text, function(result, newText)
        if result then
            network.tcpSend(msgids.C_ChatSendMsg,{ChatType=self.channel,Content=newText, VisualLimit = limit})
            self.editLb:setString("")
            self.editLb.text = ""
        else
            MoveLabel.new(WordDictionary[22208])
        end
    end)
end

function ChatWin:checkSimilarText(text)
    if RESOURCE_PARAMS and RESOURCE_PARAMS.isKorea then
        return false
    else
        for k,v in ipairs(self.lastMessage) do
            if self:compareStrSimilarity(v, text) > 0.9 then
                return true
            end
        end
    end
    return false
end

function ChatWin:compareStrSimilarity(str1, str2)
    local lenA = string.len(str1)
    local lenB = string.len(str2)
    local tabA, tabB, tabDif = {}, {}, {}

    for k = 1, lenA do
        tabDif[k] = {}
        tabDif[k][1] = k
        tabA[k] = string.sub(str1, k, k)
    end
    for k = 1, lenB do
        tabDif[1][k] = k
        tabB[k] = string.sub(str2, k, k)
    end

    local temp = 0
    for i = 2, lenA do
        for j = 2, lenB do
            if tabA[i -1] == tabB[j - 1] then
                temp = 0
            else
                temp = 1
            end

            tabDif[i][j] = math.min(tabDif[i-1][j-1]+temp, tabDif[i][j-1]+1, tabDif[i-1][j]+1)
        end
    end

    local similarity = 1 - tabDif[lenA][lenB] / math.max(lenA, lenB)
    return similarity
end

---家族招募
function ChatWin:updateGuildInvite()
    local btnImg = self.resourceNode_:getChildByName('panel_bg'):getChildByName('btn_invite')
    local myPos = FamilyModel:getMyPosData() and FamilyModel:getMyPosData().Rank or 999
    if myPos <= 3 and self.channel == ChatType.UnionInvite then
        btnImg:setVisible(true)
        local costData = globalPublicConf[1].guildRecruitCost
        local myNum = Helper.getItemOrCurrencyCnt(costData[1].id)
        local inviteBtn = UIImageBox.new(btnImg,function()
            local canCnt = globalPublicConf[1].guildRecruitLimit - FamilyModel:getTodayInviteCnt()
            if canCnt > 0 then
                if Helper.getItemOrCurrencyCnt(costData[1].id) >= costData[1].n then
                    local data_ = {
                        str = string.format(WordDictionary[23723], costData[1].n),
                        canResetNum = canCnt,
                        resetTip = WordDictionary[23726],
                    }
                    self:openWin("PublicTipWin", {tipLabel = data_}, function()
                        network.tcpSend(msgids.C_GulidInviteRecruit)
                    end)
                else
                    local currency, price = Helper.getExchangeItemCurrencyAndPirce(costData[1].id)
                    if currency == 0 then return end
                    local buyCnt = costData[1].n - Helper.getItemOrCurrencyCnt(costData[1].id)
                    local costItem = Helper.getItemOrCurrencyData(costData[1].id)
                    local data = {
                        str1 = string.format(WordDictionary[20159], c.ITEM_COLOR_16[costItem.color], costItem.name),
                        str2 = string.format(WordDictionary[20160], buyCnt, c.ITEM_COLOR_16[costItem.color], costItem.name),
                        costNum = buyCnt * price,
                        costId = currency,
                    }
                    self:openWin("PublicTipWin", {buyLabel = data}, function()
                        local isOpen = Helper.getOpenState(17)
                        if isOpen then
                            local data_ = {{
                                Id = costData[1].id,
                                N = buyCnt,
                            },}
                            MoveLabel.new(WordDictionary[21613])
                            network.tcpSend(msgids.C_ItemExchange, {ObjFrom = "zhaomu", Items = data_})
                        end
                    end)
                end
            else
                MoveLabel.new(WordDictionary[23725])
            end
        end)
        local iconPath = Helper.getPathById(costData[1].id)
        inviteBtn:getChildByName("sp_icon"):setTexture(iconPath)
        inviteBtn:getChildByName("txt_num"):setString("x"..costData[1].n)
        inviteBtn:getChildByName("txt_num"):setTextColor(myNum >= costData[1].n and CoreColor.GREEN or CoreColor.RED)
    else
        btnImg:setVisible(false)
    end
end

return ChatWin