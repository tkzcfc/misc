--
-- Author: hexianxiong
-- Date: 2018-01-25 15:15:06
--
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local RichLabel = require "sandglass.ui.RichLabel"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local MoveLabel = require "sandglass.ui.MoveLabel"
local init = require "app.models.init"
local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local CoreColor = require "sandglass.core.CoreColor"
local ui = require "sandglass.ui.ui"
local royalFightJobConf = require"app.configs.royalFightJob"
local forceLeaderShowConf = require"app.configs.forceLeaderShow"
local guildConf = require "app.configs.guild"

local PlayerModel = init.PlayerModel
local FamilyModel = init.FamilyModel

local ChatItem = class("ChatItem", function ()
  return cc.Node:create()
end)

function ChatItem.create(info)
  return ChatItem.new(info)
end

function ChatItem:ctor(info)
    self.info = info
    if info.ChatType == 3 then
        self:createInviteTalk(info)
    else
        self:createOrdinaryTalk(info)
    end
end

function ChatItem:createOrdinaryTalk(info)
    local fileName = "chat/chatLeftItem.csb"
    local isSelf = false
    if info.SendPlr.Plrid == PlayerModel.info.userId then
    fileName = "chat/chatRightItem.csb"
    isSelf = true
    end
    local node = cc.CSLoader:createNode(fileName)
    local panel_bg = node:getChildByName('panel_bg')
    self:addChild(node)

    local high = 10
    local maxWidth = 370
    local job = nil
    local leader = nil
    if info.SendPlr.RoyalRank and royalFightJobConf[info.SendPlr.RoyalRank] then
    job = info.SendPlr.RoyalRank
    end
    if info.SendPlr.Camp and forceLeaderShowConf[info.SendPlr.Camp] then
     leader = info.SendPlr.Camp
    end

    local sp_icon = panel_bg:getChildByName("sp_icon")
    local img_job = panel_bg:getChildByName("img_job")
    local txt_job = panel_bg:getChildByName("txt_job")
    local img_leader = panel_bg:getChildByName("img_leader")
    local desBg = panel_bg:getChildByName("img_content")
    local txt_content =  panel_bg:getChildByName("txt_content")
    local txt_time =  panel_bg:getChildByName("txt_time")
    local txt_vip = panel_bg:getChildByName("txt_vip")
    local txt_name = panel_bg:getChildByName("txt_name")

    local headData = {
      frame = panel_bg:getChildByName("img_frame"),
      headId = info.SendPlr.Head,
      frameId = info.SendPlr.HFrame,
      title = info.SendPlr.Title,
    }
    Helper.createPlayerHead(headData)
    self.playerHead = panel_bg:getChildByName("img_frame")
    txt_vip:setString(WordDictionary[22706]..info.SendPlr.Vip)
    txt_time:setString(os.date("%H:%M",info.Ts))

    --官衔
    img_job:setVisible(job ~= nil)
    txt_job:setVisible(job ~= nil)
    if job then
    txt_job:setString(royalFightJobConf[job].job)
    img_job:loadTexture("chat/"..royalFightJobConf[job].talkPic..".png",ccui.TextureResType.plistType)
    end
    -----领袖势力
    img_leader:setVisible(leader ~= nil)
    if leader then
    img_leader:getChildByName("txt_leader"):setString(forceLeaderShowConf[leader].job)
    img_leader:loadTexture("chat/"..forceLeaderShowConf[leader].talkPic..".png",ccui.TextureResType.plistType)
    end

    local nameLable = RichLabel.new({
    fontSize = 18,
    maxWidth = maxWidth,
    })
    txt_name:setVisible(false)
    local nameStr = ""

    local patternStr = isSelf and "<div fontname='%s' fontsize=18 fontcolor=#42AFEE outline=1,#294454>[%s]</div><div fontname='%s' fontsize=18 fontcolor=#B3EE42 outline=1,#2F410C>%s</div>" or
                                "<div fontname='%s' fontsize=18 fontcolor=#42AFEE outline=1,#294454>%s</div><div fontname='%s' fontsize=18 fontcolor=#EBD7BC outline=1,#624B2C>[%s]</div>"
    if info.ChatType == 0 then
    local unionName = WordDictionary[21203]
    if info.SendPlr.GName and info.SendPlr.GName ~= "" then
     unionName = info.SendPlr.GName
    end
    if isSelf then
    nameStr = string.format(patternStr,c.NORMALFONT,unionName,c.NORMALFONT,info.SendPlr.Name)
    else
    nameStr = string.format(patternStr,c.NORMALFONT,info.SendPlr.Name,c.NORMALFONT,unionName)
    end
    else
    local gRank = info.SendPlr.GRank
    local gRandStr = WordDictionary[21450]
    if gRank == c.GUILD_RK.owner then
    gRandStr = WordDictionary[21448]
    elseif gRank == c.GUILD_RK.vice then
    gRandStr = WordDictionary[21449]
    else
    gRandStr = WordDictionary[21450]
    end
    nameStr = string.format(patternStr,c.NORMALFONT,gRandStr,c.NORMALFONT,info.SendPlr.Name)
    end
    nameLable:setString(nameStr)
    panel_bg:addChild(nameLable)

    if not job then
    img_leader:setPositionX(img_job:getPositionX())
    end
    local offset = (job and img_job:getContentSize().width or 0) + (leader and img_leader:getContentSize().width or 0)
    local x = txt_name:getPositionX() + offset
    if isSelf then
    x = txt_name:getPositionX()-nameLable:getContentSize().width-offset
    end
    display.align(nameLable, display.TOP_LEFT, x, txt_name:getPositionY())


    txt_content:setVisible(false)
    local editLabel = RichLabel.new({
    fontColor = CoreColor.WHITE,
    fontSize = 18,
    maxWidth = maxWidth,
    })
    editLabel:setString(Helper.convertStringToExpression(info.Content,"#030000"))
    panel_bg:addChild(editLabel)
    local size = editLabel:getContentSize()
    local x = txt_content:getPositionX()
    if isSelf then
    x = txt_content:getPositionX()-editLabel:getContentSize().width
    end
    display.align(editLabel, display.TOP_LEFT, x, txt_content:getPositionY())
    high = size.height + high + 10

    local desBg = panel_bg:getChildByName("img_content")
    local desId = "1" 
    if leader then
    desId = tostring(forceLeaderShowConf[leader].talkFrame) 
    elseif job then 
    desId = tostring(royalFightJobConf[job].talkFrame) 
    end
    if isSelf then
    desId = desId .. "-self"
    end
    desBg:loadTexture("chat/"..desId..".png",ccui.TextureResType.plistType)

    local rect = desBg:getContentSize()
    high = high < 51 and 51 or high
    rect.height = high
    rect.width = size.width + 50
    desBg:setContentSize(rect)

    local time_posX = txt_name:getPositionX()+nameLable:getContentSize().width+5+offset
    if isSelf then
    time_posX = txt_name:getPositionX()-nameLable:getContentSize().width-5-offset
    end
    -- txt_time:setPositionX(time_posX)

    -- local x = txt_time:getPositionX() + txt_time:getContentSize().width + 5
    -- if isSelf then
    --   x = txt_time:getPositionX() - txt_time:getContentSize().width - 5
    -- end

    local spX = nameLable:getPositionX()
    if not isSelf then
    spX = spX + nameLable:getContentSize().width
    end
    sp_icon:setPositionX(spX)
    sp_icon:setVisible(info.IsTrumpet == true)

    -----公会邀请
    if not isSelf then
        local img_guild = panel_bg:getChildByName("img_guild")
        local posx = (info.IsTrumpet == true) and spX + sp_icon:getContentSize().width * sp_icon:getScale() or spX
        img_guild:setPositionX(posx)
        img_guild:setVisible(false)
        local myPos = FamilyModel:getMyPosData() and FamilyModel:getMyPosData().Rank or 999
        myPos = myPos or 999
        if FamilyModel.guildName and FamilyModel.guildName ~= "" then
            if not (info.SendPlr.GName and info.SendPlr.GName ~= "") and (myPos <= 3) then
                img_guild:setVisible(true)
                img_guild:getChildByName("txt_str"):setString(WordDictionary[22718])
                UIImageBox.new(img_guild,function()
                    network.tcpSend(msgids.C_GulidInvitePlr, {PlrId = info.SendPlr.Plrid})
                end)
            end
        elseif info.SendPlr.GName and info.SendPlr.GName ~= "" then
            img_guild:setVisible(true)
            img_guild:getChildByName("txt_str"):setString(WordDictionary[22719])
            UIImageBox.new(img_guild,function()
                if Helper.getOpenState(20) then
                    if FamilyModel.guildName and FamilyModel.guildName ~= "" then
                        MoveLabel.new(WordDictionary[22721])
                        return
                    end
                    local leftTime = (PlayerModel.info.guildLeaveTs or 0) - Helper.getFixedTime()
                    if leftTime > 0 then    
                        MoveLabel.new(string.format(WordDictionary[23197],Helper.getTimeString(leftTime,true,true)))
                        return
                    end
                    network.tcpSend(msgids.C_GuildApply, {GuildId = info.SendPlr.GuildId})
                    --display.getRunningScene():getChildByName("ViewBase"):openWin("ApplyFamilyWin", info.SendPlr.GuildId)
                end
            end)
        end
    end

    self.height = 40 + high
end

function ChatItem:createInviteTalk(info)
    local fileName = "chat/inviteLeft.csb"
    local isSelf = false
    if info.SendPlr.Plrid == PlayerModel.info.userId then
        fileName = "chat/inviteRight.csb"
        isSelf = true
    end
    local node = cc.CSLoader:createNode(fileName)
    local panel_bg = node:getChildByName('panel_bg')
    self:addChild(node)

    local txt_time =  panel_bg:getChildByName("txt_time")
    local txt_vip = panel_bg:getChildByName("txt_vip")
    local txt_name = panel_bg:getChildByName("txt_name")
    local txt_guildName = panel_bg:getChildByName("txt_guildName")
    local txt_num = panel_bg:getChildByName("txt_num")
    UIImageBox.new(panel_bg:getChildByName("img_guild"),function()
        if Helper.getOpenState(20) then
            if FamilyModel.guildName and FamilyModel.guildName ~= "" then
                MoveLabel.new(WordDictionary[22721])
            else
                local leftTime = (PlayerModel.info.guildLeaveTs or 0) - Helper.getFixedTime()
                if leftTime > 0 then    
                    MoveLabel.new(string.format(WordDictionary[23197],Helper.getTimeString(leftTime,true,true)))
                    return
                end
                network.tcpSend(msgids.C_GuildApply, {GuildId = info.SendPlr.GuildId})
                --display.getRunningScene():getChildByName("ViewBase"):openWin("ApplyFamilyWin", info.SendPlr.GuildId)
            end
        end
    end)

    local headData = {
        frame = panel_bg:getChildByName("img_frame"),
        headId = info.SendPlr.Head,
        frameId = info.SendPlr.HFrame,
        title = info.SendPlr.Title,
    }
    Helper.createPlayerHead(headData)
    self.playerHead = panel_bg:getChildByName("img_frame")
    txt_time:setString(os.date("%H:%M",info.Ts))

    local nameLable = RichLabel.new({
        fontSize = 18,
    })
    txt_name:setVisible(false)
    local nameStr = ""
    local patternStr = isSelf and "<div fontname='%s' fontsize=18 fontcolor=#42AFEE outline=1,#294454>[%s]</div><div fontname='%s' fontsize=18 fontcolor=#B3EE42 outline=1,#2F410C>%s</div>" or
    "<div fontname='%s' fontsize=18 fontcolor=#42AFEE outline=1,#294454>%s</div><div fontname='%s' fontsize=18 fontcolor=#EBD7BC outline=1,#624B2C>[%s]</div>"

    local unionName = info.SendPlr.GName
    if isSelf then
        nameStr = string.format(patternStr,c.NORMALFONT,unionName,c.NORMALFONT,info.SendPlr.Name)
    else
        nameStr = string.format(patternStr,c.NORMALFONT,info.SendPlr.Name,c.NORMALFONT,unionName)
    end
    nameLable:setString(nameStr)
    panel_bg:addChild(nameLable)

    local x = txt_name:getPositionX() 
    if isSelf then
        x = x - nameLable:getContentSize().width
    end
    display.align(nameLable, display.TOP_LEFT, x, txt_name:getPositionY())
    txt_vip:setString(WordDictionary[22706]..info.SendPlr.Vip)

    local info_ = string.split(info.Content, ",")
    local guildLv, guildCnt = tonumber(info_[1]), tonumber(info_[2])
    local limitCnt = guildConf[guildLv].mbLimit
    txt_guildName:setString(unionName .. " Lv." .. guildLv)
    txt_num:setString(WordDictionary[22720].. guildCnt.."/"..limitCnt)

    self.height = 120 + 40
end

function ChatItem:getHeight()
  return self.height
end

return ChatItem
