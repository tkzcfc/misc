--
-- Author: hexianxiong
-- Date: 2018-04-20 14:44:12
--
local init = require "app.models.init"
local RichLabel = require "sandglass.ui.RichLabel"
local SpineManager = require "sandglass.core.SpineManager"

local ChatModel = init.ChatModel

local LampMessage = class("LampMessage")

function LampMessage:ctor(lampNode, onlyShow)
	self.lampNode = lampNode
	--true表示不在主界面展示，仅仅在单独的玩法界面展示
	self.onlyShow = onlyShow
end

function LampMessage:playLamp()
    self.lampNode:stopAllActions()
	if self.lampNode:getChildByName("lampItem") then
		return
	end
	local lampData, time = ChatModel:getLampMessage()
	if lampData then
		local speed = 10
		local lampItem = nil
		if lampData.Style == 1 then --普通跑马灯
			lampItem = cc.CSLoader:createNode("chat/lampNode.csb")
		elseif lampData.Style == 3 then --王者之剑跑马灯
			if not self.onlyShow then
				return
			end
			lampItem = cc.CSLoader:createNode("chat/lampNode.csb")
			--特殊跑马灯背景spine
            local anim = SpineManager.createAnimation("public/ui_paomadengliuguang", 1)
            anim:playAnimation("idle", -1)
            lampItem:addChild(anim)
        elseif lampData.Style == 4 then ----领袖跑马灯
        	lampItem = cc.CSLoader:createNode("chat/lampNode.csb")
            local anim = SpineManager.createAnimation("public/ui_caidai", 1)
            anim:playAnimation("idle", 1)
            anim:setAutoRemove(true)
            anim:setPositionY(display.cy-self.lampNode:getPositionY())
            self.lampNode:addChild(anim)
		else
			lampItem = cc.CSLoader:createNode("chat/lampNode_escort.csb")
		end

		self.lampNode:addChild(lampItem)
		lampItem:setName("lampItem")

		local panelSize = lampItem:getChildByName("panel_lamp"):getContentSize()
		local text = RichLabel.new({
	        fontSize = 20,
	        fontColor = cc.c3b(243, 212, 143),
	        --maxWidth = 800,
	    })
		text:setString(lampData.Content)
		local textSize = text:getContentSize()
		local distance = panelSize.width + textSize.width
	    text:runAction(cc.Sequence:create(cc.MoveBy:create(speed, cc.p(-distance,0)),cc.CallFunc:create(function(target)
	    	lampItem:removeFromParent()
	    	--if lampData.Num > 0 then
	    		self:playLamp()
	    	--end
    	end)))
		lampItem:getChildByName("panel_lamp"):addChild(text)
	    display.align(text,display.LEFT_CENTER,panelSize.width,panelSize.height/2)
	else
		self.lampNode:removeAllChildren()
        if time and time > 0 then
            self.lampNode:runAction(cc.Sequence:create(
                cc.DelayTime:create(time),
                cc.CallFunc:create(function()
                    self:playLamp()
                end)
            ))
        end
	end
end
return LampMessage