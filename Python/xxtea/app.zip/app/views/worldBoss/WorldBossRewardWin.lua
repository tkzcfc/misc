local WinBase = require "sandglass.core.WinBase"
local c = require "app.configs.constants"
local UIImageBox = require "sandglass.ui.UIImageBox"
local Helper = require "app.Helper"
local init = require "app.models.init"
local MoveLabel = require "sandglass.ui.MoveLabel"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local worldBossRewardsConf = require "app.configs.worldBossRewards"
local worldBossConf = require "app.configs.worldBoss"
local mailConf = require "app.configs.mail"
require "sandglass.ui.UIListView"

local WorldBossRewardWin = class("WorldBossRewardWin", WinBase)
WorldBossRewardWin.RESOURCE_FILENAME = "worldBoss/worldBossReward.csb"


function WorldBossRewardWin:onCreate(curStage, lastStage)
    self.priority = c.WIN_ZORDER.POPUP

    self.rewardData = {}
    self.stageRewardData = {}
    self.curStage = curStage
    self.lastStage = lastStage
    self:initData()
end

function WorldBossRewardWin:initialView()
	self:setAutoClose(self.resourceNode_:getChildByName("bg"))
    
    local listView = self.resourceNode_:getChildByName("listView")
    listView:setScrollBarEnabled(false)
    listView:updateListView(self.rewardData, function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRewardItem(data, index)
        end
        cacheView:updateView(data, index)
        return cacheView
    end)

    local perX = 80
    local count = #self.stageRewardData[1]
    local offset = count * perX / 2 - perX / 2
    for k,v in ipairs(self.stageRewardData[1]) do
        local item = Helper.createGoodsItem({id = v.Id, num = v.n, scale = 0.7})
        self.resourceNode_:getChildByName("node_item"):addChild(item)
        item:setPositionX((k - 1) * perX - offset)
    end

    self.resourceNode_:getChildByName("txt_des"):setString(self.tipStr or "")
end

function WorldBossRewardWin:createRewardItem(data, index)
    local node = cc.CSLoader:createNode("worldBoss/rewardItem.csb")
    local layer = ccui.Layout:create()

    layer.updateView = function(layer, data, index)
        node:getChildByName("txt_rank"):setVisible(index > 3)
        node:getChildByName("img_rank"):setVisible(index <= 3)
        if index > 3 then
            node:getChildByName("txt_rank"):setString(
                worldBossRewardsConf[index].worldBossRankLimit[1].up .. "~" .. worldBossRewardsConf[index].worldBossRankLimit[1].down )
            if index == #worldBossRewardsConf then
               node:getChildByName("txt_rank"):setString(string.format(WordDictionary[23927], worldBossRewardsConf[index].worldBossRankLimit[1].up)) 
            end
        else
            node:getChildByName("img_rank"):loadTexture("public/0"..index..".png", ccui.TextureResType.plistType)
        end

        node:getChildByName("node_item"):removeAllChildren()
        local perX = 80
        for k,v in ipairs(data) do
            local item = Helper.createGoodsItem({id = v.Id, num = v.n, scale = 0.7})
            node:getChildByName("node_item"):addChild(item)
            item:setPositionX((k-1) * perX)
        end
    end
    layer:setContentSize(cc.size(460, 75))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer
end

function WorldBossRewardWin:initData()
    for i = 1, #worldBossRewardsConf do
        local mailId = worldBossRewardsConf[i].Mail
        if mailConf[mailId] then
            local reward = clone(mailConf[mailId].mailItem)
            table.insert(self.rewardData, reward)
        end
    end
    
    local reward = {}
    if self.lastStage ~= self.curStage then
        self.tipStr = WordDictionary[23920]
        local mailId = worldBossConf[1].bossStage[self.curStage].mail
        if mailConf[mailId] then
            reward = clone(mailConf[mailId].mailItem)
        end
    else
        self.tipStr = WordDictionary[23921]
        reward = clone(mailConf[worldBossConf[1].bossLoopReward].mailItem)
    end
    table.insert(self.stageRewardData, reward)
end

function WorldBossRewardWin:getActionIn()
    Helper.enterWinAction1(self)
end

return WorldBossRewardWin