local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local WorldBossConf = require "app.configs.worldBoss"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local monsterConf = require "app.configs.monster"
local skinConf = require "app.configs.skin"
local MoveLabel = require "sandglass.ui.MoveLabel"
local RichLabel = require "sandglass.ui.RichLabel"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local enums = require "app.network.enums"
local BulletScreen = require "sandglass.ui.BulletScreen"
local timePlayConf = require "app.configs.timePlay"
local SpineManager = require "sandglass.core.SpineManager"
local AudioManager = require "sandglass.core.AudioManager"
local init = require "app.models.init"
local monsterPowerConf = require "app.configs.monsterPower"
local worldBossTargetConf = require "app.configs.worldBossTarget"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel

local WorldBossWin = class("WorldBossWin", WinBase)
WorldBossWin.RESOURCE_FILENAME = "worldBoss/worldBoss.csb"

function WorldBossWin:onCreate()
    self.showType = self.WinShowType.hiddenBack
    
    self.canSendDanMu = true
    self.isOpenBoss = false
    self.isDie = false
    self.bossData = {}

    local msgList = {
        msgids.GS_WorldBossEnter_R,
        msgids.GS_WorldBossBarrage,
        msgids.GS_WorldBossTargetTake_R,
        msgids.GS_WorldBossTotalDmg,
    }
    network.addListener(self, msgList, handler(self, self.updateHandler))
    network.tcpSend(msgids.C_WorldBossEnter)
end

function WorldBossWin:updateHandler(op, data)
    if op == msgids.GS_WorldBossEnter_R then
        self.bossData = data.Data
        self:checkTargetRewardTips()
        self:updateLayer(data)
    elseif op == msgids.GS_WorldBossBarrage then
        local bulletData = data.One
        local str = string.format(WordDictionary[23909], bulletData.Name)..Helper.convertStringToExpression(string.format(WordDictionary[23908], "#FFFFFF", bulletData.Content))
        self.danMu:addBullet(str)
    elseif op == msgids.GS_WorldBossDmgList_R then
        self.damageRankData = data.DmgList
        self:updateLookers()
    elseif op == msgids.GS_WorldBossUpdate then
        if self.bossData.Stage ~= data.Stage then
            self.bossData.Stage = data.Stage
            self:changeBoss()
        else
            self.bossData.Stage = data.Stage
            self.updateBossInfo()
        end
    elseif op == msgids.GS_WorldBossTargetTake_R then
        if not self.bossData.TargetTaken then
            self.bossData.TargetTaken = {}
        end
        table.insert(self.bossData.TargetTaken, data.Id)
        self:checkTargetRewardTips()
    elseif op == msgids.GS_WorldBossTotalDmg then
        self.bossData.TotalDmg = data.TotalDmg
        self:changeBoss()
    end
end

function WorldBossWin:closeSelf()
    AudioManager.playMusic(self.curMusic)
    network.tcpSend(msgids.C_WorldBossOut)
    WorldBossWin.super.closeSelf(self)
end

function WorldBossWin:initialView()
    self.curMusic = AudioManager.getCurMusic()
    AudioManager.playMusic("music/bgm_wfightbgm.mp3")

    self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(WordDictionary[23900])
	UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
        self:closeSelf()
	end)
    ---------规则
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"),function()
        self:openWin("PublicRuleWin", WordDictionary[23901])
    end)
    ------排行榜
    UIImageBox.new(self.resourceNode_:getChildByName("node_lt"):getChildByName("btn_rank"),function()
        self:openWin("WorldBossRankWin")
    end)
    ------奖励预览
    UIImageBox.new(self.resourceNode_:getChildByName("node_rb"):getChildByName("btn_box"),function()
        if self.bossData then
            self:openWin("WorldBossRewardWin", self.bossData.Stage, self.bossData.AwardLimit)
        end
    end)
    ------目标奖励
    UIImageBox.new(self.resourceNode_:getChildByName("node_lt"):getChildByName("btn_reward"),function()
        if self.bossData then
            self:openWin("WorldBossTargetRewardWin", self.bossData)
        end
    end)
    --------弹幕开关
    self.danMuBtn = UIImageBox.new(self.resourceNode_:getChildByName("node_lb"):getChildByName("btn_chatToggle"), function()
        local isOpen = self.danMu:getOpen()
        self.danMu:setOpen(not isOpen)
        PlayerConfig.setSetting(PlayerModel.info.userId.."openWorldBossDanMu",not isOpen)
        self:updateDanMuBtn()
    end, {noAnimEffect = true})
    self:updateDanMuBtn()
    ------发送弹幕
    UIImageBox.new(self.resourceNode_:getChildByName("node_lb"):getChildByName("btn_chat"), function()
        if self.canSendDanMu then
            self:openWin("DanMuWin", function(str)
                if str ~= "" then
                    network.tcpSend(msgids.C_WorldBossSendBarrage, {Content = str})
                    self:startSendDanMu() 
                else
                    MoveLabel.new(WordDictionary[23926])
                end
            end)
        else
            MoveLabel.new(WordDictionary[23904])     
        end
    end)

    local timeStr = ""
    if #WorldBossConf[1].wdays == 7 then
        timeStr = timeStr..WordDictionary[23906]
    else
        for k,v in ipairs(WorldBossConf[1].wdays) do
            if k == 1 then
                timeStr = timeStr..string.format(WordDictionary[23907], WordDictionary[23910+v])
            else
                timeStr = timeStr.."、"..WordDictionary[23910+v]
            end
        end
    end
    for i,v in ipairs(WorldBossConf[1].openCloseTime_Ex) do
        timeStr = timeStr..v.begtime.."-"..v.endtime.." "
    end
    self.openTimeStr = timeStr
   
    self:timerTask()
end

function WorldBossWin:updateLayer(data)
    self.damageRankData = data.DmgList
   
    local danMuList = {}
    for k,v in ipairs(data.Data.Barrage) do
        local str = string.format(WordDictionary[23909], v.Name)..Helper.convertStringToExpression(string.format(WordDictionary[23908], "#FFFFFF", v.Content))
        table.insert(danMuList,{str = str})
    end
    self.danMu = BulletScreen.new({
        parentNode = self.resourceNode_:getChildByName("node_danmu"),
        bulletList = danMuList,
        isOpen = PlayerConfig.getSetting(PlayerModel.info.userId.."openWorldBossDanMu", true),
    })
    self.danMu:start()

    self:changeBoss()
    self:updateLookers()
end

function WorldBossWin:changeBoss()
    local worldBossData = WorldBossConf[1].bossStage[self.bossData.Stage]
    local monsterData = monsterConf[worldBossData.id]
    local serHpMax = self:getBossMaxHp(worldBossData.id, worldBossData.lv)

    local bossNode = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss")
    -- self.isDie = self.bossData.TotalDmg and self.bossData.TotalDmg >= serHpMax
    bossNode:removeAllChildren()
    local bossSpine = SpineManager.createAnimation("spine/actors/"..roleConf[monsterData.role].spine)
    bossSpine:playAnimation("idle", -1)
    bossSpine:registerSkin("normal")
    bossSpine:setScale(monsterData.bodyScale)
    bossSpine:setName("bossSpine")
    bossSpine:setFlipX(true)
    bossNode:addChild(bossSpine)

    local bossLockEffect = SpineManager.createAnimation("worldBoss/ui_shijieboss_fengyin")
    bossLockEffect:setName("bossLockEffect")
    bossLockEffect:setPositionY(160)
    if not self.isOpenBoss or self.isDie then
        bossLockEffect:playAnimation("idle1", -1)
        Helper.greyFunc(bossSpine)
    else
        bossLockEffect:setVisible(false)
    end
    bossNode:addChild(bossLockEffect)

    self:updateBossInfo()
end


function WorldBossWin:getBossMaxHp(id, level)
    local mConf = monsterConf[id]
    local mpConf = monsterPowerConf[level]
    local maxHp = math.ceil(mConf.maxLife * mpConf.maxLife)
    return maxHp
end


function WorldBossWin:updateBossInfo()
    if not self.bossData.Stage then
        return
    end
    local node_rb = self.resourceNode_:getChildByName("node_rb")
    local worldBossData = WorldBossConf[1].bossStage[self.bossData.Stage]
    local monsterData = monsterConf[worldBossData.id]
    UIImageBox.new(node_rb:getChildByName("btn_fight"), function()
        if not self.isOpenBoss then
            MoveLabel.new(WordDictionary[23922])
            return
        end
        if self.isDie then
            MoveLabel.new(WordDictionary[23923])
            return
        end
        local curCnt = PlayerModel:getCounterByID(enums.Cnt_WorldBoss_FightCnt)
        local maxCnt = PlayerModel:getCounterByID(enums.Max_Vip_Cnt_WorldBoss_FightCnt)
        if curCnt >= maxCnt then
            MoveLabel.new(WordDictionary[23924])
            return
        end
        local data = {
            fightStatus = c.FightStatus.worldBoss, 
            monsterId = worldBossData.id, 
            monsterLevel = worldBossData.lv, 
            bg = WorldBossConf[1].background,
            bgMusic = WorldBossConf[1].battleMusic,
            backgroundEffect = WorldBossConf[1].backgroundEffect,
            decHp = 0, --self.bossData.TotalDmg,
            banIds = WorldBossConf[1].banId,
        }
        self:openWin("EmbattleWin",data)
    end)
    node_rb:getChildByName('txt_bossName'):setString(monsterData.name)
    node_rb:getChildByName('txt_bossLevel'):setString("Lv."..self.bossData.Stage)
    local hpPercent = nil
    local serHpMax = self:getBossMaxHp(worldBossData.id, worldBossData.lv)
    if self.bossData.TotalDmg > serHpMax/2 then
        hpPercent = math.ceil((serHpMax-self.bossData.TotalDmg)/serHpMax * 100)
    else
        hpPercent = math.floor((serHpMax-self.bossData.TotalDmg)/serHpMax * 100)
    end

    hpPercent = math.max(math.min(100-hpPercent, 100), 0)
    node_rb:getChildByName('txt_hp'):setString(hpPercent.."%")
    node_rb:getChildByName("bar_hp"):setPercent(hpPercent)
    local curCnt = PlayerModel:getCounterByID(enums.Cnt_WorldBoss_FightCnt)
    local maxCnt = PlayerModel:getCounterByID(enums.Max_Vip_Cnt_WorldBoss_FightCnt)
    node_rb:getChildByName("txt_fightNum"):setString((maxCnt-curCnt).."/"..maxCnt)
    if maxCnt - curCnt > 0 and self.isOpenBoss then
        RedTipsModel:addRedTip(node_rb:getChildByName("btn_fight"), cc.p(115, 40))
    else
        RedTipsModel:removeRedTip(node_rb:getChildByName("btn_fight"))
    end
    --扳英雄----
    self.resourceNode_:getChildByName("node_lb"):getChildByName("node_limit"):removeAllChildren()
    local banInfo = Helper.getBanInfo(WorldBossConf[1].banId)
    for k,v in ipairs(banInfo) do
        local banItem = nil
        if v.icon then
            banItem = display.newSprite("#"..v.icon)
            if v.scale then
                banItem:setScale(v.scale)
            end
            self.resourceNode_:getChildByName("node_lb"):getChildByName("node_limit"):addChild(banItem)
            self.resourceNode_:getChildByName("node_lb"):getChildByName("txt_limit"):setString(WordDictionary[23925])
        else
            self.resourceNode_:getChildByName("node_lb"):getChildByName("txt_limit"):setString("")
        end
    end
end

function WorldBossWin:updateTimeTips(openHour, openMinute, closeHour, closeMinute, node_time)
    local txt_time = node_time:getChildByName("txt_time")
    local txt_timeStr = node_time:getChildByName("txt_timeStr")
    local img_timebg = node_time:getChildByName("img_timebg")

    local times = {}
    local ts = {}
    for i,v in ipairs(WorldBossConf[1].openCloseTime_Ex) do
        table.insert(ts, v.begtime .."-".. v.endtime)
    end
    for i,v in ipairs(WorldBossConf[1].wdays) do
        times[v] = ts
    end
    local delayTime, opening = Helper.getFuncOpenTimeInterval(times)
    if opening then
        txt_timeStr:setString(WordDictionary[23918])
        txt_time:setString(Helper.getTimeString(delayTime, true))
        if not self.isOpenBoss and not self.isDie  then
            self.isOpenBoss = true
            local effect = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossLockEffect")
            if effect then
                effect:setVisible(true)
                local bossSpine = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossSpine")
                Helper.greyFunc(bossSpine, true)
                bossSpine:playAnimation("skill_a", 1)
                bossSpine:appendNextAnimation("idle", -1)
                effect:playAnimation("idle2", 1)
            end
            self:updateBossInfo()
        end
        self.isOpenBoss = true
    else
        txt_time:setString(self.openTimeStr)
        txt_timeStr:setString(WordDictionary[23905])
        if self.isOpenBoss then
            self.isOpenBoss = false
            local effect = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossLockEffect")
            if effect then
                effect:setVisible(true)
                Helper.greyFunc(self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossSpine"))
                effect:playAnimation("idle1", -1)
            end
            self:updateBossInfo()
        end
        self.isOpenBoss = false
    end
    --local curTime = Helper.getFixedTime()
    --local curTimeTs = os.date("*t", curTime)
    --local todayOpen = false
    --local curWeek = os.date("%w",curTime)
    --curWeek = tonumber(curWeek)
    --for k,v in ipairs(WorldBossConf[1].wdays) do
    --    if v == curWeek then
    --        local openTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = openHour, min = openMinute, sec = 0})
    --        local closeTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = closeHour, min = closeMinute, sec = 0})
    --        local leftOpen = openTime - curTime
    --        local leftClose = closeTime - curTime
    --        if leftOpen > 0 or leftClose < 0 then--未开启
    --            txt_time:setString(self.openTimeStr)
    --            txt_timeStr:setString(WordDictionary[23905])
    --            if self.isOpenBoss then
    --                self.isOpenBoss = false
    --                local effect = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossLockEffect")
    --                if effect then
    --                    effect:setVisible(true)
    --                    Helper.greyFunc(self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossSpine"))
    --                    effect:playAnimation("idle1", -1)
    --                end
    --                self:updateBossInfo()
    --            end
    --            self.isOpenBoss = false
    --        elseif leftOpen < 0 and leftClose > 0 then--开启中
    --            txt_timeStr:setString(WordDictionary[23918])
    --            txt_time:setString(Helper.getTimeString(leftClose, true))
    --            if not self.isOpenBoss and not self.isDie  then
    --                self.isOpenBoss = true
    --                local effect = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossLockEffect")
    --                if effect then
    --                    effect:setVisible(true)
    --                    local bossSpine = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossSpine")
    --                    Helper.greyFunc(bossSpine, true)
    --                    bossSpine:playAnimation("skill_a", 1)
    --                    bossSpine:appendNextAnimation("idle", -1)
    --                    effect:playAnimation("idle2", 1)
    --                end
    --                self:updateBossInfo()
    --            end
    --            self.isOpenBoss = true
    --        end
    --        todayOpen = true
    --        break
    --    end
    --end
    --if not todayOpen then
    --    txt_time:setString(self.openTimeStr)
    --    txt_timeStr:setString(WordDictionary[23905])
    --    if self.isOpenBoss then
    --        self.isOpenBoss = false
    --        local effect = self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossLockEffect")
    --        if effect then
    --            effect:setVisible(true)
    --            Helper.greyFunc(self.resourceNode_:getChildByName("node_rb"):getChildByName("node_boss"):getChildByName("bossSpine"))
    --            effect:playAnimation("idle1", -1)
    --        end
    --        self:updateBossInfo()
    --    end
    --    self.isOpenBoss = false
    --end
    --
    local txtTimeW = txt_time:getContentSize().width
    local txtTimeStrW = txt_timeStr:getContentSize().width
    local imgTimeBgSize = img_timebg:getContentSize()
    txt_timeStr:setPositionX(txt_time:getPositionX() - txtTimeW - 2)
    img_timebg:setContentSize(txtTimeW+txtTimeStrW+150, imgTimeBgSize.height)

end

function WorldBossWin:timerTask()
    --local info = string.split(WorldBossConf[1].openTime, ":")
    --local openHour, openMinute = tonumber(info[1]), tonumber(info[2])
    --local info = string.split(WorldBossConf[1].closeTime, ":")
    --local closeHour, closeMinute = tonumber(info[1]), tonumber(info[2])
    local node_time = self.resourceNode_:getChildByName("node_time")
    node_time:stopActionByTag(0XABC)
    self:updateTimeTips(openHour, openMinute, closeHour, closeMinute,node_time)
    node_time:actionScheduleInterval(function()
        self:updateTimeTips(openHour, openMinute, closeHour, closeMinute,node_time)
    end, 1, 0XABC)
end

function WorldBossWin:updateLookers()
    local node_top3 = self.resourceNode_:getChildByName("node_rank")
    local isTop3 = false
    for i = 1, 3 do
        local data = self.damageRankData.List and self.damageRankData.List[i] or nil
        local node = node_top3:getChildByName("node_top_"..i)
        node:removeChildByName("spine")
        if data then
            node:setVisible(true)
            local heroData = heroConf[data.HeroId]
            local spine = SpineManager.createAnimation("spine/actors/"..roleConf[heroData.role].spine)
            spine:registerSkin(skinConf[data.Skin].spineName)
            spine:playAnimation("idle", -1)
            spine:setName("spine")
            spine:setScale(0.8)
            node:addChild(spine, -1)
            node:getChildByName("txt_name"):setString(data.Name)
            if data.Plrid == PlayerModel.info.userId then
                isTop3 = true
            end
        else
            node:setVisible(false)
        end
    end

    local allLookers = {}
    for k,v in ipairs(self.damageRankData.List or {}) do
        if k > 3 then
            table.insert(allLookers, {name = v.Name, heroId = v.HeroId, skin = v.Skin, id = v.Plrid})
        end
    end
    local lookers,hasMe = {}, false
    local playerCnt = math.min(7, #allLookers)
    for i = 1, playerCnt do
        local randomK = math.random(1, #allLookers)
        local looker = allLookers[randomK]
        if looker.id == PlayerModel.info.userId then
            hasMe = true
        end
        table.insert(lookers, looker)
        table.remove(allLookers,randomK)
    end
    if not hasMe and not isTop3 then
        lookers[math.random(1,12)] = {name = PlayerModel.info.name, heroId = self.damageRankData.SelfHeroId, skin = self.damageRankData.SelfSkin, id = PlayerModel.info.userId}
    end

    for k,v in ipairs(lookers) do
        local node = self.resourceNode_:getChildByName("node_lb"):getChildByName("node_"..k)
        node:runAction(cc.Sequence:create(cc.DelayTime:create(k*0.1), cc.CallFunc:create(function()
            local heroData = heroConf[v.heroId]
            local spine = SpineManager.createAnimation("spine/actors/"..roleConf[heroData.role].spine)
            spine:registerSkin(skinConf[v.skin].spineName)
            spine:playAnimation("idle", -1)
            spine:setScale(0.7)
            node:removeAllChildren()
            node:addChild(spine, -1)
            local color = cc.c3b(255,255,255)
            if v.id == PlayerModel.info.userId then
                color = cc.c3b(146,253,32)
            end
            local nameStr = UILabel.new({
                text = v.name,
                color = color,
                size = 20,
                back = CoreColor.BLACK,
            })
            display.align(nameStr, display.CENTER, 0, 100)
            node:addChild(nameStr)
            node:setLocalZOrder(display.height - node:getPositionY())
        end)))
    end
end

function WorldBossWin:updateDanMuBtn()
    local sp_spot = self.danMuBtn:getChildByName("sp_spot")
    local txt_tip = self.danMuBtn:getChildByName("txt_name")
    local isOpenDanMu = PlayerConfig.getSetting(PlayerModel.info.userId.."openWorldBossDanMu", true)
    if isOpenDanMu then
        sp_spot:setPositionX(self.danMuBtn:getContentSize().width-sp_spot:getContentSize().width/2)
        txt_tip:setString(WordDictionary[23902])
        self.danMuBtn:loadTexture("playerInfo/gerenxingxi-kaiguan2.png",ccui.TextureResType.plistType)
    else
        sp_spot:setPositionX(sp_spot:getContentSize().width/2)
        txt_tip:setString(WordDictionary[23903])
        self.danMuBtn:loadTexture("playerInfo/gerenxingxi-kaiguan1.png",ccui.TextureResType.plistType)
    end
end



function WorldBossWin:startSendDanMu()
    local danMuCD = 5
    self.canSendDanMu = false
    self.resourceNode_:stopAllActions()
    self.resourceNode_:runAction(cc.Sequence:create(cc.DelayTime:create(danMuCD), cc.CallFunc:create(function()
        self.canSendDanMu = true
    end)))
end

function WorldBossWin:checkTargetRewardTips()
    local hasRed = false
    if self.bossData then
        for i,v in pairs(worldBossTargetConf) do
            if self.bossData.SelfTotalDmg >= v.needScore then
                local hasId = false
                for _,id in ipairs(self.bossData.TargetTaken or {}) do
                    if v.Id == id then
                        hasId = true
                        break
                    end 
                end
                if not hasId then
                    hasRed = true
                    break
                end
            end
        end
    end
    local btn = self.resourceNode_:getChildByName("node_lt"):getChildByName("btn_reward")
    if hasRed then
        RedTipsModel:addRedTip(btn, cc.p(50, 50))
    else
        RedTipsModel:removeRedTip(btn)
    end
    
end

return WorldBossWin