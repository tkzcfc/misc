
local WinBase = require "sandglass.core.WinBase"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local SpineManager = require "sandglass.core.SpineManager"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local wfGradeConf = require "app.configs.wfGrade"

local WorldFightAdvanceWin = class("WorldFightAdvanceWin", WinBase)

WorldFightAdvanceWin.RESOURCE_FILENAME = "layer/worldFight/worldFightAdvance.csb"

function WorldFightAdvanceWin:onCreate(grade)
	self.priority = c.WIN_ZORDER.NORMAL
	self.grade = grade
end

function WorldFightAdvanceWin:initialView()
	local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
    self.resourceNode_:runAction(moveAction)
    moveAction:play("animation0", false)

    local path = "public/ui_shengji_di"
    local anim = SpineManager.createAnimation(path,1)
    anim:playAnimation("idle", 1)
    anim:setPosition(display.cx,display.cy)
    local node = cc.ClippingNode:create(anim)
    node:setAlphaThreshold(0.5)
    self.resourceNode_:addChild(node,-1)
    anim:addLuaHandler(function(eventName, animName, intValue, floatValue)
        if animName == "idle" and eventName == "end" then
            anim:setPause(true)
        end
    end)

    -- local bg = display.newSprite("fight/zhujiemian-di.png")
    -- local pos = node:convertToNodeSpace(cc.p(display.cx,display.cy))
    -- bg:setPosition(pos.x,pos.y)
    -- node:addChild(bg,-1)

    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(2),
        cc.CallFunc:create(function()
            local listener = cc.EventListenerTouchOneByOne:create()
            listener:setSwallowTouches(true)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_MOVED)
            listener:registerScriptHandler(handler(self, function()
        	    self:closeSelf()
            end), cc.Handler.EVENT_TOUCH_ENDED)

            local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.resourceNode_)
        end)
    ))

    local info = wfGradeConf[self.grade]
    local img = display.newSprite("icon/medallion/" .. info.icon .. ".png")
    self.resourceNode_:getChildByName("Node_1"):getChildByName("Node"):addChild(img)
    self.resourceNode_:getChildByName("Node_1"):getChildByName("Text_2"):setString(info.name)
    self.resourceNode_:getChildByName("Node_1"):getChildByName("Image_3"):runAction(cc.RepeatForever:create(cc.RotateBy:create(20,360)))
end

return WorldFightAdvanceWin