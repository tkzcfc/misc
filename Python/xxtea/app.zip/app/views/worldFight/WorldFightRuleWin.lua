local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local WordDictionary = require "app.configs.WordDictionary"
local wfightConf = require "app.configs.wfight"
local Helper = require "app.Helper"

local WorldFightRuleWin = class("WorldFightRuleWin", WinBase)

WorldFightRuleWin.RESOURCE_FILENAME = "layer/worldFight/rules.csb"

local max = 7

function WorldFightRuleWin:onCreate()
	self.priority = c.WIN_ZORDER.POPUP
	
	self.texts = {
		{23611,23612,23613},
		{23614,23615},
		{23616,23617},
		{23618,23619},
		{23620},
		{23633,23634},
		{23621,23622},
	}
end

function WorldFightRuleWin:initialView()
	-- 关闭
	UIImageBox.new(self.resourceNode_:getChildByName("closeBtn"),function()
		self:closeSelf()
	end)

    self.curPage = 0
	self:initPageView()
end

function WorldFightRuleWin:initPageView()
	self.resourceNode_:getChildByName("txt_page"):setString(string.format(WordDictionary[23250],1,max))
	local pageView = self.resourceNode_:getChildByName("PageView")
	local leftBtn = UIImageBox.new(self.resourceNode_:getChildByName("btn_left"),function()
		self.curPage = self.curPage - 1
		if self.curPage <= 0 then
			self.curPage = 0
		end
		pageView:scrollToPage(self.curPage)
	end)
    leftBtn:setEnabled(false)
	local rightBtn = UIImageBox.new(self.resourceNode_:getChildByName("btn_right"),function()
		self.curPage = self.curPage + 1
		if self.curPage >= max - 1 then
			self.curPage = max - 1
		end
		pageView:scrollToPage(self.curPage)
	end)
	self:refreshMiddle()

	pageView:addEventListener(function(pageView)
		local curPage = pageView:getCurrentPageIndex()
		self.curPage = curPage
		self.resourceNode_:getChildByName("txt_page"):setString(string.format(WordDictionary[23250],self.curPage+1,max))
		if curPage <= 0 then
			leftBtn:setEnabled(false)
		else
			leftBtn:setEnabled(true)
		end

		if curPage >= max - 1 then
			rightBtn:setEnabled(false)
		else
			rightBtn:setEnabled(true)
		end
	end)	
end


function WorldFightRuleWin:refreshMiddle()
	local pageView = self.resourceNode_:getChildByName("PageView")
	pageView:removeAllPages()
	for i = 1, max do
		local contentNode = cc.CSLoader:createNode("layer/worldFight/rule_"..i..".csb")

		local ids = self.texts[i]
		for k,id in ipairs(ids) do
			contentNode:getChildByName("txt_"..k):setString(WordDictionary[id])
		end

		if i == 6 then
			local cnts = {0, 0, 0}
			for _, v in pairs(wfightConf[1].winMailReward) do
				local cnt = cnts[v.rank] + 1
				cnts[v.rank] = cnt

				local node = contentNode:getChildByName("node_"..v.rank.."_"..cnt)
				if node then
					node:removeAllChildren()
					local item = Helper.createGoodsItem({scale = 0.8,id = v.id,num = v.n})
					node:addChild(item)
				end
			end
		end

		display.align(contentNode,display.BOTTOM_LEFT, 0 , 0)
		local widget = ccui.Widget:create()
		widget:addChild(contentNode)

		pageView:addPage(widget)
	end
end

function WorldFightRuleWin:getActionIn()
    Helper.enterWinAction1(self)
end

return WorldFightRuleWin