
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local currencyConf = require "app.configs.currency"
local WordDictionary = require "app.configs.WordDictionary"
local wfGradeConf = require "app.configs.wfGrade"
local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"

local WorldFightSeasonRuleWin = class("WorldFightSeasonRuleWin", WinBase)

WorldFightSeasonRuleWin.RESOURCE_FILENAME = "layer/worldFight/seasonRules.csb"

function WorldFightSeasonRuleWin:onCreate()
	self.priority = c.WIN_ZORDER.POPUP
end

function WorldFightSeasonRuleWin:initialView()
	-- 关闭
	UIImageBox.new(self.resourceNode_:getChildByName("closeBtn"),function()
		self:closeSelf()
	end)
	self.resourceNode_:getChildByName("txt_tips"):setString(WordDictionary[23628])
	self:initContent()
end

function WorldFightSeasonRuleWin:initContent()
	local scrollView = self.resourceNode_:getChildByName("scrollView")
	scrollView:setScrollBarEnabled(false)
	local conSize = scrollView:getInnerContainerSize()

	local offset = 5
	local y = 0
	for i = #wfGradeConf, 1, -1 do
		y = y + offset

		local item = self:createGradeItem(wfGradeConf[i])
		item:align(display.BOTTOM_CENTER, conSize.width/2, y)
		scrollView:addChild(item)

		y = y + item:getContentSize().height
	end
	y = y + offset

	if y > conSize.height then
		scrollView:setInnerContainerSize(cc.size(conSize.width, y))
	end
end

function WorldFightSeasonRuleWin:createGradeItem(info)
	local node = cc.CSLoader:createNode("layer/worldFight/seasonRuleNode.csb")
	node:setContentSize(node:getChildByName("sp_bg"):getContentSize())

	local icon = node:getChildByName("sp_icon")
	local currencyConfData = currencyConf[c.CurrencyName.worldFightScore]
	icon:setTexture("icon/medallion/" .. info.icon .. ".png")
	icon:setScale(0.5)
	node:getChildByName("txt_score"):setString(tostring(info.score))
	node:getChildByName("txt_title"):setString(info.name)
	local label = node:getChildByName("Text_1")
	label:setString(string.format(WordDictionary[23667],WordDictionary[24055]))
	local sp_currency = node:getChildByName("sp_currency")
	sp_currency:setTexture("icon/currency/"..currencyConfData.icon..".png")

	local parent = node:getChildByName("node_rewards")
	local x = 0
	local offset = 2
	for _, v in pairs(info.rewards) do
		local item = Helper.createGoodsItem({scale = 0.7,id = v.id,num = v.n})
		local w = item:getContentSize().width * item:getScale()+2
		item:setPositionX(x + w / 2)
		parent:addChild(item)
		x = x + w + offset
	end

	return node
end

function WorldFightSeasonRuleWin:getActionIn()
    Helper.enterWinAction1(self)
end

return WorldFightSeasonRuleWin