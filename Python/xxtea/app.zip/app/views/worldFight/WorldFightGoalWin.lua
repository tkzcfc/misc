
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local WordDictionary = require "app.configs.WordDictionary"
local wfObjvConf = require "app.configs.wfObjv"
local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local SpineManager = require "sandglass.core.SpineManager"
local init = require "app.models.init"
local MoveLabel = require "sandglass.ui.MoveLabel"
local WorldFightModel = init.WorldFightModel

local WorldFightGoalWin = class("WorldFightGoalWin", WinBase)

WorldFightGoalWin.RESOURCE_FILENAME = "layer/worldFight/seasonGoal.csb"

function WorldFightGoalWin:onCreate()
	self.priority = c.WIN_ZORDER.POPUP

	WorldFightModel:sortGoals()

	local msgList = {
        msgids.GS_WfightObjvTakeReward_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function WorldFightGoalWin:initialView()
	-- 关闭
	UIImageBox.new(self.resourceNode_:getChildByName("closeBtn"),function()
		self:closeSelf()
	end)

	self:initContent()
end

function WorldFightGoalWin:initContent()
	self:updateBoxPercent()
	self:updateScrollView()
end

function WorldFightGoalWin:updateBoxPercent()
	local number = 0
	local maxNum = 1
	for idx, v in ipairs(WorldFightModel.boxGoals) do
		local conf = wfObjvConf[v.id]
		if maxNum < conf.p1 then 
			maxNum = conf.p1
		end
		number = v.cnt

		local node = self.resourceNode_:getChildByName("node_cnt_"..idx)
		if node then
			if node:getChildByName("light") then
				node:removeChildByName("light")
			end

			local taken = v.taken
			local btn = UIImageBox.new(node:getChildByName("img"), function()
				if taken then
					MoveLabel.new(WordDictionary[23630])
				elseif number >= conf.p1 then
					network.tcpSend(msgids.C_WfightObjvTakeReward, {Id = conf.id})
				else
					self:openWin("StageBoxWin",nil, conf.rewards)
				end
			end)

			if taken then
				btn:setImage("quest/renwu-baoxiang"..idx.."_open.png", {isPlist = true})
			elseif number >= conf.p1 then
				local light = SpineManager.createAnimation("public/ui_baochuanbeihouguang",1)
				light:playAnimation("idle", -1)
				light:setName("light")
				light:setScale(0.3)
				node:addChild(light, -1)
			end

			local str = number.."/"..conf.p1
			node:getChildByName("txt_tips"):setString(str)
		end
	end

	self.resourceNode_:getChildByName("loadingBar"):setPercent(math.floor(number / maxNum * 100))
end

function WorldFightGoalWin:updateScrollView()
	local listView = self.resourceNode_:getChildByName("listView")
	listView:updateListView(WorldFightModel.goals, function(cacheView,index,data)
		if cacheView == nil then
			cacheView = self:createItem(data, index)
		end
		cacheView:updateView(data)
		return cacheView
    end)
end

function WorldFightGoalWin:createItem(data, index)
	local node = cc.CSLoader:createNode("layer/worldFight/seasonGoalNode.csb")
	local layer = ccui.Layout:create()

	layer.updateView = function(layer,data)
		local conf = wfObjvConf[data.id]
		local itemView = layer:getChildByName("itemView")
		itemView:getChildByName("txt_title"):setString(string.format(conf.des, conf.p1))
		itemView:getChildByName("txt_percent"):setString(data.cnt .. "/" .. conf.p1)
		itemView:getChildByName("loadingBar"):setPercent(math.floor(data.cnt/conf.p1*100))
		itemView:getChildByName("mask"):setVisible(data.taken == true)

		local btn = UIImageBox.new(itemView:getChildByName("btn_get"), function()
			network.tcpSend(msgids.C_WfightObjvTakeReward, {Id = conf.id})
		end,{swallowTouches = false})
		btn:setEnabled(data.finish and (data.taken ~= true))

		if data.taken == true then
			itemView:getChildByName("txt_get"):setString(WordDictionary[23632])
		else
			itemView:getChildByName("txt_get"):setString(WordDictionary[23631])
		end

		for idx, v in ipairs(conf.rewards) do
			local node = itemView:getChildByName("node_reward" .. idx)
			if node then
				node:removeAllChildren()
				local item = Helper.createGoodsItem({scale = 0.7,id = v.id,num = v.n})
				node:addChild(item)
			end
		end
	end

	local size = node:getChildByName("back"):getContentSize()
	layer:setContentSize(cc.size(size.width,size.height+5))
	layer:setAnchorPoint(cc.p(0.5,0))
	layer:addChild(node)
	node:setName("itemView")
	return layer
end

function WorldFightGoalWin:updateTime(str)
	self.resourceNode_:getChildByName("txt_time"):setString(str)
end

function WorldFightGoalWin:receive(op, data)
	if op == msgids.GS_WfightObjvTakeReward_R then
		self:openWin("PublicGetRewardWin",{rewards = data.Rewards})

		local tp = math.floor(data.Id / 1000)
		if tp == 99 then
			self:updateBoxPercent()
		else
			WorldFightModel:sortGoals()
			self:updateScrollView()
		end
	end
end

function WorldFightGoalWin:getActionIn()
    Helper.enterWinAction1(self)
end

return WorldFightGoalWin