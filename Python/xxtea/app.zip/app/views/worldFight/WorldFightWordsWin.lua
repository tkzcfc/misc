local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local WordDictionary = require "app.configs.WordDictionary"
local ui = require "sandglass.ui.ui"
local MoveLabel = require "sandglass.ui.MoveLabel"
local Helper = require "app.Helper"

local WorldFightWordsWin = class("WorldFightWordsWin", WinBase)

WorldFightWordsWin.RESOURCE_FILENAME = "layer/worldFight/worldFightWords.csb"

local max = 6

function WorldFightWordsWin:onCreate()
	self.priority = c.WIN_ZORDER.POPUP
	
	local msgList = {
        msgids.GS_WFightWords_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function WorldFightWordsWin:initialView()
	self.resourceNode_:getChildByName("txt_label"):setString(WordDictionary[23623])

	-- 取消
	self.resourceNode_:getChildByName("txt_cancel"):setString(WordDictionary[20074])
	UIImageBox.new(self.resourceNode_:getChildByName("btn_cancel"),function()
		self:closeSelf()
	end)

    local txt_bg = self.resourceNode_:getChildByName("txt_bg")
	txt_bg:setVisible(false)
	local size = txt_bg:getContentSize()
	local contentText = ui.newEditBox({
	    size = cc.size(size.width,size.height),
	    image = "public/public_slat_04.png",
	})
	contentText:setText("")
	contentText:setPlaceHolder(WordDictionary[23624])
	contentText:setFont(c.NORMALFONT,22)
	contentText:setPlaceholderFont(c.NORMALFONT,22)
	contentText:setMaxLength(20)

	display.align(contentText,display.CENTER,txt_bg:getPositionX(),txt_bg:getPositionY())
	self.resourceNode_:addChild(contentText)


	--确定
    self.resourceNode_:getChildByName("txt_sure"):setString(WordDictionary[20104])
    UIImageBox.new(self.resourceNode_:getChildByName("btn_sure"),function()
		local txt = contentText:getText()
		if not txt or txt == "" then
			MoveLabel.new(WordDictionary[23626])
			return
		end

	    Helper.checkFilterTextBySDK(txt, function(result, newText)
    		if result then
    			network.tcpSend(msgids.C_WFightWords, {Text = newText})
    		else
    			MoveLabel.new(WordDictionary[22208])
    		end
    	end)
	end)
end

function WorldFightWordsWin:receive(op, data)
	MoveLabel.new(WordDictionary[23625])

	local win = self:getScene().winManager:findWinByName("WorldFightWin")
	win:setFightWords(data.Text or "")

	self:closeSelf()
end

function WorldFightWordsWin:getActionIn()
    Helper.enterWinAction1(self)
end

return WorldFightWordsWin