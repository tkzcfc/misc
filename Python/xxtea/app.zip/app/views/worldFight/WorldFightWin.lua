
require "sandglass.ui.UIListView"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local UIImageBox = require "sandglass.ui.UIImageBox"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local wfightConf = require "app.configs.wfight"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local currencyConf = require "app.configs.currency"
local Helper = require "app.Helper"
local roleConf = require "app.configs.role"
local heroConf = require "app.configs.hero"
local skinConf = require "app.configs.skin"
local globalPublicConf = require "app.configs.globalPublic"
local wfGradeConf = require "app.configs.wfGrade"
local msgPack = require "app.network.MessagePack"
local TeamController = require "app.battle.controllers.TeamController"
local MoveLabel = require "sandglass.ui.MoveLabel"
local RichLabel = require "sandglass.ui.RichLabel"
local UILabel = require "sandglass.ui.UILabel"
local WinBase = require "sandglass.core.WinBase"
local init = require "app.models.init"
local PlayerModel = init.PlayerModel
local WorldFightModel = init.WorldFightModel
local RedTipsModel = init.RedTipsModel

local WorldFightWin = class("WorldFightWin", WinBase)

WorldFightWin.RESOURCE_FILENAME = "layer/worldFight/worldFight.csb"

local STAGE_STATE = {
	first = 1,
	pending = 2,
	fighting = 3,
}

local BRIEF_TYPE = {
	my = 1,
	all = 2,
}

local LOOKER_INFO = {
	node_left1 = {name = "monster_white", action = {"idle"}, scale = 0.8, },
	node_left2 = {name = "monster_sumo", action = {"idle"}, scale = 0.8, },
	node_left3 = {name = "monster_swords", action = {"idle"}, scale = 0.8, },
	node_left4 = {name = "monster_pipe", action = {"idle"}, scale = 0.8, },
	node_left5 = {name = "monster_oldman", action = {"idle2"}, scale = 0.8, },
	node_left6 = {name = "monster_ninja", action = {"idle"}, scale = 0.8, },
	node_left7 = {name = "monster_master", action = {"idle"}, scale = 0.8, },
	node_left8 = {name = "monster_katana", action = {"idle"}, scale = 0.8, },
	node_left9 = {name = "monster_ironball", action = {"idle2"}, scale = 0.8, },
	node_right1 = {name = "monster_hat", action = {"idle"}, scale = 0.8, flip = true},
	node_right2 = {name = "monster_oldman", action = {"idle2"}, scale = 0.8, flip = true},
	node_right3 = {name = "monster_gun", action = {"idle"}, scale = 0.8, flip = true},
	node_right4 = {name = "monster_sumo", action = {"idle"}, scale = 0.8, flip = true},
	node_right5 = {name = "monster_fan", action = {"idle"}, scale = 0.8, flip = true},
	node_right6 = {name = "monster_swords", action = {"idle"}, scale = 0.8, flip = true},
	node_right7 = {name = "monster_pipe", action = {"idle"}, scale = 0.8, flip = true},
	node_right8 = {name = "monster_boxer", action = {"idle"}, scale = 0.8, flip = true},
	node_right9 = {name = "monster_assassin", action = {"idle"}, scale = 0.8, flip = true},
}

function WorldFightWin:onCreate(data, sceneData)
	self.sceneData = sceneData or {}
	self.showType = self.WinShowType.canNotClose

	self.state = nil
	self.isMatching = false
	self.curType = nil
	self.seasonTime = 0
	self.data = data
	self.team = json.decode(PlayerConfig.getSetting(PlayerModel.info.userId .. "wfightTeam", "{}")) or {}

	local msgList = {
        msgids.GS_WFightMatched,
        msgids.GS_WFightResult,
        msgids.GS_WFightBriefing,
        msgids.GS_WFightLike_R,
        msgids.GS_WFightDoMatch_R,
        msgids.GS_WFightDismatched,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function WorldFightWin:closeSelf()
	if self.isMatching and self.state == STAGE_STATE.fighting then
		MoveLabel.new(WordDictionary[23606])
		return
	end

	network.tcpSend(msgids.C_WFightLeave, {})

	local data_ = {afterLoading = self.sceneData.afterLoading or Helper.getFromScene(g_lastScene), win = self.sceneData.win, time = 1}
	self:getApp():enterScene("LoadingScene", data_)
end

function WorldFightWin:initialView( ... )
	local moveAction = cc.CSLoader:createTimeline("layer/worldFight/worldFight.csb")
    self.resourceNode_:runAction(moveAction)
    moveAction:play("animation0", false)
    
	local topNode = self.resourceNode_:getChildByName("node_top")
	--返回按钮
	UIImageBox.new(topNode:getChildByName("closeNode"):getChildByName("closeBtn"),function()
		self:closeSelf()
	end)

	--规则
	UIImageBox.new(topNode:getChildByName("btn_rule"), function()
		-- self:openWin("WorldFightRuleWin")
		self:openWin("HelpWin",WordDictionary[22626],WordDictionary[23611])
	end)

	--商店
	UIImageBox.new(topNode:getChildByName("btn_shop"), function()
		self:openWin("ShopWin",11,1)
	end)

	--赛季目标
	UIImageBox.new(topNode:getChildByName("btn_target"), function()
		self.goalWin = self:openWin("WorldFightGoalWin")
		local str = self.resourceNode_:getChildByName("node_season"):getChildByName("txt_time"):getString()
		self.goalWin:updateTime(str)
	end)

	--云特效
	local bgNode = self.resourceNode_:getChildByName("node_bg")
	local moonBg = bgNode:getChildByName("sp_moon")
	local clouds = {}
	local x = 0
	for i = 1, 3 do
		local cloud = display.newSprite("worldFight/quanfuzhengba-yun" .. i .. ".png")
		x = x + cloud:getContentSize().width
		cloud:align(display.RIGHT_BOTTOM, x, -math.random(1, 10))
			:addTo(moonBg)
		table.insert(clouds, cloud)
	end

	moonBg:onUpdate(function(dt)
		local speed = 5
		for idx, cloud in ipairs(clouds) do
			cloud:setPositionX(cloud:getPositionX() - speed * dt)
		end

		local cloud = clouds[1]
		if cloud and cloud:getPositionX() <= 0 then
			cloud:removeFromParent()
			table.remove(clouds, 1)
		end

		local cloud = clouds[#clouds]
		if cloud and cloud:getPositionX() < display.width then
			local cloud = display.newSprite("worldFight/quanfuzhengba-yun" .. math.random(1, 3) .. ".png")
			cloud:align(display.RIGHT_BOTTOM, display.width + cloud:getContentSize().width, -math.random(1, 10))
				:addTo(moonBg)
			table.insert(clouds, cloud)
		end
	end)

	--飞艇
	local spView = bgNode:getChildByName("sp_view")
	local anim = SpineManager.createAnimation("public/ui_feiting",1)
	anim:playAnimation("idle", -1)
	anim:setPosition(545, 300)
	spView:addChild(anim, 1)

	self:refreshState()
	self:onTick()
	self:actionScheduleInterval(handler(self, self.onTick), 1)
end

function WorldFightWin:onEnter()
	self:registerEvent("refreshWorldFightTips")
	RedTipsModel:refreshWorldFightTips()
end

function WorldFightWin:onEventReceive(event)
	local name = event:getEventName()
	local param = event._usedata
	if name == "refreshWorldFightTips" then
		if param.addtips then
			RedTipsModel:addRedTip(self.resourceNode_:getChildByName("node_top"):getChildByName("btn_target"), cc.p(5, 38))
		else
			RedTipsModel:removeRedTip(self.resourceNode_:getChildByName("node_top"):getChildByName("btn_target"))
		end
	end
end

function WorldFightWin:refreshState(showState)
	local bgNode = self.resourceNode_:getChildByName("node_bg")
	bgNode:getChildByName("node_first_view"):setVisible(false)
	bgNode:getChildByName("node_pending"):setVisible(false)
	bgNode:getChildByName("node_fighting"):setVisible(false)
	bgNode:getChildByName("node_looker"):setVisible(false)
	bgNode:getChildByName("sp_podium"):setVisible(false)
	self.resourceNode_:getChildByName("node_bottom"):getChildByName("img_record_bg"):unscheduleUpdate()
	self.resourceNode_:getChildByName("node_bottom"):setVisible(false)
	self.resourceNode_:getChildByName("node_season"):setVisible(false)
	for name, _ in pairs(LOOKER_INFO) do
		bgNode:getChildByName("node_looker"):getChildByName(name):removeAllChildren()
	end
	for i = 1, 3 do
		bgNode:getChildByName("node_first_view"):getChildByName("node"..i):removeChildByName("spine")
		bgNode:getChildByName("node_pending"):getChildByName("node"..i):removeChildByName("spine")
	end

	local curTime = Helper.getFixedTime()
	local curTimeTs = os.date("*t", curTime)
	local openHour, openMinute = self:getTimeFromString(wfightConf[1].openTime)
	local closeHour, closeMinute = self:getTimeFromString(wfightConf[1].closeTime)
	local todayOpen = false
	for k,v in ipairs(wfightConf[1].wdays) do
	    if v + 1 == curTimeTs.wday then
			self.openTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = openHour, min = openMinute, sec = 0})
			self.closeTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day, hour = closeHour, min = closeMinute, sec = 0})
			self.deadline = curTime
			todayOpen = true
	        break
	    end
	end

	local function getNextOpenDay()
		local addDay = 0
		for i = 1,7 do
			addDay = i
			local wday = curTimeTs.wday + addDay
			if wday > 7 then
				wday = wday - 7
			end
			local thisDayOpen = false
			for k,v in ipairs(wfightConf[1].wdays) do
				if v + 1 == wday then
					thisDayOpen = true
					break
				end
			end
			if thisDayOpen == true then
				break
			end
		end
		return addDay
	end


	if not todayOpen then
		local addDay = getNextOpenDay()
		self.openTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day + addDay, hour = openHour, min = openMinute, sec = 0})
		self.closeTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day + addDay, hour = closeHour, min = closeMinute, sec = 0})
		self.deadline = curTime
	end

	-- 赛季结束时间
	local finishTime = self.closeTime
	if curTimeTs.wday ~= 1 then
		local day = 8 - curTimeTs.wday
		finishTime = finishTime + day * 24 * 60 * 60
	end
	if finishTime < curTime then
		finishTime = finishTime + 7 * 24 * 60 * 60
	end
	self.seasonTime = finishTime - curTime

	if curTime >= self.openTime and curTime <= self.closeTime then
		self.state = STAGE_STATE.fighting
		self.deadline = self.closeTime
	else
		if not self.data.Rows or table.nums(self.data.Rows) <= 0 then
			self.state = STAGE_STATE.first
		else
			self.state = STAGE_STATE.pending
		end

		if curTime < self.openTime then
			self.deadline = self.openTime
		else
			local addDay = getNextOpenDay()
			local openTime = os.time({year = curTimeTs.year, month = curTimeTs.month, day = curTimeTs.day + addDay, hour = openHour, min = openMinute, sec = 0})
			self.deadline = openTime
		end
	end

	if not tolua.isnull(self.firework) then
		self.firework:removeFromParent()
	end

	if self.state ~= STAGE_STATE.fighting then
		local spView = self.resourceNode_:getChildByName("node_bg"):getChildByName("sp_view")
		local pos = spView:convertToNodeSpace(cc.p(display.cx, display.cy))
		local effect = SpineManager.createAnimation("public/ui_zhengba_yanhua",1)
	    effect:playAnimation("idle", -1)
	    effect:setPosition(pos)
		spView:addChild(effect)
		self.firework = effect
	end

	if self.state == STAGE_STATE.first then
		self:firstTimeView()
	elseif self.state == STAGE_STATE.pending then
		self:pendingView()
	elseif self.state == STAGE_STATE.fighting then
		self:fightingView()
	end

	-- 赛季
	self:updateSeasonInfo()

	if showState then
		local name = "layer/worldFight/worldFightState.csb"
		local csb = cc.CSLoader:createNode(name)
		self:addChild(csb)

		if self.state == STAGE_STATE.fighting then
			csb:getChildByName("node_state"):getChildByName("sp_finish"):setVisible(false)
		else
			csb:getChildByName("node_state"):getChildByName("sp_start"):setVisible(false)
		end

		local action = cc.CSLoader:createTimeline(name)
	    csb:runAction(action)

	    csb:runAction(
	    	cc.Sequence:create(
	    		cc.CallFunc:create(function()
			    	action:play("animation0", false)
	    		end),
	    		cc.DelayTime:create(3),
	    		cc.CallFunc:create(function()
			    	action:play("animation1", false)
	    		end),
	    		cc.DelayTime:create(1.5),
	    		cc.RemoveSelf:create()
	    	)
	    )
	end
end

function WorldFightWin:firstTimeView()
	self.resourceNode_:getChildByName("node_top"):getChildByName("txt_title"):setString(WordDictionary[23600])

	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_first_view")
	parent:setVisible(true)

	local info = {
		node1 = {name = "glaze", action = {"idle", "win"}, scale = 1, skin = "upgrade2"},
		node2 = {name = "monster_mine", action = {"idle2"}, scale = 0.8},
		node3 = {name = "monster_mine", action = {"idle2"}, scale = 0.8, flip = true},
	}

	for nodeName, value in pairs(info) do
		local anim = self:createLookerAnim(value)
		local node = parent:getChildByName(nodeName)
		node:removeAllChildren()
		anim:setName("spine")
		node:addChild(anim)
	end

	self:updateLookers()
	self:updateStageTips()
end

function WorldFightWin:pendingView()
	self.resourceNode_:getChildByName("node_season"):setVisible(true)
	self.resourceNode_:getChildByName("node_top"):getChildByName("txt_title"):setString(WordDictionary[23600])

	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_pending")
	parent:setVisible(true)

	--发言
	UIImageBox.new(parent:getChildByName("btn_speak"), function()
		self:openWin("WorldFightWordsWin")
	end)
	parent:getChildByName("btn_speak"):setVisible(false)
	for _, row in pairs(self.data.Rows) do
		if row.Name == PlayerModel.info.name then
			parent:getChildByName("btn_speak"):setVisible(true)
			break
		end
	end

	local rows = self.data.Rows or {}
	for i = 1, 3 do
		local node = parent:getChildByName("node"..i)
		local info = rows[i]
		node:setVisible(info ~= nil)

		if info then
			node:getChildByName("txt_name"):setString(info.Name or "")
			node:getChildByName("txt_cnt"):setString(tostring(info.LikedCnt or ""))
			local beatCntTxt = node:getChildByName("txt_beat_cnt")
			beatCntTxt:setString(tostring(info.ComboMax or ""))
			node:getChildByName("txt_zi"):setPositionX(beatCntTxt:getPositionX() + beatCntTxt:getContentSize().width)

			--英雄spine
			node:removeChildByName("spine")
			local role = heroConf[info.Hero.Id].role
			local anim = SpineManager.createAnimation("spine/actors/" .. roleConf[role].spine)
			anim:registerSkin(skinConf[info.Hero.Skin or 1].spineName)
			anim:playAnimation("idle", -1)
			anim:setName("spine")
			anim:setScale(0.8)
			anim:setPositionY(20)
			node:addChild(anim)

			local effect = SpineManager.createAnimation("public/ui_zhengba_mingciguangxiao", 1)
			effect:playAnimation("idle_"..i, -1)
			anim:addChild(effect)
			
			local rank = i
			local btn = node:getChildByName("btn_worship")
			UIImageBox.new(btn, function()
				network.tcpSend(msgids.C_WFightLike, {Rk = rank}, {lockScreen = true,view = self})
			end)
			btn:setVisible(not self.data.Liked)

			node:removeChildByName("anniuEffect")
			local effect = SpineManager.createAnimation("public/ui_rjzb_mobaianniu", 1)
			effect:playAnimation("idle", -1)
			effect:setName("anniuEffect")
			local size = btn:getContentSize()
			effect:setPosition(size.width * 0.5, size.height * 0.5)
			btn:addChild(effect)
		end
	end

	self:updateLookers()
	self:updateStageTips()
end

function WorldFightWin:fightingView()
	self.resourceNode_:getChildByName("node_top"):getChildByName("txt_title"):setString(WordDictionary[23601])
	self.resourceNode_:getChildByName("node_bg"):getChildByName("sp_podium"):setVisible(true)
	self.resourceNode_:getChildByName("node_bg"):getChildByName("node_looker"):setVisible(true)
	self.resourceNode_:getChildByName("node_bg"):getChildByName("node_fighting"):setVisible(true)
	self.resourceNode_:getChildByName("node_season"):setVisible(true)

	local nodeBottom = self.resourceNode_:getChildByName("node_bottom")
	nodeBottom:setVisible(true)

	--个人信息
	self:updatePlayerInfo()

	--阵容调整
	UIImageBox.new(nodeBottom:getChildByName("btn_team"), handler(self, self.onClickSetTeam))

	--我的战报
	local curTimeTs = os.date("*t",Helper.getFixedTime())
	local key = PlayerModel.info.userId.."_brief"
	local briefs = json.decode(PlayerConfig.getSetting(key, "{}")) or {}
	local timestamp = curTimeTs.year..curTimeTs.month..curTimeTs.day
	briefs = briefs[timestamp] or {}
	local listView = nodeBottom:getChildByName("brief_my")
	listView:updateListView(briefs, function(_,index,data)
		local txt = self:getBriefTxt(data)
		local item = self:createBrief(txt)
		return item
	end)
	UIImageBox.new(nodeBottom:getChildByName("btn_my"), function()
		self:onClickBrief(BRIEF_TYPE.my)
	end)

	--所有战报
	self.myFightInfo = {}
	self.cachedFightBriefs = {}
	self.cachedBriefs = {}
	self.cachedLookers = {}
	self.briefLabels = {}
	for _, brief in pairs(WorldFightModel.briefs) do
		table.insert(self.cachedBriefs, self:getBriefTxt(brief))

		for _, info in pairs(brief.Briefs) do
			self:addFightLooker(info)
		end
	end

	self.pullRowDt = 0
	self.pullLookerDt = 1
	nodeBottom:getChildByName("img_record_bg"):onUpdate(handler(self, self.update))
	UIImageBox.new(nodeBottom:getChildByName("btn_all"), function()
		self:onClickBrief(BRIEF_TYPE.all)
	end)
	self:onClickBrief(BRIEF_TYPE.all)

	--参战
	local joinBtn = nodeBottom:getChildByName("btn_join")
	UIImageBox.new(joinBtn, handler(self, self.onClickFight))

	joinBtn:removeAllChildren()

    local anim = SpineManager.createAnimation("public/ui_zhengba_pipeitiao", 1)
    anim:setPosition(joinBtn:getContentSize().width * 0.5, joinBtn:getContentSize().height * 0.5 + 2)
    anim:playAnimation("idle", -1)
	joinBtn:addChild(anim)

	local progress = cc.ProgressTimer:create(display.newSprite("#worldFight/quanfuzhengba-anniu2.png"))
	progress:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
	progress:setReverseDirection(true)
    progress:setPercentage(100)
    self.progress = progress

    progress:setPosition(joinBtn:getContentSize().width * 0.5, joinBtn:getContentSize().height * 0.5+3)
    joinBtn:addChild(progress)



    --领奖台
	self:updateRankRows(self.data.Rows)
end

function WorldFightWin:addFightLooker(info)
	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_looker")
	local unusedKeys = {}
	local usedKeys = {}
	for name, _ in pairs(LOOKER_INFO) do
		local node = parent:getChildByName(name)
		local anim = node:getChildByName("spine")

		if not anim then
			table.insert(unusedKeys, name)
		elseif anim.uid ~= info.Id and anim.uid ~= PlayerModel.info.userId then
			table.insert(usedKeys, name)
		else
			return
		end
	end

	local name = nil
	if #unusedKeys > 0 then
		name = unusedKeys[math.random(1, #unusedKeys)]
	elseif #usedKeys > 0 then
		name = usedKeys[math.random(1, #usedKeys)]
	end

	if not name then
		return
	end

	local node = parent:getChildByName(name)
	node:removeAllChildren()

	local appearAnim = SpineManager.createAnimation("spine/effect/common_heroappear")
    appearAnim:playAnimation("idle", 1)
    appearAnim:setAutoRemove(true)
	node:addChild(appearAnim, 1)

	local value = LOOKER_INFO[name]
	local role = heroConf[info.Hero.Id].role
	local anim = SpineManager.createAnimation("spine/actors/" .. roleConf[role].spine)
	anim:registerSkin(skinConf[info.Hero.Skin or 1].spineName)
	anim:playAnimation("idle", -1)
	anim:setName("spine")
	anim:setScale(value.scale or 1)
	if value.flip then
		anim:setScaleX(-1 * anim:getScaleX())
	end
	anim.uid = info.Id
	node:addChild(anim)

	local color = cc.c3b(255,228,165)
	if info.Id == PlayerModel.info.userId then
		color = cc.c3b(146,253,32)
	end
	local nameLabel = UILabel.new({
    	text = info.Name or "",
    	size = 16,
    	color = color,
    	back = cc.c3b(0,0,0),
    })
    if value.flip then
    	nameLabel:setScaleX(-1 * nameLabel:getScaleX())
    end
    anim:addChildFollowBone("hp_point",nameLabel)
end

function WorldFightWin:removeFightLooker(uid)
	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_looker")
	for name, _ in pairs(LOOKER_INFO) do
		local node = parent:getChildByName(name)
		local anim = node:getChildByName("spine")
		if anim and anim.uid == uid then
			anim:removeFromParent()
			break
		end
	end
end

function WorldFightWin:updateRankRows(data)
	local rows = data or {}
	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("sp_podium")
	for i = 1, 3 do
		local node = parent:getChildByName("node"..i)
		local info = rows[i]
		node:setVisible(info ~= nil)

		if info then
			node:getChildByName("txt_name"):setString(info.Name or "")
			local beatCntTxt = node:getChildByName("txt_beat_cnt")
			beatCntTxt:setString(tostring(info.ComboMax or ""))
			node:getChildByName("txt_zi"):setPositionX(beatCntTxt:getPositionX() + beatCntTxt:getContentSize().width)

			local anim = node:getChildByName("spine")
			if anim == nil or anim.name ~= info.Name then
				node:removeChildByName("spine")

				local disappearAnim = SpineManager.createAnimation("spine/effect/common_heroappear")
    			disappearAnim:playAnimation("idle", 1)
			    disappearAnim:setAutoRemove(true)
			    node:addChild(disappearAnim)

				--英雄spine
				local role = heroConf[info.Hero.Id].role
				local anim = SpineManager.createAnimation("spine/actors/" .. roleConf[role].spine)
				anim:registerSkin(skinConf[info.Hero.Skin or 1].spineName)
				anim:playAnimation("idle", -1)
				anim:setName("spine")
				anim:setScale(0.8)
				anim.name = info.Name
				node:addChild(anim, -1)

				local effect = SpineManager.createAnimation("public/ui_zhengba_mingciguangxiao", 1)
				effect:playAnimation("idle_"..i, -1)
				anim:addChild(effect)
			end
		end
	end
end

function WorldFightWin:updateSeasonInfo()
	local data = self.data.PlrWData or {}
	local score = data.Score or 0
	local node = self.resourceNode_:getChildByName("node_season")
	node:getChildByName("txt_score"):setString(tostring(score))
	local currencyConfData = currencyConf[c.CurrencyName.worldFightScore]
	node:getChildByName("Text_5"):setString(string.format(WordDictionary[23668],currencyConfData.name))
	local sp_currency = node:getChildByName("sp_currency")
	sp_currency:setTexture("icon/currency/"..currencyConfData.icon..".png")

	-- 段位
	local index = #wfGradeConf
	for idx, v in ipairs(wfGradeConf) do
		if score >= v.score then
			index = idx
			break
		end
	end
	local info = wfGradeConf[index]
	local icon = node:getChildByName("sp_grade")
	icon:setTexture("icon/medallion/" .. info.icon .. ".png")
	icon:setScale(0.4)
	
	node:getChildByName("txt_title"):setString(info.name)

    --奖励
    local parent = node:getChildByName("node_rewards")
	local x = 0
	local offset = 2
	for _, v in pairs(info.rewards) do
		local item = Helper.createGoodsItem({scale = 0.4,id = v.id,num = v.n})
		local w = item:getContentSize().width * item:getScale()
		item:setPositionX(x + w / 2)
		parent:addChild(item)
		x = x + w + offset
	end

	--问号
	UIImageBox.new(node:getChildByName("btn_explain"), function()
		self:openWin("WorldFightSeasonRuleWin")
	end)
end

function WorldFightWin:updatePlayerInfo()
	local plrInfo = self.data.PlrInfo or {}
	local nodeBottom = self.resourceNode_:getChildByName("node_bottom")
	nodeBottom:getChildByName("txt_max_win"):setString(plrInfo.ComboMax or 0)
	nodeBottom:getChildByName("txt_win"):setString(plrInfo.Win or 0)
	nodeBottom:getChildByName("txt_lose"):setString(plrInfo.Lose or 0)

	local limit = wfightConf[1].contWinWeakTimesLimit
	local combo = plrInfo.Combo or 0
	nodeBottom:getChildByName("txt_cur_win"):setString(combo)
	local txtAttr = nodeBottom:getChildByName("txt_attr")

	if combo > limit then
		combo = limit
	end
	combo = combo - wfightConf[1].contWinLimit
	txtAttr:setVisible(combo > 0)
	if combo > 0 then
		local attack, defense = 0, 0
		for _, v in pairs(wfightConf[1].contWinWeak) do
			if v.attr == 10 then
				attack = attack + v.n
			elseif v.attr == 11 then
				defense = defense + v.n
			end
		end
		attack = math.floor(math.abs(attack) * combo * 100)
		defense = math.floor(math.abs(defense) * combo * 100)
		txtAttr:setString(string.format(WordDictionary[23604], attack, defense))
	end
end

function WorldFightWin:updateJoinBtn()
	local nodeBottom = self.resourceNode_:getChildByName("node_bottom")
	local txtPosY = 24.35
	local bgPosY = 27.96
	local offset = 0

	if self.isMatching then
		nodeBottom:getChildByName("txt_join"):setString(WordDictionary[23603])
		offset = 150
	else
		nodeBottom:getChildByName("txt_join"):setString(WordDictionary[23602])
	end

	nodeBottom:getChildByName("txt_join"):setPositionY(txtPosY + offset)
	nodeBottom:getChildByName("sp_txt_bg"):setPositionY(bgPosY + offset)
	nodeBottom:getChildByName("btn_team"):setVisible(not self.isMatching)

	self.progress:stopAllActions()
	self.progress:setPercentage(100)
	if self.isMatching then
		self.progress:runAction(cc.ProgressTo:create(wfightConf[1].quitMatch or 30, 5))
	end
end

function WorldFightWin:onTick()
	local curTime = Helper.getFixedTime()
	local seconds = self.deadline - curTime

	local refresh = (seconds < 0)
	if refresh then
		seconds = 0
	end
	local label = self.resourceNode_:getChildByName("node_top"):getChildByName("txt_time")
	label:setString(Helper.getTimeString(seconds,true))

	self.seasonTime = self.seasonTime - 1
	if self.seasonTime < 0 then
		self.seasonTime = 0
	end
	local str = Helper.getTimeString(self.seasonTime, true)
	self.resourceNode_:getChildByName("node_season"):getChildByName("txt_time"):setString(str)
	if not tolua.isnull(self.goalWin) then
		self.goalWin:updateTime(str)
	end

	if refresh then
		self:refreshState(true)
	end
end

function WorldFightWin:getTimeFromString(str)
	local info = string.split(str, ":")
	return tonumber(info[1]), tonumber(info[2])
end

function WorldFightWin:receive(op, data)
	if op == msgids.GS_WFightResult then
		self.myFightInfo["result"] = data
	elseif op == msgids.GS_WFightDismatched then
		self.isMatching = false
		self:updateJoinBtn()
		self:removeFightLooker(PlayerModel.info.userId)
		MoveLabel.new(WordDictionary[23607])
	elseif op == msgids.GS_WFightLike_R then
		local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_pending")
		for i = 1, 3 do
			local node = parent:getChildByName("node"..i)
			node:getChildByName("btn_worship"):setVisible(false)

			if i == data.Rk then
				local label = node:getChildByName("txt_cnt")
				local cnt = tonumber(label:getString()) + 1
				label:setString(tostring(cnt))
			end
		end
		self.data.Liked = true
		Helper.receiveReward({rewards = data.Rewards})

		local effect = SpineManager.createAnimation("public/ui_caidai", 1)
		effect:playAnimation("idle", 1)
		effect:setAutoRemove(true)
		effect:setPosition(display.cx, display.cy)
		self:addChild(effect)

		network.tcpSend(msgids.C_WFightEnter, {})
	elseif op == msgids.GS_WFightBriefing then
		self:recieveFightBrief(data)
	elseif op == msgids.GS_WFightDoMatch_R then
		local heroId = 20012
		for idx = 1, 5 do
			if self.team[idx] ~= nil then
				heroId = self.team[idx]
				break
			end
		end
		self:addFightLooker({
			Id = PlayerModel.info.userId,
			Hero = {
				Id = heroId,
			},
			Name = PlayerModel.info.name,
		})

		self.isMatching = true
		self:updateJoinBtn()
	end
end

function WorldFightWin:setDefenderTeam(heroIds)
	self.team = heroIds
	PlayerConfig.setSetting(PlayerModel.info.userId .. "wfightTeam", json.encode(self.team))
end

function WorldFightWin:onClickFight()
	if self.isMatching then
		MoveLabel.new(WordDictionary[23605])
		return
	end

	if table.nums(self.team) <= 0 then
		self:onClickSetTeam()
		return
	end

	local team = {}
	for idx = 1, 5 do
		team[idx] = self.team[idx] or 0
	end
	network.tcpSend(msgids.C_WFightDoMatch, {Team = team}, {lockScreen = true, view = self})
end

function WorldFightWin:onClickSetTeam()
	self:openWin("EmbattleWin",{heroIds = self.team, fightStatus = c.FightStatus.selectHero, winName = self:getName()})
end

function WorldFightWin:onClickBrief(bType)
	if self.curType == bType then
		return
	end

	self.curType = bType
	local nodeBottom = self.resourceNode_:getChildByName("node_bottom")

	for name, t in pairs(BRIEF_TYPE) do
		local btn = nodeBottom:getChildByName("btn_"..name)
		local txt = btn:getChildByName("txt_"..name)
		local view = nodeBottom:getChildByName("brief_"..name)
		view:setVisible(t == self.curType)
		if t == self.curType then
			btn:loadTexture("worldFight/quanfuzhengba-yeka2.png",ccui.TextureResType.plistType)
			txt:setTextColor(cc.c3b(255,255,255))
		else
			btn:loadTexture("worldFight/quanfuzhengba-yeka1.png",ccui.TextureResType.plistType)
			txt:setTextColor(cc.c3b(176,172,171))
		end
	end
end

function WorldFightWin:getBriefTxt(data)
	local function getName(brief)
		if brief.Id == PlayerModel.info.userId then
			return WordDictionary[23608]
		else
			return brief.Name
		end
	end

	local txt = ""
	if data.Win ~= 1 and data.Win ~= 2 then
		txt = string.format(WordDictionary[23649], getName(data.Briefs[1]), getName(data.Briefs[2]), data.Briefs[1].Score, data.Briefs[2].Score)
	else
		local winIdx = data.Win
		local loseIdx = (data.Win == 1) and 2 or 1

		if data.Briefs[loseIdx].Combo > 1 then
			txt = string.format(WordDictionary[23648], getName(data.Briefs[winIdx]), getName(data.Briefs[loseIdx]), data.Briefs[loseIdx].Combo, data.Briefs[winIdx].Score)
		elseif data.Briefs[winIdx].Combo > 1 then
			txt = string.format(WordDictionary[23647], getName(data.Briefs[winIdx]), getName(data.Briefs[loseIdx]), data.Briefs[winIdx].Combo, data.Briefs[winIdx].Score)
		else
			txt = string.format(WordDictionary[23646], getName(data.Briefs[winIdx]), getName(data.Briefs[loseIdx]), data.Briefs[winIdx].Score)
		end
	end

	return txt
end

function WorldFightWin:recieveFightBrief(data)
	if self.state ~= STAGE_STATE.fighting then
		return
	end

	local isMyBrief = false
	for idx, brief in pairs(data.Briefs) do
		if brief.Id == PlayerModel.info.userId then
			isMyBrief = true
			break
		end
	end

	local txt = self:getBriefTxt(data)

	if isMyBrief then
		self.myFightInfo["fightBriefs"] = data
		self:saveMyBrief(data)
	else
		table.insert(self.cachedBriefs, 1, txt)
		while(#self.cachedBriefs > 100) do
			table.remove(self.cachedBriefs, #self.cachedBriefs)
		end

		table.insert(self.cachedFightBriefs, 1, data)
		while(#self.cachedFightBriefs > 100) do
			table.remove(self.cachedFightBriefs, #self.cachedFightBriefs)
		end
	end

	for _, brief in pairs(data.Briefs) do
		if brief.Id ~= PlayerModel.info.userId then
			table.insert(self.cachedLookers, 1, brief)
		end
	end

	while(#self.cachedLookers > 20) do
		table.remove(self.cachedLookers, #self.cachedLookers)
	end
end

function WorldFightWin:saveMyBrief(data)
	local curTimeTs = os.date("*t",Helper.getFixedTime())
	local timestamp = curTimeTs.year..curTimeTs.month..curTimeTs.day
	local key = PlayerModel.info.userId.."_brief"
	local briefs = json.decode(PlayerConfig.getSetting(key, "{}")) or {}

	--删除其他日期记录
	for _, k in pairs(table.keys(briefs)) do
		if k ~= timestamp then
			briefs[k] = nil
		end
	end

	briefs[timestamp] = briefs[timestamp] or {}
	table.insert(briefs[timestamp], 1, data)
	while(#briefs[timestamp] > 50) do
		table.remove(briefs[timestamp], #briefs[timestamp])
	end
	PlayerConfig.setSetting(key, json.encode(briefs))

	return true
end

function WorldFightWin:scrollAllBriefs(dt)
	local speed = 15
	local maxCnt = 20
	local scrollView = self.resourceNode_:getChildByName("node_bottom"):getChildByName("brief_all")
	local size = scrollView:getContentSize()

	if #self.briefLabels < maxCnt and #self.cachedBriefs > 0 then
		local label = self:createBrief(self.cachedBriefs[#self.cachedBriefs])
		table.remove(self.cachedBriefs, #self.cachedBriefs)

		local y = 0
		local lastLabel = self.briefLabels[1]
		if lastLabel then
			y = lastLabel:getPositionY()
		end
		label:align(display.LEFT_BOTTOM, 0, y - label:getContentSize().height)
			:addTo(scrollView)
		table.insert(self.briefLabels, 1, label)
	end

	local lastLabel = self.briefLabels[1]
	if lastLabel then
		local y = lastLabel:getPositionY() + speed * dt
		if y > 0 then
			y = 0
		end
		local dis = y - lastLabel:getPositionY()

		for idx = #self.briefLabels, 1, -1 do
			local label = self.briefLabels[idx]
			local y = label:getPositionY() + dis
			label:setPositionY(y)

			if y > size.height then
				label:removeFromParent()
				table.remove(self.briefLabels, idx)
			end
		end
	end
end

function WorldFightWin:createBrief(txt)
	local widget = ccui.Widget:create()
	local x, y = 13, 5

	local line = display.newSprite("#worldFight/quanfuzhengba-fenxian1.png", 0, 0, {scale9 = true, size = cc.size(470,2)})
	line:align(display.LEFT_BOTTOM, 13, y)
		:addTo(widget)

	y = y + line:getContentSize().height

	local label = RichLabel.new({
		fontSize = 16,
		maxWidth = 470,
	})
	label:setString(txt)
	label:align(display.LEFT_BOTTOM, x, y)
		:addTo(widget)

	y = y + label:getContentSize().height

	widget:setContentSize(cc.size(496, y))
	return widget
end

function WorldFightWin:updateFightStage(dt)
	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_fighting")

	--有正在播放的战斗
	if parent:getChildByName("node1"):getChildrenCount() > 0 or parent:getChildByName("node2"):getChildrenCount() > 0 then
		return
	end

	--自己的战斗优先展示
	local fightBriefs = self.myFightInfo["fightBriefs"]
	local result = self.myFightInfo["result"]
	if fightBriefs and result then
		self.myFightInfo = {}
		self:createFightPreview(fightBriefs, result)
		return
	end

	--其他战斗展示
	local info = self.cachedFightBriefs[#self.cachedFightBriefs]
	if info then
		table.remove(self.cachedFightBriefs, #self.cachedFightBriefs)
		self:createFightPreview(info)
	end
end

function WorldFightWin:createFightPreview(fightBriefs, result)
	local parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_fighting")

	for idx, brief in pairs(fightBriefs.Briefs) do
		local node = parent:getChildByName("node"..idx)
		node:removeAllChildren()

		local showAnim = SpineManager.createAnimation("public/ui_choukashilian_chuchang",1)
	    showAnim:playAnimation("idle", 1)
	    showAnim:setAutoRemove(true)
		node:addChild(showAnim, 1)
		showAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
	        if eventName == "trigger" then
	        	local anim = self:createHeroAnim(brief)
				anim:playAnimation("idle", -1)
				anim:setName("spine")
				anim:setScale(0.8)
				node:addChild(anim)

				local nameLabel = UILabel.new({
			    	text = brief.Name or "",
			    	size = 14,
			    	color = cc.c3b(255,228,165),
			    	back = cc.c3b(0,0,0),
			    })
			    anim:addChildFollowBone("hp_point",nameLabel)

			    if idx == 2 then
					anim:setScaleX(-1 * anim:getScaleX())
					nameLabel:setScaleX(-1 * nameLabel:getScaleX())
				end
	        end
        end)
	end

	local action = cc.Sequence:create(
		cc.DelayTime:create(1),
		cc.CallFunc:create(function()
			if result ~= nil then
				self.progress:stopAllActions()
				self.progress:runAction(cc.ProgressTo:create(0.3, 0))

				parent:runAction(
					cc.Sequence:create(
						cc.DelayTime:create(0.3),
						cc.CallFunc:create(function()
							local data = result
							local replay = msgPack.unpack(data.Replay)
							local value = TeamController.getDataFromServer(replay.T)
							value.params.fightStatus = c.FightStatus.worldFight
							value.params.seed = replay.Seed
							value.params.isWin = data.IsWin
							value.params.rewards = data.Rewards
							value.params.bg = globalPublicConf[1].wFightBackground
							value.params.isReplay = true
							value.params.bgMusic = {"array_bg_01.mp3"}--背景音乐
							value.params.afterLoading = Helper.getFromScene()
							self:getApp():enterScene("GameScene", value)
						end)
					)
				)
				return
			end

			local node1 = parent:getChildByName("node1")
			local anim1 = node1:getChildByName("spine")
			anim1:setVisible(false)
			local node2 = parent:getChildByName("node2")
			local anim2 = node2:getChildByName("spine")
			anim2:setVisible(false)

			local fightAnim = SpineManager.createAnimation("public/ui_zhengba_zhandou",1)
		    fightAnim:playAnimation("idle", 1)
		    fightAnim:setAutoRemove(true)
		    fightAnim:setPosition( (node1:getPositionX()+node2:getPositionX())/2, (node1:getPositionY()+node2:getPositionY())/2+40 )
			parent:addChild(fightAnim, 1)
			fightAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
		        if eventName == "trigger" then
		        	anim1:setVisible(true)
		        	anim2:setVisible(true)

		        	if fightBriefs.Win == 1 then
		        		anim1:playAnimation("win", -1)
		        	else
		        		anim1:playAnimation("die", 1)
		        	end

		        	if fightBriefs.Win == 2 then
		        		anim2:playAnimation("win", -1)
		        	else
		        		anim2:playAnimation("die", 1)
		        	end

		        	local brief = fightBriefs.Briefs[fightBriefs.Win]
		        	if brief then
			        	local effect = SpineManager.createAnimation("public/ui_zhengba_lianzhan", 1)
			        	if brief.Combo <= 1 then
				        	effect:playAnimation("idle1", 1)
				        else
				        	local number = self:createComboNumber(brief.Combo)
				        	number:setAnchorPoint(cc.p(0.5, 0.5))
				        	number:setScale(0.65)
				        	effect:addChildFollowSlot("no_point", number)
				        	effect:playAnimation("idle2", 1)
				        end
				        effect:setPositionY(150)
				        effect:setScale(0.75)

				        if fightBriefs.Win == 1 then
				        	node1:addChild(effect)
				        else
				        	node2:addChild(effect)
				        end
			        end

		        	node1:runAction(cc.Sequence:create(
		        		cc.DelayTime:create(2),
		        		cc.CallFunc:create(function(sender)

		        			if fightBriefs.Win == 1 then
			        			sender:removeAllChildren()
			        			local disappearAnim = SpineManager.createAnimation("spine/effect/common_heroappear")
			        			disappearAnim:playAnimation("idle", 1)
							    disappearAnim:setAutoRemove(true)
							    sender:addChild(disappearAnim)
							else
								anim1:runAction(
									cc.Sequence:create(
										cc.FadeOut:create(0.5),
										cc.RemoveSelf:create()
									)
								)
							end
		        		end)
		        	))
		        	node2:runAction(cc.Sequence:create(
		        		cc.DelayTime:create(2),
		        		cc.CallFunc:create(function(sender)
		        			if fightBriefs.Win == 2 then
			        			sender:removeAllChildren()
			        			local disappearAnim = SpineManager.createAnimation("spine/effect/common_heroappear")
			        			disappearAnim:playAnimation("idle", 1)
							    disappearAnim:setAutoRemove(true)
							    sender:addChild(disappearAnim)
							else
								anim2:runAction(
									cc.Sequence:create(
										cc.FadeOut:create(0.5),
										cc.RemoveSelf:create()
									)
								)
							end
		        		end)
		        	))
		        end
	        end)
		end)
	)
	parent:runAction(action)
end

function WorldFightWin:createHeroAnim(info)
	local role = heroConf[info.Hero.Id].role
	local anim = SpineManager.createAnimation("spine/actors/" .. roleConf[role].spine)
	anim:registerSkin(skinConf[info.Hero.Skin or 1].spineName)

	return anim
end

function WorldFightWin:updateFightLookers(dt)
	self.pullLookerDt = self.pullLookerDt + dt

	if self.pullLookerDt > 1 then
		local brief = self.cachedLookers[#self.cachedLookers]
		if brief then
			self:addFightLooker(brief)
			table.remove(self.cachedLookers, #self.cachedLookers)
		end

		self.pullLookerDt = self.pullLookerDt - 1
	end
end

function WorldFightWin:update(dt)
	self:scrollAllBriefs(dt)
	self:updateFightStage(dt)
	self:updateFightLookers(dt)

	self.pullRowDt = self.pullRowDt + dt
	if self.pullRowDt > 5 then
		network.tcpSend(msgids.C_WFightRankCombo, {}, {
			lockScreen = false,
			view = self,
			ops = {msgids.GS_WFightRankCombo_R},
			callback = function(op, data)
				if self.state ~= STAGE_STATE.fighting then
					return
				end

				self.data.Rows = data.Rows
				self:updateRankRows(self.data.Rows)
			end,
		})
		self.pullRowDt = self.pullRowDt - 5
	end
end

---------------------------气泡---------------------------

function WorldFightWin:updateStageTips()
	local parent = nil
	if self.state == STAGE_STATE.first then
		parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_first_view")
	else
		parent = self.resourceNode_:getChildByName("node_bg"):getChildByName("node_pending")
	end

	local index = math.random(1, 3)
	local name = "node".. index
	local node = parent:getChildByName(name)
	local txt = WordDictionary[math.random(23650, 23666)]

	if self.state == STAGE_STATE.pending then
		local row = self.data.Rows[index]
		if not row then
			return
		end

		if row.Words and row.Words ~= "" then
			txt = row.Words
		end
	end

	local tip = self:createTipsNode(txt)
	if self.state == STAGE_STATE.first then
		tip:setPositionY(200)
	else
		tip:setPositionY(250)
	end
	node:addChild(tip)

    tip:setScale(0)
    tip:runAction(
    	cc.Sequence:create(
	    	cc.EaseElasticOut:create(cc.ScaleTo:create(1, 1), 0.4),
    		cc.DelayTime:create(math.random(3, 5)),
    		cc.CallFunc:create(handler(self, self.updateStageTips)),
    		cc.RemoveSelf:create()
    	)
	)
end

function WorldFightWin:setFightWords(txt)
	for _, row in pairs(self.data.Rows) do
		if row.Name == PlayerModel.info.name then
			row.Words = txt
		end
	end
end
---------------------------气泡---------------------------

function WorldFightWin:createComboNumber(number)
	local node = cc.Node:create()
	local format = "worldFight/qfzb-zi-%02d.png"

	local digits = {}
	local scale = 1
	if number >= 100 then
		scale = 0.7
	end

	while number > 0 do
		digits[#digits + 1] = number % 10
		number = math.floor(number / 10)
	end

	if #digits == 0 then
		digits[#digits + 1] = 0
	end

	local x, y = 0, 0
	local offset = 8

	for idx = #digits, 1, -1 do
		local sprite = display.newSprite(string.format(format, digits[idx]))
		display.align(sprite, display.LEFT_BOTTOM, x, (#digits - idx) * 10)
		node:addChild(sprite)
		local size = sprite:getContentSize()
		x = x + size.width - offset

		if size.height + (#digits - idx) * 10 > y then
			y = size.height
		end
	end

	node:setContentSize(cc.size(x, y))
	node:setScale(scale)
	node:setCascadeOpacityEnabled(true)
	return node
end

return WorldFightWin
