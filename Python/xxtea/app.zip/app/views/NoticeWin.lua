-- 公告

local UIImageBox = require "sandglass.ui.UIImageBox"
local network = require "app.network.network"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"

local WinBase = require "sandglass.core.WinBase"
local NoticeWin = class("NoticeWin", WinBase)

NoticeWin.RESOURCE_FILENAME = "login/notice.csb"

function NoticeWin:onCreate(url)
	self.showType = self.WinShowType.normal
	self.url = url
end

function NoticeWin:initialView()
    local style = Helper.getFestivalStyle()
    if style > 0 then
        if self.resourceNode_:getChildByName("festival"..style) then
            self.resourceNode_:getChildByName("festival"..style):setVisible(true)
            self.resourceNode_:getChildByName("bg"):setVisible(false)
        end
    end
	UIImageBox.new(self.resourceNode_:getChildByName("btn"), function()
		self:closeSelf()
	end)
    self.resourceNode_:getChildByName("list_content"):setScrollBarEnabled(false)
	network.httpGet(self.url, handler(self, self.handleNotice))
end

function NoticeWin:handleNotice(xhr)
    if tolua.isnull(self) then
        return
    end
    
	if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
        local data = json.decode(xhr.response)

        --self.resourceNode_:getChildByName("txt_title"):setString(data.title)
        local listView = self.resourceNode_:getChildByName("list_content")
        local size = listView:getContentSize()

		local label = UILabel.new({
			text = data.content,
			color = cc.c3b(162,134,95),
			size = 22,
			dimensions = cc.size(size.width-50,0)
		}):align(display.LEFT_TOP, 0, 0)
		:addTo(listView)

		local lableSize = label:getContentSize()
		listView:setInnerContainerSize(cc.size(size.width, lableSize.height))
		listView:scrollToTop(0.2,true)
    else
        print("NoticeWin handleNotice error. xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
    end
end

function NoticeWin:getActionIn()
     Helper.enterWinAction1(self)
end

return NoticeWin
