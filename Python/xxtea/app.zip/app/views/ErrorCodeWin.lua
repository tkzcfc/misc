--ErrorCodeWin.lua

local c = require "app.configs.constants"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local MoveLabel = require "sandglass.ui.MoveLabel"
local network = require "app.network.network"

local errorCodeConf = require "app.configs.errorcode"
local counterConf = require "app.configs.counter"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"

local ErrorCodeWin = class("ErrorCodeWin", WinBase)

ErrorCodeWin.RESOURCE_FILENAME = "public/errorCode.csb"

function ErrorCodeWin:onCreate(errorCode)
	self.priority = c.WIN_ZORDER.ERROR
	
	self.errorCode = errorCode
	self.shieldLayer_:setVisible(false)
end

function ErrorCodeWin:initialView()
	self.resourceNode_:getChildByName("node_info"):setVisible(false)
	local errorType = 1
	if errorCodeConf[self.errorCode] then
		errorType = errorCodeConf[self.errorCode].codeType
	end
	
	if errorType == 1 then
		self:openTips()
	elseif errorType == 2 then
		self:openWin()
	else
		self:runAction(cc.Sequence:create(
			cc.DelayTime:create(0),
			cc.CallFunc:create(function()
				self:closeSelf()
			end)
		))
	end
end

function ErrorCodeWin:openTips()  --弹tips
	local errorStr = nil
	if self.errorCode > 200000000 then --次数不足错误
		local counterId = self.errorCode % 200000000
		errorStr = counterConf[counterId].errorcode
	elseif self.errorCode > 100000000 then --道具不足错误
		local itemId = self.errorCode % 100000000
		local item = itemConf[itemId] or currencyConf[itemId]
		errorStr = item.errorcode
	elseif errorCodeConf[self.errorCode] then
		errorStr = errorCodeConf[self.errorCode].code
	end
	MoveLabel.new(errorStr or "")
	self:runAction(cc.Sequence:create(
		cc.DelayTime:create(0.5),
		cc.CallFunc:create(function()
			self:closeSelf()
		end)
	))
end

function ErrorCodeWin:openWin()  --弹窗
	self.resourceNode_:getChildByName("node_info"):setVisible(true)
	self.shieldLayer_:setVisible(true)
	self.showType = self.WinShowType.normal

	self.resourceNode_:getChildByName("node_info"):getChildByName("txt_tips"):setString(errorCodeConf[self.errorCode] and errorCodeConf[self.errorCode].code or (WordDictionary[-3] .. self.errorCode))

	UIImageBox.new(self.resourceNode_:getChildByName("node_info"):getChildByName("btn"),function()
		if self.errorCode == -1 or self.errorCode == 102 then --重新登录
			local SDKController = require "app.sdk.SDKController"
			SDKController.logoutGame()
			self:closeSelf()
		else
			self:closeSelf()
		end
	end)
end

function ErrorCodeWin:getActionIn()
    local AudioManager = require "sandglass.core.AudioManager"
	self.resourceNode_:setPositionY(-display.height /2)
	self.resourceNode_:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.6, cc.p(0, 0))))
	AudioManager.playEffect("music/ui_popup05.mp3")
end

return ErrorCodeWin