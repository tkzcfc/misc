
local WinBase = require "sandglass.core.WinBase"
local c = require "app.configs.constants"
local UIImageBox = require "sandglass.ui.UIImageBox"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local Helper = require "app.Helper"
local WordDictionary = require "app.configs.WordDictionary"
local SpineManager = require "sandglass.core.SpineManager"
local heroConf = require "app.configs.hero"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local RichLabel = require "sandglass.ui.RichLabel"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SDKController = require "app.sdk.SDKController"
local ui = require "sandglass.ui.ui"
local exclusivegiftConf = require "app.configs.exclusivegift"
local RedTipsModel = init.RedTipsModel

local ActivityModel = init.ActivityModel
local PlayerModel = init.PlayerModel
local PayModel = init.PayModel
local PushGiftModel = init.PushGiftModel

local VipServerWin = class("VipServerWin", WinBase)
VipServerWin.RESOURCE_FILENAME = "vipServer/vipServer.csb"

function VipServerWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP
    local msgList = {
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function VipServerWin:receive(op, msg)
    
end

function VipServerWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"), function()
        self:closeSelf()
    end)
    local anim = SpineManager.createAnimation("public/ui_cha_zuiniang",1)
    self.resourceNode_:getChildByName("node_spine"):addChild(anim)
    anim:playAnimation("idle", -1)

    local serverImg = self.resourceNode_:getChildByName("img_serveBg")
    for i = 1, 3 do
        serverImg:getChildByName("txt_name"..i):setString(WordDictionary[71410 + i])
        serverImg:getChildByName("txt_des"..i):setString(WordDictionary[71413 + i])
    end

    local inputBg = self.resourceNode_:getChildByName("img_input")
    inputBg:setVisible(false)
    local size = inputBg:getContentSize()
    local inputText = ui.newEditBox({
        size = cc.size(size.width,size.height),
        _image = "vipServer/VIP-di2.png",
    })
    inputText:setFontSize(24)
    inputText:setPlaceholderFontName(c.NORMALFONT)
    inputText:setPlaceholderFontColor(cc.c3b(67,53,41))

    inputText:setFontName(c.NORMALFONT)
    inputText:setFontColor(cc.c3b(239,218,191))
    
    inputText:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)--单行
    inputText:setPlaceHolder("")
    inputText:setInputFlag(2)
    inputText:setText(SDK_PARAMS.vipQQ or WordDictionary[71410])
    display.align(inputText,display.LEFT_CENTER,inputBg:getPositionX(),inputBg:getPositionY())
    inputText:setName("inputText")
    self.resourceNode_:addChild(inputText)
end

function VipServerWin:updateView()
    
end

function VipServerWin:onTabChange(data)
    
end

function VipServerWin:createMenuItem(data)
    
end

function VipServerWin:getActionIn()
     Helper.enterWinAction1(self)
end

return VipServerWin