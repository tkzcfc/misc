local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local MythAnimalConf = require "app.configs.mythAnimal"
local Helper = require "app.Helper"
local SpineManager = require "sandglass.core.SpineManager"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local init = require "app.models.init"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SDKController = require "app.sdk.SDKController"
local UILabel = require "sandglass.ui.UILabel"
local attributeConf = require "app.configs.attribute"
local CoreColor = require "sandglass.core.CoreColor"
local globalPublicConf = require "app.configs.globalPublic"
require "sandglass.ui.UIListView"
require "sandglass.ui.UIGridView"

local MythAnimalWin = class("MythAnimalWin", WinBase)

local PayModel = init.PayModel
local ItemModel = init.ItemModel
local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel

MythAnimalWin.RESOURCE_FILENAME = "layer/mythAnimal/mythAnimal.csb"

function MythAnimalWin:onCreate(data)
    self.curId = 1
    local msgList = {
        msgids.GS_MythAnimalGetInfo_R,
        msgids.GS_MythAnimalAdd_R,
        msgids.GS_MythAnimalBillNew,
        msgids.GS_MythAnimalTakeFree_R,
        msgids.GS_BagUpdate,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_MythAnimalGetInfo) 
end

function MythAnimalWin:initialView()
    self.closeBtn = UIImageBox.new(self.resourceNode_:getChildByName("node_close"):getChildByName("closeBtn"),function()
        self:closeSelf()
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_explain"), function()
        self:openWin("HelpWin",WordDictionary[24001],WordDictionary[26209])
    end)

    for i = 1, 3 do
        self.resourceNode_:getChildByName("btn_monster"..i):getChildByName("txt_name"):setString(MythAnimalConf[i * 100].name)
        UIImageBox.new(self.resourceNode_:getChildByName("btn_monster"..i), function()
            self:onChangeTab(i)
        end)
    end

    UIImageBox.new(self.resourceNode_:getChildByName("btn_left"), function()
        self.curShowLevel = self.curShowLevel - 1
        if self.curShowLevel <= 0 then
            if self.data[self.curId].Lv == 0 then
                self.curShowLevel = 0
            else
                self.curShowLevel = 1
            end
            return
        end
        self:onChangeTab(self.curId, self.curShowLevel, true)
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_right"), function()
        self.curShowLevel = self.curShowLevel + 1
        if self.curShowLevel == 1 then
            self.curShowLevel = 2
        end
        if self.curShowLevel > 5 then
            self.curShowLevel = 5
            return
        end
        self:onChangeTab(self.curId, self.curShowLevel, true)
    end)

    local num_ = globalPublicConf[1].ssZhanli[4]
    local numStr = tostring(num_)
    for i=1,3 do
        local str_ = string.sub(numStr, i, i)
        local sp_num = self.resourceNode_:getChildByName("node_shop"):getChildByName("node_power"):getChildByName("sp_num_"..i)
        if str_ and string.len(str_) > 0 then
            sp_num:setVisible(true)
            sp_num:setSpriteFrame("mythAnimal/yaoshou-shuzi"..str_..".png")
        else
            sp_num:setVisible(false)
        end      
    end

    -- local percentAnim = SpineManager.createAnimation("public/ui_renwuyangcheng_juexingshuiqiu",1)
    -- percentAnim:playAnimation("idle", -1)
    -- local clipNode = cc.ClippingNode:create(display.newSprite("list/juexing-zhezhao.png"))
    -- clipNode:setAlphaThreshold(0.5)
    -- clipNode:addChild(percentAnim)
    -- percentAnim:setPosition(cc.p(0, -115))
    -- percentAnim:setName("percentAnim")
    -- self.resourceNode_:getChildByName("node_culture"):getChildByName("img_decBg"):addChild(clipNode)
    -- clipNode:setName("clipNode")
    -- local size = self.resourceNode_:getChildByName("node_culture"):getChildByName("img_decBg"):getContentSize()
    -- clipNode:setPosition(cc.p(size.width/2, size.height/2))
end

function MythAnimalWin:onChangeTab(id, level, force, playEffect)
    if self.curId and self.curId == id and not force then
        return
    end
    self.curId = id

    local posY = self.resourceNode_:getChildByName("btn_monster"..self.curId):getPositionY()
    self.resourceNode_:getChildByName("img_select"):setVisible(true)
    self.resourceNode_:getChildByName("img_select"):setPositionY(posY)

    local animalInfo = self.data[self.curId]
    local animalData = MythAnimalConf[self.curId * 100 + animalInfo.Lv]

    self.curShowLevel = level or animalInfo.Lv
    local curShowAnimalData = MythAnimalConf[self.curId * 100 + self.curShowLevel]

    if not animalData then return end

    self.resourceNode_:getChildByName("txt_name"):setString(curShowAnimalData.name)
    self:updateLoadingBar(animalInfo.Lv, 5)
    self.resourceNode_:getChildByName("node_shop"):getChildByName("node_power"):getChildByName("sp_type"):setSpriteFrame("mythAnimal/yaoshou-zi_"..self.curId..".png")
    --self.resourceNode_:getChildByName("txt_grade"):setString(string.format(WordDictionary[26200], WordDictionary[22100 + self.curShowLevel]))
    self.resourceNode_:getChildByName("node_monster"):removeAllChildren()

    local num_ = globalPublicConf[1].ssZhanli[self.curId]
    local numStr = tostring(num_)
    for i=1,3 do
        local str_ = string.sub(numStr, i, i)
        local sp_num = self.resourceNode_:getChildByName("node_shop"):getChildByName("node_power"):getChildByName("sp_num"..i)
        if str_ and string.len(str_) > 0 then
            sp_num:setVisible(true)
            sp_num:setSpriteFrame("mythAnimal/yaoshou-shuzi"..str_..".png")
        else
            sp_num:setVisible(false)
        end      
    end

    local animalSpine = SpineManager.createAnimation("spine/actors/" .. curShowAnimalData.mythAnimalSpine)
    animalSpine:playAnimation("idle", -1)
    self.resourceNode_:getChildByName("node_monster"):addChild(animalSpine)

    self:updateCostItem()
    local attrList = curShowAnimalData.attachAttrId
    local color = CoreColor.TEXT_GREEN

    if self.curShowLevel == 0 then
        attrList = MythAnimalConf[self.curId * 100 + 1].attachAttrId
        self.resourceNode_:getChildByName("txt_lv"):setString(WordDictionary[26201])
        --self.resourceNode_:getChildByName("txt_activation"):setString(WordDictionary[26201])
        self.resourceNode_:getChildByName("txt_lv"):setTextColor(CoreColor.TEXT_RED)
        --self.resourceNode_:getChildByName("txt_activation"):setTextColor(CoreColor.TEXT_RED)
        color = cc.c3b(191,157,147)
    else
        if self.curShowLevel > animalInfo.Lv then
            color = cc.c3b(191,157,147)
            self.resourceNode_:getChildByName("txt_lv"):setString(string.format(WordDictionary[26200], WordDictionary[22100 + self.curShowLevel]))
            --self.resourceNode_:getChildByName("txt_activation"):setString(WordDictionary[26201])
            self.resourceNode_:getChildByName("txt_lv"):setTextColor(CoreColor.TEXT_RED)
           -- self.resourceNode_:getChildByName("txt_activation"):setTextColor(CoreColor.TEXT_RED)
        else
            self.resourceNode_:getChildByName("txt_lv"):setString(string.format(WordDictionary[26200], WordDictionary[22100 + self.curShowLevel]))
            --self.resourceNode_:getChildByName("txt_activation"):setString(WordDictionary[26202])
            self.resourceNode_:getChildByName("txt_lv"):setTextColor(CoreColor.TEXT_GREEN)
            --self.resourceNode_:getChildByName("txt_activation"):setTextColor(CoreColor.TEXT_GREEN)
        end

        if self.curShowLevel > 1 then
            local effect = SpineManager.createAnimation("public/ui_yssj_yaoshounengliangquan", 1)
            effect:playAnimation("idle"..(self.curShowLevel-1), -1)
            effect:setPositionY(-30)
            self.resourceNode_:getChildByName("node_monster"):addChild(effect)
        end
    end

    if animalInfo.Lv == 0 then
        UIImageBox.new(self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"), function()
            if animalInfo.TakeFree then
                MoveLabel.new(WordDictionary[26207])
            else
                network.tcpSend(msgids.C_MythAnimalTakeFree, {Id = animalData.mythAnimalId})
            end
        end)
        if animalInfo.TakeFree then
            self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"):getChildByName("txt_buy"):setString(WordDictionary[26207])
        else
            self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"):getChildByName("txt_buy"):setString(WordDictionary[26203])
        end
        self.resourceNode_:getChildByName("node_shop"):setVisible(true)
        --self.resourceNode_:getChildByName("img_number"):setVisible(true)
        -- self.resourceNode_:getChildByName("bar_number"):setVisible(true)
        -- self.resourceNode_:getChildByName("txt_numberStr"):setVisible(true)
        -- self.resourceNode_:getChildByName("txt_number"):setVisible(true)
        --self.resourceNode_:getChildByName("sp_number"):setVisible(true)
    else
        local billData = self:getBillDataByType(animalData.billType)
        if billData then
            self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"):getChildByName("txt_buy"):setString(string.format(WordDictionary[26204], c.CURRENCY_TYPE[billData.Ccy], billData.Price/100))
            UIImageBox.new(self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"), function()
                if billData then
                    if Helper.getFixedTime() - (animalInfo.LastBillTs + animalData.buyCd * 3600) > 0 then
                        local sdkHelper = SDKController.getSDKHelper()
                        sdkHelper:pay(billData,function(ret)
                        end)
                    else
                        MoveLabel.new(WordDictionary[26208])
                    end
                else
                    MoveLabel.new(WordDictionary[26206])
                end
            end)

            self.resourceNode_:getChildByName("node_shop"):setVisible(true)
            --self.resourceNode_:getChildByName("img_number"):setVisible(true)
            -- self.resourceNode_:getChildByName("bar_number"):setVisible(true)
            -- self.resourceNode_:getChildByName("txt_numberStr"):setVisible(true)
            -- self.resourceNode_:getChildByName("txt_number"):setVisible(true)
            --self.resourceNode_:getChildByName("sp_number"):setVisible(true)
        else
            self.resourceNode_:getChildByName("node_shop"):setVisible(false)
            --self.resourceNode_:getChildByName("img_number"):setVisible(false)
            -- self.resourceNode_:getChildByName("bar_number"):setVisible(false)
            -- self.resourceNode_:getChildByName("txt_numberStr"):setVisible(false)
            -- self.resourceNode_:getChildByName("txt_number"):setVisible(false)
            --self.resourceNode_:getChildByName("sp_number"):setVisible(false)
        end
    end

    local listView = self.resourceNode_:getChildByName("list_increase")
    listView:removeAllChildren()
    listView:updateGridView(2,attrList, function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createItem(data, index, color)
        end
        cacheView:updateView(data)
        return cacheView
    end)

    if animalData.needs ~= 0 then
        local percent = animalInfo.Exp / animalData.needs * 100
        --self:setPercent(percent)
    end
    self.resourceNode_:getChildByName("node_shop"):getChildByName("txt_number"):setString(animalInfo.BillCnt .. "/" .. globalPublicConf[1].ssDecrementMax)
    local buyPercent = math.min(animalInfo.BillCnt/globalPublicConf[1].ssDecrementMax * 100, 100)
    self.resourceNode_:getChildByName("node_shop"):getChildByName("bar_number"):setPercent(buyPercent)
    --self.resourceNode_:getChildByName("sp_number"):setPositionX(810 + 292 * buyPercent/100)

    self.resourceNode_:getChildByName("node_shop"):getChildByName("node_buy"):removeAllChildren()
    for i = 1, 2 do
        local getData = animalData.buyAchieve[i]
        if getData then
            local itemIcon = Helper.createGoodsItem({id = getData.id, num = getData.n})
            self.resourceNode_:getChildByName("node_shop"):getChildByName("node_buy"):addChild(itemIcon)
            itemIcon:setPositionX(-70 + (i - 1) * 140)
        end
    end

    UIImageBox.new(self.resourceNode_:getChildByName("node_culture"):getChildByName("btn_up"), function()
        network.tcpSend(msgids.C_MythAnimalAdd, {Id = animalData.mythAnimalId})
    end)

    self.actTime = self.resourceNode_:getChildByName("node_shop"):getChildByName("txt_condition")
    self.lastTime = animalInfo.LastBillTs
    self.cdTime = animalData.buyCd * 3600
    self:actCountdown()
    self.actTime:actionScheduleInterval(function()
        self:actCountdown()
    end, 1)

    if playEffect then
        if self.preData and self.preData.Lv < animalInfo.Lv then
            local animalEffect = SpineManager.createAnimation("public/ui_yssj_bossshengjiewanchengguang", 1)
            animalEffect:playAnimation("idle", 1)
            animalEffect:setAutoRemove(true)
            animalEffect:setPositionY(-30)
            self.resourceNode_:getChildByName("node_monster"):addChild(animalEffect)

            local btnEffect = SpineManager.createAnimation("public/ui_yssj_shengjiewancheng", 1)
            btnEffect:playAnimation("idle", 1)
            btnEffect:setAutoRemove(true)
            btnEffect:setPosition(68, 68)
            self.resourceNode_:getChildByName("node_culture"):getChildByName("btn_up"):addChild(btnEffect)

            local attrEffect = SpineManager.createAnimation("public/ui_yssj_zhuangtaimianbansaoguang", 1)
            attrEffect:playAnimation("idle", 1)
            attrEffect:setAutoRemove(true)
            attrEffect:setPosition(160, 120)
            self.resourceNode_:getChildByName("img_increase"):addChild(attrEffect)
        else
            local btnEffect = SpineManager.createAnimation("public/ui_yssj_shengjieweidianji_a", 1)
            btnEffect:playAnimation("idle", 1)
            btnEffect:setAutoRemove(true)
            btnEffect:setPosition(68, 68)
            self.resourceNode_:getChildByName("node_culture"):getChildByName("btn_up"):addChild(btnEffect)
        end
    end


    local hasRedTips, state = RedTipsModel:checkMythAnimalById(self.curId)
    RedTipsModel:removeRedTip(self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"))
    RedTipsModel:removeRedTip(self.resourceNode_:getChildByName("node_culture"):getChildByName("btn_up"))
    if hasRedTips then
        if state < 3 then
            RedTipsModel:addRedTip(self.resourceNode_:getChildByName("node_shop"):getChildByName("btn_buy"), cc.p(120, 40))
        else
            RedTipsModel:addRedTip(self.resourceNode_:getChildByName("node_culture"):getChildByName("btn_up"), cc.p(120, 40))
        end
    end

    self.preData = clone(animalInfo)
end

function MythAnimalWin:updateCostItem()
    local animalInfo = self.data[self.curId]
    local animalData = MythAnimalConf[self.curId * 100 + animalInfo.Lv]
    self.resourceNode_:getChildByName("node_culture"):getChildByName("img_money"):removeAllChildren()
    local costData = animalData.cost[1]

    if costData then
        self.resourceNode_:getChildByName("node_culture"):setVisible(true)
        local costItem = Helper.createGoodsItem({id = costData.id, scale = 0.35})
        self.resourceNode_:getChildByName("node_culture"):getChildByName("img_money"):addChild(costItem)
        display.align(costItem, display.CENTER, 0, 12)
        local useNum = 0
        if itemConf[costData.id] then
            local item = ItemModel:getItem(costData.id)
            useNum = item and item.number or 0
        elseif currencyConf[costData.id] then
            useNum = PlayerModel:getPlayerCurrency(costData.id)
        end
        self.resourceNode_:getChildByName("node_culture"):getChildByName("txt_cost"):setString(useNum .. "/" .. costData.n)
        if useNum >= costData.n then
            self.resourceNode_:getChildByName("node_culture"):getChildByName("txt_cost"):setTextColor(CoreColor.TEXT_GREEN)
        else
            self.resourceNode_:getChildByName("node_culture"):getChildByName("txt_cost"):setTextColor(CoreColor.TEXT_RED)
        end
    else
        self.resourceNode_:getChildByName("node_culture"):setVisible(false)
    end
end

function MythAnimalWin:actCountdown()
    local leftTime = (self.lastTime + self.cdTime) - Helper.getFixedTime()
    if leftTime <= 0 then
        self.actTime:setString("")
        self.actTime:stopAllActions()       
    else
        self.actTime:setString(string.format(WordDictionary[26205], Helper.getTimeString(leftTime, true, true)))
    end
end

function MythAnimalWin:getBillDataByType(typeId)
    for i,v in pairs(PayModel.billProduct) do
        if v.TypeId==typeId and v.PlatformId==PAY_PLATFORM then
            return v
        end
    end
    return nil
end

function MythAnimalWin:setPercent(percent)
    local anim = self.resourceNode_:getChildByName("node_culture"):getChildByName("img_decBg"):getChildByName("clipNode"):getChildByName("percentAnim")
    local animZeroY = -115
    local animHundredY = 2
    local animDesY = animZeroY + ((animHundredY - animZeroY) / 100) * percent
    anim:stopAllActions()
    anim:runAction(cc.EaseSineOut:create(cc.MoveTo:create(0.5, cc.p(0, animDesY))))
    anim.percent = percent
end

function MythAnimalWin:createItem(data, index, color)
    local layer = ccui.Layout:create()
    layer:setContentSize(cc.size(200, 35))
    layer.updateView = function(layer,data, updateIndex)
        layer:removeAllChildren()
        local attrStr = UILabel.new({
            text = attributeConf[data.id].name .. " +" .. Helper.getAttriValue(data.id, data.val, true),
            color = color,
            size = 18,
            back = CoreColor.BLACK,
            backWidth = 2,
        })
        layer:addChild(attrStr)
        display.align(attrStr, display.BOTTOM_LEFT, 50, 3)
    end

    return layer
end

function MythAnimalWin:refreshButton()
    for i = 1, 3 do
        local path = MythAnimalConf[i * 100 + self.data[i].Lv].tabs
        self.resourceNode_:getChildByName("btn_monster"..i):loadTexture("mythAnimal/"..path..".png",ccui.TextureResType.plistType)
        if RedTipsModel:checkMythAnimalById(i) then
            RedTipsModel:addRedTip(self.resourceNode_:getChildByName("btn_monster"..i), cc.p(110, 25))
        else
            RedTipsModel:removeRedTip(self.resourceNode_:getChildByName("btn_monster"..i))
        end 
    end
end

function MythAnimalWin:updateLoadingBar(curLv, sum)
    local bar = self.resourceNode_:getChildByName("bar")
    local barNode = self.resourceNode_:getChildByName("node_bar")
    barNode:removeAllChildren()
    bar:setPercent((curLv-1)/(sum-1)*100)
    local sumWidth = bar:getContentSize().width
    local spacing = sumWidth/(sum-1)
    for i=1,sum do
        local img = display.newSprite("#mythAnimal/yaoshou-zhuzi1.png")
        local color_ = cc.c3b(191,191,191)
        if curLv >= i then
            img = display.newSprite("#mythAnimal/yaoshou-zhuzi2.png")
            color_ = cc.c3b(255,118,0)
        end
        display.align(img,display.CENTER, (i-1)*spacing, 0)
        barNode:addChild(img)
        local lvStr = UILabel.new({
            text = WordDictionary[22001 + i],
            size = 14,
            color = color_,
        })
        display.align(lvStr, display.CENTER, 12.5, 35)
        img:addChild(lvStr)
    end
end

function MythAnimalWin:receive(op, data)
    if op == msgids.GS_MythAnimalGetInfo_R then
        self.data = {}
        for k,v in pairs(data.Data.Animals) do
            self.data[v.Id] = v
        end
        self:refreshButton()
        self:onChangeTab(self.curId, nil, true, false)
    elseif op == msgids.GS_MythAnimalAdd_R then
        if data.One then
            for k,v in ipairs(self.data) do
                if k == data.One.Id then
                    self.data[k] = data.One
                    break
                end
            end
        end
        self:refreshButton()
        self:onChangeTab(self.curId, nil, true, true)
    elseif op == msgids.GS_MythAnimalTakeFree_R 
        or op == msgids.GS_MythAnimalBillNew then
        if data.Rewards then
            self:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        end

        if data.One then
            for k,v in ipairs(self.data) do
                if k == data.One.Id then
                    self.data[k] = data.One
                    break
                end
            end
        end
        self:refreshButton()
        self:onChangeTab(self.curId, nil, true, false)
    elseif op == msgids.GS_BagUpdate then
        self:updateCostItem()
    end
end

return MythAnimalWin