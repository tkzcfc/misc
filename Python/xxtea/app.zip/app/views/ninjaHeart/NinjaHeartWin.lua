local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local SpineManager = require "sandglass.core.SpineManager"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local MoveLabel = require "sandglass.ui.MoveLabel"
local AudioManager = require "sandglass.core.AudioManager"
local init = require "app.models.init"
local Helper = require "app.Helper"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local attributeConf = require "app.configs.attribute"
local CoreColor = require "sandglass.core.CoreColor"
local rzzxConf = require "app.configs.rzzx"
require "sandglass.ui.UIListView"
local RichLabel = require "sandglass.ui.RichLabel"

local RedTipsModel = init.RedTipsModel
local NinjaHeartModel = init.NinjaHeartModel
local PlayerModel = init.PlayerModel

local NinjaHeartWin = class("NinjaHeartWin", WinBase)

NinjaHeartWin.RESOURCE_FILENAME = "ninjaHeart/ninjaHeart.csb"

function NinjaHeartWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP
    local msgList = {
        msgids.GS_RzzxAddExp_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function NinjaHeartWin:receive(op, data)
    if op == msgids.GS_RzzxAddExp_R then
        self.info = NinjaHeartModel:getInfo()
        -- self:updateInfo()
        if self.barAnim and not tolua.isnull(self.barAnim) then
            self.barAnim:playAnimation("idle2", 1)
            self:updateInfo()
        end

        local anim = SpineManager.createAnimation("ninjaHeart/ui_renzhezhixin_shengjitubiao",1)
        anim:playAnimation("idle", 1)
        self.longAnim:addChild(anim)
        anim:setAutoRemove(true)
        anim:setPosition(self.longAnim:getContentSize().width * 0.5,self.longAnim:getContentSize().height * 0.5)
        
        local node_nextAttr = self.resourceNode_:getChildByName("node_nextAttr")
        local node_curAttr = self.resourceNode_:getChildByName("node_curAttr")
        --属性刷新
        for i=1,3 do
            local anim1 = SpineManager.createAnimation("public/ui_tongyongshujushuaxin",1)
            anim1:playAnimation("idle", 1)
            node_curAttr:getChildByName("sp_attr"..i):addChild(anim1)
            anim1:setAutoRemove(true)
            anim1:setPosition(108,node_curAttr:getChildByName("sp_attr"..i):getContentSize().height * 0.5)
            anim1:setScaleX(0.65)

            local anim2 = SpineManager.createAnimation("public/ui_tongyongshujushuaxin",1)
            anim2:playAnimation("idle", 1)
            node_nextAttr:getChildByName("sp_attr"..i):addChild(anim2)
            anim2:setAutoRemove(true)
            anim2:setPosition(108,node_nextAttr:getChildByName("sp_attr"..i):getContentSize().height * 0.5)
            anim2:setScaleX(0.65)
        end
    end
end

function NinjaHeartWin:initialView()
    self.btn_up = UIImageBox.new(self.resourceNode_:getChildByName("btn_up"), function ()
        if not NinjaHeartModel:canUpLv() then
            MoveLabel.new(WordDictionary[70004])
            return
        end
        network.tcpSend(msgids.C_RzzxAddExp)
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"), function ()
        self:closeSelf()
    end)
    self.richLabel = Helper.createRichLable(self.resourceNode_:getChildByName("txt_tips2"))
    self.richLabel:setString(WordDictionary[70005])
    self.resourceNode_:getChildByName("txt_tips1"):setString(WordDictionary[70006])
    self.resourceNode_:getChildByName("txt_tips3"):setString(WordDictionary[70007])

    --icon常驻特效
    self.longAnim = SpineManager.createAnimation("ninjaHeart/ui_renzhezhixin",1)
    self.longAnim:playAnimation("idle1", -1)
    self.resourceNode_:addChild(self.longAnim)
    self.longAnim:setPosition(cc.p(self.resourceNode_:getChildByName("sp_icon"):getPosition()))
    self.resourceNode_:getChildByName("sp_icon"):setVisible(false)
    self:updateInfo()

    self:registerEvent("refreshNinjaHeartRedTips")
    RedTipsModel:refreshNinjaHeartRedTips()
end

function NinjaHeartWin:onEventReceive(event)
    local name = event:getEventName()
    local param = event._usedata
    if name == "refreshNinjaHeartRedTips" then
        if param.canUpLv then
            RedTipsModel:addRedTip(self.resourceNode_:getChildByName("btn_up"), cc.p(124, 43))
            Helper.buttonAddEffect(self.resourceNode_:getChildByName("btn_up"),"public/ui_tongyonganniugaoliang")
        else
            RedTipsModel:removeRedTip(self.resourceNode_:getChildByName("btn_up"))
            Helper.buttonRemoveEffect(self.resourceNode_:getChildByName("btn_up"))
        end
    end
end

function NinjaHeartWin:updateInfo()
    local info = NinjaHeartModel:getInfo()
    self.info = info---新手使用
    local conf = clone(rzzxConf[info.Lv])
    local nextConf = rzzxConf[info.Lv + 1]
    local isMax = nextConf == nil
    local node_nextAttr = self.resourceNode_:getChildByName("node_nextAttr")
    local node_curAttr = self.resourceNode_:getChildByName("node_curAttr")
    self.resourceNode_:getChildByName("txt_atk"):setString(PlayerModel:getInfo().atkPwr)
    self.resourceNode_:getChildByName("txt_lv"):setString("Lv."..info.Lv)
    self.resourceNode_:getChildByName("node_curAttr"):getChildByName("txt_curLv"):setString(info.Lv..WordDictionary[21003])
    self.resourceNode_:getChildByName("txt_atk"):setString(info.MaxAtk)
    self.longAnim:playAnimation(conf.effect, -1)
    if not isMax then
        self.resourceNode_:getChildByName("txt_pec"):setString((info.ExpStore + info.Exp).."/"..conf.exp)
        self.resourceNode_:getChildByName("bar_pec"):setPercent((info.ExpStore + info.Exp) / conf.exp * 100)
        self.resourceNode_:getChildByName("node_nextAttr"):getChildByName("txt_nextLv"):setString((info.Lv + 1)..WordDictionary[21003])
    else
        self.resourceNode_:getChildByName("btn_up"):getChildByName("txt_btn"):setString("MAX")
        self.resourceNode_:getChildByName("txt_pec"):setString("MAX")
        self.resourceNode_:getChildByName("bar_pec"):setPercent(100)
    end
    node_nextAttr:setVisible(not isMax)
    for i=1,3 do
        node_curAttr:getChildByName("txt_curAttrName"..i):setVisible(conf.attr[i] ~= nil)
        node_curAttr:getChildByName("txt_curAttrNum"..i):setVisible(conf.attr[i] ~= nil)
        node_curAttr:getChildByName("txt_curAttrName"..i):setString(attributeConf[conf.attr[i].id].name)
        node_curAttr:getChildByName("txt_curAttrNum"..i):setString(conf.attr[i].val)
        if not isMax then
            node_nextAttr:getChildByName("txt_nextAttrName"..i):setVisible(nextConf.attr[i] ~= nil)
            node_nextAttr:getChildByName("txt_nextAttrNum"..i):setVisible(nextConf.attr[i] ~= nil)
            node_nextAttr:getChildByName("txt_nextAttrName"..i):setString(attributeConf[nextConf.attr[i].id].name)
            node_nextAttr:getChildByName("txt_nextAttrNum"..i):setString(nextConf.attr[i].val)
        end
    end

    --条
    if not isMax and NinjaHeartModel:canUpLv() and (not self.barAnim or tolua.isnull(self.barAnim)) then 
        self.barAnim = SpineManager.createAnimation("ninjaHeart/ui_renzhezhixin_tiao",1)
        self.barAnim:playAnimation("idle1", -1)
        self.barAnim:setPosition(-33, 6)
        self.resourceNode_:getChildByName("bar_pec"):addChild(self.barAnim)
        self.barAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
            if eventName == "complete" and animName == "idle2" then                    
                if not isMax and NinjaHeartModel:canUpLv() then
                    self.barAnim:playAnimation("idle1", -1)
                end
            end
        end)
    end

    self.btn_up:setEnabled(not isMax and NinjaHeartModel:canUpLv())
end

function NinjaHeartWin:getActionIn()
    Helper.enterWinAction1(self)
end

return NinjaHeartWin