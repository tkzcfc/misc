local Helper = require "app.Helper"
local c = require "app.configs.constants"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local BulletScreen = require "sandglass.ui.BulletScreen"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local jobConf = require "app.configs.job"
local RichLabel = require "sandglass.ui.RichLabel"
local BattleController = require "app.battle.controllers.BattleController"
local TeamController = require "app.battle.controllers.TeamController"
local monsterConf = require "app.configs.monster"
local talentConf = require "app.configs.talent"
local skillConf = require "app.configs.skill"
local msgPack = require "app.battle.server.MessagePack"
local kfbsConf = require "app.configs.kfbs"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local KfbsModel = init.KfbsModel

local words = {
    [10000] = WordDictionary[24340],
    [10001] = WordDictionary[24341],
    [10002] = WordDictionary[24342],
    [10003] = WordDictionary[24343],
    [10004] = WordDictionary[24344],
    [10005] = WordDictionary[24345],
    [10006] = WordDictionary[24346],
    [10007] = WordDictionary[24347],
    [10008] = WordDictionary[24348],
    [10009] = WordDictionary[24349],
    [10010] = WordDictionary[24350],
    [10011] = WordDictionary[24351],
    [10012] = WordDictionary[24352],
    [10013] = WordDictionary[24353],
}

local FightLiveView = class('FightLiveView',function() 
    return ccui.Layout:create()
end)

function FightLiveView:ctor(parentWin)
    self.parentWin = parentWin
    self.canSendDanMu = true

    self:onWinEnter()
end

function FightLiveView:receive(op,data)
    if op == msgids.GS_BattleGetReplay_R then
        if self.sending then
            self.sending = false
            self:initFightData(data)
        end
    elseif op == msgids.GS_KfbsGetBarrage_R then
        self:createDanMu(data.Barrage or {})
    elseif op == msgids.GS_KfbsBarrageNew then
        local bulletData = data.Data
        local groupStr = self.isChampion and "" or string.format(WordDictionary[24359], bulletData.Group)
        local str = groupStr..string.format(WordDictionary[23909], bulletData.Name) .. Helper.convertStringToExpression(string.format(WordDictionary[24380], "#FFFFFF", bulletData.Content))
        self.danMu:addBullet(str)
    end
end

function FightLiveView:onWinEnter()
    self.contentView = self.parentWin:createCsbNode("crossServer/fightLive.csb")
    self:addChild(self.contentView)

    self.selImg = self.contentView:getChildByName("node_ct"):getChildByName("img_sel")
    self.selImg:setVisible(false)

    local listView = self.contentView:getChildByName("node_ct"):getChildByName("list_content")
    listView:setScrollBarEnabled(false)

    self.contentView:getChildByName("node_ct"):getChildByName("leftPlayer"):getChildByName("node_team"):setVisible(false)
    self.contentView:getChildByName("node_ct"):getChildByName("rightPlayer"):getChildByName("node_team"):setVisible(false)
    UIImageBox.new(self.contentView:getChildByName("node_ct"):getChildByName("btn_close"),function()
        self.parentWin:closeFightLive()
    end)
end

function FightLiveView:createDanMu(data)
     --弹幕--
    local danMuList = {}
    for k,v in ipairs(data) do
        local groupStr = self.isChampion and "" or string.format(WordDictionary[24359], v.Group)
        local str = groupStr .. string.format(WordDictionary[23909], v.Name) .. Helper.convertStringToExpression(string.format(WordDictionary[24380], "#FFFFFF", v.Content))
        table.insert(danMuList,{str = str})
    end

    self.danMu = BulletScreen.new({
        parentNode = self.contentView:getChildByName("node_danmu"),
        bulletList = danMuList,
        isOpen = PlayerConfig.getSetting(PlayerModel.info.userId.."openCrossServerDanMu", true),
        posY = {130,100,70,40,},
        fontSize = 20
    })
    self.danMu:start()

    self.danMuBtn = UIImageBox.new(self.contentView:getChildByName("node_rb"):getChildByName("btn_chatToggle"), function()
        local isOpen = self.danMu:getOpen()
        self.danMu:setOpen(not isOpen)
        PlayerConfig.setSetting(PlayerModel.info.userId.."openCrossServerDanMu",not isOpen)
        self:updateDanMuBtn()
    end, {noAnimEffect = true})
    self:updateDanMuBtn()
    ------发送弹幕
    UIImageBox.new(self.contentView:getChildByName("node_rb"):getChildByName("btn_chat"), function()
        if self.canSendDanMu then
            self.parentWin:openWin("DanMuWin", function(str)
                if str ~= "" then
                    network.tcpSend(msgids.C_KfbsBarrage, {Group = self.isChampion and 10 or self.group, Content = str})
                    self:startSendDanMu() 
                else
                    MoveLabel.new(WordDictionary[23926])
                end
            end, kfbsConf[1].barrageLen)
        else
            MoveLabel.new(WordDictionary[23904])     
        end
    end)
end

function FightLiveView:updateDanMuBtn()
    local sp_spot = self.danMuBtn:getChildByName("sp_spot")
    local txt_tip = self.danMuBtn:getChildByName("txt_name")
    local isOpenDanMu = PlayerConfig.getSetting(PlayerModel.info.userId.."openCrossServerDanMu", true)
    if isOpenDanMu then
        sp_spot:setPositionX(self.danMuBtn:getContentSize().width-sp_spot:getContentSize().width/2)
        txt_tip:setString(WordDictionary[23902])
        self.danMuBtn:loadTexture("public/tongyong-kaiguan2.png",ccui.TextureResType.plistType)
    else
        sp_spot:setPositionX(sp_spot:getContentSize().width/2)
        txt_tip:setString(WordDictionary[23903])
        self.danMuBtn:loadTexture("public/tongyong-kaiguan1.png",ccui.TextureResType.plistType)
    end
end


function FightLiveView:startSendDanMu()
    local danMuCD = 5
    self.canSendDanMu = false
    self.contentView:stopAllActions()
    self.contentView:runAction(cc.Sequence:create(cc.DelayTime:create(danMuCD), cc.CallFunc:create(function()
        self.canSendDanMu = true
    end)))
end

function FightLiveView:showResult()
    if self.replayInfo.info.AtkWin then
        self.contentView:getChildByName("node_ct"):getChildByName("node_right"):getChildByName("sp_tab"):setSpriteFrame("crossServer/kuafubeisai-dui1.png")
    else
        self.contentView:getChildByName("node_ct"):getChildByName("node_left"):getChildByName("sp_tab"):setSpriteFrame("crossServer/kuafubeisai-dui1.png")
    end
end

function FightLiveView:updateView(replayInfo, isChampion, group)
    if not replayInfo or (self.replayInfo and self.replayInfo.info.Id == replayInfo.info.Id) then
        return
    end
    self.replayInfo = replayInfo
    self.isChampion = isChampion
    self.group = group
    self.contentView:getChildByName("node_danmu"):removeAllChildren()
    network.tcpSend(msgids.C_KfbsGetBarrage, {Group = self.isChampion and 10 or self.group})

    local node_ct = self.contentView:getChildByName("node_ct")
    local headData1 = {
        frame = node_ct:getChildByName("leftPlayer"):getChildByName("img_head"),
        headId = replayInfo.Atk.Head,
        frameId = replayInfo.Atk.HFrame,
        title = replayInfo.Atk.Title,
        level = replayInfo.Atk.Lv,
    }
    Helper.createPlayerHead(headData1)
    local headData2 = {
        frame = node_ct:getChildByName("rightPlayer"):getChildByName("img_head"),
        headId = replayInfo.Def.Head,
        frameId = replayInfo.Def.HFrame,
        title = replayInfo.Def.Title,
        level = replayInfo.Def.Lv,
    }
    Helper.createPlayerHead(headData2)

    node_ct:getChildByName("leftPlayer"):getChildByName("txt_name"):setString(replayInfo.Atk.Name)
    node_ct:getChildByName("leftPlayer"):getChildByName("txt_server"):setString(string.format(WordDictionary[24357], replayInfo.Atk.SvrId))
    node_ct:getChildByName("node_left"):getChildByName("sp_tab"):getChildByName("txt_index"):setString(string.sub("ABC", replayInfo.info.AtkTeam, replayInfo.info.AtkTeam)..WordDictionary[24337])
    node_ct:getChildByName("rightPlayer"):getChildByName("txt_name"):setString(replayInfo.Def.Name)
    node_ct:getChildByName("rightPlayer"):getChildByName("txt_server"):setString(string.format(WordDictionary[24357], replayInfo.Def.SvrId))
    node_ct:getChildByName("node_right"):getChildByName("sp_tab"):getChildByName("txt_index"):setString(string.sub("ABC", replayInfo.info.DefTeam, replayInfo.info.DefTeam)..WordDictionary[24337])
    node_ct:getChildByName("node_right"):getChildByName("sp_tab"):setSpriteFrame("crossServer/kuafubeisai-dui2.png")
    node_ct:getChildByName("node_left"):getChildByName("sp_tab"):setSpriteFrame("crossServer/kuafubeisai-dui2.png")

    if not self.sending then
        self.sending = true
        network.tcpSend(msgids.C_BattleGetReplay, {Id = self.replayInfo.info.Id, Src = "master"})
    end
end

function FightLiveView:initFightData(data)
    for i=1,5 do
        self.contentView:getChildByName("node_ct"):getChildByName("node_atk_"..i):removeAllChildren()
        self.contentView:getChildByName("node_ct"):getChildByName("node_dfd_"..i):removeAllChildren()
    end

    self:registerFightEvent()
    self.dt = 0
    self.battleUpdate = 0.016
    self.saveLogCnt = 100

    local replay = msgPack.unpack(data.Replay)
    local value = TeamController.getDataFromServer(replay.T)
    value.params.fightStatus = c.FightStatus.kfbsChampion
    value.params.seed = replay.Seed
    
    BattleController.ctor(value, value.params.seed)
    BattleController.initializeUnits()
    BattleController.autoFight = {
        [c.UnitGroup.ATTACKER] = true,
        [c.UnitGroup.DEFENDER] = true,
    }
    BattleController.canFreezing = {
        [c.UnitGroup.ATTACKER] = true,
        [c.UnitGroup.DEFENDER] = true,
    }
    BattleController.sendEventView = self.parentWin
    BattleController.start()
    self:onUpdate(handler(self, self.update))
end

function FightLiveView:registerFightEvent()
    for k,v in pairs(c.BATTLE_EVENT) do
        self.parentWin:registerEvent(v)
    end
end

function FightLiveView:onEventReceive(event)
    local name = tonumber(event:getEventName())
    local param = event._usedata
    if name == c.BATTLE_EVENT.BATTLE_START then
        self:initPlayerInfo(param)
    elseif name == c.BATTLE_EVENT.BATTLE_NEXTWAVE then
    elseif name == c.BATTLE_EVENT.BATTLE_UPDATEROUND then
        self:updateBattleRound(param)
    elseif name == c.BATTLE_EVENT.BATTLE_UPDATESTATE then
        self:updateBattleState(param)
    elseif name == c.BATTLE_EVENT.BATTLE_UPDATEHP then
        self:updatePlayerHp(param)
    elseif name == c.BATTLE_EVENT.BATTLE_UPDATEMP then
        self:updatePlayerMp(param)
    elseif name == c.BATTLE_EVENT.BATTLE_UNITUSESKILL then
        self:onUnitUseSkill(param)
    elseif name == c.BATTLE_EVENT.BATTLE_KAMIUSESKILL then
        self:onKamiUseSkill(param)
    elseif name == c.BATTLE_EVENT.BATTLE_UNITREBORN then
        self:onUnitReborn(param)
    end
end

function FightLiveView:initPlayerInfo(data)
    self.units = data.data
    for k,v in pairs(self.units) do
        local nodeName = (v.group == 1 and "node_atk_" or "node_dfd_") .. v.order
        local node = self.contentView:getChildByName("node_ct"):getChildByName(nodeName)
        node:removeAllChildren()
        local heroItem = self:createHeroItem(v)
        node:addChild(heroItem)
    end
end

function FightLiveView:updateBattleRound(data)
    local round = data.data

    local str = string.format(words[10001], round)
    self:addInfoLogToList(str)
end

function FightLiveView:createHeroItem(data)
    local heroItem = self.parentWin:createCsbNode("crossServer/heroItem2.csb")
    heroItem:getChildByName("szImg"):setVisible(false)
    heroItem:getChildByName("szBack"):setVisible(false)
    heroItem:getChildByName("starNode"):setVisible(true)
    
    local cData = heroConf[data.heroId] or monsterConf[data.heroId]
    if not cData then
        print("can't find conf from heroConf or monsterConf id is :" .. data.heroId)
        return
    end

    --头像,头像框
    local heroFrame = heroItem:getChildByName("heroFrame")
    if not heroFrame:getChildByName("headImg") then
        local imgName = "icon/head/" .. roleConf[cData.role].head .. ".png"
        local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png",1)
        display.align(headImg,display.CENTER, heroFrame:getContentSize().width * 0.5 , heroFrame:getContentSize().height * 0.5)
        headImg:setName("headImg")
        heroFrame:addChild(headImg)
    end

    --职业图标
    local jobImg = heroItem:getChildByName("jobIcon")
    jobImg:loadTexture( "public/" .. jobConf[cData.jobId].icon .. ".png", ccui.TextureResType.plistType)

    --稀有度图标
    local sp_rare = heroItem:getChildByName("sp_rare")
    sp_rare:setSpriteFrame("public/yingxiong-" .. cData.rare .. ".png")

    --等级 突破等级
    heroItem:getChildByName("Text_1"):setString("Lv."..data.level)

    --星级
    if data.star > 0 then
        Helper.updateHeroStar(heroItem:getChildByName("starNode"),data.star)
    end

    --天赋
    local txt_talent = heroItem:getChildByName("sp_talent"):getChildByName("txt_talent")
    txt_talent:setString("+"..data.cls)

    heroFrame:loadTexture("public/public_frame_01.png", ccui.TextureResType.plistType)
    for m,n in ipairs(talentConf[data.heroId] and talentConf[data.heroId].talentColor or {}) do
        if data.cls == m then
            heroFrame:loadTexture("public/public_frame_0"..n..".png", ccui.TextureResType.plistType)
            break
        end
    end

    heroItem:getChildByName("barNode"):getChildByName("bloodBar"):setPercent(100)
    heroItem:getChildByName("barNode"):getChildByName("energyBar"):setPercent(0)
    heroItem:getChildByName("img_force"):setVisible(false)

    heroItem:setName("heroItem")
    heroItem.heroId = data.heroId
    heroItem.curHp = data.hp
    heroItem:setScale(0.7)
    return heroItem
end

function FightLiveView:updateBattleState(data)
    local state = data.data
    local str = ""
    if state == c.GameState.ATTACK_WIN then
        str = string.format(words[10007], words[10009])
    elseif state == c.GameState.ATTACK_LOSE then
        str = string.format(words[10007], words[10010])
    elseif state == c.GameState.COMPLETE then
        str = words[10008]
    end
    self:addInfoLogToList(str)
end

function FightLiveView:updatePlayerHp(data)
    local hpInfo = data.data
    local nodeName = (hpInfo.group == 1 and "node_atk_" or "node_dfd_") .. hpInfo.order
    local heroItem = self.contentView:getChildByName("node_ct"):getChildByName(nodeName):getChildByName("heroItem")
    if heroItem then
        heroItem:getChildByName("barNode"):getChildByName("bloodBar"):percentTo((hpInfo.hp / hpInfo.maxLife) * 100, 0.2)
        
        local heroId = heroItem.heroId
        local heroData = heroConf[heroId] or monsterConf[heroId]
        local heroName = (heroData.heroName or heroData.name)

        local deltHp = math.ceil(heroItem.curHp - hpInfo.hp)
        if deltHp > 0 then --掉血
            local str = string.format(words[10002], ((hpInfo.group == 1) and words[10005] or words[10006]), heroName, deltHp)
            -- self:addInfoLogToList(str)
        elseif deltHp < 0 then
            local str = string.format(words[10003], ((hpInfo.group == 1) and words[10005] or words[10006]), heroName, -deltHp)
            self:addInfoLogToList(str)
        end

        if hpInfo.hp == 0 and not heroItem:getChildByName("sp_dead"):isVisible() then
            heroItem:getChildByName("sp_dead"):setScale(1.5)
            Helper.greyFunc(heroItem)
            Helper.greyFunc(heroItem:getChildByName("sp_dead"), true)
            heroItem:getChildByName("sp_dead"):setVisible(true)
            heroItem:getChildByName("sp_dead"):runAction(cc.EaseInOut:create(cc.ScaleTo:create(1, 1), 10))
            local str = string.format(words[10004], ((hpInfo.group == 1) and words[10005] or words[10006]), heroName)
            self:addInfoLogToList(str)
        elseif hpInfo.hp > 0 and heroItem:getChildByName("sp_dead"):isVisible() then
            Helper.greyFunc(heroItem, true)
            heroItem:getChildByName("sp_dead"):setVisible(false)
        end

        heroItem.curHp = hpInfo.hp
    end
end

function FightLiveView:updatePlayerMp(data)
    local mpInfo = data.data
    local nodeName = (mpInfo.group == 1 and "node_atk_" or "node_dfd_") .. mpInfo.order
    local heroItem = self.contentView:getChildByName("node_ct"):getChildByName(nodeName):getChildByName("heroItem")
    if heroItem then
        heroItem:getChildByName("barNode"):getChildByName("energyBar"):percentTo((mpInfo.mp / mpInfo.energy) * 100, 0.2)
    end
end

function FightLiveView:onUnitUseSkill(data)
    local useSkillInfo = data.data
    local nodeName = (useSkillInfo.group == 1 and "node_atk_" or "node_dfd_") .. useSkillInfo.order
    local heroItem = self.contentView:getChildByName("node_ct"):getChildByName(nodeName):getChildByName("heroItem")
    if heroItem then
        local x, y = self.contentView:getChildByName("node_ct"):getChildByName(nodeName):getPosition()
        self.selImg:setPosition(cc.p(x, y - 7))
        self.selImg:setVisible(true)

        local heroId = heroItem.heroId
        local heroData = heroConf[heroId] or monsterConf[heroId]
        local skillId = useSkillInfo.skillId

        local txt = ((useSkillInfo.group == 1) and words[10005] or words[10006]) .. (heroData.heroName or heroData.name) .. words[10000] .. skillConf[skillId].name
        ---检查是不是同一个技能发送多次
        if not self:checkRepeatSkill(txt) then
            self:addInfoLogToList(txt)
        end
    end
end

function FightLiveView:checkRepeatSkill(txt)
    local maxRepeatCnt = 4
    if not self.skillRecord then
        self.skillRecord = {str = txt, num = 1}
        return false
    else
        if txt == self.skillRecord.str then
            self.skillRecord.num = self.skillRecord.num + 1
        else
            self.skillRecord.str = txt
            self.skillRecord.num = 1
        end
        if self.skillRecord.num >= maxRepeatCnt then
            self.skillRecord.num = maxRepeatCnt - 1
            return true
        else
            return false
        end
    end
    return false
end

function FightLiveView:onKamiUseSkill(data)
    local useSkillInfo = data.data
    local txt = ((useSkillInfo.group == 1) and words[10005] or words[10006]) .. words[10011] .. words[10000] .. skillConf[useSkillInfo.skillId].name
    self:addInfoLogToList(txt)
end

function FightLiveView:onUnitReborn(data)
    local rebornInfo = data.data
    local nodeName = (rebornInfo.group == 1 and "node_atk_" or "node_dfd_") .. rebornInfo.order
    local heroItem = self.contentView:getChildByName("node_ct"):getChildByName(nodeName):getChildByName("heroItem")
    if heroItem then
        heroItem:getChildByName("barNode"):getChildByName("bloodBar"):percentTo((rebornInfo.hp / rebornInfo.maxLife) * 100, 0.2)
        
        local heroId = rebornInfo.heroId
        local oldHeroId = heroItem.heroId

        if heroId ~= oldHeroId then
            local oldHeroData = heroConf[oldHeroId] or monsterConf[oldHeroId]
            local heroData = heroConf[heroId] or monsterConf[heroId]
            local txt = string.format(words[10013], ((rebornInfo.group == 1) and words[10005] or words[10006]), (oldHeroData.heroName or oldHeroData.name), (heroData.heroName or heroData.name)) 
            self:addInfoLogToList(txt)
        else
            local heroData = heroConf[heroId] or monsterConf[heroId]
            local txt = string.format(words[10012], ((rebornInfo.group == 1) and words[10005] or words[10006]), (heroData.heroName or heroData.name)) 
            self:addInfoLogToList(txt)
        end

        heroItem:getChildByName("sp_dead"):setVisible(false)
        Helper.greyFunc(heroItem, true)
        heroItem.curHp = rebornInfo.hp
    else
        self:createHeroItem(rebornInfo)
    end
end

function FightLiveView:update(dt)
    self.dt = self.dt + dt
    if self.dt >= self.battleUpdate then
        self.dt = self.dt - self.battleUpdate

        BattleController.update(0.016)

        local state = BattleController.state

        if state == c.GameState.NEXT_WAVE then
            BattleController.updateNextWave()
            BattleController.start()
        elseif state == c.GameState.ATTACK_WIN or state == c.GameState.ATTACK_LOSE or state == c.GameState.COMPLETE then
            BattleController.isPaused = true
            self:showResult()
            self:unscheduleUpdate()
        end
    end
end

function FightLiveView:addInfoLogToList(txt)
    local listView = self.contentView:getChildByName("node_ct"):getChildByName("list_content")
    if listView:getChildrenCount() > self.saveLogCnt then
        self:removeOldLog()
    end

    local item = self:createInfoLog(txt)
    display.align(item, display.LEFT_BOTTOM, 0, 0)
    self.listViewInnerHeight = (self.listViewInnerHeight and self.listViewInnerHeight or 0) + item:getContentSize().height
    listView:addChild(item)
    listView:setInnerContainerSize(cc.size(670, self.listViewInnerHeight))
    listView:jumpToBottom()
end

function FightLiveView:removeOldLog()
    local listView = self.contentView:getChildByName("node_ct"):getChildByName("list_content")
    local removeItem = listView:getItem(0)
    if removeItem then
        self.listViewInnerHeight = self.listViewInnerHeight - removeItem:getContentSize().height
        listView:removeItem(0)
        listView:setInnerContainerSize(cc.size(670, self.listViewInnerHeight))
    end
end

function FightLiveView:createInfoLog(txt)
    local widget = ccui.Widget:create()
    local x, y = 13, 5

    local line = display.newSprite("#login/renjiezhuzai-fenxian.png", 0, 0, {scale9 = true, size = cc.size(660,2)})
    line:align(display.LEFT_BOTTOM, 10, y)
        :addTo(widget)

    y = y + line:getContentSize().height

    local label = RichLabel.new({
        fontSize = 16,
        maxWidth = 670,
    })
    label:setString(txt)
    label:align(display.LEFT_BOTTOM, x, y)
        :addTo(widget)

    y = y + label:getContentSize().height

    widget:setContentSize(cc.size(670, y))
    return widget
end


return FightLiveView