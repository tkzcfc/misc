local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local jobConf = require "app.configs.job"
local init = require "app.models.init"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"
local monsterConf = require "app.configs.monster"

local KfbsModel = init.KfbsModel
local HeroModel = init.HeroModel

local ChaSetTeamWin = class("ChaSetTeamWin", WinBase)
ChaSetTeamWin.RESOURCE_FILENAME = "crossServer/setTeam.csb"

function ChaSetTeamWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP

     local msgList = {
        msgids.GS_KfbsChampionSetTeamr_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function ChaSetTeamWin:receive(op, data)
    if op == msgids.GS_KfbsChampionSetTeamr_R then
        if self.index then
            KfbsModel.info.ChampionTeam = data.Team
            self:updateTeamInfo(self.index)
        end
    end
end

function ChaSetTeamWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("btn_ok"),function()
        self:closeSelf()
    end)
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[24314])
    local k = 1
    self.resourceNode_:actionScheduleInterval(function()
        local node = self.resourceNode_:getChildByName("node_"..k)
        if node then
            self:updateTeamInfo(k)
        else
            self.resourceNode_:stopAllActions()
        end
        k = k + 1
    end, 0.2)

end

function ChaSetTeamWin:updateTeamInfo(index)
    local node = self.resourceNode_:getChildByName("node_"..index)
    if not node then return end
    local teamData = KfbsModel.info.ChampionTeam or {}
    local heros = teamData[index] or {}
    UIImageBox.new(node:getChildByName("img_di"),function()
        local teamData = KfbsModel.info.ChampionTeam or {}
        if (teamData[index-1] and table.nums(teamData[index-1]) > 0) or (index == 1) then
            local disableHero = {}
            for i=1,3 do
                if i ~= index then
                    for k,heroId in pairs(teamData[i] or {}) do
                        disableHero[heroId] = true
                    end
                end
            end
            self:openWin("EmbattleWin",{
                heroIds = heros, 
                fightStatus = c.FightStatus.selectHero, 
                winName = self:getName(), 
                index = index,
                disableHero = disableHero,
            })
        else
            MoveLabel.new(WordDictionary[24354])
        end
    end, {noAnimEffect  = true, ableGLProgram = false})
    local addImg = node:getChildByName("btn_add")
    local itemNode = node:getChildByName("node_item")
    itemNode:removeAllChildren()
    if table.nums(heros) > 0 then
        addImg:setVisible(false)
        for i,heroId in ipairs(heros) do
            local item = self:createHeroItem(heroId)
            itemNode:addChild(item)
            item:setPositionX((i-1)*105)
        end
    else
        addImg:setVisible(true)
    end
end

function ChaSetTeamWin:createHeroItem(heroId)
    local node = self:createCsbNode("crossServer/heroItem.csb")
    local heroData = heroConf[heroId] or monsterConf[heroId]
    if heroData then
        local useData = HeroModel:getHero(heroId)
        local heroFrame = node:getChildByName("heroFrame")
        heroFrame:removeAllChildren()
        local imgName = "icon/head/" .. roleConf[heroData.role].head .. ".png"
        local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png",1)
        display.align(headImg,display.CENTER, heroFrame:getContentSize().width * 0.5 , heroFrame:getContentSize().height * 0.5)
        heroFrame:addChild(headImg)
        node:getChildByName("sp_job"):setSpriteFrame("public/" .. jobConf[heroData.jobId].icon .. ".png")
        node:getChildByName("txt_lv"):setString("Lv."..useData.level)
        node:getChildByName("txt_talent"):setString("+"..useData.cls)
        node:getChildByName("sp_rare"):setSpriteFrame("public/yingxiong-" .. heroData.rare .. ".png")
        Helper.updateHeroStar(node:getChildByName("starNode"), useData.star)
    else
        node:getChildByName("mask"):setVisible(true)
    end
    node:setScale(0.9)
    return node
end

function ChaSetTeamWin:setDefenderTeam(heroIds, params)
    local team = {}
    for idx = 1, 5 do
        team[idx] = heroIds[idx] or 0
    end

    local teamData = clone(KfbsModel.info.ChampionTeam or {})
    if params and params.index then
        self.index = params.index
        teamData[self.index] = team
    end
    network.tcpSend(msgids.C_KfbsChampionSetTeam, {Team = teamData})
end

function ChaSetTeamWin:getActionIn()
    Helper.enterWinAction1(self)
end

return ChaSetTeamWin