local c = require "app.configs.constants"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local SpineManager = require "sandglass.core.SpineManager"
local Helper = require "app.Helper"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local MoveLabel = require "sandglass.ui.MoveLabel"
local kfbsConf = require "app.configs.kfbs"

local RedTipsModel = init.RedTipsModel
local PlayerModel = init.PlayerModel
local KfbsModel = init.KfbsModel

local CS_STAGE = KfbsModel:getAllStage()

local CrossServerWin = class("CrossServerWin", WinBase)
CrossServerWin.RESOURCE_FILENAME = "crossServer/crossServer.csb"

function CrossServerWin:onCreate()
    self.showType = self.WinShowType.hiddenBack
	local msgList = {
		msgids.GS_KfbsSvrStage,
        msgids.GS_KfbsLadderRefresh_R,
        msgids.GS_KfbsLadderOneKey_R,
        msgids.GS_KfbsLadderBuyCnt_R,
        msgids.GS_KfbsLadderRank_R,
        msgids.GS_KfbsLadderLike_R,
        msgids.GS_KfbsChampionInfo_R,
        msgids.GS_KfbsChampionTeam_R,
        msgids.GS_BattleGetReplay_R,
        msgids.GS_KfbsChampionSetTeamr_R,
        msgids.GS_KfbsGetBarrage_R,
        msgids.GS_KfbsBarrageNew,
        msgids.GS_KfbsInfo_R,
        msgids.GS_KfbsChampionGuess_R,
        msgids.GS_KfbsLadderReport,
        msgids.GS_KfbsChampionLike_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_KfbsEnter)
end

function CrossServerWin:receive(op, data)
    -- 下发消息
    if not tolua.isnull(self.developView) and self.developView.receive then
        self.developView:receive(op, data)
    end
    if not tolua.isnull(self.liveView) and self.liveView.receive then
        self.liveView:receive(op, data)
    end

    if op == msgids.GS_KfbsSvrStage or op == msgids.GS_KfbsInfo_R
    or op == msgids.GS_KfbsChampionInfo_R then
        self:updateDevelop()
    end
end


function CrossServerWin:initialView()
    self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(WordDictionary[24300])
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
        network.tcpSend(msgids.C_KfbsQuit)
        self:closeSelf()
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"),function()
        self:openWin("PublicRuleWin", WordDictionary[24301])
    end)

    self:checkReplayInfo()
    self:updateDevelop()
end

function CrossServerWin:updateDevelop()
    local node = self.resourceNode_:getChildByName("node_content")
    node:removeAllChildren()
    local curStage = KfbsModel:getCurStage()

    if curStage == CS_STAGE.NotStart
    or curStage == CS_STAGE.PreSoonOpen
    or curStage == CS_STAGE.Close then
        self.developView = require ("app.views.crossServer.NotStartView").new(self)
    elseif curStage == CS_STAGE.PreStart then
        self.developView = require ("app.views.crossServer.PreelectionView").new(self)
    elseif curStage == CS_STAGE.PreEnd then
        self.developView = require ("app.views.crossServer.PreelectionEndView").new(self)
    elseif curStage == CS_STAGE.GroupSoon
    or curStage == CS_STAGE.Group
    or curStage == CS_STAGE.GroupEnd
    or curStage == CS_STAGE.Champion then 
        self.developView = require ("app.views.crossServer.ChampionView").new(self)
    elseif curStage == CS_STAGE.ChaEnd then
        if self.liveView then
            self.liveView:removeAllChildren()
            self.liveView = nil
        end
        self.developView = require ("app.views.crossServer.ChampionEndView").new(self)
    else
        self.developView = nil
    end
    if self.developView then
        node:addChild(self.developView) 
    end
end

function CrossServerWin:setDefenderTeam(heroIds, params)
    local team = {}
    for idx = 1, 5 do
        team[idx] = heroIds[idx] or 0
    end
    network.tcpSend(msgids.C_KfbsLadderSetTeam, {Team = team})
end

function CrossServerWin:checkReplayInfo()
    local curTime = Helper.getFixedTime()
    local stage, nextTime = KfbsModel:getCurStage()
    if curTime >= nextTime then
       network.tcpSend(msgids.C_KfbsInfo)
       return 
    end
    local isChampion = false
    local fightCnt = nil
    local conf = kfbsConf[1]
    if stage >= CS_STAGE.ChaEnd then
        fightCnt = 7 * 9
    elseif stage >= CS_STAGE.Champion then
        isChampion = true
    elseif stage >= CS_STAGE.GroupEnd then
        fightCnt = 7 * 8
    elseif stage >= CS_STAGE.Group then
        isChampion = false
    else
        fightCnt = 0
    end 

    if not fightCnt then
        local readyT = (isChampion and conf.championReady or conf.groupReady) * 60
        local fightT = (isChampion and conf.championFight or conf.groupFight) * 60
        local sTime = Helper.getFixedTime() - KfbsModel:getStageStartTime()
        sTime = sTime + readyT ---第一场不用准备---
        fightCnt = math.ceil(sTime / (readyT+fightT))
    end
    fightCnt = fightCnt - 1 
    if fightCnt >= 0 then
        local hasCnt = false
        for k,v in pairs(KfbsModel.chaInfo.Rep or {}) do
            if v.ChpFightCnt == fightCnt then
                hasCnt = true 
                break
            end
        end
        if not hasCnt then
            network.tcpSend(msgids.C_KfbsChampionInfo)
        end
    end
end

function CrossServerWin:openFightLive(replayInfo, isChampion, group)
    local liveNode = self.resourceNode_:getChildByName("node_live")
    local developNode = self.resourceNode_:getChildByName("node_content")
    if not self.liveView then
        self.liveView = require ("app.views.crossServer.FightLiveView").new(self)
        liveNode:addChild(self.liveView)
    end
    self.liveView:updateView(replayInfo, isChampion, group)
    liveNode:stopAllActions()
    developNode:stopAllActions()
    liveNode:setPositionY(display.height)
    liveNode:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.5, cc.p(0, 0))))
    developNode:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.5, cc.p(0, -display.height))))
    self.resourceNode_:getChildByName("closeNode"):setVisible(false)
end

function CrossServerWin:closeFightLive()
    local liveNode = self.resourceNode_:getChildByName("node_live")
    local developNode = self.resourceNode_:getChildByName("node_content")
    liveNode:stopAllActions()
    developNode:stopAllActions()
    liveNode:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.5, cc.p(0, display.height))))
    developNode:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.5, cc.p(0, 0))))
    self.resourceNode_:getChildByName("closeNode"):setVisible(true)
end

function CrossServerWin:onEventReceive(event)
    if not tolua.isnull(self.liveView) and self.liveView.onEventReceive then
        self.liveView:onEventReceive(event)
    end
end

return CrossServerWin
