local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local BulletScreen = require "sandglass.ui.BulletScreen"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skinConf = require "app.configs.skin"
local monsterConf = require "app.configs.monster"
local kfbsConf = require "app.configs.kfbs"
local c = require "app.configs.constants"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local KfbsModel = init.KfbsModel

local ChampionEndView = class('ChampionEndView',function() 
    return ccui.Layout:create()
end)

function ChampionEndView:ctor(parentWin)
    self.parentWin = parentWin
    self.canSendDanMu = true
    self:onWinEnter()
    network.tcpSend(msgids.C_KfbsGetBarrage, {Group = 0})
end

function ChampionEndView:receive(op,data)
    if op == msgids.GS_KfbsChampionLike_R then
        self:updateLikeNum()
        self.parentWin:openWin("PublicGetRewardWin",{rewards = data.Rewards})
    elseif op == msgids.GS_KfbsGetBarrage_R then
        self:createDanMu(data.Barrage or {})
    elseif op == msgids.GS_KfbsBarrageNew then
        local bulletData = data.Data
        local groupStr = self.isChampion and "" or string.format(WordDictionary[24359], bulletData.Group)
        local str = string.format(WordDictionary[23909], bulletData.Name) .. Helper.convertStringToExpression(string.format(WordDictionary[24371], "#FFFFFF", bulletData.Content))
        self.danMu:addBullet(str)
    end
end

function ChampionEndView:onWinEnter()
    self.contentView = self.parentWin:createCsbNode("crossServer/finalsResult.csb")
    self:addChild(self.contentView)

    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_rank"),function()
        self.parentWin:openWin("CsRankWin", true)
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_shop"),function()
        self.parentWin:openWin("ShopWin", 46)
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_reward"),function()
        self.parentWin:openWin("CsRewardWin", true)
    end)
    -- UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_log"),function()
    --     self.parentWin:openWin("ChaReplayWin")
    -- end)
    -- UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("btn_setTeam"),function()
    --     self.parentWin:openWin("EmbattleWin",{
    --         heroIds = KfbsModel.info.LadderTeam or {}, 
    --         fightStatus = c.FightStatus.selectHero, 
    --         winName = self.parentWin:getName(), 
    --     })
    -- end)

    local nextTime = WordDictionary[24364]
    local timeInfo = string.split(kfbsConf[1].open, "/")
    nextTime = nextTime..WordDictionary[24505 + tonumber(timeInfo[1])]..timeInfo[2]
    self.contentView:getChildByName("node_lb"):getChildByName("txt_openTime"):setString(nextTime)
    self.contentView:getChildByName("node_lb"):getChildByName("txt_curRank"):setString(KfbsModel:getMyInfoData(true) or WordDictionary[24319])
    self.contentView:getChildByName("node_lb"):getChildByName("txt_tips"):setString(WordDictionary[24309])
    local maxRank = KfbsModel.info.ChampionHisIdx > 0 and KfbsModel.info.ChampionHisIdx or WordDictionary[24319]
    self.contentView:getChildByName("node_lb"):getChildByName("txt_maxRank"):setString(maxRank)

    self.playerData = {}
    for i,v in pairs(KfbsModel.chaInfo.Rec or {}) do
        if v.Idx <= 3 then
            table.insert(self.playerData, v)
        end
    end
    table.sort(self.playerData, function(a, b)
        return a.Idx < b.Idx
    end)

    for i=1,3 do
        local node = self.contentView:getChildByName("node_cc"):getChildByName("node_"..i)
        local data = self.playerData[i]
        node:getChildByName("txt_name"):setString(data and data.Name or WordDictionary[24303])
        node:getChildByName("txt_server"):setString(data and string.format(WordDictionary[24357], data.SvrId) or "")
        if data and (heroConf[data.HeroId] or monsterConf[data.HeroId]) then
            local hData = heroConf[data.HeroId] or monsterConf[data.HeroId]
            local path = "spine/actors/".. roleConf[hData.role].spine
            local anim = SpineManager.createAnimation(path)  
            node:getChildByName("node_spine"):addChild(anim)
            anim:registerSkin("normal")
            anim:playAnimation("idle", -1)
            anim:setScale(1.2)
        end
    end
    self:updateLikeNum()
end

function ChampionEndView:updateLikeNum()
    for i=1,3 do
        local likeBtn = self.contentView:getChildByName("node_cc"):getChildByName("node_"..i):getChildByName("btn_like")
        local data = self.playerData[i]
        if data then
            likeBtn:setVisible(true)
            UIImageBox.new(likeBtn,function()
                network.tcpSend(msgids.C_KfbsChampionLike, {PlrId = data.PlrId})
            end)
            likeBtn:getChildByName("txt_num"):setString(data.BeLike)
        else
            likeBtn:setVisible(false)
        end
    end
    local myInfo = KfbsModel:getMyInfoData()
    self.contentView:getChildByName("node_lb"):getChildByName("txt_likeCnt"):setString(myInfo.BeLike or 0)
end

----弹幕--
function ChampionEndView:createDanMu(data)
    local danMuList = {}
    for k,v in ipairs(data) do
        local str = string.format(WordDictionary[23909], v.Name) .. Helper.convertStringToExpression(string.format(WordDictionary[24371], "#FFFFFF", v.Content))
        table.insert(danMuList,{str = str})
    end

    self.danMu = BulletScreen.new({
        parentNode = self.contentView:getChildByName("node_danmu"),
        bulletList = danMuList,
        isOpen = PlayerConfig.getSetting(PlayerModel.info.userId.."openCrossServerDanMu", true),
    })
    self.danMu:start()

    self.danMuBtn = UIImageBox.new(self.contentView:getChildByName("node_rb"):getChildByName("btn_chatToggle"), function()
        local isOpen = self.danMu:getOpen()
        self.danMu:setOpen(not isOpen)
        PlayerConfig.setSetting(PlayerModel.info.userId.."openCrossServerDanMu",not isOpen)
        self:updateDanMuBtn()
    end, {noAnimEffect = true})
    self:updateDanMuBtn()
    ------发送弹幕
    UIImageBox.new(self.contentView:getChildByName("node_rb"):getChildByName("btn_chat"), function()
        if self.canSendDanMu then
            self.parentWin:openWin("DanMuWin", function(str)
                if str ~= "" then
                    network.tcpSend(msgids.C_KfbsBarrage, {Group =0, Content = str})
                    self:startSendDanMu() 
                else
                    MoveLabel.new(WordDictionary[23926])
                end
            end, kfbsConf[1].barrageLen)
        else
            MoveLabel.new(WordDictionary[23904])     
        end
    end)
end

function ChampionEndView:updateDanMuBtn()
    local sp_spot = self.danMuBtn:getChildByName("sp_spot")
    local txt_tip = self.danMuBtn:getChildByName("txt_name")
    local isOpenDanMu = PlayerConfig.getSetting(PlayerModel.info.userId.."openCrossServerDanMu", true)
    if isOpenDanMu then
        sp_spot:setPositionX(self.danMuBtn:getContentSize().width-sp_spot:getContentSize().width/2)
        txt_tip:setString(WordDictionary[23902])
        self.danMuBtn:loadTexture("public/tongyong-kaiguan2.png",ccui.TextureResType.plistType)
    else
        sp_spot:setPositionX(sp_spot:getContentSize().width/2)
        txt_tip:setString(WordDictionary[23903])
        self.danMuBtn:loadTexture("public/tongyong-kaiguan1.png",ccui.TextureResType.plistType)
    end
end


function ChampionEndView:startSendDanMu()
    local danMuCD = 5
    self.canSendDanMu = false
    self.contentView:stopAllActions()
    self.contentView:runAction(cc.Sequence:create(cc.DelayTime:create(danMuCD), cc.CallFunc:create(function()
        self.canSendDanMu = true
    end)))
end

return ChampionEndView