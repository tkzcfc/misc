local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local init = require "app.models.init"
local kfbsChampionConf = require "app.configs.kfbsChampion"
local CoreColor = require "sandglass.core.CoreColor"

local KfbsModel = init.KfbsModel

local BetsLogWin = class("BetsLogWin", WinBase)
BetsLogWin.RESOURCE_FILENAME = "crossServer/guessRecord.csb"

function BetsLogWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP
end

function BetsLogWin:initialView()
    self.itemId = kfbsChampionConf[1].guessId
    self:setAutoClose(self.resourceNode_:getChildByName("bg"))
    self.resourceNode_:getChildByName("sp_icon"):setTexture(Helper.getPathById(self.itemId))
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[24312])
    self.resourceNode_:getChildByName("txt_getLabel"):setString(WordDictionary[24313])

    local listData = {}
    local num = 0
    for k,v in ipairs(KfbsModel.info.ChampionGuessGet or {}) do
        if v.Num > 0 then
            table.insert(listData, v)
            num = num + v.Get
        end
    end
    self:setTextString(num, self.resourceNode_:getChildByName("txt_num"))
    local listView = self.resourceNode_:getChildByName("list_rank")
    listView:updateListView(listData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end)
end

function BetsLogWin:createRankItem(data,index)
    local node = self:createCsbNode("crossServer/recordNode.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        self:setTextString(data.Get, itemView:getChildByName("txt_num"))
        itemView:getChildByName("sp_icon"):setTexture(Helper.getPathById(self.itemId))
        itemView:getChildByName("txt_name"):setString(KfbsModel:getFgithType(data.Cnt))
        local num = WordDictionary[24370]..(data.Rate/10)
        if data.Get <= 0 then
            num = ""
        end
        itemView:getChildByName("txt_odds"):setString(num)
    end
    layer:setContentSize(cc.size(378, 40))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer
end

function BetsLogWin:setTextString(num, text)
    local num = num
    local color = CoreColor.WHITE
    if num > 0 then
        num = "+ "..num
        color = CoreColor.GREEN
    elseif num < 0 then
        num = num
        color = CoreColor.RED
    end
    text:setString(num)
    text:setTextColor(color)
end

function BetsLogWin:getActionIn()
    Helper.enterWinAction1(self)
end

return BetsLogWin