local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local jobConf = require "app.configs.job"
local init = require "app.models.init"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local monsterConf = require "app.configs.monster"

local KfbsModel = init.KfbsModel
local HeroModel = init.HeroModel

local ChaPlayerTeamWin = class("ChaPlayerTeamWin", WinBase)
ChaPlayerTeamWin.RESOURCE_FILENAME = "crossServer/setTeam.csb"

function ChaPlayerTeamWin:onCreate(data)
    self.priority = c.WIN_ZORDER.POPUP
    self.data = data
end

function ChaPlayerTeamWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[24355])
    self.resourceNode_:getChildByName("btn_ok"):setVisible(false)
    self.resourceNode_:getChildByName("btn_close"):setVisible(true)
    for i=1,3 do
        self.resourceNode_:getChildByName("node_"..i):getChildByName("btn_add"):setVisible(false)
    end
    local k = 1
    self.nodes = {}
    self.resourceNode_:actionScheduleInterval(function()
        local node = self.resourceNode_:getChildByName("node_"..k)
        if node then
            self.nodes[k] = node
            self:updateTeamInfo(k)
        else
            self.resourceNode_:stopAllActions()
        end
        k = k + 1
    end, 0.2)

end

function ChaPlayerTeamWin:updateTeamInfo(index)
    local node = self.nodes[index]
    if not node then return end
    local teamData = self.data.Cts[index]
    local heros = teamData and teamData.Bt or {}
    local itemNode = node:getChildByName("node_item")
    itemNode:removeAllChildren()
    for i=1,5 do
        local item = self:createHeroItem(heros[i])
        itemNode:addChild(item)
        item:setPositionX((i-1)*105)
    end
end

function ChaPlayerTeamWin:createHeroItem(data)
    local node = self:createCsbNode("crossServer/heroItem.csb")
    if data and (heroConf[data.Id] or monsterConf[data.Id]) then
        local heroData = heroConf[data.Id] or monsterConf[data.Id]
        local heroFrame = node:getChildByName("heroFrame")
        heroFrame:removeAllChildren()
        local imgName = "icon/head/" .. roleConf[heroData.role].head .. ".png"
        local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png",1)
        display.align(headImg,display.CENTER, heroFrame:getContentSize().width * 0.5 , heroFrame:getContentSize().height * 0.5)
        heroFrame:addChild(headImg)
        node:getChildByName("sp_job"):setSpriteFrame("public/" .. jobConf[heroData.jobId].icon .. ".png")
        node:getChildByName("txt_lv"):setString("Lv."..data.Lv)
        node:getChildByName("txt_talent"):setString("+"..data.Cls)
        node:getChildByName("sp_rare"):setSpriteFrame("public/yingxiong-" .. heroData.rare .. ".png")
        Helper.updateHeroStar(node:getChildByName("starNode"), data.Star)
    else
        node:getChildByName("mask"):setVisible(true)
    end
    node:setScale(0.9)
    return node
end

function ChaPlayerTeamWin:getActionIn()
    Helper.enterWinAction1(self)
end

return ChaPlayerTeamWin