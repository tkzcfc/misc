local Helper = require "app.Helper"
local c = require "app.configs.constants"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local KfbsModel = init.KfbsModel

local CS_STAGE = KfbsModel:getAllStage()

local NotStartView = class('NotStartView',function() 
    return ccui.Layout:create()
end)

function NotStartView:ctor(parentWin)
    self.parentWin = parentWin
    self:onWinEnter()
end

function NotStartView:receive(op,data)
   
end

function NotStartView:onWinEnter()
    self.contentView = self.parentWin:createCsbNode("crossServer/notStarted.csb")
    self:addChild(self.contentView)
    local stage, time = KfbsModel:getCurStage()

    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_guesses"),function()
        if stage == CS_STAGE.PreSoonOpen then
            self.parentWin:openWin("PreGuessesWin")
        else
            MoveLabel.new(WordDictionary[24315])
        end
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_rank"),function()
        self.parentWin:openWin("PreRankWin")
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_shop"),function()
        self.parentWin:openWin("ShopWin", 46)
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_log"),function()
        self.parentWin:openWin("PreReplayWin")
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_reward"),function()
        self.parentWin:openWin("CsRewardWin")
    end)

    local txt_time = self.contentView:getChildByName("node_ct"):getChildByName("txt_time")
    txt_time:stopAllActions()
    if time-Helper.getFixedTime() > 0 then
        txt_time:setString(Helper.getTimeString(time-Helper.getFixedTime(),true,true))
        txt_time:actionScheduleInterval(function()
            if time-Helper.getFixedTime() < 0 then
               txt_time:stopAllActions() 
            elseif stage == CS_STAGE.PreSoonOpen then
                txt_time:setString(Helper.getTimeString(time-Helper.getFixedTime(),true,true))
            end 
        end, 1)
    else
        txt_time:setString(Helper.getTimeString(0,true,true))
    end
    if stage == CS_STAGE.NotStart or stage == CS_STAGE.Close then
        self.contentView:getChildByName("node_ct"):getChildByName("txt_timeStr"):setString(WordDictionary[24315])
        txt_time:setString("")
    elseif stage == CS_STAGE.PreSoonOpen then
        self.contentView:getChildByName("node_ct"):getChildByName("txt_timeStr"):setString(WordDictionary[24316])
    end


    self.contentView:getChildByName("node_lb"):getChildByName("txt_myRank"):setString(KfbsModel.info.LadderIdx>0 and KfbsModel.info.LadderIdx or WordDictionary[24319])
    self.contentView:getChildByName("node_cb"):getChildByName("txt_tips"):setString(WordDictionary[24302])

    UIImageBox.new(self.contentView:getChildByName("node_cb"):getChildByName("btn_setTeam"),function()
        if stage == CS_STAGE.PreSoonOpen then
            self.parentWin:openWin("EmbattleWin",{
                heroIds = KfbsModel.info.LadderTeam or {}, 
                fightStatus = c.FightStatus.selectHero, 
                winName = self.parentWin:getName(), 
            })
        else
            MoveLabel.new(WordDictionary[24315])
        end
    end)

end



return NotStartView

