local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local CoreColor = require "sandglass.core.CoreColor"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skinConf = require "app.configs.skin"
local kfbsConf = require "app.configs.kfbs"
local buyConf = require "app.configs.buy"
local monsterConf = require "app.configs.monster"
local c = require "app.configs.constants"
local kfbsLadderConf = require "app.configs.kfbsLadder"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local KfbsModel = init.KfbsModel

local PreelectionView = class('PreelectionView',function() 
    return ccui.Layout:create()
end)

function PreelectionView:ctor(parentWin)
    self.parentWin = parentWin
    self:onWinEnter()
    network.tcpSend(msgids.C_KfbsLadderRefresh)
end

function PreelectionView:receive(op,data)
    if op == msgids.GS_KfbsLadderRefresh_R then
        self:updateRankInfo(data.Rec or {})
    elseif op == msgids.GS_KfbsLadderOneKey_R then
        self.parentWin:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        self:updateView()
    elseif op == msgids.GS_KfbsLadderBuyCnt_R then
        self:updateView()
    elseif op == msgids.GS_KfbsLadderReport then
        self:checkLogBtnRedTip()
        self:updateView()
    end
end

function PreelectionView:onWinEnter()
    self.contentView = self.parentWin:createCsbNode("crossServer/trials.csb")
    self:addChild(self.contentView)

    self.contentView:getChildByName("node_rb"):getChildByName("txt_tips"):setString(WordDictionary[24382])
    self.contentView:getChildByName("node_ct"):getChildByName("txt_tips"):setString(WordDictionary[24383])

    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_guesses"),function()
        self.parentWin:openWin("PreGuessesWin")
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_rank"),function()
        self.parentWin:openWin("CsRankWin")
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_log"),function()
        self.parentWin:openWin("PreReplayWin", function()
            if self.checkLogBtnRedTip then
                self:checkLogBtnRedTip()
            end
        end)
    end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_reward"),function()
        self.parentWin:openWin("CsRewardWin")
    end)
    -- UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_shop"),function()
    --     self.parentWin:openWin("ShopWin", 46)
    -- end)
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_hotShop"),function()
        self.parentWin:openWin("DiscountShopWin", 1)
    end)

    local _, time = KfbsModel:getCurStage()
    local txt_time = self.contentView:getChildByName("node_ct"):getChildByName("txt_time")
    txt_time:stopAllActions()
    if time - Helper.getFixedTime() > 0 then
        txt_time:setString(Helper.getTimeString(time - Helper.getFixedTime(),true,true))
        txt_time:actionScheduleInterval(function()
            if time < 0 then
               txt_time:stopAllActions() 
            else
                txt_time:setString(Helper.getTimeString(time - Helper.getFixedTime(),true,true))
            end 
        end, 1)
    else
        txt_time:setString(Helper.getTimeString(0,true,true))
    end

    self.refreshBtn = UIImageBox.new(self.contentView:getChildByName("node_rb"):getChildByName("btn_refresh"),function()
        self:refreshBtnTime()
        network.tcpSend(msgids.C_KfbsLadderRefresh)
    end)
    
    self:checkLogBtnRedTip()
    self:updateView()
end

function PreelectionView:refreshBtnTime()
    local time = kfbsLadderConf[1].refreshCD
    self.refreshBtn:setEnabled(false)
    self.refreshBtn:stopAllActions()
    self.refreshBtn:getChildByName("txt_btn"):setString(Helper.getTimeString(time, true))
    self.refreshBtn:actionScheduleInterval(function()
        time = time - 1
        if time < 0 then
           self.refreshBtn:stopAllActions() 
           self.refreshBtn:getChildByName("txt_btn"):setString(WordDictionary[24318])
           self.refreshBtn:setEnabled(true)
        else
            self.refreshBtn:getChildByName("txt_btn"):setString(Helper.getTimeString(time, true))
        end 
    end, 1)
end

function PreelectionView:updateView()
    self.contentView:getChildByName("node_lb"):getChildByName("txt_myRank"):setString(KfbsModel.info.LadderIdx>0 and KfbsModel.info.LadderIdx or WordDictionary[24319])
    self.contentView:getChildByName("node_lb"):getChildByName("txt_power"):setString(PlayerModel.info.atkPwr or 0)

    local txt_rewardCnt = self.contentView:getChildByName("node_rb"):getChildByName("txt_fightCnt")
    local maxNum = kfbsLadderConf[1].fightCnt
    local rewardCnt = maxNum - KfbsModel.info.LadderCnt
    if rewardCnt < 0 then
        rewardCnt = 0
    end
    txt_rewardCnt:setString(rewardCnt.."/"..maxNum)
    ----一键挑战
    local btn = UIImageBox.new(self.contentView:getChildByName("node_rb"):getChildByName("btn_fight"),function()
        if rewardCnt <= 0 then
            MoveLabel.new(WordDictionary[24321])
        else
            network.tcpSend(msgids.C_KfbsLadderOneKey)
        end
    end)

    if rewardCnt > 0 then
        btn:setEnabled(true)
        txt_rewardCnt:setTextColor(CoreColor.GREEN)
    else
        btn:setEnabled(false)
        txt_rewardCnt:setTextColor(CoreColor.RED)
    end
end

function PreelectionView:updateRankInfo(pDatas)
    table.sort(pDatas, function(a, b)
        return a.Idx > b.Idx
    end)
    local k = 1
    local node = self.contentView:getChildByName("node_hero")
    node:stopAllActions()
    node:actionScheduleInterval(function()
        local heroNode = node:getChildByName("node_"..k)
        if not heroNode then
            node:stopAllActions()
            return
        end
        local data = pDatas[k]
        if data then
            heroNode:setVisible(true)
            local animNode = heroNode:getChildByName("node_spine")
            animNode:removeAllChildren()
            if data.HeroId and data.HeroId ~= 0 then
                local conf = heroConf[data.HeroId] or monsterConf[data.HeroId]
                local path = "spine/actors/" .. roleConf[conf.role].spine
                local anim = SpineManager.createAnimation(path)
                anim:registerSkin(skinConf[data.CurSkin > 0 and data.CurSkin or 1].spineName)
                anim:playAnimation("idle", -1)
                -- anim:setScale(1)
                animNode:addChild(anim)
            end

            local isSelf = data.PlrId == PlayerModel.info.userId
            local fightBtn = UIImageBox.new(heroNode:getChildByName("btn_fight"),function()
                    --local hasTeam = false
                    --or _,id in pairs(KfbsModel.info.LadderTeam) do
                       -- if id > 0 then
                         --   hasTeam = true
                           -- break
                       -- end
                    --end
                    --if hasTeam then
                        local attackPlayerInfo = {
                            name = PlayerModel.info.name,
                            head = PlayerModel.info.head,
                            hFrame = PlayerModel.info.hFrame,
                            title = PlayerModel.info.title
                        }
                        local defenderPlayerInfo = {
                            name = data.Name,
                            head = data.Head,
                            hFrame = data.HFrame,
                            title = data.Title
                        }
                        self.parentWin:openWin("EmbattleWin", {fightStatus = c.FightStatus.kfbsLadder, Tar = {PlrId = data.PlrId, Val = data.Idx}, attackPlayerInfo = attackPlayerInfo, defenderPlayerInfo = defenderPlayerInfo})
                    --else
                        -- self.parentWin:openWin("EmbattleWin",{
                        --     heroIds = {}, 
                        --     fightStatus = c.FightStatus.selectHero, 
                        --     winName = self.parentWin:getName(), 
                        -- })
                      --  MoveLabel.new(WordDictionary[24322])
                   -- end
            end)
            fightBtn:setEnabled(not isSelf)
            heroNode:getChildByName("txt_index"):setString(data.Idx)
            heroNode:getChildByName("txt_index"):setTextColor(isSelf and CoreColor.GREEN or CoreColor.ORANGE)
            heroNode:getChildByName("txt_name"):setString(data.Name)
            heroNode:getChildByName("txt_name"):setTextColor(isSelf and CoreColor.GREEN or CoreColor.WHITE)
            heroNode:getChildByName("txt_server"):setString(string.format(WordDictionary[24357], data.SvrId))
            heroNode:getChildByName("txt_server"):setTextColor(isSelf and CoreColor.GREEN or CoreColor.ORANGE)
            heroNode:getChildByName("txt_power"):setString(data.BtAtk)
        else
            heroNode:setVisible(false)
        end
        k = k + 1
    end, 0.05)
end

function PreelectionView:checkLogBtnRedTip()
    local btn = self.contentView:getChildByName("node_rt"):getChildByName("btn_log")
    RedTipsModel:removeRedTip(btn)
    if KfbsModel.preNewLog and table.nums(KfbsModel.preNewLog) > 0 then
        RedTipsModel:addRedTip(btn, cc.p(50,55))
    end
end

return PreelectionView