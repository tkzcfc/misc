local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local c = require "app.configs.constants"
local monsterConf = require "app.configs.monster"
local kfbsLadderConf = require "app.configs.kfbsLadder"
local MoveLabel = require "sandglass.ui.MoveLabel"

local KfbsModel = init.KfbsModel

local PreGuessesWin = class("PreGuessesWin", WinBase)
PreGuessesWin.RESOURCE_FILENAME = "crossServer/guess2.csb"

function PreGuessesWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP

    local msgList = {
        msgids.GS_KfbsLadderRank_R,
        msgids.GS_KfbsLadderGuess_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_KfbsLadderRank, {Guess = true})
end

function PreGuessesWin:receive(op, data)
    if op == msgids.GS_KfbsLadderRank_R then
        self:updateView(data.Rec or {})
    elseif op == msgids.GS_KfbsLadderGuess_R then
        network.tcpSend(msgids.C_KfbsLadderRank, {Guess = true})
    end
end

function PreGuessesWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    self.resourceNode_:getChildByName("txt_tips"):setString(WordDictionary[24334])
end

function PreGuessesWin:updateView(rankData)
    table.sort(rankData, function(a, b)
        return a.Idx < b.Idx
    end )
    local listView = self.resourceNode_:getChildByName("list_rank")
    listView:updateListView(rankData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end, true, true)
end

function PreGuessesWin:createRankItem(data,index)
    local node = self:createCsbNode("crossServer/trialsRankItem.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        itemView:getChildByName("txt_name"):setString(data.Name)
        itemView:getChildByName("txt_power"):setString(data.BtAtk)
        itemView:getChildByName("txt_family"):setString((data.Guild == "") and WordDictionary[24385] or data.Guild)
        itemView:getChildByName("txt_num"):setString(data.BeGuess)
        if index > 3 then
            itemView:getChildByName("sp_num"):setVisible(false)
            itemView:getChildByName("txt_index"):setString(data.Idx)
        else
            itemView:getChildByName("sp_num"):setVisible(true)
            itemView:getChildByName("txt_index"):setString("")
            itemView:getChildByName("sp_num"):setSpriteFrame("public/0"..index..".png")
        end
        local node_team = itemView:getChildByName("node_team")
        node_team:removeAllChildren()
        for i,id in ipairs(data.Team or {}) do
            if id ~= 0 then
                local heroHead = nil
                if monsterConf[id] then
                    heroHead = Helper.CreateMonsterHead({scale = 0.5, id = id}) 
                else
                    heroHead = Helper.createGoodsItem({scale = 0.5, id = id})
                end
                node_team:addChild(heroHead)
                heroHead:setPositionX((i-1)*50)
            end
        end

        local likeBtn = UIImageBox.new(itemView:getChildByName("btn"),function()
            local guesseds = KfbsModel.info.LadderGuess or {}
            if table.nums(guesseds) < kfbsLadderConf[1].guessCnt then
                network.tcpSend(msgids.C_KfbsLadderGuess, {PlrId = data.PlrId})
            else
                MoveLabel.new(WordDictionary[24376])
            end
        end)

        local guessed = false
        for k,v in pairs(KfbsModel.info.LadderGuess or {}) do
            if v == data.PlrId then
                guessed = true
                break
            end
        end
        if guessed then
            likeBtn:setEnabled(false)
        else
            likeBtn:setEnabled(true)
        end
    end
    local size = node:getChildByName("img_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height+4))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer

end

function PreGuessesWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PreGuessesWin