local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local init = require "app.models.init"
local kfbsChampionConf = require "app.configs.kfbsChampion"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"

local KfbsModel = init.KfbsModel

local BetsSelectWin = class("BetsSelectWin", WinBase)
BetsSelectWin.RESOURCE_FILENAME = "crossServer/betsTips.csb"

function BetsSelectWin:onCreate(playerId, itemId, fightCnt)
    self.priority = c.WIN_ZORDER.POPUP
    self.playerId = playerId
    self.itemId = itemId
    self.fightCnt = fightCnt
end

function BetsSelectWin:initialView()
    self:setAutoClose(self.resourceNode_:getChildByName("bg"))
    self.resourceNode_:getChildByName("sp_icon"):setTexture(Helper.getPathById(self.itemId))
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_ok"),function()
        if self.useNum and self.useNum > 0 then
            network.tcpSend(msgids.C_KfbsChampionGuess, {PlrId = self.playerId, Num = self.useNum, ChpFightCnt = self.fightCnt})
            self:closeSelf()
        else
            MoveLabel.new(WordDictionary[24387])
        end
    end)

    self:updateView()

end

function BetsSelectWin:updateView()
    local myNum = Helper.getItemOrCurrencyCnt(self.itemId)
    self.resourceNode_:getChildByName("txt_ownNum"):setString(myNum)
    -------滑动条---------
    local updateUseNum = function(num)
        self.resourceNode_:getChildByName("txt_useNum"):setString(num)
        self.useNum = num
    end
    local slider = self.resourceNode_:getChildByName("slider")
    local maxNumber = kfbsChampionConf[1].guessMax
    local minNumber = kfbsChampionConf[1].guessMin
    if myNum < minNumber then
        maxNumber = 0
    elseif myNum < maxNumber then
        maxNumber = myNum
    end
    local useNum = maxNumber
    slider:setMaxPercent(maxNumber)
    slider:setPercent(useNum)
    updateUseNum(useNum)
    if maxNumber == 0 then return end
    UIImageBox.new(self.resourceNode_:getChildByName("btn_minus"),function()
        useNum = useNum - 1
        if useNum < minNumber then
            useNum = minNumber
        end
        slider:setPercent(useNum)
        updateUseNum(useNum)
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("btn_add"),function()
        useNum = useNum + 1
        if useNum > maxNumber then
            useNum = maxNumber
        end
        slider:setPercent(useNum)
        updateUseNum(useNum)
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_max"),function()
        useNum = maxNumber
        slider:setPercent(useNum)
        updateUseNum(useNum)
    end)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_min"),function()
        useNum = minNumber
        slider:setPercent(useNum)
        updateUseNum(useNum)
    end)

    slider:addEventListener(function(sender,eventType)
        if eventType == ccui.SliderEventType.percentChanged then
            useNum = slider:getPercent()
            if useNum < minNumber then
                useNum = minNumber
            end
            slider:setPercent(useNum)
            updateUseNum(useNum)
        end
    end)
    
end


function BetsSelectWin:getActionIn()
    Helper.enterWinAction1(self)
end

return BetsSelectWin