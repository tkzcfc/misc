local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local hotShopConf = require "app.configs.hotShop"
local init = require "app.models.init"
local MoveLabel = require "sandglass.ui.MoveLabel"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local SpineManager = require "sandglass.core.SpineManager"

local PlayerModel = init.PlayerModel

local DiscountShopWin = class("DiscountShopWin", WinBase)
DiscountShopWin.RESOURCE_FILENAME = "crossServer/discountShop.csb"

function DiscountShopWin:onCreate(gotoType)
    self.priority = c.WIN_ZORDER.POPUP
    self.gotoType = gotoType

    local msgList = {
        msgids.GS_HotShopInfo_R,
        msgids.GS_HotShopTake_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))

    network.tcpSend(msgids.C_HotShopInfo)
end

function DiscountShopWin:receive(op, data)
    if op == msgids.GS_HotShopInfo_R then
        self.Taken = data.Data.Taken or {}
        self:updateView()
    elseif op == msgids.GS_HotShopTake_R then
        local hasId = false
        for k,v in pairs(self.Taken) do
            if v.Id == data.Id then
                hasId = true
                v.N = v.N + 1
                break
            end
        end
        if not hasId then
            table.insert(self.Taken, {Id = data.Id, N = 1})
        end
        if data.Rewards then
            Helper.receiveReward({rewards = data.Rewards})
        end
        self:updateView()
    end
end

function DiscountShopWin:initialView()
    local anim = SpineManager.createAnimation("activity/rebateshop/ui_cha_tianzhaodi",1)
    anim:playAnimation("idle", -1)
    self.resourceNode_:getChildByName("node_spine"):addChild(anim)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    if self.gotoType == 3 then
        self.resourceNode_:getChildByName("sp_title"):setVisible(false)
    end
end 

function DiscountShopWin:updateView()
    local allConf = {}
    for i,v in ipairs(clone(hotShopConf)) do
        if v.type == self.gotoType then
            if not allConf[v.week] then
                allConf[v.week] = {}
            end
            table.insert(allConf[v.week], v)
        end
    end

    local confData = {}
    local secs = Helper.getFixedTime() - PlayerModel.info.svrOpenTs
    ---- 获取开服时间是星期几，然后补天数星期天就补上6天，星期一补0天----
    local svrOpenTs = os.date("*t",PlayerModel.info.svrOpenTs)
    local wday = (svrOpenTs.wday - 1 == 0) and 7 or svrOpenTs.wday - 1
    secs = secs + ((wday - 1) * 24*60*60)
    local week = math.ceil(secs/(7*24*60*60))
    while not allConf[week] do
        if week == 0 then
            break
        end
        week = week - 1
    end

    for i,v in ipairs(clone(allConf[week] or {})) do
        if not confData[v.grid] then
            confData[v.grid] = {}
        end
        table.insert(confData[v.grid], v)
    end

    local data_ = {}
    for k,data in pairs(confData) do
        for _,v in ipairs(data) do
            if self:checkIsCurItem(v.id, v.buyLimit) then
                data_[k] = v
                break
            end
        end
        if not data_[k] then
            data_[k] = data[#data]
        end
    end

    local shopData = {}
    for k,v in pairs(data_) do
        table.insert(shopData, v)
    end

    table.sort(shopData, function(a, b)
        return a.grid < b.grid
    end)

    local listView = self.resourceNode_:getChildByName("listview")
    listView:setScrollBarEnabled(false)
    listView:updateGridView(4, shopData, function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end)
end

function DiscountShopWin:createItem(data,index)
    local node = self:createCsbNode("crossServer/discountShopItem.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        itemView:getChildByName("txt_num"):setString((data.sale/1000)..WordDictionary[21633])
        local node_item = itemView:getChildByName("node_item")
        node_item:removeAllChildren()
        local icon = Helper.createGoodsItem({scale = 0.7,id = data.item[1].id,num = data.item[1].n})       
        node_item:addChild(icon)
        itemView:getChildByName("sp_icon1"):setTexture(Helper.getPathById(data.price[1].id))
        itemView:getChildByName("sp_icon_2"):setTexture(Helper.getPathById(data.buyCost[1].id))
        itemView:getChildByName("txt_oriPrice"):setString(data.price[1].n)
        itemView:getChildByName("txt_curPrice"):setString(data.buyCost[1].n)
        local sp_nil = itemView:getChildByName("sp_nil")
        local buyBtn = UIImageBox.new(itemView:getChildByName("btn_buy"),function(me)
            local myCnt = Helper.getItemOrCurrencyCnt(data.buyCost[1].id)
            if myCnt >= data.buyCost[1].n then
                network.tcpSend(msgids.C_HotShopTake, {Id = data.id})
                me:setTouchEnabled(false)
            else
                MoveLabel.new(WordDictionary[25118])
            end
        end)
        if self:checkIsCurItem(data.id, data.buyLimit) then
            buyBtn:setEnabled(true)
            sp_nil:setVisible(false)
        else
            buyBtn:setEnabled(false)
            sp_nil:setVisible(true)
        end
    end
    local size = node:getChildByName("sp_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width+20,size.height+4))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setPosition(10, 0)
    node:setName("itemView")
    return layer
end

function DiscountShopWin:checkIsCurItem(id, limitCnt)
    for k,v in pairs(self.Taken or {}) do
        if v.Id == id then
            if v.N >= limitCnt then
                return false
            end 
            break
        end
    end
    return true
end

function DiscountShopWin:getActionIn()
    Helper.enterWinAction1(self)
end

return DiscountShopWin