local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local TeamController = require "app.battle.controllers.TeamController"
local msgPack = require "app.battle.server.MessagePack"
local CoreColor = require "sandglass.core.CoreColor"

local KfbsModel = init.KfbsModel
local PlayerModel = init.PlayerModel

local PreReplayWin = class("PreReplayWin", WinBase)
PreReplayWin.RESOURCE_FILENAME = "crossServer/warReport.csb"

function PreReplayWin:onCreate(callBack)
    self.priority = c.WIN_ZORDER.POPUP
    self.callBack = callBack
    self.curPage = 1
    self.replayData = {}
    local msgList = {
        msgids.GS_KfbsLadderRep_R,
        msgids.GS_BattleGetReplay_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_KfbsLadderRep)
end

function PreReplayWin:receive(op,data)
    if op == msgids.GS_KfbsLadderRep_R then
        self.replayData[2] = data.Rep or {}
    elseif op == msgids.GS_BattleGetReplay_R then
        local replay = msgPack.unpack(data.Replay)
        local value = TeamController.getDataFromServer(replay.T)
        value.params.fightStatus = c.FightStatus.kfbsLadder
        value.params.seed = replay.Seed
        value.params.isWin = self.result
        value.params.attackPlayerInfo = self.attackPlayerInfo
        value.params.defenderPlayerInfo = self.defenderPlayerInfo 
        value.params.isReplay = true
        value.params.afterLoading = Helper.getFromScene()
        KfbsModel:removeNewLog()
        self:getApp():enterScene("GameScene", value)
    end
end

function PreReplayWin:initialView()  
    self.replayData[1] = KfbsModel.info.LadderRep or {}
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        KfbsModel:removeNewLog()
        if self.callBack then
            self.callBack()
        end
        self:closeSelf()
    end)

    for i=1,2 do
        UIImageBox.new(self.resourceNode_:getChildByName("btn_record_"..i),function()
            if self.curPage ~= i then
                self.curPage = i
                self:updateView()
            end
        end)    
    end
    self:updateView()
end

function PreReplayWin:updateView()
    for i=1,2 do
        local img = self.resourceNode_:getChildByName("btn_record_"..i)
        if self.curPage == i then
            img:loadTexture("public/fanye_xuanzhong.png",ccui.TextureResType.plistType)
        else
            img:loadTexture("public/fanye.png",ccui.TextureResType.plistType)
        end
    end
    if not self.replayData[self.curPage] then
        return
    end

    local listView = self.resourceNode_:getChildByName("list_rank")
    local rankData = self.replayData[self.curPage] or {}
    table.sort(rankData, function(a, b)
        -- local new_a = KfbsModel:checkIsNewLog(a.Id)
        -- local new_b = KfbsModel:checkIsNewLog(b.Id)
        -- if new_a == new_b then
            return a.Ts > b.Ts
        -- else
        --     return new_a
        -- end
    end)
    listView:updateListView(rankData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end, true, true)

    self.resourceNode_:getChildByName("txt_tip"):setString((#rankData > 0) and "" or WordDictionary[24386])
end

function PreReplayWin:createItem(data,index)
    local node = self:createCsbNode("crossServer/warReportNode.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        itemView:getChildByName("txt_time"):setString("")
        itemView:getChildByName("txt_attkName"):setString(data.AtkName)
        if data.AtkPlrId == PlayerModel.info.userId then
            itemView:getChildByName("txt_attkName"):setTextColor(CoreColor.GREEN)
        else
            itemView:getChildByName("txt_attkName"):setTextColor(CoreColor.WHITE)
        end
        itemView:getChildByName("txt_attkRank"):setString(data.AtkIdx)
        itemView:getChildByName("txt_attkServer"):setString(string.format(WordDictionary[24357], data.AtkSvrId))
        local headDataL = {
            frame = itemView:getChildByName("sp_attkHead"),
            headId = data.AtkHead,
            frameId = data.AtkHFrame,
            title = data.AtkTitle or data.Title,
            level = data.AtkLv,
        }
        Helper.createPlayerHead(headDataL)
        local headDataR = {
            frame = itemView:getChildByName("sp_defHead"),
            headId = data.DefHead,
            frameId = data.DefHFrame,
            fitle = data.DefTitle or data.Title,
            level = data.DefLv,
        }
        Helper.createPlayerHead(headDataR)

        itemView:getChildByName("txt_defName"):setString(data.DefName)
        if data.DefPlrId == PlayerModel.info.userId then
            itemView:getChildByName("txt_defName"):setTextColor(CoreColor.GREEN)
        else
            itemView:getChildByName("txt_defName"):setTextColor(CoreColor.WHITE)
        end
        itemView:getChildByName("txt_defRank"):setString(data.DefIdx)
        itemView:getChildByName("txt_defServer"):setString(string.format(WordDictionary[24357], data.DefSvrId))
        local isWin = data.AtkWin
        if data.AtkPlrId == PlayerModel.info.userId or data.DefPlrId == PlayerModel.info.userId then
            if data.AtkPlrId == PlayerModel.info.userId then
                isWin = data.AtkWin
            else
                isWin = not data.AtkWin
            end
        end
        if isWin then
            itemView:getChildByName("sp_attkResult"):setSpriteFrame("public/biwuchang-shengli.png")
        else    
            itemView:getChildByName("sp_attkResult"):setSpriteFrame("public/biwuchang-shibai.png")
        end
        UIImageBox.new(itemView:getChildByName("btn_play"),function()
            self.result = data.AtkWin
            self.attackPlayerInfo = {
                name = data.AtkName,
                head = data.AtkHead,
                hFrame = data.AtkHFrame,
                title = data.AtkTitle or data.Title
            }
            self.defenderPlayerInfo = {
                name = data.DefName,
                head = data.DefHead,
                hFrame = data.DefHFrame,
                title = data.DefTitle or data.Title
            }
            network.tcpSend(msgids.C_BattleGetReplay, {Id = data.Id, Src = "master"})
        end)
        local showNew = (self.curPage == 1) and KfbsModel:checkIsNewLog(data.Id)
        local showSelf = (self.curPage == 2) and (data.AtkPlrId == PlayerModel.info.userId or data.DefPlrId == PlayerModel.info.userId)
        itemView:getChildByName("sp_self"):setVisible(showSelf)
        itemView:getChildByName("sp_new"):setVisible(showNew)
       
    end
    local size = node:getChildByName("bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height+4))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer
end

function PreReplayWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PreReplayWin