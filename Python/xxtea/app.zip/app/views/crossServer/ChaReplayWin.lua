local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local TeamController = require "app.battle.controllers.TeamController"
local msgPack = require "app.battle.server.MessagePack"
local monsterConf = require "app.configs.monster"
local jobConf = require "app.configs.job"

local KfbsModel = init.KfbsModel
local PlayerModel = init.PlayerModel

local ChaReplayWin = class("ChaReplayWin", WinBase)
ChaReplayWin.RESOURCE_FILENAME = "crossServer/warReport2.csb"

function ChaReplayWin:onCreate(fightCnt)
    self.priority = c.WIN_ZORDER.POPUP
    self.fightCnt = fightCnt or nil
    local msgList = {
        msgids.GS_BattleGetReplay_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function ChaReplayWin:receive(op,data)
    if op == msgids.GS_BattleGetReplay_R then
        local replay = msgPack.unpack(data.Replay)
        local value = TeamController.getDataFromServer(replay.T)
        value.params.fightStatus = c.FightStatus.kfbsChampion
        value.params.seed = replay.Seed
        value.params.isWin = self.result
        value.params.attackPlayerInfo = self.attackPlayerInfo
        value.params.defenderPlayerInfo = self.defenderPlayerInfo 
        value.params.isReplay = true
        value.params.afterLoading = Helper.getFromScene()
        self:getApp():enterScene("GameScene", value)
    end
end

function ChaReplayWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        KfbsModel:removeNewLog(true)
        self:closeSelf()
    end)
    
    self:updateView()
end

function ChaReplayWin:updateView()
    local listView = self.resourceNode_:getChildByName("list_rank")
    local logData = {}
    for _,v in pairs(KfbsModel.chaInfo.Rep or {}) do
        if not self.fightCnt or self.fightCnt == v.ChpFightCnt then
            for _,k in ipairs(v.Report or {}) do
                local data = clone(k)
                data.ChpFightCnt = v.ChpFightCnt
                data.Atk = v.Atk
                data.Def = v.Def  
                data.Ts = v.Ts
                table.insert(logData, data)
            end
        end
    end
    -- table.sort(logData, function(a, b)
    --     return a.ChpFightCnt > b.ChpFightCnt
    -- end)

    local pageView = self.resourceNode_:getChildByName("pageView")
    pageView:removeAllPages()
    self:stopActionByTag(0XABC)

    local height = 400
    local sumPage = math.ceil(#logData/3)
    local index = 1
    self:actionScheduleInterval(function()
        if index > sumPage then
            self:stopActionByTag(0XABC)
        else
            local widget = ccui.Widget:create()
            for i=1, 3 do
                local num = (index-1)*3 + i
                if logData[num] then
                    local itemNode = self:createItem(logData[num])
                    display.align(itemNode,display.LEFT_TOP, i*(height/3), 0)
                    widget:addChild(itemNode)
                end
            end
            pageView:addPage(widget)
        end
        index = index + 1
    end, 0.5, 0XABC)

end

function ChaReplayWin:createItem(data)
    local node = self:createCsbNode("crossServer/warReportNode2.csb")
    node:getChildByName("txt_time"):setString(KfbsModel:getTimedate(data.Ts))
    node:getChildByName("txt_attkName"):setString(data.Atk.Name)
    node:getChildByName("txt_attkServer"):setString(string.format(WordDictionary[24357], data.Atk.SvrId))
    local headDataL = {
        frame = node:getChildByName("sp_attkHead"),
        headId = data.Atk.Head,
        frameId = data.Atk.HFrame,
        title = data.Atk.Title,
        level = data.Atk.Lv,
    }
    local headDataR = {
        frame = node:getChildByName("sp_defHead"),
        headId = data.Def.Head,
        frameId = data.Def.HFrame,
        title = data.Def.Title,
        level = data.Def.Lv,
    }
    Helper.createPlayerHead(headDataL)
    Helper.createPlayerHead(headDataR)

    node:getChildByName("txt_defName"):setString(data.Def.Name)
    node:getChildByName("txt_defServer"):setString(string.format(WordDictionary[24357], data.Def.SvrId))
    node:getChildByName("sp_attkResult"):setVisible(false)
    local leftTab = node:getChildByName("sp_leftTab")
    local rightTab = node:getChildByName("sp_rightTab")
    UIImageBox.new(node:getChildByName("btn_play"),function()
        self.result = data.AtkWin
        self.attackPlayerInfo = {
            name = data.Atk.Name,
            head = data.Atk.Head,
            hFrame = data.Atk.HFrame,
            title = data.Atk.Title
        }
        self.defenderPlayerInfo = {
            name = data.Def.Name,
            head = data.Def.Head,
            hFrame = data.Def.HFrame,
            title = data.Def.Title
        }
        network.tcpSend(msgids.C_BattleGetReplay, {Id = data.Id, Src = "master"})
    end)

    local showNew = KfbsModel:checkIsNewLog(data.Id, true)
    local showSelf = false
    node:getChildByName("sp_self"):setVisible(showSelf)
    node:getChildByName("sp_new"):setVisible(showNew)
    leftTab:setSpriteFrame("crossServer/kuafubeisai-dui"..(data.AtkWin and 2 or 1)..".png")
    leftTab:getChildByName("txt_index"):setString(string.sub("ABCD", data.AtkTeam, data.AtkTeam)..WordDictionary[24337])
    rightTab:setSpriteFrame("crossServer/kuafubeisai-dui"..(data.AtkWin and 1 or 2)..".png")
    rightTab:getChildByName("txt_index"):setString(string.sub("ABCD", data.DefTeam, data.DefTeam)..WordDictionary[24337])
    local node_left = node:getChildByName("node_left")
    local node_right = node:getChildByName("node_right")
    node:stopAllActions() 
    local i = 1
    node:actionScheduleInterval(function()
        if i > 5 then
           node:stopAllActions() 
        else
            self:createHero(node_left:getChildByName("node_"..i), data.AtkHero[i])
            self:createHero(node_right:getChildByName("node_"..i), data.DefHero[i])
        end 
        i = i + 1
    end, 0.1)
    local str = KfbsModel:getFgithType(data.ChpFightCnt)
    node:getChildByName("txt_attkType"):setString(str)
    node:getChildByName("txt_defType"):setString(str)
    node:setRotation(-90)
    return node
end

function ChaReplayWin:createHero(node, data)
    if data and (heroConf[data.Id] or monsterConf[data.Id]) then 
        local heroData = heroConf[data.Id] or monsterConf[data.Id]
        node:getChildByName("mask"):setVisible(false)
        local heroFrame = node:getChildByName("heroFrame")
        heroFrame:removeAllChildren()
        local imgName = "icon/head/" .. roleConf[heroData.role].head .. ".png"
        local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png",1)
        display.align(headImg,display.CENTER, heroFrame:getContentSize().width * 0.5 , heroFrame:getContentSize().height * 0.5)
        heroFrame:addChild(headImg)
        node:getChildByName("sp_job"):setSpriteFrame("public/" .. jobConf[heroData.jobId].icon .. ".png")
        node:getChildByName("txt_lv"):setString("Lv."..data.Lv)
        node:getChildByName("txt_talent"):setString("+"..data.Cls)
        node:getChildByName("sp_rare"):setSpriteFrame("public/yingxiong-" .. heroData.rare .. ".png")
        Helper.updateHeroStar(node:getChildByName("starNode"), data.Star)
        if data.Die then
            Helper.greyFunc(node)
        else
            Helper.greyFunc(node, true)
        end
    else
        node:getChildByName("mask"):setVisible(true)
    end
end

function ChaReplayWin:getActionIn()
    Helper.enterWinAction1(self)
end

return ChaReplayWin