local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local init = require "app.models.init"
local kfbsChampionConf = require "app.configs.kfbsChampion"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"

local KfbsModel = init.KfbsModel

local ChaBetsWin = class("ChaBetsWin", WinBase)
ChaBetsWin.RESOURCE_FILENAME = "crossServer/guess.csb"

function ChaBetsWin:onCreate(player, time, fightCnt)
    self.priority = c.WIN_ZORDER.POPUP
    self.player = player
    self.time = time
    self.fightCnt = fightCnt

    local msgList = {
        msgids.GS_KfbsChampionGuess_R,
        msgids.GS_KfbsChampionGetGuess_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_KfbsChampionGetGuess, {ChpFightCnt = self.fightCnt})
end

function ChaBetsWin:receive(op, data)
    if op == msgids.GS_KfbsChampionGuess_R then
        network.tcpSend(msgids.C_KfbsChampionGetGuess, {ChpFightCnt = self.fightCnt})
    elseif op == msgids.GS_KfbsChampionGetGuess_R then
        self:updateView(data.Data or {})
    end
end

function ChaBetsWin:initialView()
    self.itemId = kfbsChampionConf[1].guessId 
    if not self.itemId then return end
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("btn_log"),function()
        self:openWin("BetsLogWin")
    end)

    self.resourceNode_:getChildByName("txt_tips"):setString(WordDictionary[24375])
    self.resourceNode_:getChildByName("sp_iocn3"):setTexture(Helper.getPathById(self.itemId))
    self.resourceNode_:getChildByName("node_left"):getChildByName("sp_iocn"):setTexture(Helper.getPathById(self.itemId))
    self.resourceNode_:getChildByName("node_right"):getChildByName("sp_iocn"):setTexture(Helper.getPathById(self.itemId))

    local time = self.time
    local txt_time = self.resourceNode_:getChildByName("txt_time")
    txt_time:setString(Helper.getTimeString(time,true,true))
    txt_time:actionScheduleInterval(function()  
        time = time - 1
        if time < 0 then
            txt_time:stopAllActions() 
            self:closeSelf()
        else
            txt_time:setString(Helper.getTimeString(time,true,true))
        end 
    end, 1)

    local headData1 = {
        frame = self.resourceNode_:getChildByName("sp_frame1"),
        headId = self.player[1].Head,
        frameId = self.player[1].HFrame,
        title = self.player[1].Title,
    }
    local headData2 = {
        frame = self.resourceNode_:getChildByName("sp_frame2"),
        headId = self.player[2].Head,
        frameId = self.player[2].HFrame,
        title = self.player[2].Title,
    }
    Helper.createPlayerHead(headData1)
    Helper.createPlayerHead(headData2)

    self.resourceNode_:getChildByName("txt_name1"):setString(self.player[1].Name)
    self.resourceNode_:getChildByName("txt_server1"):setString(string.format(WordDictionary[24357], self.player[1].SvrId))
    self.resourceNode_:getChildByName("txt_name2"):setString(self.player[2].Name)
    self.resourceNode_:getChildByName("txt_server2"):setString(string.format(WordDictionary[24357], self.player[2].SvrId))
end

function ChaBetsWin:updateView(data)
    self.resourceNode_:getChildByName("txt_ownNum"):setString(Helper.getItemOrCurrencyCnt(self.itemId))
    local leftNode = self.resourceNode_:getChildByName("node_left")
    local rightNode = self.resourceNode_:getChildByName("node_right")
    local leftBtn = UIImageBox.new(self.resourceNode_:getChildByName("btn_left"),function()
        self:openWin("BetsSelectWin", self.player[1].PlrId, self.itemId, self.fightCnt)
    end)
    local rightBtn = UIImageBox.new(self.resourceNode_:getChildByName("btn_right"),function()
        self:openWin("BetsSelectWin", self.player[2].PlrId, self.itemId, self.fightCnt)
    end)

    local dataL, dataR = nil, nil
    for k,v in pairs(data) do
        if v.PlrId == self.player[1].PlrId then
            dataL = v
        end
        if v.PlrId == self.player[2].PlrId then
            dataR = v
        end
    end
    local myNumL, TotalNumL, myNumR, TotalNumR = 0, 0, 0, 0
    if dataL then
        myNumL, TotalNumL = dataL.Num, dataL.Total
    end
    if dataR then
        myNumR, TotalNumR = dataR.Num, dataR.Total
    end
    leftNode:getChildByName("txt_num"):setString(myNumL)
    rightNode:getChildByName("txt_num"):setString(myNumR)
    local getOddsFunc = function(num1, num2)
        local odds = 0
        if num1 > 0 and num2 > 0 then
            odds = num1/num2
        else
            local max = num1 > num2 and num1 or num2
            if max > kfbsChampionConf[1].guessPool then
                if max == num1 then
                    num2 = kfbsChampionConf[1].guessPool
                else
                    num1 = kfbsChampionConf[1].guessPool
                end
                odds = num1/num2
            else
                odds = 2
            end
        end
        if odds > kfbsChampionConf[1].guessRateMax then
            odds = kfbsChampionConf[1].guessRateMax
        end
        odds = string.format("%.1f", odds)
        return odds
    end

    leftNode:getChildByName("txt_odds"):setString(string.format(WordDictionary[24363], getOddsFunc(TotalNumR, TotalNumL)))
    rightNode:getChildByName("txt_odds"):setString(string.format(WordDictionary[24363], getOddsFunc(TotalNumL, TotalNumR)))

    rightNode:setVisible(true)
    rightBtn:setEnabled(true)
    leftBtn:setEnabled(true)
    leftNode:setVisible(true)
    if myNumL > 0 then
        rightNode:setVisible(false)
        rightBtn:setEnabled(false)
        leftBtn:setEnabled(false)
    elseif myNumR > 0 then
        leftNode:setVisible(false)
        rightBtn:setEnabled(false)
        leftBtn:setEnabled(false)
    end
end


function ChaBetsWin:getActionIn()
    Helper.enterWinAction1(self)
end

return ChaBetsWin