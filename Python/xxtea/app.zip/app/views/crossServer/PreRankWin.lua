local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"

local KfbsModel = init.KfbsModel

local PreRankWin = class("PreRankWin", WinBase)
PreRankWin.RESOURCE_FILENAME = "crossServer/rank1.csb"

function PreRankWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP

    local msgList = {
        msgids.GS_KfbsLadderRank_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_KfbsLadderRank)
end

function PreRankWin:receive(op, data)
    if op == msgids.GS_KfbsLadderRank_R then
        self:updateView(data.Rec or {})
    end
end

function PreRankWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)

    self.resourceNode_:getChildByName("txt_myScore"):setString(KfbsModel.info.LadderIdx>0 and KfbsModel.info.LadderIdx or WordDictionary[24311])

end

function PreRankWin:updateView(rankData)
    table.sort(rankData, function(a, b)
        return a.Idx < b.Idx
    end)
    local listView = self.resourceNode_:getChildByName("list_rank")
    listView:updateListView(rankData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end, true, true)
end

function PreRankWin:createRankItem(data,index)
    local node = self:createCsbNode("crossServer/rankNode1.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        itemView:getChildByName("txt_name"):setString(data.Name)
        itemView:getChildByName("txt_power"):setString(data.BtAtk)
        itemView:getChildByName("txt_family"):setString((data.Guild == "") and WordDictionary[24385] or data.Guild)
        if index > 3 then
            itemView:getChildByName("sp_num"):setVisible(false)
            itemView:getChildByName("txt_index"):setString(data.Idx)
        else
            itemView:getChildByName("sp_num"):setVisible(true)
            itemView:getChildByName("txt_index"):setString("")
            itemView:getChildByName("sp_num"):setSpriteFrame("public/0"..index..".png")
        end
        local headData = {
            frame = itemView:getChildByName("sp_frame"),
            headId = data.Head,
            frameId = data.HFrame,
            title = data.Title,
            level = data.Lv,
        }
        Helper.createPlayerHead(headData)
    end
    local size = node:getChildByName("img_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height+4))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer
end

function PreRankWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PreRankWin