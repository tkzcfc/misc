local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"

local KfbsModel = init.KfbsModel
local PlayerModel = init.PlayerModel

local CsRankWin = class("CsRankWin", WinBase)
CsRankWin.RESOURCE_FILENAME = "crossServer/rank2.csb"

function CsRankWin:onCreate(isChampion)
    self.priority = c.WIN_ZORDER.POPUP
    self.isChampion = isChampion

    local msgList = {
        msgids.GS_KfbsLadderRank_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
    if not self.isChampion then
        network.tcpSend(msgids.C_KfbsLadderRank)
    end
end

function CsRankWin:receive(op, data)
    if op == msgids.GS_KfbsLadderRank_R then
        self:updateView(data.Rec or {})
    end
end

function CsRankWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    local rank = self.isChampion and KfbsModel:getMyInfoData(true) or KfbsModel.info.LadderIdx
    rank = rank and rank or 0
    self.resourceNode_:getChildByName("txt_myRank"):setString(rank>0 and rank or WordDictionary[24311])

    if self.isChampion then
        local playerData = KfbsModel.chaInfo.Rec or {}
        self:updateView(playerData)
    end
end

function CsRankWin:updateView(rankData)
    local myData = {}
    for i,v in ipairs(rankData) do
        if v.PlrId == PlayerModel.info.userId then
            myData = v
            break
        end
    end
    local num = self.isChampion and myData.BeLike or myData.BeGuess
    self.resourceNode_:getChildByName("txt_num"):setString(num or 0)
    local listView = self.resourceNode_:getChildByName("list_rank")
    table.sort(rankData, function(a, b)
        return a.Idx < b.Idx
    end)
    
    listView:updateListView(rankData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end, true, true)
end


function CsRankWin:createRankItem(data,index)
    local node = self:createCsbNode("crossServer/rankNode2.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        itemView:getChildByName("txt_name"):setString(data.Name)
        itemView:getChildByName("txt_num"):setString(self.isChampion and data.BeLike or data.BeGuess)
        if self.isChampion then
            itemView:getChildByName("txt_power"):setString("")
            itemView:getChildByName("txt_str1"):setString("")
            itemView:getChildByName("txt_name"):setPositionY(38)
        else
            itemView:getChildByName("txt_power"):setString(data.BtAtk)
            itemView:getChildByName("txt_str1"):setString(WordDictionary[24368])
        end
        if index > 3 then
            itemView:getChildByName("sp_num"):setVisible(false)
            itemView:getChildByName("txt_index"):setString(data.Idx)
        else
            itemView:getChildByName("sp_num"):setVisible(true)
            itemView:getChildByName("txt_index"):setString("")
            itemView:getChildByName("sp_num"):setSpriteFrame("public/0"..index..".png")
        end
        local headData = {
            frame = itemView:getChildByName("sp_frame"),
            headId = data.Head,
            frameId = data.HFrame,
            level = data.Lv,
            title = data.Title,
        }
        Helper.createPlayerHead(headData)
    end
    local size = node:getChildByName("img_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height+4))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer
end

function CsRankWin:getActionIn()
    Helper.enterWinAction1(self)
end

return CsRankWin