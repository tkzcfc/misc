local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local CoreColor = require "sandglass.core.CoreColor"
local kfbsChampionConf = require "app.configs.kfbsChampion"
local kfbsConf = require "app.configs.kfbs"
local UIAniButton = require "sandglass.ui.UIAniButton"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local KfbsModel = init.KfbsModel

local MAXGROUP = 8--小组赛最大组数
local FIGHT_STATE = KfbsModel:getAllFightState()
local CS_STAGE = KfbsModel:getAllStage()

local ChampionView = class('ChampionView',function() 
    return ccui.Layout:create()
end)

function ChampionView:ctor(parentWin)
    self.parentWin = parentWin
    self.curGroup = KfbsModel:getSelfGroup() or math.ceil((KfbsModel.chaInfo.Guess + 1)/7) 
    self:onWinEnter()
end

function ChampionView:receive(op,data)
    if op == msgids.GS_KfbsChampionTeam_R then
        local win = display.getRunningScene().winManager:findWinByName("ChaPlayerTeamWin")
        if not win then
            self.parentWin:openWin("ChaPlayerTeamWin", data.Data)
        end
    elseif op == msgids.GS_KfbsChampionSetTeamr_R then
        local hasMy = false
        local curGroupData = self.isChampion and KfbsModel:getChampoinGroup() or KfbsModel:getOrdinaryGroup(self.curGroup)
        for k,v in pairs(curGroupData) do
            if v.PlrId == PlayerModel.info.userId then 
                hasMy = true
                break
            end
        end
        if hasMy then
            self:updateView()
        end
    elseif op == msgids.GS_KfbsChampionGuess_R then
        self:updateRecommendBtn()
    end
end

function ChampionView:onWinEnter()
    self.contentView = self.parentWin:createCsbNode("crossServer/finals.csb")
    self:addChild(self.contentView)

    self.contentView:getChildByName("node_cc"):getChildByName("txt_tips"):setString(WordDictionary[24335])
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_reward"),function()
        self.parentWin:openWin("CsRewardWin", true)
    end)
    -- UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_shop"),function()
    --     self.parentWin:openWin("ShopWin", 46)
    -- end)
    self:updateRecommendBtn()
    UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_hotShop"),function()
        self.parentWin:openWin("DiscountShopWin", 2)
    end)

    local stage, time = KfbsModel:getCurStage()
    local timeStr = ""
    if stage == CS_STAGE.GroupSoon then
        timeStr = WordDictionary[24369]
    elseif stage == CS_STAGE.Group then
        timeStr = WordDictionary[24365]
    elseif stage == CS_STAGE.GroupEnd then
        timeStr = WordDictionary[24366]
        self.isChampion = true
    elseif stage == CS_STAGE.Champion then
        timeStr = WordDictionary[24367]
        self.isChampion = true
    end
    self.contentView:getChildByName("node_ct"):getChildByName("txt_timeStr"):setString(timeStr)
    local txt_time = self.contentView:getChildByName("node_ct"):getChildByName("txt_time")
    txt_time:stopAllActions()
    if time-Helper.getFixedTime() > 0 then
        txt_time:setString(Helper.getTimeString(time-Helper.getFixedTime(),true,true))
        txt_time:actionScheduleInterval(function()
            if time-Helper.getFixedTime() < 0 then
                txt_time:stopAllActions() 
            else
                txt_time:setString(Helper.getTimeString(time-Helper.getFixedTime(),true,true))
            end 
        end, 1)
    else
        txt_time:setString(Helper.getTimeString(0,true,true))
    end


    UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("btn_match1"),function()
        self.isChampion = false
        self.curGroup = 1
        self:updateView()
    end)
    UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("btn_match2"),function()
        self.isChampion = true
        self:updateView()
    end)

    self.setTeamBtn = UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("btn_setTeam"),function()
        if self.isChampion then
            if KfbsModel:checkGotoChampion() then
                self.parentWin:openWin("ChaSetTeamWin")
            else
                MoveLabel.new(WordDictionary[24384])
            end
        else
            if KfbsModel:getSelfGroup() then
                self.parentWin:openWin("ChaSetTeamWin")
            else
                MoveLabel.new(WordDictionary[24356])
            end
        end
    end)

    self.leftBtn = UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("btn_left"),function()
        self.curGroup = self.curGroup - 1
        if self.curGroup <= 0 then
            self.curGroup = MAXGROUP
        end
        self:updateView()
    end)
    self.rightBtn = UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("btn_right"),function()
        self.curGroup = self.curGroup + 1
        if self.curGroup > MAXGROUP then
            self.curGroup = 1
        end
        self:updateView()
    end)

    self.pageBtn = UIImageBox.new(self.contentView:getChildByName("node_cc"):getChildByName("pageBtn"),function()
        self.pageBtn.open = not self.pageBtn.open
        for i=1,8 do
            self.pageBtn:getChildByName("btn_"..i):setVisible(self.pageBtn.open)
        end
        self.pageBtn:getChildByName("sp_arrow"):setRotation(self.pageBtn.open and 0 or 90)
    end)

    local myGroup = KfbsModel:getSelfGroup()
    for i=1,8 do
        UIImageBox.new(self.pageBtn:getChildByName("btn_"..i),function()
            self.curGroup = i
            self:updateView()
        end)
        if myGroup and myGroup == i then
            self.pageBtn:getChildByName("btn_"..i):getChildByName("txt_str"):setTextColor(CoreColor.GREEN)
        end
    end

    self:updateView()
end

function ChampionView:updateView()
    for i=1,2 do
        if i == (self.isChampion and 2 or 1) then
            self.contentView:getChildByName("node_cc"):getChildByName("btn_match"..i):loadTexture("public/fanye_xuanzhong.png",ccui.TextureResType.plistType)
        else
            self.contentView:getChildByName("node_cc"):getChildByName("btn_match"..i):loadTexture("public/fanye.png",ccui.TextureResType.plistType)
        end
    end
    self.leftBtn:setVisible(not self.isChampion)
    self.rightBtn:setVisible(not self.isChampion)
    self.pageBtn:setVisible(not self.isChampion)
    if not self.isChampion then
        self.pageBtn:getChildByName("txt_type"):setString(self.curGroup..WordDictionary[24304])
    end
    
    self:createFinalsInfo()
end

function ChampionView:createFinalsInfo()
    local playersNode = self.contentView:getChildByName("node_cc"):getChildByName("node_player")
    local linesNode = self.contentView:getChildByName("node_cc"):getChildByName("node_line")
    local btnsNode = self.contentView:getChildByName("node_cc"):getChildByName("node_btn")
    ----隐藏所有线条----
    for i,line in ipairs(linesNode:getChildren()) do
        line:setVisible(false)
    end
    -----删除所有按钮-----
    for i,node in ipairs(btnsNode:getChildren()) do
        node:stopAllActions()
        node:removeAllChildren()
    end
    self.playerNodes = {}
    local curGroupData = self.isChampion and KfbsModel:getChampoinGroup() or KfbsModel:getOrdinaryGroup(self.curGroup)
    -----创建玩家信息-----
    for i=1,8 do
        local pData = curGroupData[i]
        local pNode = playersNode:getChildByName("node_"..i)
        pNode:stopAllActions()
        Helper.greyFunc(pNode, true)
        if pData then
            local headData = {
                frame = pNode:getChildByName("img_head"),
                headId = pData.Head,
                frameId = pData.HFrame,
                level = pData.Lv,
                title = pData.Title,
            }
            Helper.createPlayerHead(headData, function()
                network.tcpSend(msgids.C_KfbsChampionTeam, {PlrId = pData.PlrId})
            end)
            pNode:getChildByName("txt_name"):setString(pData.Name)
            pNode:getChildByName("txt_server"):setString(string.format(WordDictionary[24357], pData.SvrId))
            pNode:getChildByName("node_team"):setVisible(true)
            for k=1,3 do
                local sp_team = pNode:getChildByName("node_team"):getChildByName("sp_team"..k)
                if k <= pData.TeamNum then
                    sp_team:setSpriteFrame("crossServer/kuafubeisai-dui2.png")
                else 
                    Helper.greyFunc(sp_team)
                end
            end
            if pData.PlrId == PlayerModel.info.userId then
                pNode:getChildByName("txt_name"):setTextColor(CoreColor.GREEN)
                pNode:getChildByName("txt_server"):setTextColor(CoreColor.GREEN)
            else
                pNode:getChildByName("txt_name"):setTextColor(CoreColor.ORANGE)
                pNode:getChildByName("txt_server"):setTextColor(CoreColor.WHITE)
            end
            self.playerNodes[i] = pNode
        else
            pNode:getChildByName("img_head"):removeAllChildren()
            pNode:getChildByName("txt_name"):setString(WordDictionary[24319])
            pNode:getChildByName("txt_server"):setString("")
            pNode:getChildByName("node_team"):setVisible(false)
            UIImageBox.new(pNode:getChildByName("img_head"),function()
            end, {noAnimEffect = true})
        end
    end
    self:updateRoundInfo()
end

function ChampionView:updateRoundInfo(round)
    local round = round or 1
    if round > 7 then return end
    local state, time = KfbsModel:getCurRoundState(round, self.isChampion)
    if state == FIGHT_STATE.NotStart then
        return
    elseif state == FIGHT_STATE.Readying then
        self:showReadyBtn(round, time)
    elseif state == FIGHT_STATE.Bets then
        self:showGuessBtn(round, time)
    elseif state == FIGHT_STATE.Fighting then
        self:showFightAnim(round, time)
        self:updateTeamInfo(round, time)
    elseif state == FIGHT_STATE.End then
        self:showReplayBtn(round)
        self:updatePlayerState(round)
        self:showLine(round)
    end
    self:updateRoundInfo(round + 1)
    self:updateRecommendBtn()
end

function ChampionView:showReadyBtn(round, time)
    local node = self.contentView:getChildByName("node_cc"):getChildByName("node_btn"):getChildByName("node_"..round)
    if node then
        node:removeAllChildren()
        node:stopAllActions()
        local readyBtn = display.newSprite("#crossServer/kuafubeisai-zhazhouzhong.png")
        node:addChild(readyBtn)

        local readyImg = display.newSprite("#crossServer/kuafubeisai-zhazhouzhong.png")
        readyImg:setRotation(-90)
        readyImg:setPosition(readyBtn:getContentSize().width/2, readyBtn:getContentSize().height/2)
        readyBtn:addChild(readyImg)

        local str = UILabel.new({
            text = WordDictionary[24377], 
            color = CoreColor.WHITE,
            size = 14,
            back = cc.c3b(61, 24, 6),
        })
        str:setPosition(readyBtn:getContentSize().width/2, readyBtn:getContentSize().height/3-10)
        readyBtn:addChild(str)
    end
end

function ChampionView:showGuessBtn(round, time)
    local node = self.contentView:getChildByName("node_cc"):getChildByName("node_btn"):getChildByName("node_"..round)
    if node then
        node:removeAllChildren()
        node:stopAllActions()

        local btn = nil
        local timeLabel = UILabel.new({
            color = CoreColor.RED,
            size = 14,
            back = cc.c3b(61, 24, 6),
        })
        local fightCnt = KfbsModel:getCurFightCnt(round, self.curGroup, self.isChampion) 
        if KfbsModel.chaInfo.Guess and KfbsModel.chaInfo.Guess == fightCnt then
            btn = UIImageBox.new("crossServer/kuafubeisai-xiazhu.png", function()
                local players = KfbsModel:getPlayerByRound(round, self.curGroup, self.isChampion)
                if #players == 2 then
                    self.parentWin:openWin("ChaBetsWin", players, time, fightCnt)
                else
                    MoveLabel.new(WordDictionary[24323])
                end 
            end, {isPlist = true})
            node:addChild(btn)

            local btnName = UILabel.new({
                text = WordDictionary[24305], 
                color = CoreColor.WHITE,
                size = 14,
                back = cc.c3b(61, 24, 6),
            })
            btnName:setPosition(btn:getContentSize().width/2, btn:getContentSize().height/3)
            btn:addChild(btnName)
            timeLabel:setPosition(btn:getContentSize().width/2, 0)
        else
            btn = UIAniButton.new("crossServer/ui_huangting_xiaodao", function(eventType,me,point)
                if eventType == "ended" then
                end
            end)
            btn:playAnimation("idle2", -1)
            node:addChild(btn)
            local str = UILabel.new({
                text = WordDictionary[24378], 
                color = CoreColor.WHITE,
                size = 14,
                back = cc.c3b(61, 24, 6),
            })
            str:setPosition(btn:getContentSize().width/2, btn:getContentSize().height/3)
            btn:addChild(str)
            timeLabel:setPosition(btn:getContentSize().width/2, -15)
        end
        btn:addChild(timeLabel)
        timeLabel:setString(Helper.getTimeString(time,true,true))
        node:actionScheduleInterval(function()
            time = time - 1
            if time < 0 then
               node:stopAllActions() 
               self:updateRoundInfo(round)
            else
                timeLabel:setString(Helper.getTimeString(time,true,true))
            end 
        end, 1)
    end
end

function ChampionView:showFightAnim(round, time)
    local node = self.contentView:getChildByName("node_cc"):getChildByName("node_btn"):getChildByName("node_"..round)
    if node then
        node:removeAllChildren()
        node:stopAllActions()
        local anim = UIAniButton.new("crossServer/ui_huangting_xiaodao", function(eventType,me,point)
            if eventType == "ended" then
                local replayData, index = KfbsModel:getReplayByFightTime(round, self.curGroup, self.isChampion, time)
                if replayData and replayData.Report and replayData.Report[index] then
                    local replayInfo = {Atk = replayData.Atk, Def = replayData.Def, info = replayData.Report[index]}
                    self.parentWin:openFightLive(replayInfo, self.isChampion, self.curGroup)
                else
                    MoveLabel.new(WordDictionary[24338])
                end
            end
        end)
        anim:playAnimation("idle2", -1)
        node:addChild(anim)
        local str = UILabel.new({
            text = WordDictionary[24306], 
            color = CoreColor.WHITE,
            size = 14,
            back = cc.c3b(61, 24, 6),
        })
        str:setPosition(anim:getContentSize().width/2, anim:getContentSize().height/3)
        anim:addChild(str)
        
        local liveBtn = display.newSprite("#crossServer/kuafubeisai-zhibo.png")
        liveBtn:setPositionY(-20)
        node:addChild(liveBtn)

        local win = display.getRunningScene().winManager:findWinByName("ChaSetTeamWin")
        if win then
            win:closeSelf()
            MoveLabel.new(WordDictionary[24333])
        end
        self.setTeamBtn:setEnabled(false)
        node:actionScheduleInterval(function()
            time = time - 1
            if time < 0 then
                node:stopAllActions() 
                self.setTeamBtn:setEnabled(true)
                self:updateRoundInfo(round)
            end 
        end, 1)
    end
end

function ChampionView:showReplayBtn(round, time)
    local node = self.contentView:getChildByName("node_cc"):getChildByName("node_btn"):getChildByName("node_"..round)
    if node then
        node:removeAllChildren()
        node:stopAllActions()
        local btn = UIImageBox.new("public/anniu-huifang1.png", function()
            local fightCnt = KfbsModel:getCurFightCnt(round, self.curGroup, self.isChampion) 
            self.parentWin:openWin("ChaReplayWin", fightCnt)
        end, {isPlist = true})
        node:addChild(btn)

        local btnName = UILabel.new({
            text = WordDictionary[24307], 
            color = CoreColor.WHITE,
            size = 14,
            back = cc.c3b(61, 24, 6),
        })
        btnName:setPosition(btn:getContentSize().width/2, btn:getContentSize().height/3-10)
        btn:addChild(btnName)
    end

end

function ChampionView:updatePlayerState(round)
    local winIndex, loserIndex = KfbsModel:getWinPosByRound(round, self.curGroup, self.isChampion)
    if not loserIndex  or (not winIndex) then return end

    local pNode = self.playerNodes[loserIndex]
    if pNode then
        Helper.greyFunc(pNode)
        local curGroupData = self.isChampion and KfbsModel:getChampoinGroup() or KfbsModel:getOrdinaryGroup(self.curGroup)
        local pData = curGroupData[loserIndex]
        if pData then
            for i=1,pData.TeamNum do
                local sp_team = pNode:getChildByName("node_team"):getChildByName("sp_team"..i)
                if sp_team then
                    Helper.greyFunc(sp_team, true)
                    sp_team:setSpriteFrame("crossServer/kuafubeisai-dui1.png")
                end
            end
        end
    end
    local pNode = self.playerNodes[winIndex]
    if pNode then
        local replayInfo = nil
        local curGroupData = self.isChampion and KfbsModel:getChampoinGroup() or KfbsModel:getOrdinaryGroup(self.curGroup)
        local pData = curGroupData[winIndex]
        local fightCnt = KfbsModel:getCurFightCnt(round, self.curGroup, self.isChampion) 
        for k,v in pairs(KfbsModel.chaInfo.Rep or {}) do
            if v.ChpFightCnt == fightCnt then
                replayInfo = v
                break
            end
        end
        if replayInfo then
            for i,v in ipairs(replayInfo.Report or {}) do
                local index = ""
                local isWin = false
                if pData.PlrId == replayInfo.Atk.PlrId then
                    index = v.AtkTeam
                    isWin =  v.AtkWin
                else
                    index = v.DefTeam
                    isWin =  not v.AtkWin
                end
                local sp_team = pNode:getChildByName("node_team"):getChildByName("sp_team"..index)
                if sp_team and (not isWin) then
                    sp_team:setSpriteFrame("crossServer/kuafubeisai-dui1.png")
                end
            end
        end
    end
end

function ChampionView:showLine(round)
    for i=1,2 do
        local lineImg = self.contentView:getChildByName("node_cc"):getChildByName("node_line"):getChildByName("sp_"..round.."_"..i)
        if lineImg then
            local posIndex = KfbsModel:getWinPosByRound(round, self.curGroup, self.isChampion)
            if not posIndex then return end
            local isWin = false
            if round <= 4 then
                local curPosIndex = (round-1)*2 + i
                isWin = curPosIndex == posIndex
            elseif round == 5 then
                posIndex = posIndex > 2 and 2 or 1
                isWin = posIndex == i
            elseif round == 6 then
                posIndex = posIndex > 6 and 2 or 1
                isWin = posIndex == i
            elseif round == 7 then
                posIndex = posIndex >= 5 and 2 or 1
                isWin = posIndex == i
            end
            if isWin then
                lineImg:setVisible(true)
            else
                lineImg:setVisible(false)
            end
        end
    end
end

function ChampionView:updateTeamInfo(round, time)
    local pData = KfbsModel:getPlayerByRound(round, self.curGroup, self.isChampion)
    local nodes = {}
    local pNode = nil
    local tab = self.isChampion and "ChpPos" or "GrpPos"
    for k,v in pairs(pData) do
        local index = v[tab]
        if self.playerNodes[index] then
            nodes[v.PlrId] = self.playerNodes[index]
        end
    end

    local replayData, index, nextTime = KfbsModel:getReplayByFightTime(round, self.curGroup, self.isChampion, time)
    if replayData and replayData.Report and (index - 1) > 0 then
        for i=1,(index - 1) do
            local log = replayData.Report[i] or nil
            if log then
                local loserId = log.AtkWin and replayData.Def.PlrId or replayData.Atk.PlrId
                pNode = nodes[loserId]
                if pNode and pNode:getChildByName("node_team"):getChildByName("sp_team"..i) then
                    pNode:getChildByName("node_team"):getChildByName("sp_team"..i):setSpriteFrame("crossServer/kuafubeisai-dui1.png")
                end
            end
        end
        if index >= table.nums(replayData.Report) then----最后一场不刷新
            nextTime = nil
        end
    end
    if nextTime and nextTime > 0 and pNode then
        pNode:stopAllActions() 
        pNode:actionScheduleInterval(function()
            nextTime = nextTime - 1
            if nextTime < 0 then
                pNode:stopAllActions() 
                self:updateRoundInfo(round)
            end 
        end, 1)
    end
end


function ChampionView:updateRecommendBtn()
    local guessRound = (KfbsModel.chaInfo.Guess + 1)%7
    if guessRound == 0 then guessRound = 7 end
    local guessGroup = math.ceil((KfbsModel.chaInfo.Guess + 1)/7) 

    local btn = UIImageBox.new(self.contentView:getChildByName("node_rt"):getChildByName("btn_guess"),function()
        local state, time = KfbsModel:getCurRoundState(guessRound, false)
        if state == FIGHT_STATE.Bets then
            self.isChampion = false
            self.curGroup = guessGroup
            self:updateView()

            local players = KfbsModel:getPlayerByRound(guessRound, self.curGroup, self.isChampion)
            if #players == 2 then
                local fightCnt = KfbsModel:getCurFightCnt(guessRound, self.curGroup, self.isChampion) 
                self.parentWin:openWin("ChaBetsWin", players, time, fightCnt)
            else
                MoveLabel.new(WordDictionary[24381])
            end
        else
            MoveLabel.new(WordDictionary[24323])
        end
         
    end)
    local state, time = KfbsModel:getCurRoundState(guessRound, false)
    local stage = KfbsModel:getCurStage()
    if stage >= CS_STAGE.GroupEnd then
        btn:setVisible(false)
    else
        btn:setVisible(true)
        local canGuess = true
        for k,v in pairs(KfbsModel.info.ChampionGuess or {}) do
            if v.Cnt == (KfbsModel.chaInfo.Guess or 1) then
                canGuess = false
                break
            end
        end
        if canGuess and state == FIGHT_STATE.Bets then
            if not btn:getChildByName("anim") then
                local anim = SpineManager.createAnimation("public/ui_tongyongbeiguang", 1)
                anim:playAnimation("idle",-1)
                anim:setName("anim")
                anim:setPosition(btn:getContentSize().width/2, btn:getContentSize().height/2)
                btn:addChild(anim, -1)
            end
        elseif btn:getChildByName("anim") then
            btn:removeChildByName("anim")
        end
    end
end

return ChampionView