local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local cstRankConf = require "app.configs.kfbsLadderRank"
local cscRankConf = require "app.configs.kfbsChampionRank"
local init = require "app.models.init"

local KfbsModel = init.KfbsModel

local CsRewardWin = class("CsRewardWin", WinBase)
CsRewardWin.RESOURCE_FILENAME = "crossServer/rankReward.csb"

function CsRewardWin:onCreate(isChampion)
    self.priority = c.WIN_ZORDER.POPUP
    self.curPage = isChampion and 2 or 1
end

function CsRewardWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("btn_1"),function()
        if self.curPage ~= 1 then
            self.curPage = 1
            self:updateView()
        end
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("btn_2"),function()
        if self.curPage ~= 2 then
            self.curPage = 2
            self:updateView()
        end
    end)
    self:updateView()
end 

function CsRewardWin:updateView()
    for i=1,2 do
        local btn = self.resourceNode_:getChildByName("btn_"..i)
        if i == self.curPage then
            btn:loadTexture("public/fanye_xuanzhong.png",ccui.TextureResType.plistType)
        else
            btn:loadTexture("public/fanye.png",ccui.TextureResType.plistType)
        end
    end

    local rankData = self.curPage == 1 and cstRankConf or cscRankConf

    local listView = self.resourceNode_:getChildByName("list_rank")
    listView:updateListView(rankData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end)

    local itemNode = self.resourceNode_:getChildByName("node_reward")
    itemNode:removeAllChildren()
    local myRank = (self.curPage == 2) and KfbsModel:getMyInfoData(true) or KfbsModel.info.LadderIdx
    myRank = myRank or 0
    local rewards = nil
    for i,v in ipairs(rankData) do
        if myRank >= v.rankUp and myRank <= v.rankDown then
            rewards = v.item 
            break
        end
    end
    for i,v in ipairs(rewards or {}) do
        local icon = Helper.createGoodsItem({scale = 0.7,id = v.id,num = v.n})       
        itemNode:addChild(icon)
        icon:setPositionX((i-1)*70)
    end
    self.resourceNode_:getChildByName("txt_myRank"):setString(rewards and myRank or WordDictionary[24311])
    local txt_tips = self.resourceNode_:getChildByName("txt_tips")
    txt_tips:setString(self.curPage == 1 and WordDictionary[24374] or WordDictionary[24310])
    self.resourceNode_:getChildByName("sp_tip"):setPositionX(txt_tips:getPositionX() - txt_tips:getContentSize().width/2 - 5)
end

function CsRewardWin:createRankItem(data,index)
    local node = self:createCsbNode("crossServer/rankRewardNode.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        local indexStr = data.rankUp
        if indexStr ~= data.rankDown then
            indexStr = indexStr.."-"..data.rankDown
        end
        local itemView = layer:getChildByName("itemView")
        if index > 3 then
            itemView:getChildByName("sp_num"):setVisible(false)
            itemView:getChildByName("txt_index"):setString(indexStr)
        else
            if data.rankUp ~= data.rankDown then
                itemView:getChildByName("sp_num"):setVisible(false)
                itemView:getChildByName("txt_index"):setString(indexStr)
            else
                itemView:getChildByName("sp_num"):setVisible(true)
                itemView:getChildByName("sp_num"):setSpriteFrame("public/0"..index..".png")
                itemView:getChildByName("txt_index"):setString("")
            end
        end
        local node = itemView:getChildByName("node_reward")
        node:removeAllChildren()
        for i,v in ipairs(data.item) do
            local icon = Helper.createGoodsItem({scale = 0.7,id = v.id,num = v.n})       
            node:addChild(icon)
            icon:setPositionX((i-1)*70)
        end
    end
    local size = node:getChildByName("img_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height+4))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer
end

function CsRewardWin:getActionIn()
    Helper.enterWinAction1(self)
end

return CsRewardWin