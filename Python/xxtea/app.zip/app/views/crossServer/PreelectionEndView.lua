local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local init = require "app.models.init"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skinConf = require "app.configs.skin"
local monsterConf = require "app.configs.monster"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local KfbsModel = init.KfbsModel

local PreelectionEndView = class('PreelectionEndView',function() 
    return ccui.Layout:create()
end)

function PreelectionEndView:ctor(parentWin)
    self.parentWin = parentWin
    self:onWinEnter()
    network.tcpSend(msgids.C_KfbsLadderRank)
end

function PreelectionEndView:receive(op,data)
    if op == msgids.GS_KfbsLadderRank_R then
        self:updateView(data.Rec or {})
    elseif op == msgids.GS_KfbsLadderLike_R then
        if self.leftText[data.PlrId] then
            self.leftText[data.PlrId].num = self.leftText[data.PlrId].num + 1
            self.leftText[data.PlrId].text:setString(self.leftText[data.PlrId].num)
        end
        self.parentWin:openWin("PublicGetRewardWin",{rewards = data.Rewards})
    end
end

function PreelectionEndView:onWinEnter()
    self.contentView = self.parentWin:createCsbNode("crossServer/trialsResult.csb")
    self:addChild(self.contentView)

    self.contentView:getChildByName("node_lb"):getChildByName("txt_rank"):setString(KfbsModel.info.LadderIdx>0 and KfbsModel.info.LadderIdx or WordDictionary[24319])
    self.contentView:getChildByName("node_lb"):getChildByName("txt_maxRank"):setString(KfbsModel.info.LadderHisIdx>0 and KfbsModel.info.LadderHisIdx or WordDictionary[24319])

end

function PreelectionEndView:updateView(rankData)
    self.leftText = {}
    table.sort(rankData, function(a, b)
        return a.Idx < b.Idx
    end)
    local listView = self.contentView:getChildByName("node_rt"):getChildByName("listView")
    listView:updateListView(rankData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end, true, true)

    for i=1,3 do
        local node = self.contentView:getChildByName("node_lc"):getChildByName("node_"..i)
        local likeBtn = node:getChildByName("btn_like")
        local data = rankData[i]
        node:getChildByName("txt_name"):setString(data and data.Name or WordDictionary[24303])
        node:getChildByName("txt_server"):setString(string.format(WordDictionary[24357], data and data.SvrId or ""))
        likeBtn:setVisible(data and true or false)
        if data and data.HeroId and data.HeroId ~= 0 then
            local conf = heroConf[data.HeroId] or monsterConf[data.HeroId]
            local path = "spine/actors/" .. roleConf[conf.role].spine
            local anim = SpineManager.createAnimation(path)
            anim:registerSkin(skinConf[data.CurSkin > 0 and data.CurSkin or 1].spineName)
            anim:playAnimation("idle", -1)
            -- anim:setScale(1)
            node:getChildByName("node_spine"):removeAllChildren()
            node:getChildByName("node_spine"):addChild(anim)
            UIImageBox.new(likeBtn,function()
                network.tcpSend(msgids.C_KfbsLadderLike, {PlrId = data.PlrId})
            end)
            likeBtn:getChildByName("txt_num"):setString(data.BeLike)
            self.leftText[data.PlrId] = {text = likeBtn:getChildByName("txt_num"), num = data.BeLike}
        end
    end

end


function PreelectionEndView:createRankItem(data,index)
    local node = self.parentWin:createCsbNode("crossServer/trialsRankItem.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        itemView:getChildByName("txt_name"):setString(data.Name)
        itemView:getChildByName("txt_power"):setString(data.BtAtk)
        itemView:getChildByName("txt_family"):setString((data.Guild == "") and WordDictionary[24385] or data.Guild)
        if index > 3 then
            itemView:getChildByName("sp_num"):setVisible(false)
            itemView:getChildByName("txt_index"):setString(data.Idx)
        else
            itemView:getChildByName("sp_num"):setVisible(true)
            itemView:getChildByName("txt_index"):setString("")
            itemView:getChildByName("sp_num"):setSpriteFrame("public/0"..index..".png")
        end
        local node_team = itemView:getChildByName("node_team")
        node_team:removeAllChildren()
        for i,id in ipairs(data.Team or {}) do
            if id ~= 0 then
                local heroHead = nil
                if monsterConf[id] then
                    heroHead = Helper.CreateMonsterHead({scale = 0.5, id = id}) 
                else
                    heroHead = Helper.createGoodsItem({scale = 0.5, id = id})
                end
                node_team:addChild(heroHead)
                heroHead:setPositionX((i-1)*50)
            end
        end
        itemView:getChildByName("btn"):setVisible(false)
        itemView:getChildByName("txt_num"):setString("")
        itemView:getChildByName("txt_numStr"):setString("")
    end
    local size = node:getChildByName("img_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height+2))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer

end


return PreelectionEndView