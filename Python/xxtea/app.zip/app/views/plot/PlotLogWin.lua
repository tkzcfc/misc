
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"

local Helper = require "app.Helper"
local init = require "app.models.init"
local UILabel = require "sandglass.ui.UILabel"

local plotsJournalConf = require "app.configs.plotsJournal"
local openConf = require "app.configs.open"
local c = require "app.configs.constants"

local PlotModel = init.PlotModel

local PlotLogWin = class("PlotLogWin", WinBase)

PlotLogWin.RESOURCE_FILENAME = "plot/plotLog.csb"

function PlotLogWin:onCreate(play)
    self.priority = c.WIN_ZORDER.POPUP
    self.play = play

    self.confs = {}
    for _,v in pairs(plotsJournalConf) do
        self.confs[v.showDay] = v
    end
end

function PlotLogWin:initialView()
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[75005])
    self.resourceNode_:getChildByName("txt_close"):setString(WordDictionary[20323])
    self.resourceNode_:getChildByName("txt_tip"):setString(WordDictionary[75006])
    
    self:setAutoClose(self.resourceNode_:getChildByName("bg"))
    self:updateScrollView()
end


function PlotLogWin:updateScrollView()
    local curDay = PlotModel:getCurDay(1)
    local scrollview = self.resourceNode_:getChildByName("scrollview")

    scrollview:setScrollBarWidth(8)
    scrollview:setScrollBarColor(cc.c3b(225,213,199))
    scrollview:setScrollBarPositionFromCornerForVertical(cc.p(10,20))

    local txts = {}
    local height = 0
    for i=1,curDay do
        local conf = self.confs[i]
        if conf then
            local txt = UILabel.new({
                text = conf.plotsJournal,
                color = cc.c3b(255,253,238),
                size = 18,
                dimensions = cc.size(440,0)
                --back = CoreColor.BLACK,
            })

            table.insert(txts,txt)
            height = height + txt:getContentSize().height
        else
            break
        end
    end
    local size = scrollview:getContentSize()
    if height < size.height then
        height = size.height
    end
    scrollview:setInnerContainerSize(cc.size(size.width, height))

    local txtPosY = height
    for i,txt in ipairs(txts) do
        display.align(txt, display.LEFT_TOP, 0, txtPosY)
        scrollview:addChild(txt)

        txtPosY = txtPosY - txt:getContentSize().height
    end

    if self.play then
        local txt = txts[#txts]
        if txt then
            local txtStr = txt:getString()
            txt:setString("")

            local percent = (height - txt:getPositionY()) / (height - size.height + 1)
            if percent > 1 then
                percent = 1
            elseif percent < 0 then
                percent = 0
            end
            scrollview:scrollToPercentVertical(percent*100, 0, false)
            
            local len = string.len(txtStr)
            local idx = 1
            txt:actionScheduleInterval(function()
                txt:setString(string.sub(txtStr,1,idx))
                idx = idx + 1
            end, 0.03)
        end
    end
end

function PlotLogWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotLogWin