local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UIAniButton = require "sandglass.ui.UIAniButton"
local WordDictionary = require "app.configs.WordDictionary"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local MoveLabel = require "sandglass.ui.MoveLabel"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local AudioManager = require "sandglass.core.AudioManager"
local SpineManager = require "sandglass.core.SpineManager"
local enums = require "app.network.enums"
local UILabel = require "sandglass.ui.UILabel"

local init = require "app.models.init"
local PlotModel = init.PlotModel

local plotsStepConf = require "app.configs.plotsStep"
local monsterConf = require "app.configs.monster"
local roleConf = require "app.configs.role"

local PlotStepWin = class("PlotStepWin", WinBase)

PlotStepWin.RESOURCE_FILENAME = "plot/plotStep.csb"

function PlotStepWin:onCreate(isAutoOpen)
    self.priority = c.WIN_ZORDER.NORMAL
    self.showType = self.WinShowType.hiddenBack
    self.showCurrency = {c.CurrencyName.diamond, c.CurrencyName.gold}

    self.isAutoOpen = isAutoOpen

    self.curStep = PlotModel:getCurStep()
    self.confs = {}
    for _,v in pairs(plotsStepConf) do
        self.confs[v.step] = v
    end
    
    local msgList = {
        msgids.GS_ShopGetInfo_R,
    }

    network.addListener(self, msgList, handler(self, self.receive))
end

function PlotStepWin:receive(op,data)
    if op == msgids.GS_ShopGetInfo_R then
        
    end
end

function PlotStepWin:initialView()
    if self.curStep > self.confs[#self.confs].step then
        self.isMaxStep = true
        self.curStep = self.confs[#self.confs].step
    end
    local conf = self.confs[self.curStep]
    local bg = self.resourceNode_:getChildByName("bg")
    bg:setTexture("battleBackground/" .. conf.background ..".png")

    --创建场景spine
    if conf.backgroundEffect and conf.backgroundEffect ~= "" then
        local sp = SpineManager.createAnimation("spine/background/" .. conf.backgroundEffect, 1)
        sp:playAnimation("idle", -1)
        sp:setPosition(bg:getContentSize().width * 0.5,bg:getContentSize().height * 0.5)
        bg:addChild(sp)
    end

    self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(WordDictionary[75001])
    -- self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"):setVisible(false)
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"), function()
        self:openWin("HelpWin", WordDictionary[21488], WordDictionary[72009])
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
        self:closeSelf()
    end)

    local btn_floor = self.resourceNode_:getChildByName("node_lb"):getChildByName("btn_floor")
    UIImageBox.new(btn_floor, function()
        self:openWin("PlotFloorRewardWin")
    end)
    btn_floor:getChildByName("txt_btn"):setString(WordDictionary[75007])

    local battleBg = self.resourceNode_:getChildByName("node_rb"):getChildByName("img_cdjhBg")
    local outsideBtn = UIAniButton.new("public/zhujiemian_fengshilang", function(eventType,me,point)
        if eventType == "ended" then
            if not me.canFight then
                MoveLabel.new(WordDictionary[75029])
                return
            end

            if self.isClosing then
                return
            end
            self.isClosing = true

            --按钮动画
            if not me.originScale then
                me.originScale = me:getScale()
            end
            me:setScale(me.originScale * 0.8)
            me:runAction(cc.ScaleTo:create(0.15,me.originScale * 1.1))
            
            --响应事件
            local conf = self.confs[self.curStep]
            self:openWin("EmbattleWin", {fightStatus = c.FightStatus.plotStep, conf = conf})
        end
    end, {scale = 1})
    outsideBtn:setScale(0.5)
    outsideBtn:setFlipX(true)
    local size = battleBg:getContentSize()
    outsideBtn:setPosition(size.width * 0.5, size.height * 0.5)
    battleBg:addChild(outsideBtn)
    self.outsideBtn = outsideBtn
    battleBg:setEnabled(self.isMaxStep)
    self:updateTime()
    self:updateStep()
end

function PlotStepWin:updateTime()
    local txt_time = self.resourceNode_:getChildByName("node_ct"):getChildByName("txt_time")
    local waitTime = PlotModel:getEndCutdown(2)
    txt_time:setString(string.format(WordDictionary[75013], Helper.getTimeString(waitTime, true)))
    txt_time:actionScheduleInterval(function()
        waitTime = waitTime - 1
        if waitTime >= 0 then
            txt_time:setString(string.format(WordDictionary[75013], Helper.getTimeString(waitTime, true)))
        else
            txt_time:stopAllActions()
        end
    end, 1)
end

function PlotStepWin:updateStep()
    local step = self.curStep
    if self.isAutoOpen then
        step = step -1
    end

    local conf = self.confs[step] or {}
    local txt_title = self.resourceNode_:getChildByName("node_ct"):getChildByName("txt_title")
    txt_title:setString(conf.name)

    local node_cb = self.resourceNode_:getChildByName("node_cb")
    node_cb:getChildByName("txt_power"):setString(conf.fightPower)

    local rewardScale = 0.8

    local node_reward1 = node_cb:getChildByName("node_reward1")
    node_reward1:removeAllChildren()
    local boxAward = conf.boxAward or {}
    local startX = (-#boxAward * 100 * 0.5 + 50) * rewardScale
    for k,v in pairs(boxAward) do
        local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = rewardScale})
        item:setPosition(startX + (k-1) * 100 * rewardScale, 0)
        node_reward1:addChild(item)

        if self.isAutoOpen then
            item:runAction(
                cc.Sequence:create(
                    cc.DelayTime:create(1),
                    cc.MoveTo:create(0.5, cc.p(-243, 0)),
                    cc.CallFunc:create(function()
                        item:setVisible(false)
                    end),
                    cc.DelayTime:create(0.5),
                    cc.CallFunc:create(function()
                        self:playNextWave()
                    end)
                )
            )
        end
    end

    local node_reward2 = node_cb:getChildByName("node_reward2")
    node_reward2:removeAllChildren()
    local stepAward = conf.stepAward or {}
    local startX = (-#stepAward * 100 * 0.5 + 50) * rewardScale
    for k,v in pairs(stepAward) do
        local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = rewardScale})
        item:setPosition(startX + (k-1) * 100 * rewardScale, 0)
        node_reward2:addChild(item)
    end

    local node_monster = self.resourceNode_:getChildByName("node_monster")
    node_monster:removeAllChildren()
    local monsters = conf.monsterId or {}
    local startX = -#stepAward * 200 * 0.5
    local cnt = 0
    for k,v in pairs(monsters) do
        local role = monsterConf[v].role
        local path = "spine/actors/".. roleConf[role].spine
        local monster = SpineManager.createAnimation(path)
        monster:registerSkin("normal")
        if self.isAutoOpen then
            monster:playAnimation("die", 1)
            monster:setAutoRemove(true)
            -- monster:addLuaHandler(function (eventName, animName, intValue, floatValue)
            --     if eventName == "complete" then
            --         cnt = cnt + 1
            --         if cnt == #monsters then
            --             self:playNextWave()
            --         end
            --     end
            -- end)
        else
            monster:playAnimation("idle", -1)
        end
        monster:setScale(1.2)
        monster:setPosition(startX + (k-1) * 200, -60)
        node_monster:addChild(monster)

        local sp_di = display.newSprite("#plot/zi_di.png")
        sp_di:setScale(0.7)
        local txt = UILabel.new({
            text = monsterConf[v].name,
            color = c.ITEM_QUALITY_COLOR[monsterConf[v].color or 401],
            size = 16,
        })
        sp_di:setPosition(0, 150)
        monster:addChild(sp_di)
        local size = sp_di:getContentSize()
        txt:setPosition(size.width/2, size.height/2)
        sp_di:addChild(txt)

    end

    if self.isAutoOpen then
        local path = "plot/ui_huanshendian_saodang"
        local anim = SpineManager.createAnimation(path,1)
        anim:playAnimation("idle", 1)
        anim:setAutoRemove(true)
        node_monster:addChild(anim)
    end

    local conf = self.confs[step] or {}
    local node_c = self.resourceNode_:getChildByName("node_c")
    if conf.openDay > PlotModel:getCurDay(2) then
        node_c:getChildByName("sp_notopen"):setVisible(true)
        local txt_time = node_c:getChildByName("sp_notopen"):getChildByName("txt_time")
        local waitTime = PlotModel:getStepOpenTime(2,conf.openDay)
        txt_time:setString(string.format(WordDictionary[75014], Helper.getTimeString(waitTime, true)))
        txt_time:actionScheduleInterval(function()
            waitTime = waitTime - 1
            if waitTime >= 0 then
                txt_time:setString(string.format(WordDictionary[75014], Helper.getTimeString(waitTime, true)))
            else
                txt_time:stopAllActions()
                self:closeSelf()
            end
        end, 1)
    else
        node_c:getChildByName("sp_notopen"):setVisible(false)
    end

    node_c:getChildByName("sp_finish"):setVisible(not self.confs[self.curStep] or self.isMaxStep)
    node_monster:setVisible(self.confs[self.curStep] and not self.isMaxStep)

    local canFight = conf.openDay <= PlotModel:getCurDay(2) and self.confs[self.curStep] and not self.isMaxStep
    if canFight then
        self.outsideBtn:setNormal()
    else
        self.outsideBtn:setGray()
    end
    self.outsideBtn.canFight = canFight
end

function PlotStepWin:playNextWave()
    self.isAutoOpen = false
    self:updateStep()
end

function PlotStepWin:returnUpdate()
    self.isClosing = false
end

function PlotStepWin:getActionIn()
    Helper.enterWinAction2(self)
end

function PlotStepWin:getActionOut(callback)
   Helper.outWinAction(self, callback)
   return true
end

return PlotStepWin