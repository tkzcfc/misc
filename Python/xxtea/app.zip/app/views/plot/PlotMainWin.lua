--符能暴动主界面
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local SpineManager = require "sandglass.core.SpineManager"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local TeamController = require "app.battle.controllers.TeamController"

local Helper = require "app.Helper"
local init = require "app.models.init"

local PlotModel = init.PlotModel

local plotsConf = require "app.configs.plots"
local itemConf = require "app.configs.item"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skillConf = require "app.configs.skill"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"
local CoreColor = require "sandglass.core.CoreColor"

local PlotMainWin = class("PlotMainWin", WinBase)

PlotMainWin.RESOURCE_FILENAME = "plot/plotMain.csb"

function PlotMainWin:onCreate(itemId,buyNum)
    self.priority = c.WIN_ZORDER.POPUP
    
    local msgList = {
        msgids.GS_BagUpdate,
        msgids.GS_PlotsTake_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function PlotMainWin:receive(op,data)
    if op == msgids.GS_PlotsTake_R then
        if data.Rewards then
            self:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        end
    end
end

function PlotMainWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)

    self:initData()
    self:initStage()
    self:initRole()
end

function PlotMainWin:initData()
    self.confs = {}
    for _,v in pairs(plotsConf) do
        self.confs[v.stage] = v
    end
end

function PlotMainWin:initStage()
    local wins = {
        "PlotSpreadWin",
        "PlotStepWin",
        "PlotBossWin",
    }
    for i=1,3 do
        local conf = self.confs[i]
        local state = PlotModel:checkOpenState(i)
        local stage = self.resourceNode_:getChildByName("stage_"..i)
        stage:getChildByName("txt_name"):setString(conf.name)
        stage:getChildByName("txt_time"):setTextColor(CoreColor.TEXT_RED)
        if state == 0 then
            stage:getChildByName("txt_time"):setString(conf.timeShow)
        elseif state == 1 then
            local txt_time = stage:getChildByName("txt_time")
            txt_time:setTextColor(CoreColor.TEXT_GREEN)
            local waitTime = PlotModel:getEndCutdown(i)
            txt_time:setString(string.format(WordDictionary[75026], Helper.getTimeString(waitTime, true)))
            txt_time:actionScheduleInterval(function()
                waitTime = waitTime - 1
                if waitTime >= 0 then
                    txt_time:setString(string.format(WordDictionary[75026], Helper.getTimeString(waitTime, true)))
                else
                    txt_time:stopAllActions()
                    self:initStage()
                    self:initRole()
                end
            end, 1)

        else
            stage:getChildByName("txt_time"):setString(WordDictionary[75015])
        end
        
        stage:getChildByName("txt_desc"):setString(conf.des)

        local node_reward = stage:getChildByName("node_reward")
        local awardShow = conf.awardShow or {}
        for idx,id in pairs(awardShow) do
            local item = Helper.createGoodsItem({id = id})
            item:setPosition((idx - 1) % 4 * 100, -math.floor((idx - 1) / 4) * 100)
            node_reward:addChild(item)
        end

        local btn_go = UIImageBox.new(stage:getChildByName("btn_go"), function()
            self:openWin(wins[i])
            self:closeSelf()
        end)

        btn_go:setEnabled(state == 1)

        if state == 1 then
            self.curStage = i
            local path = "plot/ui_fuhengbaodong_jieduanxuanzhong"
            local anim = SpineManager.createAnimation(path,1)
            anim:setPosition(stage:getContentSize().width * 0.5, stage:getContentSize().height * 0.5)
            anim:playAnimation("idle", -1)
            stage:addChild(anim)
        end
    end

    self.resourceNode_:getChildByName("bg_skill"):setVisible(self.curStage and self.curStage ~= 1) --阶段1不显示技能
    self.resourceNode_:getChildByName("btn_log"):setVisible(self.curStage and self.curStage ~= 1) --阶段1不显示日志
    local btn_log = UIImageBox.new(self.resourceNode_:getChildByName("btn_log"), function(me)
        local curDay = PlotModel:getCurDay(1)
        local plotLogDay = PlayerConfig.getSetting("plotLogDay", 0)
        self:openWin("PlotLogWin", tonumber(plotLogDay) < curDay)
        PlayerConfig.setSetting("plotLogDay", curDay)
    end)

    local btnFilems = UIImageBox.new(self.resourceNode_:getChildByName("btn_films"), function(me)
        if self.curStage and self.curStage >= 2 then
            self:openWin("HgwcAnimWin")
        else
            MoveLabel.new(WordDictionary[75027])
            Helper.greyFunc(me)
        end
    end)
    if self.curStage and self.curStage < 2 then
        Helper.greyFunc(btnFilems)
    end
end

function PlotMainWin:onEnterTransitionFinish()
    if self.curStage and self.curStage >= 2 and not PlayerConfig.getSetting("hgwcAnim", false) then --阶段2首次播放动画
        self:openWin("HgwcAnimWin")
    end
end

function PlotMainWin:initRole()
    local sp_npc = self.resourceNode_:getChildByName("sp_npc")
    local bg_skill = self.resourceNode_:getChildByName("bg_skill")

    local heroId = 0
    for _,v in pairs(plotsConf) do
        if v.stage == self.curStage then
            heroId = v.hero
            break
        end
    end

    if heroId > 0 then
        local heroData = heroConf[heroId]
        if self.curStage and self.curStage >= 2 then
            sp_npc:setVisible(false)
            local path = "guide/ui_cha_huagu"
            local anim = SpineManager.createAnimation(path, 1)
            anim:playAnimation("idle5", -1)
            anim:setPositionY(-60)
            self.resourceNode_:getChildByName("node_npc"):addChild(anim)
        end

        -- 技能
        local skillPicData = {
            [1] = skillConf[heroData.skillUltimate],
            [2] = skillConf[heroData.skill1],
            [3] = skillConf[heroData.skill2],
        }
        local perX = 80
        local skillNode = bg_skill:getChildByName("node_skill")
        skillNode:removeAllChildren()
        for k,v in ipairs(skillPicData) do
            local skillItem = Helper.createSkillIcon({
                id = v.Id,
                ableGLProgram = false,
                cls = 0,
            })
            local x = (k - (#skillPicData + 1) / 2)  * perX
            local y = 0
            display.align(skillItem,display.CENTER,x,y)
            skillItem:setName("skill_"..v.Id)
            skillNode:addChild(skillItem)
        end

        UIImageBox.new(self.resourceNode_:getChildByName("bg_skill"):getChildByName("btn_perView"), function()
            local data = TeamController.getSkillPreviewTeam(20054)    
            data.params.afterLoading = c.AfterLoading.mainScene
            data.params.win = "PlotMainWin"
            self:getApp():enterScene("SkillPreviewScene", data)
        end)
    else
        bg_skill:setVisible(false)
    end
end

function PlotMainWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotMainWin