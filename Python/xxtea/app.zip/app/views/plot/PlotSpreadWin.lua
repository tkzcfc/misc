--符能扩散
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local CoreColor = require "sandglass.core.CoreColor"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local SpineManager = require "sandglass.core.SpineManager"

local Helper = require "app.Helper"
local init = require "app.models.init"

local PlotModel = init.PlotModel
local RedTipsModel = init.RedTipsModel

local plotsJournalConf = require "app.configs.plotsJournal"
local plotsJournalAwardConf = require "app.configs.plotsJournalAward"

local itemConf = require "app.configs.item"
local openConf = require "app.configs.open"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"

local PlotSpreadWin = class("PlotSpreadWin", WinBase)

PlotSpreadWin.RESOURCE_FILENAME = "plot/plotSpread.csb"

function PlotSpreadWin:onCreate(itemId,buyNum)
    self.priority = c.WIN_ZORDER.POPUP
    
    self.boxIndex = {
        1,2,2,3,3,4
    }

    local msgList = {
        msgids.GS_PlotsJournalInfo_R,
        msgids.GS_PlotsJournalTake_R,
        msgids.GS_UseRewards_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function PlotSpreadWin:receive(op,data)
    if op == msgids.GS_PlotsJournalInfo_R then
        self:updateScore()
        self:updateBox()
    elseif op == msgids.GS_PlotsJournalTake_R then
        self:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        self:updateBox()
    elseif op == msgids.GS_UseRewards_R then
        self:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        self:updateBtn()
        self:updateBox()
    end
end

function PlotSpreadWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)

    self:initBox()
    self:updateBox()
    self:updateScore()
    self:updateDay()
    self:updateBtn()

    local path = "plot/ui_funengbaodong_fuwenshuijing"
    local anim = SpineManager.createAnimation(path,1)
    anim:playAnimation("idle", -1)
    anim:setPosition(self.resourceNode_:getChildByName("bg"):getPosition())
    self.resourceNode_:addChild(anim)

    local tips_panel = self.resourceNode_:getChildByName("tips_panel")
    tips_panel:onTouch(function(evt)
        if evt.name == "ended" then
            self:hideTips()
        end
    end)

    local waitTime = 10
    self.resourceNode_:actionScheduleInterval(function()
        waitTime = 60
        network.tcpSend(msgids.C_PlotsJournalInfo, {})
    end, waitTime)
end

function PlotSpreadWin:updateBtn()
    local itemId = 34027
    local btn_use = self.resourceNode_:getChildByName("btn_use")
    local btn = UIImageBox.new(btn_use, function(me)
        if me.canUse then
            local cnt = Helper.getItemOrCurrencyCnt(itemId)
            if cnt > 1 then---批量使用
                self:openWin("ItemUseWin",itemId)
            else
                local data = {
                    Id = itemId,
                    N = 1,
                }
                network.tcpSend(msgids.C_UseItem, data)
            end
        else
            self:openWin("SourceWin",itemId)
        end
    end)

    local node_item = self.resourceNode_:getChildByName("node_item")
    node_item:removeAllChildren()
    local cnt = Helper.getItemOrCurrencyCnt(itemId)
    node_item:addChild(Helper.createGoodsItem({id = itemId, num = cnt}))
    local txt = btn_use:getChildByName("txt_btn")
    if cnt > 0 then
        btn.canUse = true
        txt:setString(WordDictionary[75004])
    else
        btn.canUse = false
        txt:setString(WordDictionary[75003])
    end
end

function PlotSpreadWin:updateDay()
    local maxDay = 1
    local confs = {}
    for _,v in pairs(plotsJournalConf) do
        confs[v.showDay] = v
        maxDay = maxDay < v.showDay and v.showDay or maxDay
    end

    local day = PlotModel:getCurDay(1)
    local conf = confs[day] or confs[maxDay]
    self.resourceNode_:getChildByName("txt_desc"):setString(conf.des)
    local txt_time = self.resourceNode_:getChildByName("txt_time")
    local waitTime = PlotModel:getEndCutdown(1)
    txt_time:setString(string.format(WordDictionary[75002], Helper.getTimeString(waitTime, true)))
    txt_time:actionScheduleInterval(function()
        waitTime = waitTime - 1
        if waitTime >= 0 then
            txt_time:setString(string.format(WordDictionary[75002], Helper.getTimeString(waitTime, true)))
        else
            txt_time:stopAllActions()
            self:closeSelf()
        end
    end, 1)

    local btn_log = UIImageBox.new(self.resourceNode_:getChildByName("btn_log"), function(me)
        local curDay = PlotModel:getCurDay(1)
        local plotLogDay = PlayerConfig.getSetting("plotLogDay", 0)
        self:openWin("PlotLogWin", tonumber(plotLogDay) < curDay)

        PlayerConfig.setSetting("plotLogDay", curDay)
        RedTipsModel:removeRedTip(me)
    end)

    local curDay = PlotModel:getCurDay(1)
    local plotLogDay = PlayerConfig.getSetting("plotLogDay", 0)

    if tonumber(plotLogDay) < curDay then
        RedTipsModel:addRedTip(btn_log, cc.p(55, 55))
    else
        RedTipsModel:removeRedTip(btn_log)
    end

    local node_reward = self.resourceNode_:getChildByName("node_reward")
    node_reward:removeAllChildren()
    local awardShow = conf.awardShow or {}
    for idx,id in pairs(awardShow) do
        local item = Helper.createGoodsItem({id = id})
        item:setPosition((idx - 1) * 100, 0)
        node_reward:addChild(item)
    end

end

function PlotSpreadWin:initBox()
    local maxCond = 0
    local curScore = PlotModel:getBoxScore()
    for i=1,6 do
        local box = self.resourceNode_:getChildByName("box_"..i)
        local txt_cnt = box:getChildByName("txt_cnt")
        txt_cnt:setString(curScore.."/"..plotsJournalAwardConf[i].cond)

        maxCond = maxCond < plotsJournalAwardConf[i].cond and plotsJournalAwardConf[i].cond or maxCond

        UIImageBox.new(box, function(me, event)
            local curScore = PlotModel:getBoxScore()
            if not PlotModel:getSpreadTaken(i) and curScore >= plotsJournalAwardConf[i].cond then
                network.tcpSend(msgids.C_PlotsJournalTake,{Id = plotsJournalAwardConf[i].id})
            else
                self:showBoxTips(i)
            end
        end,{noAnimEffect = true})
    end

    local startX = 147
    local width = 810
    for i=1,6 do
        local box = self.resourceNode_:getChildByName("box_"..i)
        local cond = plotsJournalAwardConf[i].cond
        box:setPositionX(startX + width * cond / maxCond)
    end

    local img_tips_1 = self.resourceNode_:getChildByName("img_tips_1")
    img_tips_1:setPositionX(self.resourceNode_:getChildByName("box_6"):getPositionX())
    local size = img_tips_1:getContentSize()

    local awardShow = plotsJournalAwardConf[6].awardShow or {}
    for i,v in ipairs(awardShow) do
        local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.68})
        item:setPosition(45 + (i-1) * 70, size.height * 0.55)
        img_tips_1:addChild(item)
    end

    img_tips_1:setContentSize(cc.size(#awardShow * 80, img_tips_1:getContentSize().height))
end

function PlotSpreadWin:updateBox()
    local curScore = PlotModel:getBoxScore()
    for i=1,6 do
        local box = self.resourceNode_:getChildByName("box_"..i)
        RedTipsModel:removeRedTip(box)
        local path = "public/baoxiang" .. self.boxIndex[i] .. ".png"
        if PlotModel:getSpreadTaken(i) then
            path = "public/baoxiang" .. self.boxIndex[i] .. "_open.png"
        elseif curScore >= plotsJournalAwardConf[i].cond then
            RedTipsModel:addRedTip(box, cc.p(68,54))
        end
        box:loadTexture(path, ccui.TextureResType.plistType)
    end

    local pertcent = 100 * curScore /  plotsJournalAwardConf[#plotsJournalAwardConf].cond
    self.resourceNode_:getChildByName("bar"):setPercent(pertcent)
end

function PlotSpreadWin:updateScore()
    local curScore = PlotModel:getBoxScore()
    for i=1,6 do
        local box = self.resourceNode_:getChildByName("box_"..i)
        local txt_cnt = box:getChildByName("txt_cnt")
        txt_cnt:setString(curScore.."/"..plotsJournalAwardConf[i].cond)
        if curScore < plotsJournalAwardConf[i].cond then
            txt_cnt:setTextColor(CoreColor.RED)
        else
            txt_cnt:setTextColor(CoreColor.GREEN)
        end
    end
end

function PlotSpreadWin:showBoxTips(boxIdx)
    local tips_panel = self.resourceNode_:getChildByName("tips_panel")
    local img_tips = tips_panel:getChildByName("img_tips")
    img_tips:removeAllChildren()
    tips_panel:setVisible(true)
    local size = img_tips:getContentSize()

    local conf = plotsJournalAwardConf[boxIdx]
    for i,v in ipairs(conf.award or {}) do
        local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.68})
        item:setPosition(45 + (i-1) * 70, size.height * 0.55)
        img_tips:addChild(item)
    end
    img_tips:setContentSize(cc.size(#conf.award * 75, 97))
    local box = self.resourceNode_:getChildByName("box_"..boxIdx)
    img_tips:setPositionX(box:getPositionX() + 110)
    if boxIdx == 6 then
        img_tips:setPositionX(img_tips:getPositionX())
    end
    self.resourceNode_:getChildByName("img_tips_1"):setVisible(false)
end

function PlotSpreadWin:hideTips()
    self.resourceNode_:getChildByName("tips_panel"):setVisible(false)
    self.resourceNode_:getChildByName("img_tips_1"):setVisible(true)
end

function PlotSpreadWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotSpreadWin