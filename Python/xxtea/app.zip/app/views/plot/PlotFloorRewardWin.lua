local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"

local Helper = require "app.Helper"
local init = require "app.models.init"
local UILabel = require "sandglass.ui.UILabel"

local plotsStepConf = require "app.configs.plotsStep"
local c = require "app.configs.constants"

local PlotFloorRewardWin = class("PlotFloorRewardWin", WinBase)
local PlotModel = init.PlotModel

PlotFloorRewardWin.RESOURCE_FILENAME = "plot/plotFloorReward.csb"

function PlotFloorRewardWin:onCreate(itemId,buyNum)
    self.priority = c.WIN_ZORDER.POPUP
    
    self.confs = {}
    for _,v in pairs(plotsStepConf) do
        self.confs[v.step] = v
    end
end

function PlotFloorRewardWin:initialView()
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[75008])
    self.resourceNode_:getChildByName("txt_tip"):setString(WordDictionary[75009])
    local txt_tip_1 = self.resourceNode_:getChildByName("txt_tip_1")
    local waitTime = PlotModel:getEndCutdown(2)
    txt_tip_1:setString(string.format(WordDictionary[75010], Helper.getTimeString(waitTime, true)))
    txt_tip_1:actionScheduleInterval(function()
        waitTime = waitTime - 1
        if waitTime >= 0 then
            txt_tip_1:setString(string.format(WordDictionary[75010], Helper.getTimeString(waitTime, true)))
        else
            txt_tip_1:stopAllActions()
        end
    end, 1)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    
    self:setAutoClose(self.resourceNode_:getChildByName("bg"))
    self:updateListView()
end


function PlotFloorRewardWin:updateListView()
    local rewards = {}
    for i,v in ipairs(self.confs) do
        local rConf = v.boxAward or {}
        for _,rwd in ipairs(rConf) do
            table.insert(rewards,{id = rwd.id, n = rwd.n, step = v.step, name = v.name })
        end
    end

    local listView = self.resourceNode_:getChildByName("list")
    listView:setScrollBarEnabled(false)
    listView:removeAllChildren()
    listView:updateGridView(8,rewards,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end)

end

function PlotFloorRewardWin:createItem(data, index)
    local layer = ccui.Layout:create()
    local item = Helper.createGoodsItem({id = data.id, num = data.n, scale = 0.8, ableGLProgram = false})

    local sp_di = display.newSprite("#plot/zi_di.png")
    sp_di:setScaleX(0.72)
    local txt = UILabel.new({
        text = string.format(WordDictionary[75011], string.gsub(data.name,WordDictionary[75012], "")),
        color = cc.c3b(162,134,95),
        size = 18,
    })

    sp_di:setName("itemTip")
    sp_di:setPosition(50, 50)
    item:addChild(sp_di)
    txt:setName("itemTipTxt")
    txt:setPosition(50, 50)
    item:addChild(txt)

    layer.updateView = function(layer,data)
        local passedStep = PlotModel:getCurStep() - 1
        item:getChildByName("itemTip"):setVisible(data.step > passedStep)
        item:getChildByName("itemTipTxt"):setVisible(data.step > passedStep)
        Helper.greyFunc(item, data.step <= passedStep)

        if index%8 == 7 or index%8 == 0 then
            local sp = display.newSprite("#public/buzhen-di2.png")
                    :align(display.RIGHT_TOP, item:getContentSize().width-3, item:getContentSize().height-3)
                    :addTo(item)
            local txt = ccui.Text:create(WordDictionary[72011], "fonts/HYh3gj.ttf", 18)
                :align(display.CENTER, 33, 33)
                :addTo(sp)
                :setRotation(45)
                :setTextColor(cc.c3b(255,192,0))
                :enableOutline(cc.c3b(0, 0, 0), 1)
        end
    end

    layer:setContentSize(100, 100)
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(item)
    item:setPosition(50,50)
    item:setName("itemView")
    return layer
end

function PlotFloorRewardWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotFloorRewardWin