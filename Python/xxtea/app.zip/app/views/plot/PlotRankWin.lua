local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local SpineManager = require "sandglass.core.SpineManager"
local UIAniButton = require "sandglass.ui.UIAniButton"

local Helper = require "app.Helper"
local init = require "app.models.init"
local UILabel = require "sandglass.ui.UILabel"
local msgids = require "app.network.msgids"
local network = require "app.network.network"

local plotsBossRankConf = require "app.configs.plotsBossRank"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skinConf = require "app.configs.skin"
local c = require "app.configs.constants"

local PlotModel = init.PlotModel

local PlotRankWin = class("PlotRankWin", WinBase)

PlotRankWin.RESOURCE_FILENAME = "plot/plotRank.csb"

function PlotRankWin:onCreate(itemId,buyNum)
    self.priority = c.WIN_ZORDER.POPUP
    
    self.curPage = 0

    self.confs = {}
    for _,v in pairs(plotsBossRankConf) do
        for i=v.rank[1].up,v.rank[1].down do
            self.confs[i] = v.rankAward
        end
    end

    local msgList = {
        msgids.GS_PlayerInfo_R,
    }

    network.addListener(self, msgList, handler(self, self.receive))
end

function PlotRankWin:receive(op, data)
    if op == msgids.GS_PlayerInfo_R then--排行榜获取玩家信息
        local info = data.Info
        for key,val in pairs(self.curSelectItemData or {}) do
            info[key] = val
        end
        self:openWin("PlayerInfoWin",info)
    end
end

function PlotRankWin:initialView()
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[75025])
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)

    local list = self.resourceNode_:getChildByName("list")

    list:setScrollBarWidth(8)
    list:setScrollBarColor(cc.c3b(225,213,199))
    list:setScrollBarPositionFromCornerForVertical(cc.p(10,20))
    self.list = list

    for i=1,2 do
        local page = self.resourceNode_:getChildByName("btn_"..i)
        UIImageBox.new(page, function(me)
            self:onTabChange(i)
        end)
    end

    self:initTop3()
    self:initBottomInfo()

    self:onTabChange(1)
end

function PlotRankWin:initTop3()
    local ranks = PlotModel:getRankData()

    for i=1,3 do
        local role = self.resourceNode_:getChildByName("role_"..i)
        local node_role = role:getChildByName("node_role")
        node_role:removeAllChildren()

        local rankData = ranks[i]
        if not rankData then
            role:setVisible(false)
        else
            role:setVisible(true)
            local heroData = heroConf[rankData.HeroId]
            local path = "spine/actors/".. roleConf[heroData.role].spine
            local skinId = rankData.CurSkin or 1
            local skin = skinConf[skinId] and skinConf[skinId].spineName or "normal"

            local button = UIAniButton.new(path,function(eventType,me)
                if eventType == "ended" then
                    self.curSelectItemData = rankData
                    network.tcpSend(msgids.C_PlayerInfo, {PlrId = rankData.Plrid})
                end
            end,{skin = skin})
            button:playAnimation("idle", -1)
            node_role:addChild(button)
            role:getChildByName("txt_name"):setString(rankData.Name)
        end
    end
end

function PlotRankWin:initBottomInfo()
    self.resourceNode_:getChildByName("txt_tip_1"):setString(WordDictionary[75022])
    self.resourceNode_:getChildByName("txt_tip_2"):setString(WordDictionary[75023])

    local txt_time = self.resourceNode_:getChildByName("txt_time")
    local waitTime = PlotModel:getEndCutdown(3)
    txt_time:setString(Helper.getTimeString(waitTime, true))
    txt_time:actionScheduleInterval(function()
        waitTime = waitTime - 1
        if waitTime >= 0 then
            txt_time:setString(Helper.getTimeString(waitTime, true))
        else
            txt_time:stopAllActions()
            self:closeSelf()
        end
    end, 1)

    local myRankData = PlotModel:getMyRankData()
    self.resourceNode_:getChildByName("myRankText"):setString(myRankData.Idx or 0)
    self.resourceNode_:getChildByName("myDamageText"):setString(myRankData.Score or 0)
end

function PlotRankWin:onTabChange(idx)
    if idx == self.curPage then
        return
    end

    self.curPage = idx

    local path_1 = "plot/jiazu-yeka1.png"
    local path_2 = "plot/jiazu-yeka2.png"
    for i=1,2 do
        local page = self.resourceNode_:getChildByName("btn_"..i)
        local txt_btn = page:getChildByName("txt_btn")
        if i == self.curPage then
            page:loadTexture(path_1, ccui.TextureResType.plistType)
            txt_btn:setTextColor(cc.c3b(84,57,34))
            txt_btn:enableOutline(cc.c3b(246,228,116), 2)--描边
        else
            page:loadTexture(path_2, ccui.TextureResType.plistType)
            txt_btn:setTextColor(cc.c3b(235,215,188))
            txt_btn:enableOutline(cc.c3b(84,57,34), 0)--描边
        end
    end

    self:updateListView()
end

function PlotRankWin:updateListView()
    local ranks = clone(PlotModel:getRankData())
    -- if self.curPage == 1 then
    --     local maxIdx = #self.confs
    --     for i=#ranks,maxIdx do
    --         ranks[i] = {Idx = i}
    --     end
    -- end

    self.list:updateListView(ranks, function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createRankItem(data)
        end
        cacheView:updateView(data)
        return cacheView
    end)
end

function PlotRankWin:createRankItem(data)
    local node = cc.CSLoader:createNode("plot/rankItem.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local rankIcon = node:getChildByName("rankIcon")
        local txt_rank = node:getChildByName("txt_rank")
        rankIcon:setVisible(false)
        txt_rank:setVisible(false)
        if data.Idx <= 3 then
            rankIcon:setVisible(true)
            rankIcon:setSpriteFrame("public/0"..data.Idx..".png")
        else
            txt_rank:setVisible(true)
            txt_rank:setString(data.Idx)
        end
        
        node:getChildByName("txt_name"):setString(data.Name or WordDictionary[75028])

        local txt_label = node:getChildByName("txt_label")
        local txt_val = node:getChildByName("txt_val")
        txt_label:setString(self.curPage == 2 and WordDictionary[75020] or WordDictionary[75021])
        txt_val:setString((self.curPage == 2 and data.TeamAtk or data.Score) or 0)
        txt_val:setPositionX(txt_label:getPositionX() + txt_label:getContentSize().width + 2)

        local node_hero = node:getChildByName("node_hero")
        local node_reward = node:getChildByName("node_reward")
        local txt_reward = node:getChildByName("txt_reward")
        node_hero:setVisible(false)
        node_reward:setVisible(false)
        local rewardScale = 0.65
        if self.curPage == 1 then
            node_reward:setVisible(true)
            node_reward:removeAllChildren()
            txt_reward:setVisible(true)

            for k,v in pairs(self.confs[data.Idx]) do
                local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = rewardScale})
                item:setPosition((90 + (k-1) * 100) * rewardScale, 0)
                node_reward:addChild(item)
            end
        else 
            node_hero:setVisible(true)
            node_hero:removeAllChildren()
            txt_reward:setVisible(false)
            for k,v in pairs(data.Team or {}) do
                if v and v ~= 0 then
                    local item = Helper.CreateHeroHead({id = v, scale = rewardScale})
                    item:setPosition((50 + (k-1) * 100) * rewardScale, 0)
                    node_hero:addChild(item)
                end
            end
        end

        UIImageBox.new(node:getChildByName("bg"), function()
            self.curSelectItemData = data
            network.tcpSend(msgids.C_PlayerInfo, {PlrId = data.Plrid})
        end,{swallowTouches = false, noAnimEffect = true})
    end

    local size = node:getChildByName("bg"):getContentSize()
    layer:setContentSize(cc.size(size.width,size.height + 6))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)

    return layer
end

function PlotRankWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotRankWin