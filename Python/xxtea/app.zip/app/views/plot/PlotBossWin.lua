local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UIAniButton = require "sandglass.ui.UIAniButton"
local WordDictionary = require "app.configs.WordDictionary"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local MoveLabel = require "sandglass.ui.MoveLabel"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local AudioManager = require "sandglass.core.AudioManager"
local SpineManager = require "sandglass.core.SpineManager"
local enums = require "app.network.enums"

local init = require "app.models.init"
local PlotModel = init.PlotModel

local plotsBossConf = require "app.configs.plotsBoss"
local monsterConf = require "app.configs.monster"
local roleConf = require "app.configs.role"
local heroConf = require "app.configs.hero"
local skillConf = require "app.configs.skill"
local skinConf = require "app.configs.skin"

local PlotBossWin = class("PlotBossWin", WinBase)

PlotBossWin.RESOURCE_FILENAME = "plot/PlotBoss.csb"

function PlotBossWin:onCreate()
    self.priority = c.WIN_ZORDER.NORMAL
    self.showType = self.WinShowType.hiddenBack
    self.showCurrency = {c.CurrencyName.diamond, c.CurrencyName.gold}

    self.confs = {}
    for _,v in pairs(plotsBossConf) do
        self.confs[v.openDay] = v
    end
    
    local msgList = {
        msgids.GS_PlotsBossRank_R,
    }

    network.addListener(self, msgList, handler(self, self.receive))
    network.tcpSend(msgids.C_PlotsBossRank, {})
end

function PlotBossWin:receive(op,data)
    if op == msgids.GS_PlotsBossRank_R then
        self:updateRank()
    end
end

function PlotBossWin:initialView()
    local path = "plot/ui_funengbaodong_bg2"
    local anim = SpineManager.createAnimation(path,1)
    anim:playAnimation("idle", -1)
    anim:setPosition(self.resourceNode_:getChildByName("bg"):getPosition())
    self.resourceNode_:addChild(anim)

    self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(WordDictionary[75017])
    -- self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"):setVisible(false)
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"), function()
        self:openWin("HelpWin", WordDictionary[21488], WordDictionary[72010])
    end)
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
        self:closeSelf()
    end)

    local btn_rank = self.resourceNode_:getChildByName("node_lt"):getChildByName("btn_rank")
    UIImageBox.new(btn_rank, function()
        self:openWin("PlotRankWin")
    end)
    btn_rank:getChildByName("txt_btn"):setString(WordDictionary[21483])


    self:updateTime()
    self:updateBoss()
end

function PlotBossWin:updateTime()
    local txt_time = self.resourceNode_:getChildByName("node_ct"):getChildByName("txt_time")
    local waitTime = PlotModel:getEndCutdown(3)
    txt_time:setString(string.format(WordDictionary[75013], Helper.getTimeString(waitTime, true)))
    txt_time:actionScheduleInterval(function()
        waitTime = waitTime - 1
        if waitTime >= 0 then
            txt_time:setString(string.format(WordDictionary[75013], Helper.getTimeString(waitTime, true)))
        else
            txt_time:stopAllActions()
            self:closeSelf()
        end
    end, 1)
end

function PlotBossWin:updateRank()
    local ranks = PlotModel:getRankData()

    local node_lb = self.resourceNode_:getChildByName("node_lb")
    for i=1,3 do
        local role = node_lb:getChildByName("role_"..i)
        local node_role = role:getChildByName("node_role")
        node_role:removeAllChildren()

        local rankData = ranks[i]
        if not rankData or not rankData.Plrid then
            role:setVisible(false)
        else
            role:setVisible(true)
            local heroData = heroConf[rankData.HeroId]
            local path = "spine/actors/".. roleConf[heroData.role].spine
            local anim = SpineManager.createAnimation(path)
            local skinId = rankData.CurSkin or 1
            anim:registerSkin(skinConf[skinId] and skinConf[skinId].spineName or "normal")
            anim:playAnimation("idle", -1)
            node_role:addChild(anim)
            role:getChildByName("txt_name"):setString(rankData.Name)
        end
    end
end

function PlotBossWin:updateBoss()
    local curDay = PlotModel:getCurDay(3)
    local conf = self.confs[curDay]

    local mConf = monsterConf[conf.monsterId[1]]

    local node_rb = self.resourceNode_:getChildByName("node_rb")
    local txt_name = node_rb:getChildByName("txt_name")
    txt_name:setString(mConf.name)

    local btn_fight = node_rb:getChildByName("btn_fight")
    UIImageBox.new(btn_fight, function()
        self:openWin("EmbattleWin", {fightStatus = c.FightStatus.plotBoss, conf = conf})
    end)

    local btn_viewTeam = node_rb:getChildByName("btn_viewTeam")
    UIImageBox.new(btn_viewTeam, function()
        self:openWin("PlotTeamRecommendWin")
    end)

    local txts = {
        WordDictionary[75018],
        (conf.awardCount - PlotModel:getBossCnt()) .. "/" .. conf.awardCount
    }
    for i=1,2 do
        node_rb:getChildByName("txt_tip_"..i):setString(txts[i])
    end

    local node_boss = node_rb:getChildByName("node_boss")
    node_boss:removeAllChildren()
    local path = "spine/actors/".. roleConf[mConf.role].spine
    local monster = SpineManager.createAnimation(path)
    monster:registerSkin(skinConf[conf.monsterSkin].spineName or "normal")
    monster:playAnimation("idle", -1)
    node_boss:addChild(monster)
    node_boss:setScale(-mConf.bodyScale, mConf.bodyScale)

    local node_skill = node_rb:getChildByName("node_skill")
    node_skill:removeAllChildren()
    -- 技能
    local perX = 80
    for k,v in ipairs(conf.buffId or {}) do
        local skillItem = Helper.createBuffIcon({id = v})
        local x = (k - (#conf.buffId + 1) / 2)  * perX
        local y = 0
        display.align(skillItem,display.CENTER,x,y)
        skillItem:setName("skill_"..v)
        node_skill:addChild(skillItem)
    end

    local node_reward = node_rb:getChildByName("node_reward")
    node_reward:removeAllChildren()
    local stepAward = conf.stepAward or {}
    local rewardScale = 0.8
    local startX = (-#stepAward * 100 * 0.5 + 50) * rewardScale
    for k,v in pairs(stepAward) do
        local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = rewardScale})
        item:setPosition(startX + (k-1) * 100 * rewardScale, 0)
        node_reward:addChild(item)
    end

end

function PlotBossWin:getActionIn()
    Helper.enterWinAction2(self)
end

function PlotBossWin:getActionOut(callback)
   Helper.outWinAction(self, callback)
   return true
end

return PlotBossWin