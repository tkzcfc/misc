local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local SpineManager = require "sandglass.core.SpineManager"

local Helper = require "app.Helper"
local init = require "app.models.init"
local UILabel = require "sandglass.ui.UILabel"

local plotsBossConf = require "app.configs.plotsBoss"
local c = require "app.configs.constants"

local PlotModel = init.PlotModel

local PlotTeamRecommendWin = class("PlotTeamRecommendWin", WinBase)

PlotTeamRecommendWin.RESOURCE_FILENAME = "plot/plotTeamRecommend.csb"

function PlotTeamRecommendWin:onCreate(itemId,buyNum)
    self.priority = c.WIN_ZORDER.POPUP
   
    self.confs = {}
    for _,v in pairs(plotsBossConf) do
        self.confs[v.openDay] = v
    end
end

function PlotTeamRecommendWin:initialView()
    self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[75024])
    self.resourceNode_:getChildByName("txt_close"):setString(WordDictionary[20323])
    
    self:setAutoClose(self.resourceNode_:getChildByName("bg"))

    local node_hero = self.resourceNode_:getChildByName("node_hero")
    local curDay = PlotModel:getCurDay(3)
    local conf = self.confs[curDay]
    local startX = (-#conf.showHero * 100 * 0.5 + 50)
    for k,v in pairs(conf.showHero or {}) do
        local item = Helper.CreateHeroHead({id = v})
        item:setPosition(startX + (k-1) * 100, 0)
        node_hero:addChild(item)
    end

    local txt_desc = self.resourceNode_:getChildByName("txt_desc")
    txt_desc:setString(conf.showDes)
end

function PlotTeamRecommendWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotTeamRecommendWin