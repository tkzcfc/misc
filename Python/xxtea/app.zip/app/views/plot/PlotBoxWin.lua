
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UIAniButton = require "sandglass.ui.UIAniButton"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"

local Helper = require "app.Helper"
local init = require "app.models.init"
local UILabel = require "sandglass.ui.UILabel"

local plotsConf = require "app.configs.plots"
local c = require "app.configs.constants"

local msgids = require "app.network.msgids"
local network = require "app.network.network"

local PlotBoxWin = class("PlotBoxWin", WinBase)
local PlotModel = init.PlotModel

PlotBoxWin.RESOURCE_FILENAME = "plot/plotBox.csb"

function PlotBoxWin:onCreate()
    self.priority = c.WIN_ZORDER.TOP
    
    self.confs = {}
    for _,v in pairs(plotsConf) do
        self.confs[v.stage] = v
    end

    local msgList = {
        msgids.GS_PlotsStepTake_R,
    }

    network.addListener(self, msgList, handler(self, self.receive))
    
end

function PlotBoxWin:receive(op,data)
    if op == msgids.GS_PlotsStepTake_R then
        self:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        self:closeSelf()
    end
end

function PlotBoxWin:initialView()
    local txts = {
        self.confs[2].name,
        WordDictionary[75016],
        self.confs[3].name,
    }
    for i=1,3 do
        local txt = self.resourceNode_:getChildByName("txt_"..i)
        txt:setString(txts[i])
    end
    
    local path = "plot/ui_funengbaodong_baoxiang"
    local button = UIAniButton.new(path,function(eventType,me)
        if eventType == "ended" then
            me:playAnimation("idle2", 1)
            me:appendNextAnimation("idle3", -1)
            me:addLuaHandler(function (eventName, animName, intValue, floatValue)
                if eventName == "trigger" then
                    network.tcpSend(msgids.C_PlotsStepTake, {})
                end
            end)
        end
    end)
    button:playAnimation("idle1", -1)
    local node_box = self.resourceNode_:getChildByName("node_box")
    node_box:addChild(button)
end

function PlotBoxWin:getActionIn()
    Helper.enterWinAction1(self)
end

return PlotBoxWin