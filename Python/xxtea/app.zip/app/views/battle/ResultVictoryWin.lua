
local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local levelUpConf = require "app.configs.levelUp"
local init = require "app.models.init"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local ShaderManager = require "sandglass.core.ShaderManager"
local AudioManager = require "sandglass.core.AudioManager"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local battleConf = require "app.configs.battle"
local TeamController = require "app.battle.controllers.TeamController"
local globalPublicConf = require "app.configs.globalPublic"
local towerConf = require "app.configs.tower"
local SpineManager = require "sandglass.core.SpineManager"
local MoveLabel = require "sandglass.ui.MoveLabel"
local speCardConf = require "app.configs.speCard"
local dungeonConf = require "app.configs.dungeon"
local enums = require "app.network.enums"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local msgPack = require "app.network.MessagePack"

local ResultVictoryWin = class("ResultVictoryWin", WinBase)
ResultVictoryWin.RESOURCE_FILENAME = "fight/resultVictory.csb"

local PlayerModel = init.PlayerModel
local ArmorModel = init.ArmorModel
local LevelModel = init.LevelModel
local TowerModel = init.TowerModel
local ItemModel = init.ItemModel
local SpeCardModel = init.SpeCardModel
local RuneModel = init.RuneModel

function ResultVictoryWin:onCreate(params)
    self.priority = c.WIN_ZORDER.POPUP
    self.rewards = params.rewards or {}
    if not self.rewards.Items then 
        self.rewards.Items = {}
    end
    self.team = params.team
    self.levelUp = params.levelUp
    self.defenderTeam = params.defenderTeam
    self.callBack = params.callBack
    self.autoPushMap = params.autoPushMap and (not params.levelUp) 
    self.fightStatus = params.fightStatus
    self.afterLoading = params.afterLoading
    self.star = params.star or nil
    self.allDamageData = params.allDamageData
    --体验过之后才显示月卡加成
    if SpeCardModel:getTrial() or SpeCardModel:isBuyHonorCard() or SpeCardModel:isBuyExtremeCard() then -- 考虑到3种情况，体验过未购买，体验过购买，未体验就购买
        self:calulateAddExp()
    end

    local msgList = {
        msgids.GS_TowerChallenge_R,
    }
    network.addListener(self, msgList, handler(self, self.recieve))
end

function ResultVictoryWin:recieve(op, data)
    if op == msgids.GS_TowerChallenge_R then
        local replay = msgPack.unpack(data.Replay)
        local value = TeamController.getDataFromServer(replay.T)
        value.params.fightStatus = c.FightStatus.tower
        value.params.seed = replay.Seed
        value.params.rewards = data.Rewards
        value.params.bg = globalPublicConf[1].arenaBackground
        value.params.isReplay = true
        value.params.bgMusic = {"array_bg_01.mp3"}
        value.params.afterLoading = self.afterLoading
        value.params.isWin = data.IsWin
        value.afterLoading = c.AfterLoading.gameScene
        self:getApp():enterScene("LoadingScene", value)
    end
end

function ResultVictoryWin:closeSelf()
    if self.callBack then
        self:callBack()
        ResultVictoryWin.super.closeSelf(self)
    else
        if self.pushMapNode and self.fightStatus and self.fightStatus == c.FightStatus.ordinary then
            self:clickMapRecommand()
        else
            self:getScene():getChildByName("ViewBase"):exitScene(true)
        end
    end
end

function ResultVictoryWin:initialView()
    local pushMapNode = self.resourceNode_:getChildByName("Node_2"):getChildByName("node_pushMap")
    local starNode = self.resourceNode_:getChildByName("Node_2"):getChildByName("node_star")
    pushMapNode:setVisible(false)
    starNode:setVisible(false)
    
    -- 限时挑战，手动领取奖励，隐藏本界面奖励活动
    if self.fightStatus == c.FightStatus.timeChallenge then
        self.resourceNode_:getChildByName("Node_2"):getChildByName("img_lineL"):setVisible(false)
        self.resourceNode_:getChildByName("Node_2"):getChildByName("Text_12"):setVisible(false)
    end

    if self.star and self.star > 0 then
        starNode:setVisible(true)
        for i=1,3 do
            local sp_star = starNode:getChildByName("sp_star"..i)
            if i <= self.star then
                sp_star:setSpriteFrame("fight/dixiacheng-xing3.png")
            else
                sp_star:setSpriteFrame("fight/dixiacheng-xing4.png")
            end
        end
    end

    if self.fightStatus then
        if self.fightStatus == c.FightStatus.ordinary then
            self:checkAutoPushMap(pushMapNode)
        elseif self.fightStatus == c.FightStatus.dungeon then
            self:checkDungeon(pushMapNode)
        elseif self.fightStatus == c.FightStatus.tower then
            self:checkTower(pushMapNode)
        end
    end 

    local func = function()
         local item = self.rewards.Items or {}
         local ccy = self.rewards.Ccy or {}
         local armors = self.rewards.Armors or {}
         local runes = self.rewards.Runes or {}
         local all = {}
         for k,v in ipairs(ccy) do
            table.insert(all,v)
         end
         for k,v in ipairs(item) do
             if itemConf[v.Id] or currencyConf[v.Id] then
                 table.insert(all,v)
             end
         end
         for k,v in ipairs(armors) do
             table.insert(all,ArmorModel:getArmor(v))
         end
         for k,v in ipairs(runes) do
            local id = RuneModel:getRune(v).id
            table.insert(all,{Id = id, Num = 1, seq = v})
         end

         table.sort(all, function(a, b)
            local a_color,b_color = nil, nil
            if itemConf[a.Id or a.id] then
                a_color = itemConf[a.Id or a.id].color
            elseif currencyConf[a.Id or a.id] then
                a_color = currencyConf[a.Id or a.id].color
            else
                a_color = 0
            end
            if itemConf[b.Id or b.id] then
                b_color = itemConf[b.Id or b.id].color
            elseif currencyConf[b.Id or b.id] then
                b_color = currencyConf[b.Id or b.id].color
            else
                b_color = 0
            end
            if a_color == b_color then
                if (a.Id or a.id) == (b.Id or b.id) then
                    if a.additional and b.additional then
                        if a.additional == b.additional then
                            return a.Val > b.Val
                        else
                            return a.additional > b.additional
                        end
                    else
                        return b.additional
                    end
                else
                    return (a.Id or a.id) < (b.Id or b.id)
                end
            else
                return a_color > b_color
            end
        end)
        local scrollView = self.resourceNode_:getChildByName("Node_2"):getChildByName("scrollView")
        scrollView:removeAllChildren()
        scrollView:setScrollBarEnabled(false)
        local size = scrollView:getContentSize()

        local spacing = 76
        local row = 6
        local sumWidth = #all * spacing
        if sumWidth < size.width then
            size.width = sumWidth
        end
        scrollView:setContentSize(cc.size(size.width, size.height))
        scrollView:setInnerContainerSize(cc.size(sumWidth, size.height))

        local k = 1
        self.resourceNode_:actionScheduleInterval(function()
            if k > #all then
                self.resourceNode_:stopActionByTag(0XABC)
                return
            end
            local v = all[k]
            local item = Helper.createGoodsItem({scale = 0.8,id = v.Id or v.id,num = v.Num or v.Val,additional = v.additional,cardType = v.cardType, seq = v.seq})
            display.align(item,display.BOTTOM_LEFT, (k-1)*spacing, 0)
            scrollView:addChild(item)
            item:setVisible(false)

            AudioManager.playEffect("music/ui_wupintubiaochu.mp3")
            local path = "public/ui_wupintubiaochu"
            local anim = SpineManager.createAnimation(path)
            anim:playAnimation("idle", 1)
            anim:setPosition(item:getContentSize().width/2, item:getContentSize().height/2)
            item:addChild(anim)

            anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
                if eventName == "trigger" then
                    item:setVisible(true)
                end
            end)

            k = k + 1
        end, 0.2, 0XABC)

        self.exp = nil
        for k,v in pairs(ccy) do
            if v.Id == c.CurrencyName.exp then
                self.exp = v.Val
                break
            end
        end

        if not self.exp then self.exp = 0 end
        
        self.resourceNode_:getChildByName("txt_close"):setString(WordDictionary[20088])
        self:loadingBar(self.levelUp)

        if self.team then
            UIImageBox.new(self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_damage"),function()
                self:openWin("DamageStatisticsWin",{team = self.team,defenderTeam = self.defenderTeam, allDamageData = self.allDamageData})
            end)
        else
            self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_damage"):setVisible(false)
        end
    end

    local path = "public/ui_jiesuan"
    local anim = SpineManager.createAnimation(path)
    anim:playAnimation("idle1", 1)
    anim:addChildFollowSlot("item_point", display.newSprite("fight/public_font_14.png"))
    self.resourceNode_:getChildByName("Node_1"):addChild(anim)
    anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "complete" then
            local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
            self.resourceNode_:runAction(moveAction)
            moveAction:play("animation0", false)
            moveAction:setAnimationEndCallFunc("animation0",function()
                moveAction:clearFrameEndCallFuncs()
                moveAction:play("animation1", false)
                self.resourceNode_:getChildByName("Node_2"):setVisible(true)
                func()
            end)
        end
    end)

    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(3.3),
        cc.CallFunc:create(function()
            local listener = cc.EventListenerTouchOneByOne:create()
            listener:setSwallowTouches(true)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_MOVED)
            listener:registerScriptHandler(handler(self, function()
                listener:setEnabled(false)
                self:closeSelf()
            end), cc.Handler.EVENT_TOUCH_ENDED)
                    
            local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.resourceNode_)

            if self.team then
                UIImageBox.new(self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_damage"),function()
                    self:openWin("DamageStatisticsWin",{team = self.team,defenderTeam = self.defenderTeam})
                end,{swallowTouches = true})
            else
                self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_damage"):setVisible(false)
            end
        end)
    ))

end

function ResultVictoryWin:calulateAddExp()
    --普通闯关中 普通经验和月卡加成经验分开显示
    if self.fightStatus == c.FightStatus.ordinary then
        for idx,info in ipairs(self.rewards.Ccy or {}) do
            if info.Id == c.CurrencyName.exp then
                local num = info.Val
                table.remove(self.rewards.Ccy, idx)
                --additional用于加成角标显示
                local add = 0
                local addData = SpeCardModel:getExpAddData()
                local tmp = {}
                for k,v in ipairs(addData) do
                    tmp[v.conf.id] = v
                end
                for id,card in pairs(speCardConf) do -- 算出加成的经验
                    local tType = tmp[card.id] ~= nil and c.ADDITIONAL_TYPE.realGet or c.ADDITIONAL_TYPE.onlyShow
                    if tType == c.ADDITIONAL_TYPE.realGet then
                        add = add + math.floor(num * card.exp / 100)
                    end
                end
                for _id,card in pairs(speCardConf) do -- 加成经验分开显示是根据未加成经验算
                    local tType = tmp[card.id] ~= nil and c.ADDITIONAL_TYPE.realGet or c.ADDITIONAL_TYPE.onlyShow
                    table.insert(self.rewards.Ccy, 1, {Id = c.CurrencyName.exp, Val = math.floor((num - add) * card.exp / 100), additional = tType, cardType = id})
                end
                table.insert(self.rewards.Ccy, 1, {Id = c.CurrencyName.exp, Val = num - add})
                break
            end
        end
    end
end

function ResultVictoryWin:onEnterTransitionFinish()
    self:registerEvent("ResultVictory")
end

function ResultVictoryWin:onEventReceive(event)
    local name = event:getEventName()
    if name == "ResultVictory" then
        self.resourceNode_:getChildByName("Node_2"):getChildByName("txt_lv"):setString(PlayerModel.info.level)
        self:loadingBar()
    end
end

function ResultVictoryWin:loadingBar(level)
    local percent = 0
    local nextPercent = 0
    local loadingBar = self.resourceNode_:getChildByName("Node_2"):getChildByName("panel"):getChildByName("loadingBar")
    local loadingBar_bottom = self.resourceNode_:getChildByName("Node_2"):getChildByName("panel"):getChildByName("loadingBar_0")

    if level then  --  升级
        local levelUp = levelUpConf[PlayerModel.info.level - 1]
        local totleExp = PlayerModel.info.exp
        local perExp = totleExp - self.exp + levelUp.playerExp
        self.resourceNode_:getChildByName("Node_2"):getChildByName("txt_lv"):setString(PlayerModel.info.level - 1)
        percent = perExp / levelUp.playerExp * 100
        nextPercent = 100
        loadingBar:setPercent(percent)
        loadingBar_bottom:setPercent(nextPercent)

        loadingBar:runAction(cc.Sequence:create(
            cc.DelayTime:create(0.5),
            cc.CallFunc:create(function ()
                Helper.createLoadingBarCursor(loadingBar,nextPercent)
            end)
        ))

        self.levelUp = false
    else  --  没升级
        if loadingBar:getChildByName("cursor") then
            local cursor = loadingBar:getChildByName("cursor")
            cursor:setPosition(0,0)
        end

        local totleExp = PlayerModel.info.exp
        local perExp = totleExp - self.exp
        local levelUp = levelUpConf[PlayerModel.info.level]
        self.resourceNode_:getChildByName("Node_2"):getChildByName("txt_lv"):setString(PlayerModel.info.level)
        if levelUp.playerExp == 0 then  --满级
            percent = 100
            nextPercent = 100
        else
            nextPercent = totleExp / levelUp.playerExp * 100
            percent = perExp / levelUp.playerExp * 100
        end

        loadingBar:setPercent(percent)
        loadingBar_bottom:setPercent(nextPercent)

        loadingBar:runAction(cc.Sequence:create(
            cc.DelayTime:create(1),
            cc.CallFunc:create(function ()
                Helper.createLoadingBarCursor(loadingBar,nextPercent)
            end)
        ))
    end
end

function ResultVictoryWin:checkAutoPushMap(node)
    if self.autoPushMap then
        node:setVisible(true)
        local endTime = globalPublicConf[1].aotoBattle
        local txt_time = node:getChildByName("txt_time")
        txt_time:setString(endTime.."s")
        txt_time:actionScheduleInterval(function()
            endTime = endTime - 1
            if endTime < 0 then
                txt_time:stopAllActions()
                self:clickMapRecommand()
            else
                txt_time:setString(endTime.."s")
            end
        end, 1)
        node:getChildByName("btn_cancel"):getChildByName("txt_btn"):setString(WordDictionary[20074])
        UIImageBox.new(node:getChildByName("btn_cancel"), function()
            self.autoPushMap = false
            txt_time:stopAllActions()
            node:setVisible(false)
        end)
    end
end

function ResultVictoryWin:clickMapRecommand()
    -- 推荐关卡
    local minPower = nil  --推荐关卡的战斗力
    local recommand = nil  --推荐关卡
    local all = true
    local myLv = PlayerModel.info.level

    for levelId, status in pairs(LevelModel.levels) do
        if battleConf[levelId] and battleConf[levelId].type == 1 and status == c.LevelStatus.CURRENT then
            if minPower == nil or minPower > battleConf[levelId].battlePower then
                if battleConf[levelId].stageType == 0 and myLv >= battleConf[levelId].playerLevel then
                    recommand = levelId
                    minPower = battleConf[levelId].battlePower
                end
            end
        end
        if status == c.LevelStatus.PASSED or status == c.LevelStatus.EXPLORE or not battleConf[levelId] or battleConf[levelId].type ~= 1 then
        else
            all = false
        end
    end

    if not all and recommand then
        local costData = battleConf[recommand].passCost[1]
        local myNum = ItemModel:getItem(costData.id) and ItemModel:getItem(costData.id).number or PlayerModel:getCurrencyByID(costData.id)
        if myNum >= costData.n then
            local heroIds = json.decode(PlayerConfig.getSetting(PlayerModel.info.userId .. "pveTeam", "{}")) or {}
            local data = TeamController.getLevelTeam(heroIds, recommand)
            data.params.afterLoading = c.AfterLoading.outsideScene
            data.params.autoPushMap = true
            data.afterLoading = c.AfterLoading.gameScene
            self:getApp():enterScene("LoadingScene", data)
        else
            self:getScene():getChildByName("ViewBase"):exitScene(true)
        end
    else
        self:getScene():getChildByName("ViewBase"):exitScene(true)
    end
end

function ResultVictoryWin:checkTower(node)
    local curFloor = TowerModel.info.curFloor 
    local info = towerConf[curFloor]
    local lv = PlayerModel.info.level or 1
    if info and (lv >= info.towerLevel) and (info.type == 1) then
        node:setVisible(true)
        node:getChildByName("txt_tips"):setVisible(false)
        node:getChildByName("txt_time"):setVisible(false)
        local btn = UIImageBox.new(node:getChildByName("btn_cancel"), function()
            if Helper.checkArmorCountLimit() then
                local heroIds = json.decode(PlayerConfig.getSetting(PlayerModel.info.userId .. "towerTeam", "{}")) or {}
                local team = {}
                for idx = 1, 5 do
                    team[idx] = heroIds[idx] or 0
                end
                network.tcpSend(msgids.C_TowerChallenge, {
                    Floor = curFloor,
                    Team = team,
                })
            else
                self:getScene():getChildByName("ViewBase"):exitScene(true)
            end
        end)
        btn:getChildByName("txt_btn"):setString(WordDictionary[10200])
    end
end

function ResultVictoryWin:checkDungeon(node)
    local func_nextLevel = function()
        local confData = {}
        local dungeonData = nil
        local myLv = PlayerModel.info.level

        for k,v in pairs(dungeonConf) do
            table.insert(confData, clone(v))
        end
        table.sort(confData, function(a, b)
            return a.dungeonId > b.dungeonId
        end)
        
        if LevelModel.DLevels[confData[1].dungeonId] and LevelModel.DLevels[confData[1].dungeonId] >= enums.DungeonStatus_Passed then
            MoveLabel.new(WordDictionary[10201])
        else
            for i,v in ipairs(confData) do
                local unlockInfo = LevelModel.DLevels[v.unlockId]
                local unlock = (v.unlockId == 0) or (unlockInfo and (unlockInfo >= enums.DungeonStatus_Passed) or false)
                if unlock then
                    dungeonData = v
                    break
                end
            end
            if myLv >= dungeonData.levelLimit then
                local cost = dungeonData.cost[1]
                local myNum = Helper.getItemOrCurrencyCnt(cost.id) 
                if myNum >= cost.n then
                    if not Helper.checkArmorCountLimit() then
                        MoveLabel.new(WordDictionary[20327])
                    else
                        local heroIds = json.decode(PlayerConfig.getSetting(PlayerModel.info.userId .. "pveTeam", "{}")) or {}
                        local data = TeamController.getDungeonTeam(heroIds, dungeonData.dungeonId)
                        data.params.afterLoading = self.afterLoading
                        data.afterLoading = c.AfterLoading.gameScene
                        self:getApp():enterScene("LoadingScene", data)
                    end
                else
                    MoveLabel.new(WordDictionary[10203])
                end 
            else
                MoveLabel.new(WordDictionary[10202])
            end
        end
    end

    node:setVisible(true)
    node:getChildByName("txt_tips"):setVisible(false)
    node:getChildByName("txt_time"):setVisible(false)
    local btn = UIImageBox.new(node:getChildByName("btn_cancel"), function()
        func_nextLevel()
    end)
    btn:getChildByName("txt_btn"):setString(WordDictionary[10200])
end

return ResultVictoryWin