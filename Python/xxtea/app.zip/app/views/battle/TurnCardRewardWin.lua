local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local globalPublicConf = require "app.configs.globalPublic"
local CoreColor = require "sandglass.core.CoreColor"
local MoveLabel = require "sandglass.ui.MoveLabel"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local SpineManager = require "sandglass.core.SpineManager"
local UIAniButton = require "sandglass.ui.UIAniButton"

local ItemModel = init.ItemModel
local PlayerModel = init.PlayerModel

local TurnCardRewardWin = class("TurnCardRewardWin", WinBase)
TurnCardRewardWin.RESOURCE_FILENAME = "fight/lotteryDraw.csb"

function TurnCardRewardWin:onCreate(data)
    self.priority = c.WIN_ZORDER.POPUP

    self.data = data
    self.slot = {}
    local msgList = {
        msgids.GS_FlopRewardsTake, 
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function TurnCardRewardWin:receive(op, data)
    if op == msgids.GS_FlopRewardsTake then
        for k,id in pairs(data.Slot) do
            self.slot[id] = true
        end
        for i,id in pairs(data.Slot) do
            self:updateBox(id)
        end
        self:refreshCost()
    end
end

function TurnCardRewardWin:initialView(data)
    self.closeBtn = UIImageBox.new(self.resourceNode_:getChildByName("btn_close"), function()
        local rewards = {}
        for id,v in pairs(self.slot) do
            if v then
                table.insert(rewards, self.data.Items[id])
            end
        end
        display.getRunningScene():getChildByName("ViewBase"):openWin("PublicGetRewardWin",{rewards = {Items = rewards}})
        self:closeSelf()
    end)
    self.closeBtn:setVisible(false)
    
    local time = 31
    local txt_time = self.resourceNode_:getChildByName("txt_time")
    txt_time:setString(Helper.getTimeString(time, true, true))
    txt_time:actionScheduleInterval(function()
        time = time - 1
        if time >= 0 then 
            txt_time:setString(Helper.getTimeString(time, true, true))
        else
            txt_time:stopAllActions()
            self:closeSelf()
        end
    end, 1)
    
    self.posS = {}
    for i=1,5 do
        local node = self.resourceNode_:getChildByName("node_"..i)
        local x, y = node:getPosition()
        self.posS[i] = cc.p(x,y)
        self:updateBox(i, true)
    end
    ----全部领取
    local costNum = 0
    local costId = globalPublicConf[1].fightCardItem
    local myNum = ItemModel:getItem(costId) and ItemModel:getItem(costId).number or PlayerModel:getCurrencyByID(costId)
    self.resourceNode_:getChildByName("btn_getAll"):getChildByName("sp_icon"):setTexture(Helper.getPathById(costId))
    self.resourceNode_:getChildByName("node_buy"):getChildByName("sp_icon"):setTexture(Helper.getPathById(costId))
    local txt_num = self.resourceNode_:getChildByName("btn_getAll"):getChildByName("txt_num")
    for i,v in ipairs(globalPublicConf[1].fightCardCost) do
        costNum = costNum + v
    end
    txt_num:setString(costNum)
    if myNum >= costNum then
        txt_num:setTextColor(CoreColor.GREEN)
    else
        txt_num:setTextColor(CoreColor.RED)
    end
    local allGetBtn =  UIImageBox.new(self.resourceNode_:getChildByName("btn_getAll"), function(me)
        if myNum >= costNum then
            network.tcpSend(msgids.C_FlopRewardsTake, {Slot = {1,2,3,4,5}})
            me:setVisible(false)
            self.resourceNode_:getChildByName("btn_ok"):setVisible(false)
        else
            MoveLabel.new(WordDictionary[25428])
        end  
    end)
    ------开始抽取
    UIImageBox.new(self.resourceNode_:getChildByName("btn_ok"), function(me)
        allGetBtn:setVisible(false)
        me:setVisible(false)
        self:playBoxRandomAnim()
    end)
    
    self.numbers = {}
    self:getRandomNumber()

    self:refreshCost()

end


function TurnCardRewardWin:playBoxRandomAnim()
    for i=1,5 do
        local node = self.resourceNode_:getChildByName("node_"..self.numbers[i])
        if node then
            local anim = node:getChildByName("buttonAnim")
            anim:playAnimation("idle2", 1)
            anim:getChildFollowSlot("item_point"):setVisible(false)
            anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
                if animName == "idle2" and eventName == "complete" then
                    anim:setVisible(false)
                    node:setPosition(self.posS[i])
                end
            end)
        end
    end

    self.resourceNode_:runAction(cc.Sequence:create(
        cc.DelayTime:create(0.5),
        cc.CallFunc:create(function()
            local k = 1
            self.resourceNode_:actionScheduleInterval(function()
                local h = self.numbers[k] or 0
                local node = self.resourceNode_:getChildByName("node_"..h)
                if not node then
                    self.canClick = true
                    self.resourceNode_:stopAllActions()
                    return 
                end
                local anim = node:getChildByName("buttonAnim")
                local commonAnim = SpineManager.createAnimation("spine/effect/common_heroappear")
                commonAnim:playAnimation("idle", 1)
                commonAnim:setAutoRemove(true)
                commonAnim:setPosition(0, 0)
                node:addChild(commonAnim)
                commonAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
                    if eventName == "complete" then
                        anim:setVisible(true)
                        anim:playAnimation("idle3", 1)
                    end
                end)
                k = k + 1
            end,0.1)
        end)
    ))
    
end

function TurnCardRewardWin:refreshCost()
    if table.nums(self.slot) == 5 then
        self.closeBtn:onClick()
        return
    end
    local node_buy = self.resourceNode_:getChildByName("node_buy")
    local node_free = self.resourceNode_:getChildByName("node_free")
    self.myNum = PlayerModel:getCurrencyByID(c.CurrencyName.diamond)
    local turnCnt = table.nums(self.slot)
    local freeCnt = 0
    for i,v in ipairs(globalPublicConf[1].fightCardCost) do
        if v == 0 then
            freeCnt = freeCnt + 1
        end
    end
    if turnCnt >= freeCnt then
        self.closeBtn:setVisible(true)
        node_buy:setVisible(true)
        node_free:setVisible(false)
        local txt_num = node_buy:getChildByName("txt_num")
        txt_num:setString(globalPublicConf[1].fightCardCost[turnCnt+1] or 0)
        self.costNum = globalPublicConf[1].fightCardCost[turnCnt+1] or 0
        for i=1,5 do
            local node = self.resourceNode_:getChildByName("node_"..i)
            local costNode = node:getChildByName("costNode")
            if self.slot[i] then
                costNode:setVisible(false)
            else
                costNode:setVisible(true)
                costNode:getChildByName("txt_cost"):setString(self.costNum)
            end
        end
    else
        node_free:setVisible(true)
        node_buy:setVisible(false)
        node_free:getChildByName("txt_num"):setString((freeCnt-turnCnt)..WordDictionary[10158])
    end
end

function TurnCardRewardWin:updateBox(i, isOpen)
    local node = self.resourceNode_:getChildByName("node_"..i)
    local buttonAnim = node:getChildByName("buttonAnim")
    if not buttonAnim then
        buttonAnim = UIAniButton.new("public/ui_tongyongfanpai_kaixiang",function(eventType,me)
            if eventType == "ended" then
                if not self.slot[i] and self.canClick then
                    if not self.costNum or (self.costNum <= self.myNum) then
                        network.tcpSend(msgids.C_FlopRewardsTake, {Slot = {i}})
                    else
                        MoveLabel.new(WordDictionary[25118])
                    end
                end
            end
        end)
        buttonAnim:setName("buttonAnim")
        node:addChild(buttonAnim)
        buttonAnim:setPosition(0, 50)
        local icon = Helper.createGoodsItem({scale = 0.8, id = self.data.Items[i].Id, num = self.data.Items[i].N})
        icon:setCascadeOpacityEnabled(true)
        buttonAnim:addChildFollowSlot("item_point", icon)
    end
    if self.slot[i] or isOpen then
        buttonAnim:playAnimation("idle1", 1)
        buttonAnim:getChildFollowSlot("item_point"):setVisible(true)
    else
        buttonAnim:playAnimation("idle3", 1)
        buttonAnim:getChildFollowSlot("item_point"):setVisible(false)
    end

    if isOpen then
        local costNode = self:createCsbNode("fight/lotteryCostItem.csb")
        costNode:setName("costNode")
        costNode:setVisible(false)
        costNode:setPositionY(10)
        node:addChild(costNode)
    end

end

function TurnCardRewardWin:getRandomNumber(index)
    local index = index or 1
    local num = math.random(1,5)
    if not self.numbers[num] then
        self.numbers[num] = index
        index = index + 1
    end
    if index <= 5 then
        self:getRandomNumber(index)
    end
end

function TurnCardRewardWin:getActionIn()
     Helper.enterWinAction1(self)
end

return TurnCardRewardWin