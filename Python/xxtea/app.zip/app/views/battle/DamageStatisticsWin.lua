--伤害统计

local Helper = require "app.Helper"
local c = require "app.configs.constants"
local AudioManager = require "sandglass.core.AudioManager"
local StatisticsController = require "app.battle.controllers.StatisticsController"

local roleConf = require "app.configs.role"
local heroConf = require "app.configs.hero"
local monsterConf = require "app.configs.monster"

local WinBase = require "sandglass.core.WinBase"
local DamageStatisticsWin = class("DamageStatisticsWin", WinBase)

DamageStatisticsWin.RESOURCE_FILENAME = "fight/damageStatistics.csb"

function DamageStatisticsWin:onCreate(params)
	self.priority = c.WIN_ZORDER.POPUP
	
	self.team = {}
    self.defenderTeam = {}
    self.maxHp = 0
    self:initData(params)

    self:setAutoClose(self.resourceNode_:getChildByName("bg"))
end

function DamageStatisticsWin:initData(params)
    local team = params.team
    local defenderTeam = params.defenderTeam
    local damage = nil
    if params.allDamageData then
        damage = params.allDamageData
    else
        damage = StatisticsController.damage
    end

    if team then
        for index,heroId in pairs(team) do
            if heroId ~= 0 then
                table.insert(self.team,{
                    index = index,
                    heroId = heroId,
                    damage = math.floor(damage[index] or 0),
                })
            end
        end
    end

    if defenderTeam then
        for index,heroId in pairs(defenderTeam) do
            if heroId ~= 0 then
                table.insert(self.defenderTeam,{
                    index = index,
                    heroId = heroId,
                    damage = math.floor(damage[index + 5] or 0),
                })
            end
        end
    end

    for k,v in pairs(StatisticsController.damage) do
        if v > self.maxHp then
            self.maxHp = math.floor(v)
        end
    end
end

function DamageStatisticsWin:initialView()
    AudioManager.playMusic("music/ui_openpaper.mp3",false)

    local node_1 = self.resourceNode_:getChildByName("node_1")
    local node_2 = self.resourceNode_:getChildByName("node_2")

    local haveDef = #self.defenderTeam > 0--双方
    node_1:setVisible(not haveDef)
    node_2:setVisible(haveDef)

    local path = ""
    if haveDef then
        path = "fight/jiemian_di.png"
        self:initTwo()
    else
        path = "fight/wofangshuchu_di.png"
        self:initOne()
    end
    self.resourceNode_:getChildByName("bg"):setTexture(path)
end

function DamageStatisticsWin:initOne()
    local node_1 = self.resourceNode_:getChildByName("node_1")
    
    for i,v in ipairs(self.team) do
        local node = self:initRole("Left", v)
        node_1:getChildByName("left_" .. i):addChild(node)
    end
end

function DamageStatisticsWin:initTwo()
    local node_2 = self.resourceNode_:getChildByName("node_2")

    for i,v in ipairs(self.team) do
        local node = self:initRole("Left", v)
        node_2:getChildByName("left_" .. i):addChild(node)
    end

    for i,v in ipairs(self.defenderTeam) do
        local node = self:initRole("Right", v)
        node_2:getChildByName("right_" .. i):addChild(node)
    end
end

function DamageStatisticsWin:initRole(direction, data)
    local node = cc.CSLoader:createNode("fight/damage" .. direction .. ".csb")

    local conf = heroConf[data.heroId] or monsterConf[data.heroId]
    local heroFrame = display.newSprite("#" .. c.HERO_RARE[string.upper(conf.rare ~= "" and conf.rare or "R")])
    heroFrame:setScale(0.5)
    local imgName = "icon/head/" .. roleConf[conf.role].head .. ".png"
    local headImg = Helper.createClipSprite(imgName, "#public/public_shade_01.png",1)
    display.align(headImg,display.CENTER, heroFrame:getContentSize().width * 0.5 , heroFrame:getContentSize().height * 0.5)
    heroFrame:addChild(headImg)
    node:getChildByName("node_head"):addChild(heroFrame)

    node:getChildByName("txt_name"):setString(conf.heroName or conf.name)
    node:getChildByName("txt_damage"):setString(data.damage)

    local percent = 100 * data.damage / self.maxHp
    local bar_damage = node:getChildByName("bar_damage")
    local tmpPercent = 0
    local speed = percent / 20
    bar_damage:setPercent(tmpPercent)
    bar_damage:actionScheduleInterval(function()
        tmpPercent = tmpPercent + speed
        if tmpPercent > percent then
            tmpPercent = percent
            bar_damage:stopAllActions()
        end
        bar_damage:setPercent(tmpPercent)
    end, 0.0166)

    return node
end

return DamageStatisticsWin