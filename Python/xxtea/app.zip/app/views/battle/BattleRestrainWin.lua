local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local forceConf = require "app.configs.force"
local battleConf = require "app.configs.battle"
local RichLabel = require "sandglass.ui.RichLabel"


local BattleRestrainWin = class("BattleRestrainWin", WinBase)

BattleRestrainWin.RESOURCE_FILENAME = "fight/restrain.csb"

local FORCE_TYPE = {
	[1] = WordDictionary[26005],
	[2] = WordDictionary[26006],
	[3] = WordDictionary[26007],
	[4] = WordDictionary[26008],
	[5] = WordDictionary[26035],
}

function BattleRestrainWin:onCreate(data)
	self.data = data
	self:setAutoClose(self.resourceNode_:getChildByName("bg"))
end

function BattleRestrainWin:initialView(data)
	cc.SpriteFrameCache:getInstance():addSpriteFrames("fight/fight.plist")
	-- UIImageBox.new(self.resourceNode_:getChildByName("btn_close"), function()
	-- 	self:closeSelf()
	-- end)
	local loc1 = 1
	-- local loc2 = 2
	local forces1 = {}
	-- local forces2 = {}
	for k,v in pairs(forceConf) do
		-- if v.res == FORCE_TYPE[1] or v.res == FORCE_TYPE[2] or v.res == FORCE_TYPE[3] then
			table.insert(forces1, v)
		-- else
		-- 	table.insert(forces2, v)
		-- end
    end
	local createDesList = function(list,count)
		local nodeView = self.resourceNode_:getChildByName("node_des"..count)
		for k, v in ipairs(list) do
			local tipsSprite = display.newSprite("#fight/tips.png")
			local des = RichLabel.new({
		        fontSize = 18,
		        maxWidth = 320,
		        fontColor = cc.c3b(239,218,191),
		    })
		    des:setString(string.format(v.num).."%")
		    des:setName("des"..k)
		    nodeView:addChild(des)
		    nodeView:addChild(tipsSprite)
		    --local width = (count % 2 == 0) and  - des._maxWidth or 10
		    local height = k * 25
		    tipsSprite:setPosition(23, 15 - height * 1.25)
		    print(height)
		    for i = 1,5 do
		    	if k == i then
			    	local position =  self.resourceNode_:getChildByName("txt_des"..i):getPositionX()
			    	local size = self.resourceNode_:getChildByName("txt_des"..i):getContentSize().width
			    	des:align(display.LEFT_TOP, position - size * 3.15, 27 - height * 1.25 )
			    	break
			    end
		    end
		end
	end
	createDesList(forces1,loc1)
	-- createDesList(forces2,loc2)
end

function BattleRestrainWin:getActionIn()
    local AudioManager = require "sandglass.core.AudioManager"
	self.resourceNode_:setPositionY(-display.height /2)
	self.resourceNode_:runAction(cc.EaseBackOut:create(cc.MoveTo:create(0.6, cc.p(0, 0))))
	AudioManager.playEffect("music/ui_popup05.mp3")
end

return BattleRestrainWin