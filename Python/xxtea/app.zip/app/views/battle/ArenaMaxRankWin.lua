-- 竞技场历史最高

local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local Helper = require "app.Helper"
local init = require "app.models.init"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"

local ArenaMaxRankWin = class("ArenaMaxRankWin", WinBase)
ArenaMaxRankWin.RESOURCE_FILENAME = "fight/maxRank.csb"

local PlayerModel = init.PlayerModel

function ArenaMaxRankWin:onCreate(params)
	self.priority = c.WIN_ZORDER.TOP
	self.params = params or {}
end

function ArenaMaxRankWin:initialView()
	local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
    self.resourceNode_:runAction(moveAction)
    moveAction:play("animation0", false)

	UIImageBox.new(self.resourceNode_:getChildByName("node_c"):getChildByName("Node_1"):getChildByName("btn"),function()
		self:closeSelf()
	end)
		
	local upRank = self.params.hisRankMax - self.params.myIdx
	local reward = self.params.hisMaxRwds.Ccy
	local rewardCnt = (reward and reward[1]) and reward[1].Val or 0
	local rewardId = (reward and reward[1]) and reward[1].Id or 0
	if rewardId ~= 0 then
		local path = Helper.getPathById(rewardId)
		self.resourceNode_:getChildByName("node_c"):getChildByName("Node_1"):getChildByName("costIcon"):loadTexture(path,ccui.TextureResType.localType)
	end

	local wordDic = {
		[1] = WordDictionary[20917],
		[2] = self.params.hisRankMax,
		[3] = string.format(WordDictionary[20918],self.params.myIdx),
		[4] = upRank,
		[5] = WordDictionary[20919],
		[6] = rewardCnt,
		[7] = WordDictionary[20104],
	}
	for i = 1,7 do
		local text_x = self.resourceNode_:getChildByName("node_c"):getChildByName("Node_1"):getChildByName("Text_" .. i)
		text_x:setString(wordDic[i])
	end

	local path = "public/ui_shengjibg"
	local anim2 = SpineManager.createAnimation(path)
    anim2:playAnimation("idle", -1)
    --anim2:setPosition(display.cx,display.cy)
	--self.resourceNode_:addChild(anim2,-1)
	self.resourceNode_:getChildByName("node_c"):addChild(anim2,-1)

	local path = "public/ui_shengjiyanhua"
    local anim = SpineManager.createAnimation(path)
    anim:playAnimation("idle", 1)
    anim:setPosition(display.cx,display.cy)
    self.resourceNode_:addChild(anim)

    anim:setScale(self.bgScale)
    anim2:setScale(self.bgScale)
end

return ArenaMaxRankWin