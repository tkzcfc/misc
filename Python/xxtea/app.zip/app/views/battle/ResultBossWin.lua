--ResultBossWin.lua

local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local guildMonsterConf = require "app.configs.guildMonster"
local StatisticsController = require "app.battle.controllers.StatisticsController"

local ResultBossWin = class("ResultBossWin", WinBase)
ResultBossWin.RESOURCE_FILENAME = "fight/resultBoss.csb"

local ArmorModel = init.ArmorModel
local RuneModel = init.RuneModel

function ResultBossWin:onCreate(params)
	self.priority = c.WIN_ZORDER.POPUP
	
	self.rewards = params.rewards or {}
	self.team = params.team
	self.defenderTeam = params.defenderTeam
	self.damage = params.damage
	self.params = params
	self.allDamageData = params.allDamageData or nil
end

function ResultBossWin:initialView()
	self.infoNode = self.resourceNode_:getChildByName("node")
 	UIImageBox.new(self.infoNode:getChildByName("btn"),function()
		self:getScene():getChildByName("ViewBase"):exitScene()
	end)
	
	local item = self.rewards.Items or {}
 	local ccy = self.rewards.Ccy or {}
 	local armors = self.rewards.Armors or {}
 	local runes = self.rewards.Runes or {}
 	local all = {}
 	for k,v in ipairs(ccy) do
 		table.insert(all,v)
 	end
 	for k,v in ipairs(item) do
 		table.insert(all,v)
 	end
 	for k,v in ipairs(armors) do
 		table.insert(all,ArmorModel:getArmor(v))
 	end
 	for k,v in ipairs(runes) do
		local id = RuneModel:getRune(v).id
		table.insert(all,{Id = id, Num = 1, seq = v})
	end

 	table.sort(all, function(a, b)
 		local a_color,b_color = nil, nil
 		if itemConf[a.Id or a.id] then
 			a_color = itemConf[a.Id or a.id].color
 		elseif currencyConf[a.Id or a.id] then
 			a_color = currencyConf[a.Id or a.id].color
 		else
 			a_color = 0
 		end
 		if itemConf[b.Id or b.id] then
 			b_color = itemConf[b.Id or b.id].color
 		elseif currencyConf[b.Id or b.id] then
 			b_color = currencyConf[b.Id or b.id].color
 		else
 			b_color = 0
 		end

		return a_color > b_color
	end)

 	if all then
 		local exp = nil
 		local spacing = 100
		local scrollView = self.infoNode:getChildByName("scrollView")
		scrollView:setScrollBarEnabled(false)
		local size = scrollView:getContentSize()
		local sumWidth = #all * spacing
		if sumWidth < size.width then
		    size.width = sumWidth
		end
		for k,v in ipairs(all) do
			local item = Helper.createGoodsItem({scale = 0.8, seq = v.seq, id = v.Id or v.id, num = v.Num or v.n or v.val or v.N or v.Val or v.num})
		    display.align(item,display.CENTER, (k-1)*spacing + spacing/2, size.height/2)
		    scrollView:addChild(item)
            if v.Id == c.CurrencyName.exp then
 				exp = v
 			end
		end
		scrollView:setContentSize(cc.size(size.width, size.height))
		scrollView:setInnerContainerSize(cc.size(sumWidth, size.height))

        if not exp then exp = {Num = 0} end
 	end

	UIImageBox.new(self.infoNode:getChildByName("btn_2"),function()
		self:openWin("DamageStatisticsWin",{team = self.team,defenderTeam = self.defenderTeam, allDamageData = self.allDamageData})
	end)


	-- if self.params.fightStatus and self.params.fightStatus == c.FightStatus.guildBoss then
	-- 	self.infoNode:getChildByName("Text_3"):setVisible(false)
	-- 	self.infoNode:getChildByName("Text_4"):setVisible(false)
	-- 	self.infoNode:getChildByName("Text_5"):setVisible(false)
	-- 	self.infoNode:getChildByName("Text_6"):setVisible(false)
	-- 	self.infoNode:getChildByName("Image_4"):setVisible(false)
	-- 	self.infoNode:getChildByName("loadingBar"):setPercent(0)
	-- 	self.infoNode:getChildByName("node_monster"):setVisible(true)
	-- 	local guildMonsterData = guildMonsterConf[self.params.stage]
	-- 	local barMyDamage = self.infoNode:getChildByName("node_monster"):getChildByName("bar_myDamage")
	-- 	local damageSize = barMyDamage:getContentSize()
	-- 	-- for k,v in ipairs(guildMonsterData.attackLevel) do
	-- 	-- 	local x = (v / guildMonsterData.attackLevelLimit) * damageSize.width
	-- 	-- 	barMyDamage:getChildByName("stage"..k):setPositionX(x)
	-- 	-- 	local txt = barMyDamage:getChildByName("stage"..k):getChildByName("txt_stage")
	-- 	-- 	if self.damage >= v then
	-- 	-- 		txt:setTextColor(c.ITEM_COLOR[k+1])
	-- 	-- 	else
	-- 	-- 		txt:setTextColor(cc.c3b(200,200,200))
	-- 	-- 	end
	-- 	-- end
	-- 	barMyDamage:getChildByName("txt_damage"):setString(math.ceil(self.damage))
	-- 	barMyDamage:setPercent(math.min(self.damage/self.params.monsterBlood, 1) * 100)
	if self.params.fightStatus and (self.params.fightStatus == c.FightStatus.kfbsLadder 
		or self.params.fightStatus == c.FightStatus.kfbsChampion 
		or self.params.fightStatus == c.FightStatus.plotBoss) then
        self.infoNode:getChildByName("Text_3"):setVisible(false)
		self.infoNode:getChildByName("Text_4"):setVisible(false)
		self.infoNode:getChildByName("Text_5"):setString(WordDictionary[72012])
		self.infoNode:getChildByName("Text_6"):setString(math.floor(self.damage))
		self.infoNode:getChildByName("loadingBar"):setPercent(100)
		if self.params.notShowDmg then
			self.infoNode:getChildByName("Text_5"):setVisible(false)
			self.infoNode:getChildByName("Text_6"):setVisible(false)
			self.infoNode:getChildByName("loadingBar"):setPercent(0)
			self.infoNode:getChildByName("Image_4"):setVisible(false)
		end
	else
		self.infoNode:getChildByName("node_monster"):setVisible(false)
 		local damage = self.damage
	 	local bfb = 0
	 	local perBfb = 0
	 	local maxLife = nil
	 	local hp = nil
	 	if self.params.fightStatus and (self.params.fightStatus == c.FightStatus.worldBoss or self.params.fightStatus == c.FightStatus.guildBoss or self.params.fightStatus == c.FightStatus.actTimeChallenge) then
	 		maxLife = self.params.bossMaxLife
	 		hp = self.params.bossCurHp - damage
	 		self.infoNode:getChildByName("Text_5"):setVisible(false)
	 		self.infoNode:getChildByName("Text_6"):setVisible(false)
	 		self.infoNode:getChildByName("loadingBar"):setVisible(false)
	 		self.infoNode:getChildByName("Image_4"):setVisible(false)
	 	else
		 	for i = 6,10 do
		 		if StatisticsController.maxLife[i] then
		 			maxLife = StatisticsController.maxLife[i]
		 			hp = StatisticsController.hp[i]
		 			break
		 		end
		 	end
		end
	 	local bfb = nil

	 	if hp < maxLife/2 then
	        bfb = math.ceil(hp / maxLife * 100)
	    else
	        bfb = math.floor(hp / maxLife * 100)
	    end
	    if bfb < 0 then bfb = 0 end
	 	perBfb = math.ceil((hp + damage) / maxLife * 100)

	 	local wordDic = {
			[3] = WordDictionary[10102],
			[4] = math.floor(damage),
			[5] = WordDictionary[10103],
			[6] = bfb .. "%",
		}
		for i = 3,6 do
			local text_x = self.infoNode:getChildByName("Text_" .. i)
			text_x:setString(wordDic[i])
		end

		self.infoNode:getChildByName("loadingBar"):setPercent(perBfb)
		if perBfb > 0 then
			Helper.createLoadingBarCursor(self.infoNode:getChildByName("loadingBar"),bfb)
		end

	end
end

return ResultBossWin