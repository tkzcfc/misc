local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local AudioManager = require "sandglass.core.AudioManager"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local TeamController = require "app.battle.controllers.TeamController"
local SpineManager = require "sandglass.core.SpineManager"

local KfbsResultWin = class("KfbsResultWin", WinBase)
KfbsResultWin.RESOURCE_FILENAME = "fight/kfbsResult.csb"

local PlayerModel = init.PlayerModel
local ArmorModel = init.ArmorModel
local RuneModel = init.RuneModel

function KfbsResultWin:onCreate(params)
    self.priority = c.WIN_ZORDER.POPUP
    
    self.rewards = params.rewards or {}
    self.team = params.team
    self.defenderTeam = params.defenderTeam
    self.isWin = params.isWin
end

function KfbsResultWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_close"),function()
        self:getScene():getChildByName("ViewBase"):exitScene(true)
    end)

    local func = function()
        local item = self.rewards.Items or {}
        local ccy = self.rewards.Ccy or {}
        local armors = self.rewards.Armors or {}
        local runes = self.rewards.Runes or {}
        local all = {}
        for k,v in ipairs(ccy) do
            table.insert(all,v)
        end
        for k,v in ipairs(item) do
            if itemConf[v.Id] or currencyConf[v.Id] then
                table.insert(all,v)
            end
        end
        for k,v in ipairs(armors) do
            table.insert(all,ArmorModel:getArmor(v))
        end
        for k,v in ipairs(runes) do
            local id = RuneModel:getRune(v).id
            table.insert(all,{Id = id, Num = 1, seq = v})
        end

        table.sort(all, function(a, b)
            local a_color,b_color = nil, nil
            if itemConf[a.Id or a.id] then
                a_color = itemConf[a.Id or a.id].color
            elseif currencyConf[a.Id or a.id] then
                a_color = currencyConf[a.Id or a.id].color
            else
                a_color = 0
            end
            if itemConf[b.Id or b.id] then
                b_color = itemConf[b.Id or b.id].color
            elseif currencyConf[b.Id or b.id] then
                b_color = currencyConf[b.Id or b.id].color
            else
                b_color = 0
            end
            if a_color == b_color then
                if (a.Id or a.id) == (b.Id or b.id) then
                    if a.additional and b.additional then
                        if a.additional == b.additional then
                            return a.Val > b.Val
                        else
                            return a.additional > b.additional
                        end
                    else
                        return b.additional
                    end
                else
                    return (a.Id or a.id) < (b.Id or b.id)
                end
            else
                return a_color > b_color
            end
        end)
        local scrollView = self.resourceNode_:getChildByName("Node_2"):getChildByName("scrollView")
        scrollView:removeAllChildren()
        scrollView:setScrollBarEnabled(false)
        local size = scrollView:getContentSize()

        local spacing = 76
        local row = 6
        local sumWidth = #all * spacing
        if sumWidth < size.width then
            size.width = sumWidth
        end
        scrollView:setContentSize(cc.size(size.width, size.height))
        scrollView:setInnerContainerSize(cc.size(sumWidth, size.height))

        local k = 1
        self.resourceNode_:actionScheduleInterval(function()
            if k > #all then
                self.resourceNode_:stopActionByTag(0XABC)
                return
            end
            local v = all[k]
            local item = Helper.createGoodsItem({scale = 0.8, seq = v.seq,id = v.Id or v.id,num = v.Num or v.Val,additional = v.additional,cardType = v.cardType})
            display.align(item,display.BOTTOM_LEFT, (k-1)*spacing, 0)
            scrollView:addChild(item)
            item:setVisible(false)

            AudioManager.playEffect("music/ui_wupintubiaochu.mp3")
            local path = "public/ui_wupintubiaochu"
            local anim = SpineManager.createAnimation(path)
            anim:playAnimation("idle", 1)
            anim:setPosition(item:getContentSize().width/2, item:getContentSize().height/2)
            item:addChild(anim)

            anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
                if eventName == "trigger" then
                    item:setVisible(true)
                end
            end)

            k = k + 1
        end, 0.2, 0XABC)

        local btn_damage = UIImageBox.new(self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_damage"),function()
            self:openWin("DamageStatisticsWin",{team = self.team,defenderTeam = self.defenderTeam})
        end)
        if not self.team then
            btn_damage:setEnabled(false)
        end
    end


    local imgPath = ""
    local anim = SpineManager.createAnimation("public/ui_jiesuan")
    if self.isWin then
        anim:playAnimation("idle1", 1)
        imgPath = "fight/public_font_14.png"
    else
        imgPath = "fight/public_font_15.png"
        anim:playAnimation("idle2", 1)
    end
    anim:addChildFollowSlot("item_point", display.newSprite(imgPath))
    self.resourceNode_:getChildByName("Node_1"):addChild(anim)
    anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "complete" then
            local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
            self.resourceNode_:runAction(moveAction)
            moveAction:play("animation0", false)
            moveAction:setAnimationEndCallFunc("animation0",function()
                moveAction:clearFrameEndCallFuncs()
                moveAction:play("animation1", false)
                self.resourceNode_:getChildByName("Node_2"):setVisible(true)
                func()
            end)
        end
    end)
end


return KfbsResultWin