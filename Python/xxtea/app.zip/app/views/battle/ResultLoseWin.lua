--ResultLoseWin.lua

local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local levelUpConf = require "app.configs.levelUp"
local c = require "app.configs.constants"
local ShaderManager = require "sandglass.core.ShaderManager"
local AudioManager = require "sandglass.core.AudioManager"
local openConf = require "app.configs.open"
local itemConf = require "app.configs.item"
local currencyConf = require "app.configs.currency"
local CoreColor = require "sandglass.core.CoreColor"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local GuideManager = require "app.views.guide.GuideManager"
local globalPublicConf = require "app.configs.globalPublic"

local Helper = require "app.Helper"
local GotoManager = require "app.GotoManager"
local SpineManager = require "sandglass.core.SpineManager"

local ResultLoseWin = class("ResultLoseWin", WinBase)

ResultLoseWin.RESOURCE_FILENAME = "fight/resultLose.csb"

local PlayerModel = init.PlayerModel
local ArmorModel = init.ArmorModel

function ResultLoseWin:onCreate(params)
    self.priority = c.WIN_ZORDER.POPUP

    self.showRewards = params.showRewards or false
    self.rewards = params.rewards or {}

    self.levelId = params.levelId
    self.team = params.team
    self.defenderTeam = params.defenderTeam

    self.fightStatus = params.fightStatus 
    self.afterLoading = params.afterLoading 

    self.allDamageData = params.allDamageData
    self.callBack = params.callBack
end

function ResultLoseWin:closeSelf()
    if self.callBack then
        self:callBack()
        ResultLoseWin.super.closeSelf(self)
    else
        self:getScene():getChildByName("ViewBase"):exitScene(false)
    end
end

function ResultLoseWin:initialView()
    self:checkGuide()
    local func = function()
        local Node_2 = self.resourceNode_:getChildByName("Node_2")
        Node_2:getChildByName("Node_1"):getChildByName("btn_2"):getChildByName("txt_btn"):setString(WordDictionary[10100])
        Node_2:getChildByName("Text_3"):setString(PlayerModel.info.level)
        Node_2:getChildByName("Text_4"):setString(WordDictionary[10101])
        Node_2:getChildByName("Text_5"):setString("+ 0")
        Node_2:getChildByName("Text_6"):setString("+ 0")
        self.resourceNode_:getChildByName("Text_1"):setString(WordDictionary[20088])

        if self.showRewards then
            self:createRewards()
            local Text_4 = Node_2:getChildByName("Text_4")
            Text_4:setString(WordDictionary[10108])
            Text_4:setTextColor(CoreColor.GREY)
        end

        local levelUp = levelUpConf[PlayerModel.info.level]
        local exp = PlayerModel.info.exp
        local percent = 0
        if levelUp.playerExp == 0 then
            percent = 100
        else
            percent = exp / levelUp.playerExp * 100
        end
        Node_2:getChildByName("panel"):getChildByName("loadingBar"):setPercent(percent)
        Helper.createLoadingBarCursor(Node_2:getChildByName("panel"):getChildByName("loadingBar"))


        local shader = ShaderManager.loadShader(ShaderManager.SHADER_GRAY)
        Node_2:getChildByName("Image_back"):setGLProgram(shader)
        Node_2:getChildByName("Image_back_0"):setGLProgram(shader)
        Node_2:getChildByName("Image_1"):setGLProgram(shader)
        Node_2:getChildByName("Image_2"):setGLProgram(shader)

        if not self.team or not self.defenderTeam then
            Node_2:getChildByName("Node_1"):setVisible(false)
        end
    end

    local path = "public/ui_jiesuan"
    local anim = SpineManager.createAnimation(path)
    anim:playAnimation("idle2", 1)
    anim:addChildFollowSlot("item_point", display.newSprite("fight/public_font_15.png"))
    self.resourceNode_:getChildByName("Node_1"):addChild(anim)
    anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "complete" then
            local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
            self.resourceNode_:runAction(moveAction)
            moveAction:play("animation0", false)
            moveAction:setAnimationEndCallFunc("animation0",function()
                moveAction:clearFrameEndCallFuncs()
                moveAction:play("animation1", false)
                self.resourceNode_:getChildByName("Node_2"):setVisible(true)
                func()
            end)
        end
    end)

    local btn_1 = self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_1")
    local btn_2 = self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_2")
    local btn_3 = self.resourceNode_:getChildByName("Node_2"):getChildByName("btn_3")
    btn_1:setVisible(not self.showRewards)
    self.heroListBtn = btn_1
    btn_2:setVisible(not self.showRewards)
    btn_3:setVisible(not self.showRewards)
    self.resourceNode_:getChildByName("Node_2"):getChildByName("scrollView"):setVisible(self.showRewards)

    local lv = PlayerModel.info.level
    if lv < openConf[6].p2 and lv >= openConf[10].p2 then
        display.align(btn_1,display.CENTER,448,178)
        display.align(btn_3,display.CENTER,688,178)
        btn_2:setVisible(false)
    elseif lv < openConf[10].p2 then
        display.align(btn_1,display.CENTER,570,178)
        btn_2:setVisible(false)
        btn_3:setVisible(false)
    else
        display.align(btn_1,display.CENTER,351,178)
        display.align(btn_2,display.CENTER,570,178)
        display.align(btn_3,display.CENTER,790,178)
    end

    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(3.3),
        cc.CallFunc:create(function()
            local listener = cc.EventListenerTouchOneByOne:create()
            listener:setSwallowTouches(true)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
            listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_MOVED)
            listener:registerScriptHandler(handler(self, function()
                listener:setEnabled(false)
                self:closeSelf()
            end), cc.Handler.EVENT_TOUCH_ENDED)
                    
            local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
            eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.resourceNode_)
            
            if self.team and self.defenderTeam then
                UIImageBox.new(self.resourceNode_:getChildByName("Node_2"):getChildByName("Node_1"):getChildByName("btn_2"),function()
                    self:openWin("DamageStatisticsWin",{team = self.team, defenderTeam = self.defenderTeam, allDamageData = self.allDamageData})
                end,{swallowTouches = true})
            else
                self.resourceNode_:getChildByName("Node_2"):getChildByName("Node_1"):setVisible(false)
            end

            local data = {levelId = self.levelId}
            data.fromScene = c.AfterLoading.gameScene
            data.afterLoading = (self.afterLoading and self.afterLoading == c.AfterLoading.outsideScene) and c.AfterLoading.outsideScene or c.AfterLoading.mainScene
            data.result = true

            UIImageBox.new(btn_1,function()
                data.win = "HeroListWin"
                GotoManager:goto(data)
                ResultLoseWin.super.closeSelf(self)
            end,{swallowTouches = true})

            UIImageBox.new(btn_2,function()
                data.win = "EquipWin"
                GotoManager:goto(data)
                ResultLoseWin.super.closeSelf(self)
            end,{swallowTouches = true})

            UIImageBox.new(btn_3,function()
                if Helper.getOpenState(10) then
                    if Helper.checkDivide(6) then
                        data.win = "KamiWin"
                        GotoManager:goto(data)
                        ResultLoseWin.super.closeSelf(self)
                    end
                end
            end,{swallowTouches = true})
        end)
    ))
end

function ResultLoseWin:createRewards()
    local item = self.rewards.Items or {}
     local ccy = self.rewards.Ccy or {}
     local armors = self.rewards.Armors or {}
     local all = {}
     for k,v in ipairs(ccy) do
         if v.Id == 10300 or v.Id == 10100 then
             
         else
             table.insert(all,v)
         end
     end
     for k,v in ipairs(item) do
         if itemConf[v.Id] or currencyConf[v.Id] then
             table.insert(all,v)
         end
     end
     for k,v in ipairs(armors) do
         table.insert(all,ArmorModel:getArmor(v))
     end

     local perX = 86
    local perY = 111
    local num = #all
    local lastX = num * perX
    local scrollView = self.resourceNode_:getChildByName("Node_2"):getChildByName("scrollView")
    scrollView:removeAllChildren()
    scrollView:setScrollBarEnabled(false)
    -- local svSize = scrollView:getInnerContainer()
    scrollView:setInnerContainerSize(cc.size(0,0))

    local conSize = scrollView:getInnerContainerSize()
    if lastX > conSize.width then
        scrollView:setInnerContainerSize(cc.size(lastX,0))
        conSize = scrollView:getInnerContainerSize()
    end
    scrollView:scrollToTop(0.2,true)
    local delay = 0.2

    if #all < 5 then
        local scX = 0
        if #all % 2 == 0 then
            scX = display.width / 2 - math.ceil(#all / 2) * perX
        else
            scX = display.width / 2 - (math.ceil(#all / 2) - 1) * perX - perX / 2
        end
         scrollView:setPositionX(scX)
     end


    local k = 1
    self.resourceNode_:actionScheduleInterval(function()
        if k > #all then
            self.resourceNode_:stopActionByTag(0XABC)
            return
        end
        local v = all[k]
        local item = Helper.createGoodsItem({scale = 0.8,id = v.Id or v.id,num = v.Num or v.Val})
        local itemX = item:getContentSize().width

        local x = (k - 1) * 86
        local y = conSize.height - perY + 12
        display.align(item,display.BOTTOM_LEFT, x, y)
        scrollView:addChild(item)
        item:setVisible(false)

        AudioManager.playEffect("music/ui_wupintubiaochu.mp3")
        local path = "public/ui_wupintubiaochu"
        local anim = SpineManager.createAnimation(path)
        anim:playAnimation("idle", 1)
        anim:setPosition(x + 38,y + 38)
        anim:setScale(0.8)
        scrollView:addChild(anim)

        anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
            if eventName == "trigger" then
                item:setVisible(true)
            end
        end)

        k = k + 1
    end, delay, 0XABC)
end

function ResultLoseWin:checkGuide()
    --首次死亡引导
    local guideWin = display.getRunningScene().winManager:findWinByName("GuideWin")
    if not guideWin and (PlayerModel.info.level <= globalPublicConf[1].deathLevel) then 
        if not PlayerConfig.getSetting(PlayerModel.info.userId .. "firstDeadGuide", false) then
            GuideManager.newbieStep = 11001
            GuideManager.startGuide(display.getRunningScene():getChildByName("ViewBase"))
        end
    end
end

return ResultLoseWin