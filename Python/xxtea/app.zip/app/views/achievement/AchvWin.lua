-- 成就
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local init = require "app.models.init"
local c = require "app.configs.constants"
local SpineManager = require "sandglass.core.SpineManager"
local achvConf = require "app.configs.achv"
local achvObjConf = require "app.configs.achvObj"
local MoveLabel = require "sandglass.ui.MoveLabel"
local CoreColor = require "sandglass.core.CoreColor"

local AchvWin = class("AchvWin", WinBase)
AchvWin.RESOURCE_FILENAME = "achievement/achv.csb"

local PlayerModel = init.PlayerModel
local MainLineModel = init.MainLineModel
local RedTipsModel = init.RedTipsModel

local ACHV_TYPE = {
    [1] = {type = 1, name = WordDictionary[20524]},
    [2] = {type = 2, name = WordDictionary[20525]},
    [3] = {type = 3, name = WordDictionary[20526]},
 }


function AchvWin:onCreate()
    -- self.showType = self.WinShowType.hiddenBack
    self.shieldLayer_:setVisible(false)
    
    self.curPage = nil
    local msgList = {
        msgids.GS_AchvTakeReward_R,
        msgids.GS_BuyGold_R,
        msgids.GS_BuyStrength_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function AchvWin:receive(op, data)
    if op == msgids.GS_AchvTakeReward_R then
        Helper.receiveReward({rewards = data.Rewards})
        self:checkRedTips()
        self:createTaskList()
    elseif op == msgids.GS_BuyGold_R or op == msgids.GS_BuyStrength_R then
        self:checkRedTips()
        self:createTaskList()
    end
end

function AchvWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
        self:closeSelf()
    end)
    self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(WordDictionary[20523])
    self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"):hide()

    local anim = SpineManager.createAnimation("public/ui_cha_zuiniang",1)
    anim:setFlipX(true)
    local node_spine = self.resourceNode_:getChildByName("node_spine")
    node_spine:addChild(anim)
    anim:playAnimation("idle", -1)
    
    self.btns = {}
    for i,v in ipairs(ACHV_TYPE) do
        local btnImg = self.resourceNode_:getChildByName("node_cr"):getChildByName("btn_"..i)
        btnImg:getChildByName("txt_name"):setString(v.name)
        local btn = UIImageBox.new(btnImg, function()
            if i ~= self.curPage then
                self.curPage = i
                self:createTaskList()
            end
        end)
        self.btns[i] = btn
    end

    self:checkRedTips(true)
end


function AchvWin:checkRedTips(isInit)
    local allAchvs = MainLineModel:getAllTypeAchvs()
    local notInit = true
    local btns = clone(self.btns)
    local btnData = {}
    for k,btn in pairs(btns) do
        table.insert(btnData,{btn = btn, index = k})
    end
    table.sort(btnData, function(a, b)
        return a.index < b.index
    end)
    for i,v in ipairs(btnData) do
        local hasRed = false
        local achvs = allAchvs[v.index] or {}
        for _,k in pairs(achvs) do
            if k.status == c.ACHV_STATUS.canGet then
                hasRed = true
                break
            end
        end
        if hasRed then
            RedTipsModel:addRedTip(v.btn, cc.p(145, 90))
        else
            RedTipsModel:removeRedTip(v.btn)
        end
        if hasRed and isInit and notInit then
            notInit = false
            v.btn:onClick()
        end
    end
    if isInit and notInit and (table.nums(btnData) > 0) then
        btnData[1].btn:onClick()
    end
end


function AchvWin:createTaskList()
    for i,btn in pairs(self.btns) do
        if i == self.curPage then
            btn:loadTexture("achievement/chengjiu-yeka2.png", ccui.TextureResType.plistType)
        else
            btn:loadTexture("achievement/chengjiu-yeka1.png", ccui.TextureResType.plistType)
        end
    end

    local listView = self.resourceNode_:getChildByName("node_cr"):getChildByName("listView")
    local allAchvs = MainLineModel:getAllTypeAchvs()
    local listData = allAchvs[self.curPage] 
    if not listData or (table.nums(listData) == 0) then
        self.resourceNode_:getChildByName("node_cr"):getChildByName("node_nil"):setVisible(true)
        return
    else
        self.resourceNode_:getChildByName("node_cr"):getChildByName("node_nil"):setVisible(false)
    end

    listView:updateGridView(1, listData,function(cacheView,index,data)
        if cacheView == nil then
            cacheView = self:createTaskItem(data, index)
        end
        cacheView:updateView(data)
        return cacheView
    end)
    
end

function AchvWin:createTaskItem(data,index)
    local node = self:createCsbNode("achievement/achvItem.csb")
    local layer = ccui.Layout:create()
    layer.updateView = function(layer,data)
        local itemView = layer:getChildByName("itemView")
        local mask = itemView:getChildByName("img_mask")
        local node_reward = itemView:getChildByName("node_item")
        Helper.buttonRemoveEffect(itemView:getChildByName("btn_get"))
        node_reward:removeAllChildren()
        local tData = achvObjConf[data.achvId] or {}

        local rewards = data.ap or {}
        local spacing = 75
        for i, v in ipairs(rewards) do
            local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.7})
            display.align(item, display.CENTER, (i-1)*spacing, 0)
            node_reward:addChild(item)
        end
        itemView:getChildByName("txt_des"):setString(tData.des)
        
        local canClick = true
        local btn = UIImageBox.new(itemView:getChildByName("btn_get"),function()
            if data.status == c.ACHV_STATUS.canGet then
                if canClick then
                    canClick = false
                    network.tcpSend(msgids.C_AchvTakeReward, {AId = data.achvId})
                end
            elseif data.status == c.ACHV_STATUS.working then
                MoveLabel.new(WordDictionary[20527])
            end
        end, {ableGLProgram = false})

        mask:setVisible(false)
        Helper.greyFunc(btn, true)
        local btnStr = WordDictionary[20501]
        local valStr = ""
        local color = CoreColor.RED
        if data.status == c.ACHV_STATUS.noOpen then
            btnStr = WordDictionary[20503]
            Helper.greyFunc(btn)
            valStr = "0/"..tData.p2
            Helper.buttonRemoveEffect(itemView:getChildByName("btn_get"))
        elseif data.status == c.ACHV_STATUS.finished then
            mask:setVisible(true)
            valStr = tData.p2.."/"..tData.p2
            Helper.greyFunc(btn)
            btnStr = WordDictionary[20504]
            color = CoreColor.GREEN
            Helper.buttonRemoveEffect(itemView:getChildByName("btn_get"))
        elseif data.status == c.ACHV_STATUS.canGet then
            valStr = tData.p2.."/"..tData.p2
            color = CoreColor.GREEN
            Helper.buttonAddEffect(itemView:getChildByName("btn_get"),"public/ui_tongyonganniugaoliang")
        elseif data.status == c.ACHV_STATUS.working then
            btnStr = WordDictionary[20528]
            valStr = data.val.."/"..tData.p2
            Helper.greyFunc(btn)
            Helper.buttonRemoveEffect(itemView:getChildByName("btn_get"))
        end
        btn:getChildByName("txt_btn"):setString(btnStr)
        itemView:getChildByName("txt_num"):setString("("..valStr..")")
        itemView:getChildByName("txt_num"):setTextColor(color)
        
    end

    local size = node:getChildByName("img_bg"):getContentSize()
    layer:setContentSize(cc.size(size.width, size.height+5))
    layer:setAnchorPoint(cc.p(0.5,0))
    layer:addChild(node)
    node:setName("itemView")
    return layer

end

function AchvWin:getActionIn()
    Helper.enterWinAction2(self)
end

function AchvWin:getActionOut(callback)
   Helper.outWinAction(self, callback)
   return true
end


return AchvWin