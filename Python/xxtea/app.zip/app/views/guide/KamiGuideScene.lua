local c = require "app.configs.constants"
local BattleController = require "app.battle.controllers.BattleController"
local GameScene = require "app.battle.views.GameScene"
local WordDictionary = require "app.configs.WordDictionary"
local UILabel = require "sandglass.ui.UILabel"
local SpineManager = require "sandglass.core.SpineManager"
local TeamController = require "app.battle.controllers.TeamController"
local spineConf = require "app.configs.spine"
local AudioManager = require "sandglass.core.AudioManager"
local battleConf = require "app.configs.battle"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local roleConf = require "app.configs.role"
local UIAniButton = require "sandglass.ui.UIAniButton"

local fightZOrder = {
    bg = -1,
    pos_height = display.height, --英雄最高站位
    bullet = 10000, --子弹层级
    black_layer = 20000, --黑屏层级
    anim_powermax = 20001, --英雄释放大招定屏层级
    powermax_effect = 20002, --英雄释放大招水墨画层级
    kami = 20003, -- 幻化神
    god = 20004, -- 御神
}

local KamiGuideScene = class("KamiGuideScene", GameScene)

KamiGuideScene.RESOURCE_FILENAME = "fight/fight.csb"

local steps = {
    {func = "speak", params={c.UnitGroup.DEFENDER, 1, WordDictionary[1030], 2}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 3, WordDictionary[1031], 3}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 1, WordDictionary[1032], 2}},
    {func = "useKamiSkill", params = {}},
    {func = "result", params = {}},
}

function KamiGuideScene:onCreate(data)
    self.data = data
    self.data.fightStatus = c.FightStatus.specialLevel
    self.steps = clone(steps)
    KamiGuideScene.super.onCreate(self, data)
    BattleController.autoFight[c.UnitGroup.ATTACKER] = true
    self.speed = 2
    self.data.bg = battleConf[data.levelId].background
    self.data.bgMusic = battleConf[data.levelId].battleMusic
    self.bg:setTexture("battleBackground/"..self.data.bg..".png")
    AudioManager.playMusic("music/" .. self.data.bgMusic[1])
    -- 幻化神
    self.resourceNode_:getChildByName("kamiNode"):getChildByName("sp_icon"):runAction(cc.RepeatForever:create(cc.RotateBy:create(1, -60)))
    local kami = BattleController.kamis[c.UnitGroup.ATTACKER]
    kami.attr.attack = self.data.kamiAttack
    local path = kami and "spine/actors/" .. roleConf[kami.role].spine or "spine/actors/kamione1"
    local button = UIAniButton.new(path,function(eventType,me,point)
    end)
    button:setScale(1.3)
    button:setPosition(113, 0)
    button:setGray()
    self.kamiButton = button
    self.resourceNode_:getChildByName("kamiNode"):addChild(button, -1)

    self.resourceNode_:getChildByName("kamiNode"):setVisible(true)
    self.resourceNode_:getChildByName("node_lt"):setVisible(false)
    self.resourceNode_:getChildByName("node_rb"):setVisible(false)
    self.resourceNode_:getChildByName("node_rt"):setVisible(false)
end

function KamiGuideScene:updateKamiEnergy()
    if self.topNode then
       self.topNode:setVisible(false) 
    end
end
function KamiGuideScene:updateRound(round, maxRound)
    if round >= self.data.round then
        BattleController.manualLogic = true
        self.resourceNode_:getChildByName("node_cb"):setVisible(false)
        self:delayNextStep(1)
    end
end

function KamiGuideScene:chackStep()
    local info = self.steps[1]
    if not info then
        return
    end
    self[info.func](self, unpack(checktable(info.params)))
    table.remove(self.steps,1)
end

function KamiGuideScene:delayNextStep(delayTime)
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(delayTime),
        cc.CallFunc:create(function()
            self:chackStep()
        end)
    ))
end

function KamiGuideScene:chackStep()
    local info = self.steps[1]
    if not info then
        return
    end
    self[info.func](self, unpack(checktable(info.params)))
    table.remove(self.steps,1)
end

function KamiGuideScene:speak(group, order, str, delayTime)
    local keepTime = 2

    local target = nil
    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order then
            target = unit
            break
        end
    end

    if not target then
        return
    end

    local anim = self.anims[target.uid]

    local textLabel = UILabel.new({
        text = str,
        size = 16,
    })
    textLabel:setAnchorPoint(cc.p(0, 1))
    local size = textLabel:getContentSize()
    if size.width > 200 then
        textLabel:setTextAreaSize(cc.size(200, 0))
        textLabel:setString(str)
        size = textLabel:getContentSize()
    end 
    local bgSize = cc.size(size.width + 36, size.height + 10)
    local spBg = display.newSprite("common/qipao_3gongge.png", 0, 0, {scale9 = true, size = bgSize})
    textLabel:setString("")
    textLabel.str = str

    local pos = anim:getBonePosition("hp_point")
    spBg:setName("speakNode_"..order)  

    spBg:runAction(cc.Sequence:create(
        cc.ScaleTo:create(0.15,1.2),
        cc.ScaleTo:create(0.15, 1)
    ))

    if group == c.UnitGroup.ATTACKER then
        spBg:setPosition(cc.p(pos.x + bgSize.width/2, pos.y))
        textLabel:setPosition(cc.p(pos.x + 28, pos.y + size.height/2))
    else
        spBg:setFlippedX(true)
        spBg:setPosition(cc.p(pos.x - bgSize.width/2, pos.y))
        textLabel:setPosition(cc.p(pos.x - bgSize.width + 10, pos.y + size.height/2))
    end

    self.resourceNode_:getChildByName("heroNode"):addChild(spBg, anim:getLocalZOrder())
    self.resourceNode_:getChildByName("heroNode"):addChild(textLabel, anim:getLocalZOrder())

    local length = 1
    textLabel:actionScheduleInterval(function()
        if length <= string.len(textLabel.str) then
            local str = string.utf8sub(textLabel.str, 1, length)
            textLabel:setString("")
            textLabel:setString(str)
            length = length + 1
        end
    end, 0.05)

    spBg:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.RemoveSelf:create()))
    textLabel:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.RemoveSelf:create()))
    self:delayNextStep(delayTime)
end

function KamiGuideScene:useKamiSkill()
    local progress = self.resourceNode_:getChildByName("kamiNode"):getChildByName("loadingBar")
    progress:setPercent(100)
    self.kamiButton:setNormal()
    BattleController.updateKamiEnergy(c.UnitGroup.ATTACKER, 99999)
    BattleController.kamiSkill(c.UnitGroup.ATTACKER)
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(0.5),
        cc.CallFunc:create(function()
            progress:setPercent(0)
            self.kamiButton:setGray()
        end)
    ))
end

function KamiGuideScene:updateBlackLayer()
    self.blackLayer:setVisible(BattleController.isFreezing())
    self:delayNextStep(6)
end

function KamiGuideScene:result()
    local team = {20012}
    local data = {
        LevelId = self.data.levelId,
        Team = team,
        Result = c.GameState.ATTACK_WIN,
    }
    network.tcpSend(msgids.C_WLevelFightNormal, data)
    local openResultWin = function(self, op, data)
        BattleController.pause()
        self:openWin("ResultVictoryWin",{rewards = data.Rewards, fightStatus = c.FightStatus.ordinary})
        AudioManager.stopMusic()
    end
    network.addListener(self, {msgids.GS_WLevelFightNormal_R}, handler(self, openResultWin))
end

return KamiGuideScene