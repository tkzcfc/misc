
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local SpineManager = require "sandglass.core.SpineManager"

local NinjaHeartOpenWin = class("NinjaHeartOpenWin", WinBase)
NinjaHeartOpenWin.RESOURCE_FILENAME = "guide/ninjaHeart.csb"

function NinjaHeartOpenWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP
end

function NinjaHeartOpenWin:initialView()
    local node = self.resourceNode_:getChildByName("node")

    local effect = SpineManager.createAnimation("guide/xinshou_kaiqigongnengbeiguang", 1)
    effect:playAnimation("idle2", -1)
    node:addChild(effect, -1)
    node:setScale(0)

    node:runAction(cc.EaseBackOut:create(cc.ScaleTo:create(0.5, 1.0)))

end


return NinjaHeartOpenWin