local c = require "app.configs.constants"

local UIImageBox = require "sandglass.ui.UIImageBox"
local BuffController = require "app.battle.controllers.BuffController"
local BattleController = require "app.battle.controllers.BattleController"
local GameScene = require "app.battle.views.GameScene"
local WordDictionary = require "app.configs.WordDictionary"
local random = require "app.battle.Random"
local UILabel = require "sandglass.ui.UILabel"
local CoreColor = require "sandglass.core.CoreColor"
local SpineManager = require "sandglass.core.SpineManager"
local UIAniButton = require "sandglass.ui.UIAniButton"
local TeamController = require "app.battle.controllers.TeamController"
local roleConf = require "app.configs.role"
local spineConf = require "app.configs.spine"
local UnitCard = require "app.battle.views.UnitCard"
local AudioManager = require "sandglass.core.AudioManager"
local VideoLayer = require "app.views.scene.VideoLayer"
local RichLabel = require "sandglass.ui.RichLabel"
local PlayerConfig = require "sandglass.core.PlayerConfig"

local fightZOrder = {
    bg = -1,
    pos_height = display.height, --英雄最高站位
    bullet = 10000, --子弹层级
    black_layer = 20000, --黑屏层级
    anim_powermax = 20001, --英雄释放大招定屏层级
    powermax_effect = 20002, --英雄释放大招水墨画层级
    kami = 20003, -- 幻化神
    god = 20004, -- 御神
}

local FirstFightScene = class("FirstFightScene", GameScene)

FirstFightScene.RESOURCE_FILENAME = "fight/fight.csb"

local steps = {
    {func = "startEffect", params = {1.4}},
    {func = "showDefender", params = {0.1}},
    {func = "moveCamera", params = {cc.p(display.cx * 0.3, 0), 1.3, 0.1}},
    {func = "showAttackerHero", params = {1, 0.2}},
    {func = "moveCamera", params = {cc.p(display.cx * 0.35, -60), 1.4, 0.1}},
    {func = "showAttackerHero", params = {2, 0.2}},
    {func = "moveCamera", params = {cc.p(display.cx * 0.5, 0), 1.5, 0.1}},
    {func = "showAttackerHero", params = {3, 0.2}},
    {func = "moveCamera", params = {cc.p(display.cx * 0.6, -50), 1.6, 0.1}},
    {func = "showAttackerHero", params = {4, 0.2}},
    {func = "moveCamera", params = {cc.p(display.cx * 0.65, -110), 1.7, 0.1}},
    {func = "showAttackerHero", params = {5, 0.2}},
    {func = "moveCamera", params = {cc.p(0, 0), 1, 0.2, 1}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 5, WordDictionary[1007], 0.8}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 2, WordDictionary[1008], 0.8}},
    {func = "useSkill", params = {c.UnitGroup.ATTACKER, 5, 11515, 2}},
    {func = "useSkill", params = {c.UnitGroup.ATTACKER, 2, 12214, 5}},
    {func = "updateTurn", params = {2, 2, 2}},
    {func = "showNinsover", params = {1}},
    {func = "showOtherDefender", params={1}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 4, WordDictionary[1010], 1}},
    {func = "showKazeEffect", params={}},
    {func = "useSkill", params = {c.UnitGroup.ATTACKER, 1, 11115, 5}},
    {func = "useSkill", params = {c.UnitGroup.ATTACKER, 4, 11215, 5}},
    {func = "useSkill", params = {c.UnitGroup.ATTACKER, 3, 11915, 6}},
    {func = "speak", params={c.UnitGroup.DEFENDER, 1, WordDictionary[1009], 1.5}},
    {func = "ninsoverTrans", params = {}},
    {func = "useSkill", params = {c.UnitGroup.DEFENDER, 1, 14115, 4.2}},
    -- {func = "playVideo", params = {"video/guideBattleEnd.mp4"}},
    {func = "showLogo", params={}},
}

function FirstFightScene:onCreate(data)
    self.steps = clone(steps)
    self.data = data
    BattleController.manualLogic = true
    FirstFightScene.super.onCreate(self, data)
    self.speed = 2
    self.blinkTime = 0
    self.bg:setTexture("battleBackground/background_11_3.png")
    self:HideUILayer(false)

    local effect = SpineManager.createAnimation("common/ui_pingmuhuaban", 1)
    effect:playAnimation("idle", -1)
    effect:setPosition(display.cx, display.cy)
    self.resourceNode_:getChildByName("heroNode"):addChild(effect, fightZOrder.bullet-1)

    PlayerConfig.setSetting("firstFight",true)
end

function FirstFightScene:showWithScene()
    FirstFightScene.super.showWithScene(self)

    local btn_skip = UIImageBox.new("login/juqingtiaoguozhandou.png", function()
        self:showLogo()
    end)
    btn_skip:setPosition(display.width - 100, display.height - 40)
    self:getScene():addChild(btn_skip)
end


function FirstFightScene:chackStep()
    -- self:cleanRes()
    local info = self.steps[1]
    if not info then
        return
    end
    self[info.func](self, unpack(checktable(info.params)))
    table.remove(self.steps,1)
end

function FirstFightScene:cleanRes()
    display.removeUnusedSpriteFrames()
    SpineManager.clean()
end

function FirstFightScene:delayNextStep(delayTime)
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(delayTime),
        cc.CallFunc:create(function()
            self:chackStep()
        end)
    ))
end

function FirstFightScene:startGame()
    self:onUpdate(function(dt)
        if self.freezeCnt > 0 then
            self.freezeCnt = self.freezeCnt - 1
            return
        end

        for idx = 1, self.speed do
            BattleController.update(dt)
        end
    end)
    self:delayNextStep(0)
end

function FirstFightScene:startEffect(delayTime)
    AudioManager.playMusic("music/bgm_guideBattle.mp3")

    local path = "public/ui_zhuanchangzhezhao"
    local anim = SpineManager.createAnimation(path,1)
    anim:playAnimation("idle2", 1)
    anim:setAutoRemove(true)
    anim:setPosition(display.cx, display.cy)
    self.resourceNode_:getChildByName("heroNode"):addChild(anim)
    self:delayNextStep(delayTime)
end

function FirstFightScene:showDefender(delayTime)
    local uids = {}
    for _order, info in pairs(self.data.defender[1]) do
        local unit = TeamController.createUnit(info)
        unit.order = _order
        unit.group = c.UnitGroup.DEFENDER
        BattleController.addUnit(unit)
        table.insert(uids,unit.uid)
    end

    self:showAppear({uids},function()
        self:delayNextStep(delayTime)
    end)
end

function FirstFightScene:moveCamera(pos, scale, time, delayTime)
    self.resourceNode_:runAction(cc.Sequence:create(cc.ScaleTo:create(time, scale), cc.CallFunc:create(function()
        self:delayNextStep(delayTime or 0)
    end)))
    self.resourceNode_:runAction(cc.MoveTo:create(time, pos))
end

function FirstFightScene:showAttackerHero(order, delayTime)
    local uid = nil
    for _order, info in ipairs(self.data.attacker[1]) do
        if _order == order then
            local unit = TeamController.createUnit(info)
            unit.order = order
            unit.group = c.UnitGroup.ATTACKER
            BattleController.addUnit(unit)
            uid = unit.uid
            break
        end
    end

    local anim = self.anims[uid]
    anim:setVisible(false)
    local posX, posY = anim:getPosition()
    local showAnim = SpineManager.createAnimation("public/ui_chouka_chuyingxiong", 1)
    showAnim:setPosition(posX, posY)
    anim:getParent():addChild(showAnim, anim:getLocalZOrder())

    showAnim:playAnimation("idle", 1)
    showAnim:setAutoRemove(true)
    showAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "trigger" then
            anim:setVisible(true)
        elseif eventName == "duang_start" then
            self:startShake(intValue * 2)
        elseif eventName == "duang_end" then
            self:stopShake()
            self:delayNextStep(delayTime)
        end
    end)
end

function FirstFightScene:speak(group, order, str, delayTime)
    local keepTime = 2

    local target = nil
    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order then
            target = unit
            break
        end
    end

    if not target then
        return
    end

    local anim = self.anims[target.uid]

    local textLabel = RichLabel.new {
        fontSize = 16,
        maxWidth = 200,
        fontColor = cc.c3b(255,255,255),
    }
    textLabel:setString(str)
    local size = textLabel:getContentSize()
    local bgSize = cc.size(size.width + 36, size.height + 10)
    local spBg = display.newSprite("common/qipao_3gongge.png", 0, 0, {scale9 = true, size = bgSize})
    textLabel:setString("")
    textLabel.str = str

    local pos = anim:getBonePosition("hp_point")
    spBg:setName("speakNode_"..order)  

    spBg:runAction(cc.Sequence:create(
        cc.ScaleTo:create(0.15,1.2),
        cc.ScaleTo:create(0.15, 1)
    ))

    if group == c.UnitGroup.ATTACKER then
        spBg:setPosition(cc.p(pos.x + bgSize.width/2, pos.y))
        textLabel:setPosition(cc.p(pos.x + 20, pos.y + 12))
    else
        spBg:setFlippedX(true)
        spBg:setPosition(cc.p(pos.x - bgSize.width/2, pos.y))
        textLabel:setPosition(cc.p(pos.x - bgSize.width + 10, pos.y + 12))
    end

    self.resourceNode_:getChildByName("heroNode"):addChild(spBg, anim:getLocalZOrder())
    self.resourceNode_:getChildByName("heroNode"):addChild(textLabel, anim:getLocalZOrder())

    local length = 1
    textLabel:actionScheduleInterval(function()
        if length <= string.len(textLabel.str) then
            local str = string.utf8sub(textLabel.str, 1, length)
            textLabel:setString(str)
            length = length + 1
        end
    end, 0.05)

    spBg:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.RemoveSelf:create()))
    textLabel:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.RemoveSelf:create()))
    self:delayNextStep(delayTime)
end

function FirstFightScene:useSkill(group, order, skillId, delayTime)
    local target = nil
    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order then
            target = unit
            break
        end
    end

    if target then
        local unitSkill = TeamController.newUnitSkill(target, skillId)
        if target:setState(c.UnitState.ATTACK) then
            target.curSkill = unitSkill
            unitSkill:start()
        end
    end

    self:delayNextStep(delayTime)
end

function FirstFightScene:changeSkin(group, order, preSkinName, skinName, delayTime)
    local target = nil

    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order then
            target = unit
            break
        end
    end

    if target then
        self.anims[target.uid]:unregisterSkin(preSkinName)
        self.anims[target.uid]:registerSkin(skinName)
    end
end

function FirstFightScene:updateTurn(curRound, maxRound, delayTime)
    -- 删除防守方已经死亡的单位
    for uid, unit in pairs(BattleController.units) do
        if unit.group == c.UnitGroup.DEFENDER and unit.state == c.UnitState.REMOVED then
            BattleController.units[uid] = nil
        end
    end

    -- 清除死亡单位spine
    local uids = table.keys(self.anims)
    for _, uid in pairs(uids) do
        if BattleController.units[uid] == nil then
            self.anims[uid]:removeFromParent()
            self.anims[uid] = nil
        end
    end

    local anim = SpineManager.createAnimation("public/ui_battle_huihe", 1)
    anim:playAnimation("idle", 1)
    anim:setAutoRemove(true)
    self:addChild(anim)

    anim:addChildFollowSlot("point_1", display.newSprite("fight/fight_num_0" .. curRound .. ".png"))
    anim:addChildFollowSlot("point_2", display.newSprite("fight/fight_num_0" .. maxRound .. ".png"))
    self:delayNextStep(delayTime)
end

function FirstFightScene:showNinsover(delayTime)
    local order = 1
    local info = self.data.defender[2][order]
    local unit = TeamController.createUnit(info)
    unit.order = order
    unit.group = c.UnitGroup.DEFENDER
    BattleController.addUnit(unit)
    local uid = unit.uid

    local anim = self.anims[uid]
    anim:setVisible(false)
    local posX, posY = anim:getPosition()
    local showAnim = SpineManager.createAnimation("spine/effect/destroyer_xs_chuxian_heihua")
    showAnim:setPosition(posX, posY)
    anim:getParent():addChild(showAnim, anim:getLocalZOrder())

    showAnim:playAnimation("idle1", 1)
    local curTimes,totalTimes = 0,3
    showAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "trigger" and animName == "idle1" then
            anim:setVisible(true)
            self:delayNextStep(delayTime)
        elseif eventName == "complete" and animName == "idle1" then
            -- self:startBlink(10)
        elseif eventName == "complete" and animName == "idle2" then
            curTimes = curTimes + 1
            self:startShake(curTimes)
            if curTimes == totalTimes then
                self.ninsoverAnim:setLocalZOrder(display.height)
                self.blackLayer:setVisible(false)
                local effectSpine = SpineManager.createAnimation("guide/xinshou_tzd_heihuntianzhao")
                effectSpine:setPosition(display.cx, display.cy)
                anim:getParent():addChild(effectSpine, fightZOrder.bullet + 1)
                effectSpine:playAnimation("idle")
                effectSpine:setAutoRemove(true)
                self:changeSkin(c.UnitGroup.DEFENDER, 1, "upgrade5", "normal")
                self.ninsoverShowAnim:setAutoRemove(true)
                self:stopShake()
                effectSpine:addLuaHandler(function (eventName, animName, intValue, floatValue)
                    if eventName == "complete" then
                        self:delayNextStep(0.5)
                    end
                end)

                anim:setScaleX(-1.3)
                anim:setScaleY(1.3)

                cc.Device:vibrate(3)
            end
            -- self:delayNextStep(delayTime)
        end
    end)
    self.ninsoverAnim = anim
    self.ninsoverShowAnim = showAnim
end

function FirstFightScene:showOtherDefender(delayTime)
    local uids = {}
    for _order, info in pairs(self.data.defender[2]) do
        if _order ~= 1 then --除天照帝
            local unit = TeamController.createUnit(info)
            unit.order = _order
            unit.group = c.UnitGroup.DEFENDER
            BattleController.addUnit(unit)
            table.insert(uids,unit.uid)
        end
    end

    self:showAppear({uids},function()
        self:delayNextStep(delayTime)
    end)
end

function FirstFightScene:showKazeEffect()
    local effectSpine = SpineManager.createAnimation("guide/xinshou_jipozhan")
    effectSpine:setPosition(display.cx, display.cy)
    effectSpine:playAnimation("idle")
    effectSpine:setAutoRemove(true)
    self.resourceNode_:getChildByName("heroNode"):addChild(effectSpine, fightZOrder.bullet + 1)
    effectSpine:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "complete" then
            self:delayNextStep(0)
        end
    end)
end

function FirstFightScene:ninsoverTrans(delayTime)
    self.blackLayer:setVisible(true)
    self.ninsoverAnim:setLocalZOrder(fightZOrder.anim_powermax)
    self.ninsoverShowAnim:setLocalZOrder(fightZOrder.anim_powermax)
    self.ninsoverShowAnim:playAnimation("idle2", 3)
    self.ninsoverShowAnim:setAutoRemove(true)
    AudioManager.playEffect("music/destroyer_xuliloop.mp3")
    self:startShake(1)
end

function FirstFightScene:startBlink(keepTime, delayTime)
    if not self.blackLayer then
        self.blackLayer = cc.LayerColor:create(cc.c4b(0,0,0,200)):align(display.LEFT_BOTTOM, 0, 0):addTo(self.resourceNode_, -1)
    end
    self.blinkTime = keepTime
    self.blinkDt = 0
    self:startShake(4)
    self.resourceNode_:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.CallFunc:create(function()
        self:stopBlink()
    end)))
end

function FirstFightScene:stopBlink()
    self.blinkTime = 0
    self:stopShake()
    self.blackLayer:setVisible(false)
end

function FirstFightScene:playVideo(videoPath)
    AudioManager.stopMusic()
    local video = VideoLayer.new(videoPath, function()
        self:delayNextStep(0)       
    end)
    self:addChild(video)
end

function FirstFightScene:showLogo()
    self.resourceNode_:setVisible(false)
    -- self:openWin("ShowLogoWin")
    self:getApp():enterScene("UpdateScene")
end

function FirstFightScene:HideUILayer(hide)
    self.resourceNode_:getChildByName("node_lt"):setVisible(hide)
    self.resourceNode_:getChildByName("node_rt"):setVisible(hide)
    self.resourceNode_:getChildByName("node_rb"):setVisible(hide)
    self.resourceNode_:getChildByName("node_cb"):setVisible(hide)
    self.resourceNode_:getChildByName("kamiNode"):setVisible(hide)
end

function FirstFightScene:createTopNode()
    FirstFightScene.super.createTopNode(self)
    self.topNode:setVisible(false)
end

function FirstFightScene:updateEffects(dt)
    FirstFightScene.super.updateEffects(self, dt)

    if self.blinkTime > 0 then
        local cd = 1/20
        self.blinkDt = self.blinkDt + dt
        if self.blinkDt >= cd then
            self.blackLayer:setVisible(not self.blackLayer:isVisible())
            self.blinkDt = self.blinkDt - cd
        end
        self.blinkTime = self.blinkTime - dt
    end
end

function FirstFightScene:showAnimation()
    
end

function FirstFightScene:addUnit(unit, revive)
    local anim = FirstFightScene.super.addUnit(self, unit, revive)
    anim:getChildFollowBone("hp_point"):setVisible(false)
end

return FirstFightScene