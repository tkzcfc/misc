
local c = require "app.configs.constants"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local Helper = require "app.Helper"
local GuideConf = {}

--relocation为空，且不在城内的，需要写scene 先切换到其他场景
------对话
-- {
--     stepType = c.GUIDE_STEP_TYPE.DIALOGUE, 
--     dialog = 201, --对话ID
-- },
------点击
-- {
--     stepType = c.GUIDE_STEP_TYPE.CLICK,
--     delayTime = 0.4,
--     clickPos = cc.p(568,275),
--     scale = 350,  --动画大小，
--     scaleX = 350,
--     scaleY = 350,
--     notShowRender = true, --不显示灰色遮罩
--     clickMusic = "music/ui_entermap.mp3",
--     clickType = "OutsideScrollWin", --如果加此字段说明clickpos为关卡ID
--     clickFunc = function   --点击函数
--     cancelled = function   --取消点击
--     consecutive = true,    --连续点击提示
-- },
------video
-- {
--     stepType = c.GUIDE_STEP_TYPE.VIDEO,
--     videoPath = "video/xinshouyindao.mp4",
-- },
------切换场景
-- {
--     stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
--     changeScene = c.AfterLoading.outsideScene,
-- },
------提示窗口
-- {
--     stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
--     sprite = "zhezhao-02.png", --透视sprite
--     spritePos = cc.p(100, 200),
--     tipsPos = cc.p(300, 400),--窗口坐标
--     delayTime = 0.5,
--     tipsContent = "",
--     notShowRender = true,
--     pauseBattle = true, --暂停战斗
-- },

local configs = {
    [1] = {
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1051],
        },
        -- { --初次对话弹窗
        --     stepType = c.GUIDE_STEP_TYPE.CALLBACK,
        --     callback = function(doNext, guideWin)
        --         guideWin:runAction(cc.Sequence:create(
        --             cc.DelayTime:create(0.5),
        --             cc.CallFunc:create(function()
        --                 display.getRunningScene():getChildByName("ViewBase"):openWin("GuideStartWin", "guide/guanggao_01.png")
        --                 doNext()
        --             end)
        --         ))
        --     end,
        -- },
        -- { --初次对话弹窗
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(568, 80),
        --     scale = 200,
        --     relocation = -1,
        --     clickFunc = function(doNext, guideWin)
        --         local action = guideWin:actionScheduleInterval(function()
        --             local win = display.getRunningScene().winManager:findWinByName("GuideStartWin")
        --             if win then
        --                 guideWin:stopActionByTag(0XABC)
        --                 win:closeSelf()
        --                 display.getRunningScene():getChildByName("ViewBase"):openWin("GuideStartWin", "guide/guanggao_02.png")
        --                 doNext()
        --             end
        --         end,0.2)
        --         action:setTag(0XABC)
        --     end,
        -- },
        -- { --初次对话弹窗
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(568, 80),
        --     scale = 200,
        --     relocation = -1,
        --     clickFunc = function(doNext, guideWin)
        --         local action = guideWin:actionScheduleInterval(function()
        --             local win = display.getRunningScene().winManager:findWinByName("GuideStartWin")
        --             if win then
        --                 guideWin:stopActionByTag(0XABC)
        --                 win:closeSelf()
        --                 display.getRunningScene():getChildByName("ViewBase"):openWin("GuideStartWin", "guide/guanggao_03.png")
        --                 doNext()
        --             end
        --         end,0.2)
        --         action:setTag(0XABC)
        --     end,
        -- },
        -- { --初次对话弹窗关闭
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(568, 80),
        --     scale = 200,
        --     relocation = 1,
        --     clickFunc = function(doNext, guideWin)
        --         local action = guideWin:actionScheduleInterval(function()
        --             local win = display.getRunningScene().winManager:findWinByName("GuideStartWin")
        --             if win then
        --                 guideWin:stopActionByTag(0XABC)
        --                 win:closeSelf()
        --                 doNext()
        --             end
        --         end,0.2)
        --         action:setTag(0XABC)
        --     end,
        -- },
        { --点击城外按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.4,
            clickPos = cc.p(1058,66),
            scale = 350,
            clickMusic = "music/ui_entermap.mp3",
        },
        { --切换城外场景
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.outsideScene,
            relocation = 1,
        },
        { --点击第一个关卡
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickType = "OutsideScrollWin",
            clickPos = 23023,
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        local levelId = 23023
                        local y = levelId - math.floor(levelId / 100) * 100
                        local x = (levelId - y) / 1000
                        win:openFuncWin(levelId, cc.p(x, y))
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击挑战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickPos = cc.p(568, 220),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("StagePreviewWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("EmbattleWin",{fightStatus = c.FightStatus.ordinary, id = win.clickLevelId,notRanks = true})
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --上阵风十郎
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(140, 122),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        local btn = win.guideButs[1].btn
                        for k,v in pairs(win.guideButs) do
                            if v.id == 20012 then
                                btn = v.btn
                                break
                            end
                        end
                        btn:onClick()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --点击出战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1045, 95),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                doNext()
                win.fightBtn:onClick()
            end,
        },
        { --屏蔽退出按钮
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local scene = display.getRunningScene():getChildByName("ViewBase")
                    if scene:getName() == "GameScene" then
                        guideWin:stopActionByTag(0XABC)
                        scene.resourceNode_:getChildByName("node_lt"):setVisible(false)
                        scene.resourceNode_:getChildByName("node_rb"):setVisible(false)
                        doNext()
                    end
                end, 0.01)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"
                local scene = display.getRunningScene()
                scene:runAction(cc.Sequence:create(
                    cc.DelayTime:create(1),
                    cc.CallFunc:create(function()
                        BattleController.pause()
                        doNext()
                    end)
                ))
            end,
            relocation = -1,
        },
        { --战斗提示
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1501],
            relocation = -1,
            sound = "vocal_10009.mp3",
        },
        { --战斗顺序提示
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-02.png",
            spritePos = cc.p(1100, 400),
            tipsPos = cc.p(200, 0),
            scaleX = 70,
            scaleY = 250,
            delayTime = 0.5,
            tipsContent = WordDictionary[1502],
            relocation = -1,
            sound = "vocal_10005.mp3",
        },
        { --取消暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"                
                BattleController.pause()
                doNext()
            end,
            relocation = -1,
        },
        { --监听技能释放
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local scene = display.getRunningScene()
                local BattleController = require "app.battle.controllers.BattleController"
                scene:runAction(cc.Sequence:create(
                    cc.DelayTime:create(0.1),
                    cc.CallFunc:create(function()
                        local target = nil
                        for _,unit in pairs(BattleController.units) do
                            if unit.group == c.UnitGroup.ATTACKER and unit.order == 1 then
                                target = unit
                                break
                            end
                        end
                        if not target then return end

                        local action = guideWin:actionScheduleInterval(function()
                            local mp = target.attr.mp
                            local totalMp = target.attr.energy

                            if mp >= totalMp then
                                guideWin:stopActionByTag(0XABC)
                                BattleController.pause()
                                doNext()
                            end
                        end, 0.01)
                        action:setTag(0XABC)
                    end)
                ))
            end,
            relocation = -1,
        },
        { --提示可释放大招
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-03.png",
            spritePos = cc.p(568, 105),
            tipsPos = cc.p(0, 0),
            scaleX = 185,
            scaleY = 242,
            delayTime = 0.5,
            tipsContent = WordDictionary[1505],
            relocation = -1,
            sound = "vocal_10007.mp3",
        },
        { --点击技能并释放
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.4,
            clickPos = cc.p(568, 135),
            scale = 250,
            clickFunc = function(doNext, guideWin)
                local scene = display.getRunningScene()
                local BattleController = require "app.battle.controllers.BattleController"

                local target = nil
                for _,unit in pairs(BattleController.units) do
                    if unit.group == c.UnitGroup.ATTACKER and unit.order == 1 then
                        target = unit
                        break
                    end
                end
                if not target then return end
                BattleController.pause()
                BattleController.unitPowermaxSkill(target)
                doNext()
            end,
            relocation = -1,
        },
        { --取消新手屏蔽控制
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                guideWin:setTouchListenerEnable(false)
                doNext()
            end,
            relocation = -1,
        },
        { --战斗完成
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                network.addListener(guideWin, {msgids.GS_WLevelFightNormal_R}, function()
                    doNext()
                    guideWin:getScene().winManager:forceRemoveWin(guideWin)
                end)
            end,
            relocation = 1,
        },
        { --特殊处理，等待进入城外
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --点击关闭功能开启
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1.5,
            clickPos = cc.p(568, 140),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("GetNewFunWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:closeSelf()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --初次召唤功能引导对话对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1052],
            scene = c.AfterLoading.outsideScene,
            sound = "vocal_10009.mp3",
        },
        { --点击回城
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50,530),
            scale = 250,
            relocation = 1,
        },
        { --切换回城
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.mainScene,
            relocation = 1,
        },
        { --点击召唤
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(873, 369),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MainWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("DrawWin")
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --点击普通召唤
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(427, 76),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("DrawWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win.sumBtn[2]:onClick(nil, true)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --等待召唤
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                doNext()
            end,
            key = "draw",
            relocation = 1,
        },
        { --监听英雄获得界面
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("DrawSSSHeroWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --关闭英雄获得界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 120),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("DrawSSSHeroWin")
                if win then
                    win:closeSelf()
                    doNext()
                end
            end,
        },
        { --点击确定按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.4,
            clickPos = cc.p(425,40),
            scale = 350,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("DrawMagicWin")
                if win then
                    win:closeSelf()
                    doNext()
                end
            end,
        },
        { --推出召唤界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.4,
            clickPos = cc.p(50,530),
            scale = 250,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                -- local win = display.getRunningScene().winManager:findWinByName("DrawWin")
                -- if win then
                    -- win:closeSelf()
                    doNext()
                -- end
            end,
        },
        { --切换城外场景
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.outsideScene,
            relocation = 1,
        },
        { --设置挂机100%
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:autoGainBtn(100)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --挂机引导对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1053],
            relocation = -1,
            sound = "vocal_10008.mp3",
        },
        { --点击挂机
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.2,
            clickPos = cc.p(1088, 155),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                win.animbz.clickHandler("ended")
                doNext()
            end,
        },
        { --点击领取
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(580, 65),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                doNext()
            end,
        },
        { --领取挂机
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                doNext()
            end,
            key = "guaji",
            relocation = 1,
            submitData = true,
        },
        { --监听获得物品界面
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("PublicGetRewardWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --点击获得物品界面确定
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 120),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("MapGuaJiWin")
                if win then
                    win:closeSelf()
                end
                local win_ = display.getRunningScene().winManager:findWinByName("PublicGetRewardWin")
                if win_ then
                    win_:closeSelf()
                    doNext()
                end
            end,
        },
        { --监听升级界面
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            relocation = 1,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("LevelUpWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --关闭升级界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.8,
            clickPos = cc.p(568, 120),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("LevelUpWin")
                if win then
                    win:closeSelf()
                    doNext()
                end
            end,
        },
        { --套装获得界面
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            relocation = 1,
            callback = function(doNext, guideWin)
                display.getRunningScene():getChildByName("ViewBase"):openWin("EquipmentWin")
                doNext()
            end,
        },
        { --套装获得界面关闭
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickPos = cc.p(568, 120),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("EquipmentWin")
                if win then
                    win:closeSelf()
                    doNext()
                end
            end,
        },
        { --判断是否在城外
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                if win then 
                    doNext()
                else                
                    local action = guideWin:actionScheduleInterval(function()
                        local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                        if win then
                            guideWin:stopActionByTag(0XABC)
                            doNext()
                        end
                    end,0.1)
                    action:setTag(0XABC)
                end
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击英雄列表
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50, 50),
            scale = 150,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                doNext()
                win.heroListBtn:onClick()
            end,
            relocation = -1,
        },
        { --点击英雄养成
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(143, 60),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win.ycBtn:onClick()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --升级引导对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1054],
            relocation = -1,
            sound = "vocal_10007.mp3",
        },
        { --点击英雄升级到五级
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(740, 48),
            scale = 200,
            relocation = 1,
            consecutive = true,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                if win.subPageView.sHeroData.level >= 5 then
                    doNext()
                else
                    network.addListener(guideWin, {msgids.GS_HeroUpdate}, handler(guideWin, function(guideWin, op, data)
                        if win.subPageView.sHeroData.level >= 5 then
                            doNext()
                        else
                            guideWin.finger.firstClick = true
                        end
                    end), "once")
                    win.subPageView.btn_upgrade:onClick()
                end
            end,
        },
        { --判断英雄列表是否打开
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                if win then 
                    doNext()
                else                
                    guideWin:runAction(cc.Sequence:create(
                        cc.DelayTime:create(0.8),
                        cc.CallFunc:create(function()
                           local outsideWin = display.getRunningScene().winManager:findWinByName("OutsideWin")
                            outsideWin.heroListBtn:onClick()
                        end),
                        cc.DelayTime:create(0.8),
                        cc.CallFunc:create(function()
                            local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                            local btn = win.heroImgs[1].btn
                            for k,v in pairs(win.heroImgs) do
                                if v.id == 20012 then
                                    btn = v.btn
                                    break
                                end
                            end
                            btn:onClick()
                        end),
                        cc.DelayTime:create(0.8),
                        cc.CallFunc:create(function()
                            win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                            win.ycBtn:onClick()
                            doNext()
                        end)
                    ))
                end
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击英雄装备
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1100, 200),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win:updateDevelopNode(4)
                doNext()
            end,
        },
        { --装备穿戴引导对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1055],
            relocation = -1,
            sound = "vocal_10009.mp3",
        },
        { --点击一键穿戴
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(684, 52),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.subPageView.btn_wear:onClick()
                doNext()
            end,
        },
        { --装备强化引导对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1056],
            relocation = -1,
            sound = "",
        },
        { --点击一键强化
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(950, 52),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.subPageView.btn_strength:onClick()
                doNext()
            end,
        },
        { --点击退出英雄列表
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50, 530),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.super.closeSelf(win)
                doNext()
            end,
        },
        { --点击第二个关卡
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickType = "OutsideScrollWin",
            clickPos = 23022,
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                local levelId = 23022
                local y = levelId - math.floor(levelId / 100) * 100
                local x = (levelId - y) / 1000
                win:openFuncWin(levelId, cc.p(x, y))
                doNext()
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击挑战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 220),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("StagePreviewWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("EmbattleWin",{fightStatus = c.FightStatus.ordinary, id = win.clickLevelId,specialRanks = {20012}})
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --上阵大荒剑士
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(263, 95),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        local btn = win.guideButs[1].btn
                        for k,v in pairs(win.guideButs) do
                            if v.id == 20005 then
                                btn = v.btn
                                break
                            end
                        end
                        btn:onClick()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end
        },
        { --点击出战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1045, 95),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                doNext()
                win.fightBtn:onClick()
            end,
        },
        { --屏蔽退出按钮
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local scene = display.getRunningScene():getChildByName("ViewBase")
                    if scene:getName() == "GameScene" then
                        guideWin:stopActionByTag(0XABC)
                        guideWin:setTouchListenerEnable(false)
                        scene.resourceNode_:getChildByName("node_lt"):setVisible(false)
                        scene.resourceNode_:getChildByName("node_rb"):setVisible(false)
                        doNext()
                    end
                end, 0.01)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --监听战斗结束
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                network.addListener(guideWin, {msgids.GS_WLevelFightNormal_R}, function()
                    doNext()
                end)
            end,
            relocation = 1,
        },
        { --特殊处理，等待进入城外
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1057],
            scene = c.AfterLoading.outsideScene,
            sound = "vocal_10002.mp3",
        },
        { --点击第三个关卡
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickType = "OutsideScrollWin",
            clickPos = 22022,
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                local levelId = 22022
                local y = levelId - math.floor(levelId / 100) * 100
                local x = (levelId - y) / 1000
                win:openFuncWin(levelId, cc.p(x, y))
                doNext()
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击挑战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 220),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("StagePreviewWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("EmbattleWin",{fightStatus = c.FightStatus.ordinary, id = win.clickLevelId,specialRanks = {20012, 20005}})
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --点击出战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1045, 95),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                        win.fightBtn:onClick()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --屏蔽退出按钮
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local scene = display.getRunningScene():getChildByName("ViewBase")
                    if scene:getName() == "GameScene" then
                        guideWin:stopActionByTag(0XABC)
                        guideWin:setTouchListenerEnable(false)
                        scene.resourceNode_:getChildByName("node_lt"):setVisible(false)
                        scene.resourceNode_:getChildByName("node_rb"):setVisible(false)
                        doNext()
                    end
                end, 0.01)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --监听战斗结束
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                network.addListener(guideWin, {msgids.GS_WLevelFightNormal_R}, function()
                    doNext()
                end)
            end,
            relocation = 1,
        },
        { --特殊处理，等待进入城外
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1058],
            relocation = -1,
            sound = "vocal_10004.mp3",
        },
        { --点击推荐关卡
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.3,
            clickPos = cc.p(1090, 52),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                win.search:onClick()
                doNext()
            end,
        },
        { --点击挑战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.8,
            clickPos = cc.p(568, 220),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("StagePreviewWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("EmbattleWin",{fightStatus = c.FightStatus.ordinary, id = win.clickLevelId,specialRanks = {20012, 20005}})
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --点击出战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1045, 95),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                        win.fightBtn:onClick()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --屏蔽退出按钮
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local scene = display.getRunningScene():getChildByName("ViewBase")
                    if scene:getName() == "GameScene" then
                        guideWin:stopActionByTag(0XABC)
                        guideWin:setTouchListenerEnable(false)
                        scene.resourceNode_:getChildByName("node_lt"):setVisible(false)
                        scene.resourceNode_:getChildByName("node_rb"):setVisible(false)
                        doNext()
                    end
                end, 0.01)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --监听战斗结束
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                network.addListener(guideWin, {msgids.GS_WLevelFightNormal_R}, function()
                    doNext()
                end)
            end,
            relocation = 1,
        },
        { --特殊处理，等待进入城外
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1059],
            scene = c.AfterLoading.outsideScene,
            sound = "vocal_10009.mp3",
        },
        { --点击英雄列表按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50, 45),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                if win then
                    win.heroListBtn:onClick()
                    doNext()
                end
            end,
        },
        { --点击可召唤
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1100, 42),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win.summonAnim.clickHandler("ended")
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --点击召唤
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.3,
            clickPos = cc.p(140, 58),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.summonBtn:onClick()
                doNext()
            end,
            submitData = true,
        },
        { --点击关闭获得界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickPos = cc.p(840, 70),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("DrawSSSHeroWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:closeSelf()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --判断英雄列表是否打开
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                if win then 
                    doNext()
                else                
                    guideWin:runAction(cc.Sequence:create(
                        cc.DelayTime:create(0.8),
                        cc.CallFunc:create(function()
                           local outsideWin = display.getRunningScene().winManager:findWinByName("OutsideWin")
                            outsideWin.heroListBtn:onClick()
                        end),
                        cc.DelayTime:create(0.8),
                        cc.CallFunc:create(function()
                            local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                            local btn = win.heroImgs[1].btn
                            for k,v in pairs(win.heroImgs) do
                                if v.id == 20014 then
                                    btn = v.btn
                                    break
                                end
                            end
                            btn:onClick()
                            doNext()
                        end)
                    ))
                end
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击英雄养成
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(143, 60),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.ycBtn:onClick()
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1060],
            relocation = -1,
            sound = "vocal_10007.mp3",
        },
        { --点击英雄一键升级
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(960, 48),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                if win then
                    win.subPageView.btn_five:onClick()
                end
                doNext()
            end,
        },
        { --判断英雄列表是否打开
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                if win then 
                    doNext()
                else                
                    guideWin:runAction(cc.Sequence:create(
                        cc.DelayTime:create(0.5),
                        cc.CallFunc:create(function()
                           local outsideWin = display.getRunningScene().winManager:findWinByName("OutsideWin")
                            outsideWin.heroListBtn:onClick()
                        end),
                        cc.DelayTime:create(0.8),
                        cc.CallFunc:create(function()
                            local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                            local btn = win.heroImgs[1].btn
                            for k,v in pairs(win.heroImgs) do
                                if v.id == 20014 then
                                    btn = v.btn
                                    break
                                end
                            end
                            btn:onClick()
                        end),
                        cc.DelayTime:create(0.3),
                        cc.CallFunc:create(function()
                            local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                            win.ycBtn:onClick()
                            doNext()
                        end)
                    ))
                end
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击天赋标签页
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1100, 370),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win:updateDevelopNode(2)
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1061],
            relocation = -1,
            sound = "vocal_10002.mp3",
        },
        { --点击一键训练
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(966, 51),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.subPageView.activeBtn:onClick()
                doNext()
            end,
        },
        { --点击进阶
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(966, 51),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                win.subPageView.activeBtn:onClick()
                doNext()
            end,
        },
        { --关闭进阶成功界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickPos = cc.p(568, 110),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("ClsUpSuccessWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:closeSelf()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --关闭技能解锁界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 110),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("HeroSkillUnlockWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:closeSelf()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --关闭英雄列表界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50, 530),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("HeroListWin")
                if win then
                    win.super.closeSelf(win)
                end
                doNext()
            end,
        },
        { --点击boss关卡
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickType = "OutsideScrollWin",
            clickPos = 21022,
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideScrollWin")
                local levelId = 21022
                local y = levelId - math.floor(levelId / 100) * 100
                local x = (levelId - y) / 1000
                win:openFuncWin(levelId, cc.p(x, y))
                doNext()
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --点击挑战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 1,
            clickPos = cc.p(568, 220),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("StageBossWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("EmbattleWin",{fightStatus = c.FightStatus.ordinary, id = win.clickLevelId, specialRanks = {20012, nil, 20005}})
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --上阵千本樱
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(140, 122),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        local btn = win.guideButs[1].btn
                        for k,v in pairs(win.guideButs) do
                            if v.id == 20014 then
                                btn = v.btn
                                break
                            end
                        end
                        btn:onClick()
                        local init = require "app.models.init"
                        local PlayerModel = init.PlayerModel
                        local heroIds = {20012, 20014, 20005}
                        PlayerConfig.setSetting(PlayerModel.info.userId .. "pveTeam", json.encode(heroIds))
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --点击出战按钮
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1045, 95),
            scale = 200,
            relocation = -1,
            clickFunc = function(doNext, guideWin)
                doNext()
                local data = require "app.views.guide.SupportConf"
                data.levelId = 21022
                display.getRunningScene():getChildByName("ViewBase"):getApp():enterScene("SupportScene",data)
            end,
        },
        { --开启触摸
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local scene = display.getRunningScene():getChildByName("ViewBase")
                    if scene:getName() == "SupportScene" then
                        guideWin:stopActionByTag(0XABC)
                        guideWin:setTouchListenerEnable(false)
                        doNext()
                    end
                end, 0.01)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --保持步数凑数
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                doNext()
            end,
            relocation = -1,
        },
        { --保持步数凑数
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
               doNext()
            end,
            relocation = -1,
        },
        { --监听战斗结束
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                network.addListener(guideWin, {msgids.GS_WLevelFightNormal_R}, function()
                    doNext()
                end)
            end,
            relocation = 1,
        },
        { --特殊处理，等待进入城外
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --点击忍者之心
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.8,
            clickPos = cc.p(316, 43),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                win.ninjaHeart:onClick()
                doNext()
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1062],
            relocation = -1,
            sound = "vocal_10009.mp3",
        },
        { --点击忍者之心升到五级
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(930, 118),
            scale = 200,
            consecutive = true,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("NinjaHeartWin")
                if win.info.Lv >= 5 then
                    doNext()
                else
                    network.addListener(guideWin, {msgids.GS_RzzxAddExp_R}, handler(guideWin, function(guideWin, op, data)
                        if win.info.Lv >= 5 then
                            doNext()
                        else
                            guideWin.finger.firstClick = true
                        end
                    end), "once")
                    win.btn_up:onClick()
                end
            end,
            relocation = -1,
        },
        { --关闭忍者之心
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1055, 500),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("NinjaHeartWin")
                win:closeSelf()
                doNext()
            end,
            relocation = 1,
        },
        { --点击主线任务
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(125, 188),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                win:clickMainLineWin(true)
                doNext()
            end,
            scene = c.AfterLoading.outsideScene,
        },
        { --引导结束对话1
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1066],
            relocation = 1,
        },
        { --引导结束对话2
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1067],
            relocation = 1,
        },
        { --开启引导光圈
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local outsideWin = display.getRunningScene().winManager:findWinByName("OutsideWin")
                if outsideWin then
                    outsideWin:checkRecommendBtnAnim(true)
                end
                local init = require "app.models.init"
                local PlayerModel = init.PlayerModel
                PlayerConfig.setSetting(PlayerModel.info.userId .. "guideFinish", true)
                doNext()
            end,
        },
    },
    [3] = {---比武场新手引导----
        { --比武场提示
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1101],
        },
        { --布置阵容提示
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1102],
            relocation = -1,
        },
        { --点击调整
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(255, 250),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("ArenaWin")
                win.resourceNode_:getChildByName("node_lb"):getChildByName("btn_setTeam"):onClick()
                doNext()
            end,
            relocation = -1,
        },
        { --屏蔽退出按钮
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("EmbattleWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        local UIImageBox = require "sandglass.ui.UIImageBox"
                        UIImageBox.new(win.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
                            local MoveLabel = require "sandglass.ui.MoveLabel"
                            local WordDictionary = require "app.configs.WordDictionary"
                            MoveLabel.new(WordDictionary[1103])
                        end)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = -1,
        },
        { --点击出战按钮
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                guideWin:setTouchListenerEnable(false)
                network.addListener(guideWin, {msgids.GS_ArenaSetTeam_R}, function()
                    guideWin:setTouchListenerEnable(true)
                    doNext()
                end)
            end,
            relocation = 1,
        },
        { --选择对手提示
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            -- sprite = "zhezhao-03.png",
            -- spritePos = cc.p(1052, 210),
            -- scaleX = 130,
            -- scaleY = 60,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1104],
        },
    },
    [4] = {----自动战斗引导
        { --战斗提示
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "range.png",
            spritePos = cc.p(1049, 97),
            scale = 120,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1200],
            pauseBattle = true,
        },
        { --暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"
                BattleController.pause()
                doNext()
            end,
            relocation = -1,
        },
        { --点击自动战斗
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1049, 97),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"
                local scene = display.getRunningScene():getChildByName("ViewBase")
                scene.autoBtn:onClick()
                doNext()
            end,
        },
        { --取消暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"                
                BattleController.pause()
                doNext()
            end,
        }, 
    },
    [5] = {----家族引导
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1250],
        },
        { --点击供奉
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(867, 441),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("FamilyLandWin")
                if win then
                    win.btn_shrine.clickHandler("ended")
                end
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1251],
            relocation = -1,
        },
        -- { --点击捐赠
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(375, 101),
        --     scale = 200,
        --     relocation = 1,
        --     clickFunc = function(doNext, guideWin)
        --         local win = display.getRunningScene().winManager:findWinByName("FamilyWorshipWin")
        --         if win then
        --             win:clickWorship(1)
        --         end
        --         doNext()
        --     end,
        -- },
        -- { --监听获得物品界面
        --     stepType = c.GUIDE_STEP_TYPE.CALLBACK,
        --     callback = function(doNext, guideWin)
        --         local action = guideWin:actionScheduleInterval(function()
        --             local win = display.getRunningScene().winManager:findWinByName("PublicGetRewardWin")
        --             if win then
        --                 guideWin:stopActionByTag(0XABC)
        --                 doNext()
        --             end
        --         end,0.2)
        --         action:setTag(0XABC)
        --     end,
        --     relocation = 1,
        -- },
        -- { --点击关闭获得界面
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(568, 120),
        --     scale = 200,
        --     relocation = 1,
        --     clickFunc = function(doNext, guideWin)
        --         local win = display.getRunningScene().winManager:findWinByName("PublicGetRewardWin")
        --         if win then
        --             win:closeSelf()
        --             doNext()
        --         end
        --     end,
        -- },
        { --点击关闭捐赠界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1090, 524),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("FamilyWorshipWin")
                if win then
                    win:closeSelf()
                    doNext()
                end
            end,
            relocation = 1,
        },
        { --点击家族大厅
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(603, 347),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("FamilyLandWin")
                if win then
                    win.btn_hall.clickHandler("ended")
                end
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1252],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1253],
            relocation = 1,
        },
    },
    [6] = {----矿战引导
        { 
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 100),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                network.tcpSend(msgids.C_MineWatcher, {Op = 1})
                network.tcpSend(msgids.C_MineMapInfo, {}, {
                lockScreen = true,
                view = self,
                ops = {msgids.GS_MineMapInfo_R},
                callback = function(op, data)
                    local win = display.getRunningScene().winManager:findWinByName("GetNewFunWin")
                    if win then
                        win:closeSelf()
                    end
                    if Helper.checkDivide(3) then
                        display.getRunningScene():getChildByName("ViewBase"):openWin("SwitchWin", function ( ... )
                            display.getRunningScene():getChildByName("ViewBase"):getApp():enterScene("MineWarScene")
                        end)
                    end
                    doNext()
                end})
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1300],
        },
        { --移动位置
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("MineWarScrollWin")
                if win then
                    win:moveScrollToMyPos(30, function()
                        doNext()
                    end)
                end
            end,
        },
        { --点击建筑
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(650, 217),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("MineWarScrollWin")
                if win then
                    local path = win:findWay(win.heroSpine.curBuildId, 30)
                    win:openWin("MineWarDetailWin", win, 30, path)
                end
                doNext()
            end,
            relocation = -1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(956, 62),
            scaleX = 172,
            scaleY = 77,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1301],
            relocation = -1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(117, 475),
            scaleX = 190,
            scaleY = 90,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1302],
            relocation = -1,
        },
        { --点击返回
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50, 540),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("MineWarDetailWin")
                if win then
                    win:closeSelf()
                end
                doNext()
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(100, 485),
            scaleX = 200,
            scaleY = 80,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1303],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1304],
            relocation = 1,
        },
        { --点击阵容
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(916, 33),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("MineWarWin")
                if win then
                    win.btnSetTeam:onClick()
                end
                doNext()
            end,
            relocation = 1,
        },
    },
    [7] = {----幻化神引导
        { --点击前往
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 100),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("GetNewFunWin")
                if win then
                    win:closeSelf()
                end
                doNext()
            end,
        },
        { --切换场景
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.mainScene,
            relocation = 1,
        },
        { --等待回城
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MainWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("KamiWin")
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-05.png",
            spritePos = cc.p(205, 115),
            scale = 1,
            tipsPos = cc.p(-150, 20),
            delayTime = 0.8,
            tipsContent = WordDictionary[1080],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(845, 46),
            scaleX = 200,
            scaleY = 80,
            tipsPos = cc.p(250, -50),
            delayTime = 0.5,
            tipsContent = WordDictionary[1081],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-05.png",
            spritePos = cc.p(315, 165),
            scale = 1,
            tipsPos = cc.p(100, 50),
            delayTime = 0.5,
            tipsContent = WordDictionary[1082],
            relocation = 1,
        },
        -- { --点击返回
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(50, 540),
        --     scale = 200,
        --     clickFunc = function(doNext, guideWin)
        --         local win = display.getRunningScene().winManager:findWinByName("MainWin")
        --         if win then
        --             local kamiWin = display.getRunningScene().winManager:findWinByName("KamiWin")
        --             if kamiWin then
        --                 kamiWin:closeSelf()
        --             end
        --         else
        --             display.getRunningScene():getChildByName("ViewBase"):getApp():enterScene("MainScene")
        --         end
        --         doNext()
        --     end,
        -- },
    },
    [8] = {----4倍战斗加速引导
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1090],
            pauseBattle = true,
        },
        { --暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"
                BattleController.pause()
                doNext()
            end,
            relocation = 1,
        },
        { --点击加速
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(187, 521),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local scene = display.getRunningScene():getChildByName("ViewBase")
                scene.speedUpBtn:onClick()
                doNext()
            end,
        },
        { --点击加速
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(187, 521),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local scene = display.getRunningScene():getChildByName("ViewBase")
                scene.speedUpBtn:onClick()
                doNext()
            end,
        },
        { --取消暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local init = require "app.models.init"
                local PlayerModel = init.PlayerModel
                local BattleController = require "app.battle.controllers.BattleController"      
                BattleController.pause()          
                PlayerConfig.setSetting(PlayerModel.info.userId .. "firstFightSpeedup", true)
                doNext()
            end,
        }, 
    },
    [9] = {----地图宝箱
        { --关闭多余界面
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                display.getRunningScene().winManager:closeAllWin()
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1110],
            relocation = 1,
        },
        { --点击探索宝箱
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(1088, 246),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("LevelUpWin")
                if win then
                    win:closeSelf()
                end
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                if win then
                    win.exploreBtn:onClick()
                    doNext()
                end
            end,
        },
        { --点击十连抽
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(745, 91),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("ExploreRewardWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win.btns[2]:onClick()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --等待奖励界面弹出
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("PublicGetRewardWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --点击获得物品界面确定
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 120),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("PublicGetRewardWin")
                if win then
                    win:closeSelf()
                    doNext()
                end
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(-100, 50),
            delayTime = 0.5,
            tipsContent = WordDictionary[1111],
            relocation = 1,
        },
        { --关闭探索宝箱界面
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(50, 540),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("ExploreRewardWin")
                if win then
                    win:closeSelf()
                end
                doNext()
            end,
        },
        { --打开英魂界面
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("OutsideWin")
                if win then
                    win.mapBossBtn:onClick()
                    doNext()
                end
            end,
            relocation = 1,
        },
        { --召唤英魂
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(892, 148),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MapBossWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win.btn_call:onClick()
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
        },
        { --等待英魂信息界面弹出
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MapBossInfoWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.1)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(435, 150),
            scaleX = 300,
            scaleY = 120,
            tipsPos = cc.p(200, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1112],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(778, 326),
            scaleX = 300,
            scaleY = 300,
            tipsPos = cc.p(-150, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1113],
            relocation = 1,
        },

    },
    [10] = {----2倍战斗加速引导
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1120],
            pauseBattle = true,
        },
        { --暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local BattleController = require "app.battle.controllers.BattleController"
                BattleController.pause()
                doNext()
            end,
            relocation = 1,
        },
        { --点击加速
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(187, 521),
            scale = 200,
            relocation = 1,
            clickFunc = function(doNext, guideWin)
                local scene = display.getRunningScene():getChildByName("ViewBase")
                scene.speedUpBtn:onClick()
                doNext()
            end,
        },
        { --取消暂停战斗
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local init = require "app.models.init"
                local PlayerModel = init.PlayerModel
                local BattleController = require "app.battle.controllers.BattleController"      
                BattleController.pause()          
                PlayerConfig.setSetting(PlayerModel.info.userId .. "doubleSpeedup", true)
                doNext()
            end,
        }, 
    },
    [11] = {----首次死亡引导
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-03.png",
            spritePos = cc.p(358, 174),
            scaleX = 150,
            scaleY = 150,
            tipsPos = cc.p(100, 0),
            delayTime = 1,
            tipsContent = WordDictionary[1130],
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-03.png",
            spritePos = cc.p(573, 174),
            scaleX = 150,
            scaleY = 150,
            tipsPos = cc.p(0, 50),
            delayTime = 0.3,
            tipsContent = WordDictionary[1131],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-03.png",
            spritePos = cc.p(793, 174),
            scaleX = 150,
            scaleY = 150,
            tipsPos = cc.p(0, 0),
            delayTime = 0.3,
            tipsContent = WordDictionary[1132],
            relocation = 1,
        },
        { --
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local init = require "app.models.init"
                local PlayerModel = init.PlayerModel
                -- local BattleController = require "app.battle.controllers.BattleController"      
                -- BattleController.pause()          
                PlayerConfig.setSetting(PlayerModel.info.userId .. "firstDeadGuide", true)
                doNext()
            end,
        }, 
    },
    [12] = {----坦克位置引导
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-03.png",
            spritePos = cc.p(805, 275),
            scaleX = 120,
            scaleY = 150,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1140],
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-03.png",
            spritePos = cc.p(805, 275),
            scaleX = 120,
            scaleY = 150,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1141],
            relocation = 1,
        },
        { --
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function (doNext, guideWin)
                local init = require "app.models.init"
                local PlayerModel = init.PlayerModel
                -- local BattleController = require "app.battle.controllers.BattleController"      
                -- BattleController.pause()          
                PlayerConfig.setSetting(PlayerModel.info.userId .. "tankPosGuide", true)
                doNext()
            end,
        }, 
    },
    [13] = {----通缉大厅引导
        { --点击前往
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 100),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                display.getRunningScene().winManager:closeAllWin()
                display.getRunningScene():getChildByName("ViewBase"):openWin("WantedWin")
                doNext()
            end,
        },
        { --特殊处理，等待进入
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("WantedWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1150],
            relocation = 1,
        },
        { --点击boss
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(283, 305),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("WantedWin")
                win.bossBtn[1]:onClick()
                doNext()
            end,
            relocation = 1,
        },
        { --特殊处理，等待进入
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("WantedInfoWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(790, 100),
            scaleX = 150,
            scaleY = 120,
            tipsPos = cc.p(-100, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1151],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(700, 211),
            scaleX = 350,
            scaleY = 150,
            tipsPos = cc.p(-100, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1152],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(628, 100),
            scaleX = 150,
            scaleY = 120,
            tipsPos = cc.p(-100, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1153],
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(405, 110),
            scaleX = 150,
            scaleY = 100,
            tipsPos = cc.p(-100, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1154],
        },
    },
    [14] = {----幻神宝石引导
        { --点击前往
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 100),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("GetNewFunWin")
                if win then
                    win:closeSelf()
                end
                doNext()
            end,
        },
        { --切换场景
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.mainScene,
            relocation = 1,
        },
        { --等待回城
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MainWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("KamiWin", 5)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-05.png",
            spritePos = cc.p(200, 398),
            scale = 1.5,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1550],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(869, 415),
            scaleX = 400,
            scaleY = 200,
            tipsPos = cc.p(-200, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1551],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-05.png",
            spritePos = cc.p(846, 160),
            scale = 2,
            tipsPos = cc.p(0, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1552],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-05.png",
            spritePos = cc.p(45, 477),
            scale = 0.8,
            tipsPos = cc.p(-150, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1553],
            relocation = 1,
        },
    },
    [15] = {----忍者派遣引导
        { --点击前往
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 100),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("GetNewFunWin")
                if win then
                    win:closeSelf()
                end
                doNext()
            end,
        },
        { --切换场景
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.mainScene,
            relocation = 1,
        },
        { --等待回城
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MainWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("RandomDispatchWin")
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --特殊处理，等待进入
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("RandomDispatchWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(913, 424),
            scaleX = 200,
            scaleY = 100,
            tipsPos = cc.p(0, 0),
            delayTime = 0.8,
            tipsContent = WordDictionary[1560],
            relocation = 1,
        },
        { --点击第一个任务
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(912, 430),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("RandomDispatchWin")
                win.dispatchBtns[1]:onClick()
                doNext()
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(575, 395),
            scaleX = 400,
            scaleY = 200,
            tipsPos = cc.p(-350, -100),
            delayTime = 0.5,
            tipsContent = WordDictionary[1561],
            relocation = 1,
        },
        { --点击一键上阵
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(466, 80),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("DispatchWin")
                if win then
                    win.autoBtn:onClick()
                end
                doNext()
            end,
        },
         { --点击开始
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(660, 80),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("DispatchWin")
                if win then
                    win.fightBtn:onClick()
                end
                doNext()
            end,
        },
        -- { --点击关闭
        --     stepType = c.GUIDE_STEP_TYPE.CLICK,
        --     delayTime = 0.5,
        --     clickPos = cc.p(910, 512),
        --     scale = 200,
        --     clickFunc = function(doNext, guideWin)
        --         local win = display.getRunningScene().winManager:findWinByName("DispatchWin")
        --         if win then
        --             win:closeSelf()
        --         end
        --         doNext()
        --     end,
        -- },
        -- { --剧情对话
        --     stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
        --     sprite = "zhezhao-01.png",
        --     spritePos = cc.p(914, 42),
        --     scaleX = 350,
        --     scaleY = 60,
        --     tipsPos = cc.p(100, 0),
        --     delayTime = 0.5,
        --     tipsContent = WordDictionary[1562],
        --     relocation = 1,
        -- },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(308, 42),
            scaleX = 150,
            scaleY = 60,
            tipsPos = cc.p(100, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1563],
            relocation = 1,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(490, 42),
            scaleX = 300,
            scaleY = 60,
            tipsPos = cc.p(100, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1564],
            relocation = 1,
        },
        { --添加弱引导
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("RandomDispatchWin")
                if win then
                    win:addGuideAnim()
                end
                doNext()
            end,
        },
    },
    [16] = {
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            tipsPos = cc.p(-200, 50),
            delayTime = 0.5,
            tipsContent = WordDictionary[60152],
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-05.png",
            spritePos = cc.p(575, 125),
            scaleX = 170,
            scaleY = 250,
            tipsPos = cc.p(-200, 50),
            delayTime = 0.5,
            tipsContent = WordDictionary[60154],
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "renjieyuanzheng-zhezhao.png",
            spritePos = cc.p(575, 275),
            scaleX = 400,
            scaleY = 120,
            tipsPos = cc.p(-200, 50),
            delayTime = 0.5,
            tipsContent = WordDictionary[60153],
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "renjieyuanzheng-zhezhao.png",
            spritePos = cc.p(227, 545),
            scaleX = 50,
            scaleY = 50,
            tipsPos = cc.p(-200, 50),
            delayTime = 0.5,
            tipsContent = WordDictionary[60155],
        },
    },
    [17] = {----炼魂引导
        { --点击前往
            stepType = c.GUIDE_STEP_TYPE.CLICK,
            delayTime = 0.5,
            clickPos = cc.p(568, 100),
            scale = 200,
            clickFunc = function(doNext, guideWin)
                local win = display.getRunningScene().winManager:findWinByName("GetNewFunWin")
                if win then
                    win:closeSelf()
                end
                doNext()
            end,
        },
        { --切换场景
            stepType = c.GUIDE_STEP_TYPE.CHANGE_SCENE,
            changeScene = c.AfterLoading.mainScene,
            relocation = 1,
        },
        { --等待回城
            stepType = c.GUIDE_STEP_TYPE.CALLBACK,
            callback = function(doNext, guideWin)
                local action = guideWin:actionScheduleInterval(function()
                    local win = display.getRunningScene().winManager:findWinByName("MainWin")
                    if win then
                        guideWin:stopActionByTag(0XABC)
                        win:openWin("RecycleWin")
                        doNext()
                    end
                end,0.2)
                action:setTag(0XABC)
            end,
        },
        { --剧情对话
            stepType = c.GUIDE_STEP_TYPE.TIPS_LAYER,
            sprite = "zhezhao-01.png",
            spritePos = cc.p(568, 284),
            scaleX = 400,
            scaleY = 400,
            tipsPos = cc.p(-300, 0),
            delayTime = 0.5,
            tipsContent = WordDictionary[1569],
        },
    },
}


local changes = ""
for baseStep, value in pairs(configs) do
    local index = 0
    for k, v in ipairs(value) do
        local step = 1000 * baseStep + k
        GuideConf[step] = v
        if baseStep == 1 then
            if not v.newAdd then
                index = index + 1

                local pre = 1000 *baseStep + index
                if pre ~= step then
                    changes = changes .. pre .. " =>  " .. step .. "\n"
                end
            end
        end
    end
end

-- dump(GuideConf)

-- local file = io.open("GuideChanges.json", "w")
-- file:write(changes)
-- io.close(file)

return GuideConf