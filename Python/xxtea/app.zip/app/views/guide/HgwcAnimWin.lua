local WinBase = require "sandglass.core.WinBase"
local Helper = require "app.Helper"
local SpineManager = require "sandglass.core.SpineManager"
local c = require "app.configs.constants"
local RichLabel = require "sandglass.ui.RichLabel"
local WordDictionary = require "app.configs.WordDictionary"
local UIImageBox = require "sandglass.ui.UIImageBox"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local AudioManager = require "sandglass.core.AudioManager"

local HgwcAnimWin = class("HgwcAnimWin", WinBase)

local stepFunc = {
    "onStepOne",
    "onStepTwo",
    "onStepThree",
    "onStepFour",
    "onStepFive",
    "onStepSix",
    "onStepSeven",
    "onStepEight",
    "onStepNine",
}

function HgwcAnimWin:onCreate()
    self.showType = self.WinShowType.hiddenBack
    self.priority = c.WIN_ZORDER.POPUP
end

function HgwcAnimWin:initialView()
    self.shieldLayer_:setOpacity(255)

    self.curMusic = AudioManager.getCurMusic()
    AudioManager.playMusic("music/bgm_goldcave.mp3")

    self.bgButton = UIImageBox.new("guide/ui_huaguwuchang_bg.jpg", function(me)
        if self.curCanClick then
            self.curCanClick = false
            self:onNextStep()
        elseif self.dialogBg then
            if not self.dialoging then
                return
            end
            if self.dialogBg.isShowing then
                local textLabel = self.dialogBg:getChildByName("textLabel")
                textLabel:stopAllActions()
                textLabel:setString(textLabel.str)
                self.dialogBg.isShowing = false
                self.dialogBg:getChildByName("conLabel"):setVisible(true)
            else
                self.dialoging = false
                self:onNextStep()
            end
        end
    end, {noAnimEffect = true, ableGLProgram = false})
    display.align(self.bgButton, display.CENTER, 0, 0)
    self.bgButton:setScale(self.bgScale)
    -- self.bgButton:setColor(cc.c3b(0,0,0))
    self.bgButton:setOpacity(0)
    self:addChild(self.bgButton)

    self.curStep = 0
    self:onNextStep()
end

function HgwcAnimWin:closeSelf()
    AudioManager.playMusic(self.curMusic)
    HgwcAnimWin.super.closeSelf(self)
end

function HgwcAnimWin:onNextStep()
    self.curStep = self.curStep + 1
    if stepFunc[self.curStep] then
        self[stepFunc[self.curStep]](self)
    else
        self:closeSelf()
    end
end

function HgwcAnimWin:onStepOne()
    self.curCanClick = false ----
    local line_1 = RichLabel.new({
        fontColor = cc.c3b(255,255,255),
        fontSize = 20,
    })
    line_1:setString(WordDictionary[71900])
    line_1:setOpacity(0)
    display.align(line_1, display.CENTER, 0, 20)
    self:addChild(line_1)
    line_1:runAction(cc.Sequence:create(cc.FadeIn:create(1)))
    line_1:setName("line_1")
    local line_2 = RichLabel.new({
        fontColor = cc.c3b(255,255,255),
        fontSize = 20,
    })
    line_2:setString(WordDictionary[71901])
    line_2:setOpacity(0)
    display.align(line_2, display.CENTER, 0, -20)
    self:addChild(line_2)
    line_2:runAction(cc.Sequence:create(cc.DelayTime:create(2), cc.FadeIn:create(1), cc.DelayTime:create(2), cc.CallFunc:create(function()
        self:onNextStep()
    end)))
    line_2:setName("line_2")
end

function HgwcAnimWin:onStepTwo()
    self:getChildByName("line_1"):removeFromParent()
    self:getChildByName("line_2"):removeFromParent()


    self.bgAnim = SpineManager.createAnimation("guide/ui_cha_huagu_bg", 1)
    self.bgAnim:playAnimation("idle1", 1)
    self.bgAnim:appendNextAnimation("idle2", 1)
    self.bgAnim:addLuaHandler(function(eventName, animName, intValue, floatValue)
        if animName == "idle2" and eventName == "complete" then
            self.heroAnim:runAction(cc.FadeIn:create(2))
            self.heroAnim:playAnimation("idle1", -1)
        end
    end)
    self.bgAnim:appendNextAnimation("idle3", -1)
    self:addChild(self.bgAnim)

    self.heroAnim = SpineManager.createAnimation("guide/ui_cha_huagu",1)
    self.heroAnim:setPosition(cc.p(-display.width * 0.15, -display.height*0.4))
    self.heroAnim:setOpacity(0)
    self.heroAnim:setScale(1.3)
    self:addChild(self.heroAnim)

    self.bgButton:runAction(cc.Sequence:create(cc.FadeIn:create(2), cc.DelayTime:create(4), cc.CallFunc:create(function()
        self:onNextStep()
    end)))
end

function HgwcAnimWin:onStepThree()
    self:startSpeak(WordDictionary[71902], WordDictionary[71903])
end

function HgwcAnimWin:onStepFour()
    self:startSpeak(WordDictionary[71902], WordDictionary[71904])
end

function HgwcAnimWin:onStepFive()
    self.heroAnim:playAnimation("idle2", 1)
    self.heroAnim:appendNextAnimation("idle3", -1)
    self:runAction(cc.Sequence:create(cc.DelayTime:create(3), cc.CallFunc:create(function()
        self:onNextStep()
    end)))
end

function HgwcAnimWin:onStepSix()
    self:startSpeak(WordDictionary[71905], WordDictionary[71906])
end

function HgwcAnimWin:onStepSeven()
    self.heroAnim:playAnimation("idle4", 1)
    self.heroAnim:appendNextAnimation("idle5", -1)
    self:runAction(cc.Sequence:create(cc.DelayTime:create(2), cc.CallFunc:create(function()
        self.curCanClick = true
    end)))
end

function HgwcAnimWin:onStepEight()
    self.cover = UIImageBox.new("guide/ui_huaguwuchang_bg.jpg", function(me)
        
    end, {noAnimEffect = true, ableGLProgram = false})
    display.align(self.cover, display.CENTER, 0, 0)
    self.cover:setScale(self.bgScale)
    self.cover:setColor(cc.c3b(0,0,0))
    self.cover:setOpacity(0)
    self:addChild(self.cover, 99)
    self.cover:runAction(cc.Sequence:create(cc.FadeIn:create(3), cc.CallFunc:create(function()
        self:onNextStep()
    end)))
end

function HgwcAnimWin:onStepNine()
    if not PlayerConfig.getSetting("hgwcAnim", false) then
        network.tcpSend(msgids.C_PlotsTake, {Id = 3})
    end
    PlayerConfig.setSetting("hgwcAnim", true)
    self:onNextStep()
end

function HgwcAnimWin:startSpeak(name, str)
    if not self.dialogBg then
        self.dialogBg = UIImageBox.new("guide/duihua_di.png", function(me)
            if not self.dialoging then
                return
            end
            if me.isShowing then
                local textLabel = me:getChildByName("textLabel")
                textLabel:stopAllActions()
                textLabel:setString(textLabel.str)
                me.isShowing = false
                me:getChildByName("conLabel"):setVisible(true)
            else
                self.dialoging = false
                self:onNextStep()
            end
        end, {noAnimEffect = true, ableGLProgram = false, swallowTouches = false})
        local size = self.dialogBg:getContentSize()
        self.dialogBg:setScale9Enabled(true)
        self.dialogBg:setContentSize(cc.size(display.width*1.1, size.height))
        display.align(self.dialogBg, display.CENTER_BOTTOM, 0, -display.cy)
        self:addChild(self.dialogBg)
    end

    self.dialogBg:removeAllChildren()

    local conLabel = RichLabel.new({
        fontSize = 20,
        fontColor = cc.c3b(175,149,112),
    })
    conLabel:setString(WordDictionary[71907])
    conLabel:setName("conLabel")
    conLabel:setVisible(false)
    display.align(conLabel, display.RIGHT_TOP, display.width + 20, 140)
    self.dialogBg:addChild(conLabel)

    local spArrow = display.newSprite("guide/jiantou.png")
    spArrow:setScale(0.5)
    display.align(spArrow, display.RIGHT_CENTER, -conLabel:getContentSize().width, -14)
    conLabel:addChild(spArrow)

    local nameLabel = RichLabel.new({
        fontSize = 22,
        fontColor = cc.c3b(236,168,45),
    })
    nameLabel:setString(name)
    display.align(nameLabel, display.LEFT_TOP, 100, 140)
    self.dialogBg:addChild(nameLabel)
    local textLabel = RichLabel.new({
        fontSize = 20,
        maxWidth = display.width * 0.8,
        fontColor = cc.c3b(239,218,191),
    })
    textLabel:setName("textLabel")
    textLabel:setString("")
    textLabel.str = str
    display.align(textLabel, display.LEFT_TOP, display.width * 0.1, 100)
    self.dialogBg:addChild(textLabel)
    local length = 1
    self.dialoging = true
    textLabel:actionScheduleInterval(function()
        self.dialogBg.isShowing = true
        if length <= string.utf8len(textLabel.str) then
            local str = string.utf8sub(textLabel.str, 1, length)
            textLabel:setString(str)
            length = length + 1
        else
            self.dialogBg.isShowing = false
            textLabel:stopAllActions()
            conLabel:setVisible(true)
        end
    end, 0.05)
end

return HgwcAnimWin