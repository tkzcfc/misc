local c = require "app.configs.constants"

return {
	attacker = {
		{
			[1] = {
				--忍皇
				id = 20011,
				level = 1,
				star = 5,
				skin = "normal",
				props = {
					["attack"] = {a = 51233,b = 0,c = 0},
					["defense"] = {a = 20636,b = 0,c = 0},
					["maxLife"] = {a = 145000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[2] = {
				id = 20022,
				level = 1,
				star = 5,
				skin = "normal",
				props = {
					["attack"] = {a = 21233,b = 0,c = 0},
					["defense"] = {a = 20636,b = 0,c = 0},
					["maxLife"] = {a = 145000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[3] = {
				--剑圣
				id = 20019,
				level = 1,
				star = 5,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 72233,b = 0,c = 0},
					["defense"] = {a = 16636,b = 0,c = 0},
					["maxLife"] = {a = 16000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[4] = {
				--风十郎
				id = 20012,
				level = 1,
				star = 2,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 58233,b = 0,c = 0},
					["defense"] = {a = 20636,b = 0,c = 0},
					["maxLife"] = {a = 140000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[5] = {
				--千鹤流星
				id = 20015,
				level = 1,
				star = 5,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 13000,b = 0,c = 0},
					["defense"] = {a = 25636,b = 0,c = 0},
					["maxLife"] = {a = 140000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
		},
	},
	defender = {
		{
			[1] = {
				--小怪烟枪
				id = 11242,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 19233,b = 0,c = 0},
					["defense"] = {a = 136,b = 0,c = 0},
					["maxLife"] = {a = 10000,b = 0,c = 0},
					["speed"] = {a = 116,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[2] = {
				--小怪双剑
				id = 11292,
				level = 1,
				star = 2,
				props = {
					["attack"] = {a = 21233,b = 0,c = 0},
					["defense"] = {a = 136,b = 0,c = 0},
					["maxLife"] = {a = 6000,b = 0,c = 0},
					["speed"] = {a = 120,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[3] = {
				--小怪老头
				id = 11232,
				level = 1,
				star = 1,
				props = {
					["attack"] = {a = 100233,b = 0,c = 0},
					["defense"] = {a = 136,b = 0,c = 0},
					["maxLife"] = {a = 20000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[4] = {
				--小怪拳击
				id = 11052,
				level = 1,
				star = 1,
				props = {
					["attack"] = {a = 22233,b = 0,c = 0},
					["defense"] = {a = 136,b = 0,c = 0},
					["maxLife"] = {a = 21000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[5] = {
				--小怪铁扇
				id = 11072,
				level = 1,
				star = 1,
				props = {
					["attack"] = {a = 24233,b = 0,c = 0},
					["defense"] = {a = 136,b = 0,c = 0},
					["maxLife"] = {a = 20000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			
		},
		{
			[1] = {
			--天照帝
				id = 20041,
				level = 1,
				star = 1,
				skin = "upgrade5",
				props = {
					["attack"] = {a = 22233,b = 0,c = 0},
					["defense"] = {a = 136,b = 0,c = 0},
					["maxLife"] = {a = 990000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[2] = {
			--一品醉娘
				id = 20034,
				level = 1,
				star = 1,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 22233,b = 0,c = 0},
					["defense"] = {a = 136000,b = 0,c = 0},
					["maxLife"] = {a = 30000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 1,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[3] = {
			--朽木白灵
				id = 20027,
				level = 1,
				star = 1,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 22233,b = 0,c = 0},
					["defense"] = {a = 136000,b = 0,c = 0},
					["maxLife"] = {a = 28000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 0,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 1,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[4] = {
			--花京院幻心
				id = 20032,
				level = 1,
				star = 1,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 22233,b = 0,c = 0},
					["defense"] = {a = 136000,b = 0,c = 0},
					["maxLife"] = {a = 30000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 1,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[5] = {
			--蜂皇
				id = 20026,
				level = 1,
				star = 1,
				skin = "upgrade2",
				props = {
					["attack"] = {a = 22233,b = 0,c = 0},
					["defense"] = {a = 136000,b = 0,c = 0},
					["maxLife"] = {a = 30000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 0,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 1,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			}
		}
	},
	kami = {
		-- [c.UnitGroup.ATTACKER] = 1000,
		-- [c.UnitGroup.DEFENDER] = 1001,
	},
	
	params = {
		seed = 1004,
		bg = "background_11_1",
		bgMusic = {
            "battle",
        }
	},

}