
local init = require "app.models.init"
local GuideConf = require "app.views.guide.GuideConf"
local PlayerConfig = require "sandglass.core.PlayerConfig"
local network = require "app.network.network"
local msgids = require "app.network.msgids"

local PlayerModel = init.PlayerModel

local GuideManager = {}
local self = GuideManager

function GuideManager.initData()
	self.newbieStep = PlayerModel.info.step
	if self.newbieStep == 0 then self.newbieStep = 1001 end
	-- self.newbieStep = 8888---test---

	self.relocationNewbieStep()
end


function GuideManager.relocationNewbieStep()
	while(GuideConf[self.newbieStep] ~= nil) do
		local offset = GuideConf[self.newbieStep].relocation

		if offset ~= nil then
			self.newbieStep = self.newbieStep + offset
		else
			break
		end
	end
end

function GuideManager.setNewbieStep(step)
	self.newbieStep = step
end

function GuideManager.getNewbieStep()
	return self.newbieStep
end

function GuideManager.startGuide(scene, callback)
	local guideSetting = PlayerConfig.getSetting("guideOff", true) and not (PlayerModel.info.isWhite == 2) and not PlayerModel.info.isAudit
	if not guideSetting then return end
	
    if self.newbieStep>2000 then
       self.relocationNewbieStep() 
    end 
    if not GuideConf[self.newbieStep] then return end 
    self.callback = callback
	self.win = scene:openWin("GuideWin", self)
	self.win:start(self.newbieStep)
end

function GuideManager.next()
	self.increaseNewbieStep()
	print("==self.newbieStep==", self.newbieStep)

	if GuideConf[self.newbieStep] then
		self.win:start(self.newbieStep)
	else
		self.win:getScene().winManager:forceRemoveWin(self.win)
		if self.callback then
			self.callback()
		end
		self.increaseNewbieStep()
	end
end

function GuideManager.increaseNewbieStep()
	local conf = GuideConf[self.newbieStep]

	local data = {
		Step = self.newbieStep
	}
	if conf and conf.key then
		data.Key = conf.key
	end
	local step = math.modf(self.newbieStep/1000)
	if step == 3 then---比武场
		network.tcpSend(msgids.C_CloudSet,{Key="arenaStep",Val=tostring(self.newbieStep)})
	elseif step == 4 then ---自动战斗
		network.tcpSend(msgids.C_CloudSet,{Key="autoFightStep",Val=tostring(self.newbieStep)})
	elseif step == 5 then ---家族
		network.tcpSend(msgids.C_CloudSet,{Key="familyStep",Val=tostring(self.newbieStep)})
	elseif step == 6 then ---矿战
		network.tcpSend(msgids.C_CloudSet,{Key="mineWarStep",Val=tostring(self.newbieStep)})
	elseif step == 7 then ---幻化神
		network.tcpSend(msgids.C_CloudSet,{Key="kamiStep",Val=tostring(self.newbieStep)})
	elseif step == 8 then ---战斗加速
		network.tcpSend(msgids.C_CloudSet,{Key="fightSpeedupStep",Val=tostring(self.newbieStep)})
	elseif step == 9 then ---地图宝箱
		network.tcpSend(msgids.C_CloudSet,{Key="MapBoxStep",Val=tostring(self.newbieStep)})
	elseif step == 1 then ---开始新手
		network.tcpSend(msgids.C_TutorialSet, data)
	end
	self.newbieStep = self.newbieStep + 1 
end

function GuideManager.getConfigValue()
	return GuideConf[self.newbieStep]
end

function GuideManager.changeScene(scene)
	self.increaseNewbieStep()

	local app = display.getRunningScene():getChildByName("ViewBase"):getApp()
    app:enterScene("LoadingScene",{afterLoading = scene})
end

function GuideManager.changeSpecicalScene(scene, data)
	self.increaseNewbieStep()
	local app = display.getRunningScene():getChildByName("ViewBase"):getApp()
	app:enterScene(scene, data)
end

function GuideManager.getCurConf()
	return GuideConf[self.newbieStep]
end

return GuideManager