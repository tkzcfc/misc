local c = require "app.configs.constants"

return {
    attacker = {
        {
            [1] = {
                --风十郎
                id = 20012,
                level = 1,
                star = 2,
                skin = "normal",
                props = {
                    ["attack"] = {a = 2500,b = 0,c = 0},
                    ["defense"] = {a = 1200,b = 0,c = 0},
                    ["maxLife"] = {a = 3000,b = 0,c = 0},
                    ["speed"] = {a = 500,b = 0,c = 0},

                    ["crit"] = {a = 0,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 1000,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 1000,b = 1000,c = 1000},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
                curMp = 500,
            },
            --大荒剑士
            [2] = {
                id = 20005,
                level = 1,
                star = 5,
                skin = "normal",
                props = {
                    ["attack"] = {a = 2000,b = 0,c = 0},
                    ["defense"] = {a = 500,b = 0,c = 0},
                    ["maxLife"] = {a = 2000,b = 0,c = 0},
                    ["speed"] = {a = 500,b = 0,c = 0},

                    ["crit"] = {a = 0,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 1000,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 0,b = 0,c = 0},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
                curMp = 500,
            },
            --千本樱
            [3] = {
                id = 20014,
                level = 1,
                star = 5,
                skin = "normal",
                props = {
                    ["attack"] = {a = 2600,b = 0,c = 0},
                    ["defense"] = {a = 500,b = 0,c = 0},
                    ["maxLife"] = {a = 2000,b = 0,c = 0},
                    ["speed"] = {a = 500,b = 0,c = 0},

                    ["crit"] = {a = 0,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 1000,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 0,b = 0,c = 0},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
                curMp = 500,
            },
        },
    },
    defender = {
        {
            [1] = {
                --黑影刀
                id = 13001,
                level = 1,
                star = 5,
                props = {
                    ["attack"] = {a = 1000,b = 0,c = 0},
                    ["defense"] = {a = 1800,b = 0,c = 0},
                    ["maxLife"] = {a = 27000,b = 0,c = 0},
                    ["speed"] = {a = 116,b = 0,c = 0},

                    ["crit"] = {a = 100,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 0,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 0,b = 0,c = 0},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
            },
            [2] = {
                --黑影刀
                id = 13001,
                level = 1,
                star = 5,
                props = {
                    ["attack"] = {a = 1000,b = 0,c = 0},
                    ["defense"] = {a = 1000,b = 0,c = 0},
                    ["maxLife"] = {a = 25000,b = 0,c = 0},
                    ["speed"] = {a = 120,b = 0,c = 0},

                    ["crit"] = {a = 100,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 0,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 0,b = 0,c = 0},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
            },
            [3] = {
                --黑影法师
                id = 13002,
                level = 1,
                star = 5,
                props = {
                    ["attack"] = {a = 1000,b = 0,c = 0},
                    ["defense"] = {a = 1000,b = 0,c = 0},
                    ["maxLife"] = {a = 25000,b = 0,c = 0},
                    ["speed"] = {a = 115,b = 0,c = 0},

                    ["crit"] = {a = 100,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 0,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 0,b = 0,c = 0},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
            },
            [5] = {
                --黑影法师
                id = 13002,
                level = 1,
                star = 1,
                props = {
                    ["attack"] = {a = 1000,b = 0,c = 0},
                    ["defense"] = {a = 1000,b = 0,c = 0},
                    ["maxLife"] = {a = 25000,b = 0,c = 0},
                    ["speed"] = {a = 115,b = 0,c = 0},

                    ["crit"] = {a = 100,b = 0,c = 0},
                    ["critDamage"] = {a = 1.5,b = 0,c = 0},
                    ["hit"] = {a = 1000,b = 0,c = 0},
                    ["dodge"] = {a = 0,b = 0,c = 0},
                    
                    ["lifePerHit"] = {a = 0,b = 0,c = 0},
                    ["energy"] = {a = 0,b = 0,c = 0},

                    ["damageRatio"] = {a = 1,b = 0,c = 0},
                    ["healingRatio"] = {a = 1,b = 0,c = 0},
                    ["critOdds"] = {a = 0,b = 0,c = 0},
                    ["calmOdds"] = {a = 0,b = 0,c = 0},
                    ["lifePerRound"] = {a = 0,b = 0,c = 0},
                    ["energyPerRound"] = {a = 0,b = 0,c = 0},
                    ["effectHit"] = {a = 0,b = 0,c = 0},
                    ["effectDodge"] = {a = 0,b = 0,c = 0},
                    ["cureRatio"] = {a = 0,b = 0,c = 0},
                    ["addCure"] = {a = 0,b = 0,c = 0},
                    ["damageUpRatio"] = {a = 1, b = 0, c = 0},
                },
                armors = {},
            },
        },
    },
    kami = {
        [c.UnitGroup.ATTACKER] = {
            id = 1,
            skin = 40001,
            astSkill = {},
        },
    },
    levelId = 20021,
    round = 3,
    kamiAttack = 40000,
    params = {
        seed = 1004,
    },

}