local c = require "app.configs.constants"
local BattleController = require "app.battle.controllers.BattleController"
local GameScene = require "app.battle.views.GameScene"
local WordDictionary = require "app.configs.WordDictionary"
local UILabel = require "sandglass.ui.UILabel"
local SpineManager = require "sandglass.core.SpineManager"
local TeamController = require "app.battle.controllers.TeamController"
local spineConf = require "app.configs.spine"
local AudioManager = require "sandglass.core.AudioManager"
local battleConf = require "app.configs.battle"
local msgids = require "app.network.msgids"
local network = require "app.network.network"

local fightZOrder = {
    bg = -1,
    pos_height = display.height, --英雄最高站位
    bullet = 10000, --子弹层级
    black_layer = 20000, --黑屏层级
    anim_powermax = 20001, --英雄释放大招定屏层级
    powermax_effect = 20002, --英雄释放大招水墨画层级
    kami = 20003, -- 幻化神
    god = 20004, -- 御神
}

local SupportScene = class("SupportScene", GameScene)

SupportScene.RESOURCE_FILENAME = "fight/fight.csb"

local steps = {
    {func = "hideAtkHp", params = {{1,2,3}, 0.5}},
    {func = "showHero", params = {{1,2}, false, 1}},
    {func = "speak", params={c.UnitGroup.DEFENDER, 1, WordDictionary[1020], 1}},
    {func = "speak", params={c.UnitGroup.DEFENDER, 1, WordDictionary[1021], 1.5}},
    {func = "showBoss", params = {4, 0.2}},
    {func = "useSkill", params = {c.UnitGroup.DEFENDER, 4, 60561, 2.5}},
    {func = "HeroFall", params = {c.UnitGroup.ATTACKER, 3, 0.1}},
    {func = "HeroFall", params = {c.UnitGroup.ATTACKER, 2, 0.1}},
    {func = "HeroFall", params = {c.UnitGroup.ATTACKER, 1, 1}},
    {func = "showHero", params = {{4}, true, 1}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 4, WordDictionary[1022], 1.5}},
    {func = "speak", params={c.UnitGroup.ATTACKER, 4, WordDictionary[1023], 2}},
    {func = "useSkill", params = {c.UnitGroup.ATTACKER, 4, 12214, 6}},
    {func = "result", params = {}},
}

function SupportScene:onCreate(data)
    self.data = data
    self.data.fightStatus = c.FightStatus.specialLevel
    self.steps = clone(steps)
    SupportScene.super.onCreate(self, data)
    self.speed = 2
    self.data.bg = battleConf[data.levelId].background
    self.data.bgMusic = battleConf[data.levelId].battleMusic
    self.bg:setTexture("battleBackground/"..self.data.bg..".png")
    AudioManager.playMusic("music/" .. self.data.bgMusic[1])
    self.resourceNode_:getChildByName("node_lt"):setVisible(false)
    self.resourceNode_:getChildByName("node_rb"):setVisible(false)
end

function SupportScene:chackStep()
    local info = self.steps[1]
    if not info then
        return
    end
    self[info.func](self, unpack(checktable(info.params)))
    table.remove(self.steps,1)
end

function SupportScene:HideUILayer(hide)
    self.resourceNode_:getChildByName("node_rt"):setVisible(hide)
    self.resourceNode_:getChildByName("node_cb"):setVisible(hide)
    self.resourceNode_:getChildByName("kamiNode"):setVisible(hide)
    if self.topNode then
       self.topNode:setVisible(false) 
    end
end

function SupportScene:setGameState(state)
    if state == c.GameState.NEXT_WAVE then
        BattleController.manualLogic = true
        self:HideUILayer(false)
        -- 清除死亡单位spine
        local uids = table.keys(self.anims)
        for _, uid in pairs(uids) do
            if BattleController.units[uid] == nil then
                self.anims[uid]:removeFromParent()
                self.anims[uid] = nil
            end
        end
        self:delayNextStep(0)
    end
end

function SupportScene:delayNextStep(delayTime)
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(delayTime),
        cc.CallFunc:create(function()
            self:chackStep()
        end)
    ))
end

function SupportScene:chackStep()
    local info = self.steps[1]
    if not info then
        return
    end
    self[info.func](self, unpack(checktable(info.params)))
    table.remove(self.steps,1)
end

function SupportScene:showHero(order, isAtk, delayTime)
    local uids = {}
    local tData = isAtk and self.data.attacker[2] or self.data.defender[2] 
    for k,index in pairs(order) do
        for _order, info in pairs(tData) do
            if _order == index then
                local unit = TeamController.createUnit(info)
                unit.order = _order
                unit.group = isAtk and c.UnitGroup.ATTACKER or c.UnitGroup.DEFENDER
                BattleController.addUnit(unit)
                table.insert(uids,unit.uid)
                break
            end
        end
    end
    self:showAppear({uids},function()
        self:delayNextStep(delayTime)
    end)
end

function SupportScene:hideAtkHp(order,delayTime)
    for _,index in pairs(order) do
        for _, unit in pairs(BattleController.units) do
            if unit.group == c.UnitGroup.ATTACKER and unit.order == index then
                local anim = self.anims[unit.uid]
                if anim and anim:getChildFollowBone("hp_point") then
                    local hpNode = anim:getChildFollowBone("hp_point")
                    hpNode:getChildByName("hpBsg"):setVisible(false)
                    hpNode:getChildByName("hpBar"):setVisible(false)
                    hpNode:getChildByName("energyBar"):setVisible(false)
                end
                break
            end
        end
    end
    self:delayNextStep(delayTime)
end

function SupportScene:speak(group, order, str, delayTime)
    local keepTime = 2

    local target = nil
    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order then
            target = unit
            break
        end
    end

    if not target then
        return
    end

    local anim = self.anims[target.uid]

    local textLabel = UILabel.new({
        text = str,
        size = 16,
    })
    textLabel:setAnchorPoint(cc.p(0, 1))
    local size = textLabel:getContentSize()
    if size.width > 200 then
        textLabel:setTextAreaSize(cc.size(200, 0))
        textLabel:setString(str)
        size = textLabel:getContentSize()
    end 
    local bgSize = cc.size(size.width + 36, size.height + 10)
    local spBg = display.newSprite("common/qipao_3gongge.png", 0, 0, {scale9 = true, size = bgSize})
    textLabel:setString("")
    textLabel.str = str

    local pos = anim:getBonePosition("hp_point")
    spBg:setName("speakNode_"..order)  

    spBg:runAction(cc.Sequence:create(
        cc.ScaleTo:create(0.15,1.2),
        cc.ScaleTo:create(0.15, 1)
    ))

    if group == c.UnitGroup.ATTACKER then
        spBg:setPosition(cc.p(pos.x + bgSize.width/2, pos.y))
        textLabel:setPosition(cc.p(pos.x + 28, pos.y + size.height/2))
    else
        spBg:setFlippedX(true)
        spBg:setPosition(cc.p(pos.x - bgSize.width/2, pos.y))
        textLabel:setPosition(cc.p(pos.x - bgSize.width + 10, pos.y + size.height/2))
    end

    self.resourceNode_:getChildByName("heroNode"):addChild(spBg, anim:getLocalZOrder())
    self.resourceNode_:getChildByName("heroNode"):addChild(textLabel, anim:getLocalZOrder())

    local length = 1
    textLabel:actionScheduleInterval(function()
        if length <= string.len(textLabel.str) then
            local str = string.utf8sub(textLabel.str, 1, length)
            textLabel:setString("")
            textLabel:setString(str)
            length = length + 1
        end
    end, 0.05)

    spBg:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.RemoveSelf:create()))
    textLabel:runAction(cc.Sequence:create(cc.DelayTime:create(keepTime), cc.RemoveSelf:create()))
    self:delayNextStep(delayTime)
end

function SupportScene:useSkill(group, order, skillId, delayTime)
    local target = nil
    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order and unit.state == c.UnitState.IDLE then
            target = unit
            break
        end
    end

    if target then
        local unitSkill = TeamController.newUnitSkill(target, skillId)
        if target:setState(c.UnitState.ATTACK) then
            target.curSkill = unitSkill
            unitSkill:start()
        end
    end

    self:delayNextStep(delayTime)
end

function SupportScene:showBoss(index, delayTime)
    local uid = nil
    local first = true
    for _order, info in pairs(self.data.defender[2] ) do
        if _order == index then
            local unit = TeamController.createUnit(info)
            unit.order = _order
            unit.group = c.UnitGroup.DEFENDER
            BattleController.addUnit(unit)
            uid = unit.uid
            break
        end
    end

    local anim = self.anims[uid]
    anim:setVisible(false)
    local posX, posY = anim:getPosition()
    local showAnim = SpineManager.createAnimation("public/ui_chouka_chuyingxiong", 1)
    showAnim:setPosition(posX, posY)
    anim:getParent():addChild(showAnim, anim:getLocalZOrder())
    local hpNode = anim:getChildFollowBone("hp_point")
    hpNode:setPositionY(hpNode:getPositionY() - 50)

    showAnim:playAnimation("idle", 1)
    showAnim:setAutoRemove(true)
    showAnim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "trigger" then
            anim:setVisible(true)
            anim:playAnimation("appear", 1)
        end
    end)

    anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        if eventName == "trigger" then
        elseif eventName == "duang_start" then
            self:startShake(intValue * 2)
        elseif eventName == "duang_end" then
            if first then
                first = false
                self:delayNextStep(delayTime)
            end
            self:stopShake()
        end
    end)


end

function SupportScene:HeroFall(group, order, delayTime)
    local target = nil
    for _, unit in pairs(BattleController.units) do
        if unit.group == group and unit.order == order then
            target = unit
            break
        end
    end
    if not target then
        return
    end
    local anim = self.anims[target.uid]
    anim:playAnimation("knee", 1)

    self:delayNextStep(delayTime)
end


function SupportScene:result()
    local team = {20012}
    local data = {
        LevelId = self.data.levelId,
        Team = team,
        Result = c.GameState.ATTACK_WIN,
    }
    network.tcpSend(msgids.C_WLevelFightNormal, data)
    local openResultWin = function(self, op, data)
        BattleController.pause()
        self:openWin("ResultVictoryWin",{rewards = data.Rewards, fightStatus = c.FightStatus.ordinary})
        AudioManager.stopMusic()
    end
    network.addListener(self, {msgids.GS_WLevelFightNormal_R}, handler(self, openResultWin))
end

return SupportScene