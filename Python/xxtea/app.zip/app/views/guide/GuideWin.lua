local WinBase = require "sandglass.core.WinBase"
local c = require "app.configs.constants"
local GuideConf = require "app.views.guide.GuideConf"
local VideoLayer = require "app.views.scene.VideoLayer"
local UIAniButton = require "sandglass.ui.UIAniButton"
local AudioManager = require "sandglass.core.AudioManager"
local SpineManager = require "sandglass.core.SpineManager"
local SDKController = require "app.sdk.SDKController"
local UIImageBox = require "sandglass.ui.UIImageBox"

local GuideWin = class("GuideWin", WinBase)

function GuideWin:onCreate(guideManager)
    self.priority = c.WIN_ZORDER.GUIDE
    self.showType = self.WinShowType.normal + self.WinShowType.canNotClose
    self.manager = guideManager
end

function GuideWin:onExit()
end

function GuideWin:start(step)
    self:removeAllChildren()
    local stepConf = GuideConf[step]
    local stepType = stepConf.stepType
    if stepType == c.GUIDE_STEP_TYPE.VIDEO then
        self:startVideo(stepConf)
    elseif stepType == c.GUIDE_STEP_TYPE.DIALOGUE then
        self:startDialogue(stepConf)
    elseif stepType == c.GUIDE_STEP_TYPE.CLICK then
        self:startClick(stepConf)
    elseif stepType == c.GUIDE_STEP_TYPE.CHANGE_SCENE then
        self:changeScene(stepConf)
    elseif stepType == c.GUIDE_STEP_TYPE.TIPS_LAYER then
        self:startTipsLayer(stepConf)
    elseif stepType == c.GUIDE_STEP_TYPE.CALLBACK then
        self:startCallback(stepConf)
    end

    if stepConf.submitData then
        local sdkHelper = SDKController.getSDKHelper()
        sdkHelper:submitData(SDKController.GUIDE_POINT)
    end
end

function GuideWin:startVideo(stepConf)
    local blackLayer = cc.LayerColor:create(cc.c4b( 0, 0, 0, 255))
    self:addChild(blackLayer)
    AudioManager.stopMusic()
    local video = VideoLayer.new(stepConf.videoPath, function()
        if stepConf.callbackMusic then
            AudioManager.playMusic(stepConf.callbackMusic)
        end
        self.manager.next()        
    end, stepConf.skipTime)
    self:addChild(video)
end

function GuideWin:startDialogue(stepConf)
    self:openWin("DuplicateDialogWin",stepConf.dialog,function()
        self.manager.next()
    end)
end

function GuideWin:startClick(stepConf)
    local function showFinger()
        local render = cc.RenderTexture:create(display.width, display.height)
        self:addChild(render)

        local sprite = display.newSprite("public/range.png")

        sprite:setBlendFunc(cc.blendFunc(gl.ZERO, gl.ONE_MINUS_SRC_ALPHA))

        local clickPos = stepConf.clickPos

        if stepConf.clickType and stepConf.clickType == "OutsideScrollWin" then
            clickPos = display.getRunningScene().winManager:findWinByName("OutsideScrollWin"):transitionHexToWorld(stepConf.clickPos)
        else
            clickPos = self:convertPosition(clickPos, true)
        end
        sprite:setPosition(clickPos)

        if stepConf.scaleX then
            sprite:setScaleX(stepConf.scaleX / sprite:getContentSize().width)
        end

        if stepConf.scaleY then
            sprite:setScaleY(stepConf.scaleY / sprite:getContentSize().height)
        end

        if stepConf.scale then
            sprite:setScale(stepConf.scale / sprite:getContentSize().width)
        end
        local coverLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 25))

        render:beginWithClear(0, 0, 0, 0)
        coverLayer:visit()
        sprite:visit()
        render:endToLua()

        render:setVisible(false)
        if not stepConf.notShowRender then
            render:setVisible(true)
        end
        -----光圈spine
        local circle = SpineManager.createAnimation("public/ui_xinshou_dianjitishikuang_yuan",1)
        circle:playAnimation("idle", -1)
        display.align(circle, display.CENTER, clickPos.x, clickPos.y)
        self:addChild(circle)
        -----全屏点击
        self.finger = UIImageBox.new("public/tongyong-beijing.png", function(me)
            if me.firstClick then
                me.firstClick = false
                if stepConf.clickMusic then
                    AudioManager.playEffect(stepConf.clickMusic)
                end
                if stepConf.clickFunc then
                    stepConf.clickFunc(function()
                        self.manager.next()
                    end, self)
                else
                    self.manager.next()
                end
            end
        end, {swallowTouches = stepConf.fingerTouches, ableGLProgram = false, noAnimEffect = true})
        self.finger.firstClick = true
        display.align(self.finger, display.CENTER, 0, 0)
        self.finger:setScale(self.bgScale)
        self.finger:setOpacity(0)
        self:addChild(self.finger)

        -- self.finger = UIAniButton.new("public/ui_xinshou_dianjitishikuang_yuan", function(eventType, me)
        --     if eventType == "ended" then
        --         if me.firstClick then
        --             me.firstClick = false
        --             if stepConf.clickMusic then
        --                 AudioManager.playEffect(stepConf.clickMusic)
        --             end
        --             if stepConf.clickFunc then
        --                 stepConf.clickFunc(function()
        --                     self.manager.next()
        --                 end, self)
        --             else
        --                 self.manager.next()
        --             end
        --         end
        --     elseif eventType == "cancelled" then
        --         if stepConf.cancelled then
        --             stepConf.cancelled()
        --         end
        --     end
        -- end, {swallowTouches = stepConf.fingerTouches,contentRect = stepConf.contentRect})
        -- self.finger.firstClick = true
        -- display.align(self.finger, display.CENTER, clickPos.x, clickPos.y)
        -- self:addChild(self.finger)

        ---大光圈spine
        local anim = SpineManager.createAnimation("guide/ui_ty_shoushousuodingkuang",1)
        anim:playAnimation("idle")
        anim:setAutoRemove(true)
        display.align(anim, display.CENTER, clickPos.x, clickPos.y)
        self:addChild(anim)

        if stepConf.consecutive then
            local sprite = display.newSprite("guide/xinshou-kuaisudianji.png")
            display.align(sprite, display.CENTER, clickPos.x-150, clickPos.y+10)
            self:addChild(sprite)
            sprite:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.MoveBy:create(1, cc.p(-5, 0)), cc.MoveBy:create(1, cc.p(5,0)))))
        end
    end

    if stepConf.delayTime then
        self:runAction(cc.Sequence:create(
            cc.DelayTime:create(stepConf.delayTime),
            cc.CallFunc:create(showFinger)
        ))
    else
        showFinger()
    end
end

function GuideWin:changeScene(stepConf)
    self.manager.changeScene(stepConf.changeScene)
end

function GuideWin:changeSpecicalScene(scene, data)
    self.manager.changeSpecicalScene(scene, data)
end


function GuideWin:startTipsLayer(stepConf)
    local RichLabel = require "sandglass.ui.RichLabel"
    local BattleController = require "app.battle.controllers.BattleController"
    local function showLayer()
        if stepConf.pauseBattle then
            BattleController.pause()
        end

        local render = cc.RenderTexture:create(display.width, display.height)
        render:setPosition(0, 0)
        self:addChild(render)

        local coverLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 225))
        render:beginWithClear(0, 0, 0, 0)
        coverLayer:visit()

        if stepConf.sprite then
            local sprite = nil
            if stepConf.scale then
                sprite = display.newSprite("public/"..stepConf.sprite)
                sprite:setScale(self.uiScale * stepConf.scale)
            else
                sprite = display.newSprite("public/"..stepConf.sprite,{scale9 = true, size = cc.size(stepConf.scaleX,stepConf.scaleY)})
                sprite:setScale(self.uiScale)
            end
            sprite:setPosition(self:convertPosition(stepConf.spritePos))
            sprite:setBlendFunc(cc.blendFunc(gl.ZERO, gl.ONE_MINUS_SRC_ALPHA))
            sprite:visit()
        end

        render:endToLua()
        render:setVisible(false)
        if not stepConf.notShowRender then
            render:setVisible(true)
        end

        local listener = cc.EventListenerTouchOneByOne:create()
        listener:setSwallowTouches(true)
        listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
        listener:registerScriptHandler(handler(self, function() end), cc.Handler.EVENT_TOUCH_MOVED)
        listener:registerScriptHandler(handler(self, function()
            if stepConf.pauseBattle then
                BattleController.pause()
            end

            if self.effectId then
                AudioManager.stopEffect(self.effectId)
                self.effectId = nil
            end

            self.manager.next()

        end), cc.Handler.EVENT_TOUCH_ENDED)
        
        local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, render)


        local tipsNode = cc.CSLoader:createNode("guide/tipsNode.csb")
        tipsNode:setName("tipsNode")
        tipsNode:setPosition(stepConf.tipsPos)
        self:addChild(tipsNode)

        -- local anim = SpineManager.createAnimation("public/ui_xinshouxiaoren",1)
        -- anim:playAnimation("idle", -1)
        -- tipsNode:getChildByName("node_spine"):addChild(anim)

        local scrollView = tipsNode:getChildByName("node"):getChildByName("scrollView")
        scrollView:setScrollBarEnabled(false)
        local maxWidth = scrollView:getContentSize().width
        scrollView:setSwallowTouches(true)
        local text = RichLabel.new {
            fontSize = 16,
            lineSpace = 3,
            maxWidth = maxWidth,
            fontColor = cc.c3b(47, 8, 8),
        }
        text:setString(stepConf.tipsContent)
        local lableSize = text:getContentSize()
        local listSize = scrollView:getContentSize()
        if lableSize.height > listSize.height then
            display.align(text,display.LEFT_TOP, 0, lableSize.height)
        else
            display.align(text,display.LEFT_CENTER, 0, listSize.height/2)
        end
        scrollView:setInnerContainerSize(cc.size(listSize.width, lableSize.height))
        scrollView:addChild(text)

        tipsNode:setScale(0)
        tipsNode:getChildByName("node"):setScale(0)
        tipsNode:runAction(cc.Sequence:create(
            cc.EaseBackOut:create(cc.ScaleTo:create(0.3, self.uiScale)),
            cc.CallFunc:create(function()
                if stepConf.sound then
                    self.effectId = AudioManager.playEffect("music/dialogSound/" .. stepConf.sound)
                end
                tipsNode:getChildByName("node"):runAction(cc.Sequence:create(
                    cc.EaseElasticOut:create(cc.ScaleTo:create(1, 1), 0.5),
                    cc.CallFunc:create(function()
                    end)
                ))
            end)
        ))

        -- local listview_content = tipsNode:getChildByName("ListView_Content")
        -- listview_content:setSwallowTouches(true)
        -- local anim = SpineManager.createAnimation("guide/ui_xinshouduihuakuang",1)
        -- anim:playAnimation("idle1", 1)
        -- anim:appendNextAnimation("idle2", -1)
        -- anim:addLuaHandler(function (eventName, animName, intValue, floatValue)
        --     if eventName == "trigger" then
        --         tipsNode:getChildByName("sp_miao"):setVisible(true)
        --         local text = RichLabel.new {
        --             fontSize = 20,
        --             lineSpace = 3,
        --             maxWidth = 230,
        --             fontColor = cc.c3b(54, 50, 45),
        --         }

        --         listview_content:addChild(text)
        --         text:setString(stepConf.tipsContent)

        --         local lableSize = text:getContentSize()
        --         if listview_content:getContentSize().height < lableSize.height then
        --             display.align(text,display.CENTER,280* 0.5,lableSize.height*0.5 - 3)
        --             listview_content:setInnerContainerSize(cc.size(280, lableSize.height))
        --         else
        --             display.align(text,display.CENTER,280* 0.5,listview_content:getContentSize().height*0.5)
        --             listview_content:setInnerContainerSize(cc.size(280, listview_content:getContentSize().height))
        --         end
        --     end
        -- end)
        -- tipsNode:getChildByName("node_spine"):addChild(anim)
        
        AudioManager.playEffect("music/ui_xinshoubattletip.mp3")
    end

    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(stepConf.delayTime),
        cc.CallFunc:create(showLayer)
    ))
end

function GuideWin:convertPosition(pos, isCenter)
    local x = pos.x / CC_DESIGN_RESOLUTION.width * display.width - (isCenter and display.cx or 0)
    local y = pos.y / CC_DESIGN_RESOLUTION.height * display.height - (isCenter and display.cy or 0)
    return cc.p(x, y)
end



function GuideWin:startCallback(stepConf)
    stepConf.callback(function()
        self.manager.next()
    end, self)
end

return GuideWin