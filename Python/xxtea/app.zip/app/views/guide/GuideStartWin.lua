
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local SpineManager = require "sandglass.core.SpineManager"

local GuideStartWin = class("GuideStartWin", WinBase)
GuideStartWin.RESOURCE_FILENAME = "guide/guideStart.csb"

function GuideStartWin:onCreate(path, canClose)
    self.priority = c.WIN_ZORDER.POPUP
    self.path = path
    self.canClose = canClose
end

function GuideStartWin:initialView()
    self.resourceNode_:getChildByName("sp_bg"):setTexture(self.path)

    if self.canClose then
        self.resourceNode_:runAction(cc.Sequence:create(
            cc.DelayTime:create(0.5), 
            cc.CallFunc:create(function()
                local listener = cc.EventListenerTouchOneByOne:create()
                listener:setSwallowTouches(true)
                listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_BEGAN)
                listener:registerScriptHandler(handler(self, function() return true end), cc.Handler.EVENT_TOUCH_MOVED)
                listener:registerScriptHandler(handler(self, function()
                    listener:setEnabled(false)
                    self:closeSelf()
                end), cc.Handler.EVENT_TOUCH_ENDED)
                        
                local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
                eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.resourceNode_)
            end)
        ))
    end
end

function GuideStartWin:getActionIn()
    Helper.enterWinAction1(self)
end

return GuideStartWin