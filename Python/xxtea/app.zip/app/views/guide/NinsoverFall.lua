local GameScene = require "app.battle.views.GameScene"
local BuffController = require "app.battle.controllers.BuffController"
local BattleController = require "app.battle.controllers.BattleController"
local SpineManager = require "sandglass.core.SpineManager"
local TeamController = require "app.battle.controllers.TeamController"
local spineConf = require "app.configs.spine"
local AudioManager = require "sandglass.core.AudioManager"

local c = require "app.configs.constants"

local NinsoverFall = class("NinsoverFall", GameScene)

NinsoverFall.RESOURCE_FILENAME = "layer/fight/fight.csb"

function NinsoverFall:onCreate()
	NinsoverFall.super.onCreate(self)
	self.bg:setTexture("battleBackground/background_11_3.png")
	self.steps = clone(steps)

	--BattleController.manualLogic = true
    local xinshouBk = SpineManager.createAnimation("public/xinshou_bg")
	xinshouBk:setPosition(display.cx,display.cy)
    xinshouBk:playAnimation("idle", -1)
    xinshouBk:setScale(1/0.8)
    self.bg:addChild(xinshouBk)
	AudioManager.playMusic("music/bgm_renhuangbattle.mp3")

	self.resourceNode_:getChildByName("kamiNode"):setVisible(true)
    self:hideBtn()
end

function NinsoverFall:hideBtn()
	self.resourceNode_:getChildByName("uiNode"):getChildByName("pauseBtn"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("speedBtn"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("speedLight"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("autoBtn"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("autoLight"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("speedText"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("autoText"):setVisible(false)
	self.resourceNode_:getChildByName("uiNode"):getChildByName("speedBarNode"):setVisible(false)
end


--变身
function NinsoverFall:transfiguration(group,order)
	local target = nil
	for _, unit in pairs(BattleController.units) do
		if unit.group == group and unit.order == order then
			target = unit
			break
		end
	end

	if not target then
		return
	end
	local anim = self.anims[target.uid]
	local appearEffect = "spine/effect/common_bianshen"

	local commonAnim = SpineManager.createAnimation(appearEffect,nil , true)
    commonAnim:playAnimation("idle", 1)
    anim:addChild(commonAnim)
    self.effects[#self.effects + 1] = commonAnim
    AudioManager.playEffect("music/tianzhao_bianshen.mp3")
    anim:unregisterAllSkin()
    anim:registerSkin("upgrade2")
end

--使用技能
function NinsoverFall:useSkill(group,order,skillId)
	local target = nil
	for _, unit in pairs(BattleController.units) do
		if unit.group == group and unit.order == order then
			target = unit
			break
		end
	end

	if not target then
		return
	end

	local unitSkill = TeamController.newUnitSkill(target, skillId)
	unitSkill.isExtra = false
	if target:setState(c.UnitState.ATTACK) then
		target.curSkill = unitSkill
		unitSkill:start()
	end
end

function NinsoverFall:kazeDown()
	local target = nil
	for _, unit in pairs(BattleController.units) do
		if unit.group == c.UnitGroup.ATTACKER and unit.order == 4 then
			target = unit
			break
		end
	end

	if not target then
		return
	end

	local anim = self.anims[target.uid]
	anim:clearAction()
	anim:playAnimation("die2", -1)
end

--出现屠神之刃
function NinsoverFall:showUltimate()
	local anim = SpineManager.createAnimation("public/xinshou_shishenzhiren")
	anim:playAnimation("idle1")
	anim:appendNextAnimation("idle2", -1)
	anim:setScale(1.3)
	anim:addLuaHandler(function(eventName, animName, intValue, floatValue)
        if eventName == "duang_start" and intValue then
            self:startShake(intValue)
        elseif eventName == "duang_end" then
        	self:stopShake()
        end
    end)
	self.resourceNode_:getChildByName("heroNode"):addChild(anim, 20002)
	anim:setPosition(display.cx,display.cy)
	self.ultimateAnim = anim
end

return NinsoverFall