local c = require "app.configs.constants"


return {
	attacker = {
		[1] = {
			[1] = {
				--大荒剑士
				id = 20005,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 10000,b = 0,c = 0},
					["defense"] = {a = 6000,b = 0,c = 0},
					["maxLife"] = {a = 10000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[2] = {
				--卡伦
				id = 20017,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 10000,b = 0,c = 0},
					["defense"] = {a = 4000,b = 0,c = 0},
					["maxLife"] = {a = 10000,b = 0,c = 0},
					["speed"] = {a = 120,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[3] = {
				--千本樱
				id = 20014,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 10000,b = 0,c = 0},
					["defense"] = {a = 4000,b = 0,c = 0},
					["maxLife"] = {a = 10000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[4] = {
				--风十郎
				id = 20012,
				level = 1,
				star = 1,
				props = {
					["attack"] = {a = 15000,b = 0,c = 0},
					["defense"] = {a = 4000,b = 0,c = 0},
					["maxLife"] = {a = 20000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[5] = {
				--曼陀罗
				id = 20040,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 10000,b = 0,c = 0},
					["defense"] = {a = 4000,b = 0,c = 0},
					["maxLife"] = {a = 10000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
		}
	},
	defender = {
		{
			[1] = {
				--影刃
				id = 13001,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 4000,b = 0,c = 0},
					["defense"] = {a = 100000,b = 0,c = 0},
					["maxLife"] = {a = 19000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[2] = {
				--影宗
				id = 13002,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 4000,b = 0,c = 0},
					["defense"] = {a = 100000,b = 0,c = 0},
					["maxLife"] = {a = 19000,b = 0,c = 0},
					["speed"] = {a = 120,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[3] = {
				--影破
				id = 13003,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 4000,b = 0,c = 0},
					["defense"] = {a = 100000,b = 0,c = 0},
					["maxLife"] = {a = 19000,b = 0,c = 0},
					["speed"] = {a = 115,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
			[4] = {
				--影暮
				id = 13004,
				level = 1,
				star = 2,
				props = {
					["attack"] = {a = 4000,b = 0,c = 0},
					["defense"] = {a = 100000,b = 0,c = 0},
					["maxLife"] = {a = 19000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},

			[5] = {
				--影袭
				id = 13005,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 4000,b = 0,c = 0},
					["defense"] = {a = 100000,b = 0,c = 0},
					["maxLife"] = {a = 19000,b = 0,c = 0},
					["speed"] = {a = 100,b = 0,c = 0},

					["crit"] = {a = 0,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 0,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
		},
		{
			[4] = {
				--天照帝
				id = 20041,
				level = 1,
				star = 5,
				props = {
					["attack"] = {a = 12000,b = 0,c = 0},
					["defense"] = {a = 17736,b = 0,c = 0},
					["maxLife"] = {a = 91000,b = 0,c = 0},
					["speed"] = {a = 116,b = 0,c = 0},

					["crit"] = {a = 100,b = 0,c = 0},
					["critDamage"] = {a = 1.5,b = 0,c = 0},
					["hit"] = {a = 1000,b = 0,c = 0},
					["dodge"] = {a = 1000,b = 0,c = 0},
					
					["lifePerHit"] = {a = 0,b = 0,c = 0},
					["energy"] = {a = 0,b = 0,c = 0},

					["damageRatio"] = {a = 1,b = 0,c = 0},
					["healingRatio"] = {a = 1,b = 0,c = 0},
					["critOdds"] = {a = 0,b = 0,c = 0},
					["calmOdds"] = {a = 0,b = 0,c = 0},
					["lifePerRound"] = {a = 0,b = 0,c = 0},
					["energyPerRound"] = {a = 0,b = 0,c = 0},
					["effectHit"] = {a = 0,b = 0,c = 0},
					["effectDodge"] = {a = 1,b = 0,c = 0},
					["cureRatio"] = {a = 0,b = 0,c = 0},
					["addCure"] = {a = 0,b = 0,c = 0},
					["damageUpRatio"] = {a = 1, b = 0, c = 0},
				},
				armors = {},
			},
		}
	},
	kami = {
		[c.UnitGroup.ATTACKER] = 1000,
	},
	params = {
		seed = 1004,
		bg = "background_11_1",
		bgMusic = {
            "battle",
        }
	},
}