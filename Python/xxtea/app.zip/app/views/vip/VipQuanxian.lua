--VipQuanxian.lua
local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local init = require "app.models.init"
local counterConf = require "app.configs.counter"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"

local VipQuanxian = class("VipQuanxian", WinBase)

VipQuanxian.RESOURCE_FILENAME = "layer/vip/vipQuanxian.csb"

local PlayerModel = init.PlayerModel

function VipQuanxian:onCreate()
	self.table = {}

	for k,v in pairs(counterConf) do
		if v.hide ~= 1 then
			local num = PlayerModel:getCounterByID(k)
			table.insert(self.table,{id = k, des = string.format(counterConf[k].des,num)})
		end
	end
	table.sort(self.table,function(a,b)
		return a.id < b.id
	end)
end

function VipQuanxian:initialView()
	UIImageBox.new(self.resourceNode_:getChildByName("closebtn"),function ()
		self:closeSelf()
	end)
	UIImageBox.new(self.resourceNode_:getChildByName("closebtn2"),function ()
		self:closeSelf()
	end)

	self.resourceNode_:getChildByName("Text_1"):setString(WordDictionary[22019])
	self.resourceNode_:getChildByName("closebtn2"):getChildByName("Text_2"):setString(WordDictionary[20104])

	local textY=30
	local perY = 17
	local lastY= #self.table*textY+perY

	local scrollView = self.resourceNode_:getChildByName("scrollView")

	scrollView:stopAllActions()
	scrollView:removeAllChildren()
	scrollView:setScrollBarEnabled(false)
	scrollView:setInnerContainerSize(cc.size(0,0))

	local conSize = scrollView:getInnerContainerSize()
	if lastY > conSize.height then
		scrollView:setInnerContainerSize(cc.size(0,lastY))
		conSize = scrollView:getInnerContainerSize()
	end
	scrollView:scrollToTop(0.2,true)

	for k,v in ipairs(self.table) do
		local textLabel = UILabel.new({
			text = v.des,
			color = cc.c3b(45,35,35),
			size = 20,
		})

		local y=lastY-textY*(k-1) - perY

		if k%2 ~= 0 then
			local frame = display.newSprite("#public/public_slat_09.png", 0, 0, {scale9 = true, size = cc.size(600,34)})
			frame:setOpacity(127)
			display.align(frame,display.TOP_CENTER,conSize.width * 0.5,y + 7)
			scrollView:addChild(frame)
		end
		display.align(textLabel,display.TOP_LEFT,50,y)
		scrollView:addChild(textLabel)
	end

	local path = "public/ui_lantern"
	local anim = SpineManager.createAnimation(path,1)
	anim:playAnimation("idle", -1)
	self.resourceNode_:getChildByName("Node_1"):addChild(anim)
end

function VipQuanxian:getActionIn()
    Helper.enterWinAction1(self)
end

return VipQuanxian