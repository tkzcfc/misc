--VipShopWin.lua

local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local vipGiftConf = require "app.configs.vipGift"
local Helper = require "app.Helper"
local currencyConf = require "app.configs.currency"
local init = require "app.models.init"
local vipConf = require "app.configs.vip"

local VipShopWin = class("VipShopWin", WinBase)

local PlayerModel = init.PlayerModel

VipShopWin.RESOURCE_FILENAME = "layer/vip/vipShop.csb"

function VipShopWin:onCreate(vip)
    self.priority = c.WIN_ZORDER.POPUP
    self.btns = {}
    self.max = math.floor(table.nums(vipConf)/5)
    self.curVip = math.max(math.min(vip, self.max), 1)

    local msgList = {
        msgids.GS_VipTakeGift_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function VipShopWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("closeBtn"), function()
        self:closeSelf(self)
    end)

    self.rightBtn = UIImageBox.new(self.resourceNode_:getChildByName("right"),function(me)
        self.curVip = math.min(self.curVip + 1, self.max)
        self:refreshLayer()
    end)
    self.rightBtn:runAction(cc.RepeatForever:create(cc.Sequence:create(
        cc.EaseInOut:create(cc.MoveBy:create(1, cc.p(12, 0)), 2), 
        cc.EaseInOut:create(cc.MoveBy:create(1, cc.p(-12, 0)), 2)
    )))

    self.leftBtn = UIImageBox.new(self.resourceNode_:getChildByName("left"),function(me)
        self.curVip = math.max(self.curVip - 1, 1)
        self:refreshLayer()
    end)
    self.leftBtn:runAction(cc.RepeatForever:create(cc.Sequence:create(
        cc.EaseInOut:create(cc.MoveBy:create(1, cc.p(-12, 0)), 2), 
        cc.EaseInOut:create(cc.MoveBy:create(1, cc.p(12, 0)), 2)
    )))
    self:refreshLayer()
end

function VipShopWin:refreshLayer(vipIndex)
    local vipTab = {}

    local curVipIndex = vipIndex or self.curVip

    self.leftBtn:setVisible(curVipIndex ~= 1)
    self.rightBtn:setVisible(curVipIndex ~= self.max)

    for k,v in ipairs(vipGiftConf) do
        if v.vip == curVipIndex then
            if #v.cost == 0 then
                vipTab[2] = v
            else
                vipTab[1] = v
            end
        end
        if #vipTab == 2 then
            break
        end
    end

    for i = 1, 2 do
        local node = self.resourceNode_:getChildByName("node_"..i)
        local itemNode = node:getChildByName("node_reward")
        itemNode:removeAllChildren()
        for k,v in ipairs(vipTab[i].rewards or {}) do
            local item = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.7})
            itemNode:addChild(item)
            display.align(item, display.CENTER, ((k-1) % 2) * 75, -math.floor((k-1) / 2) * 75)
        end

        local priceData = vipTab[i].price[1]
        node:getChildByName("sp_currency"):setTexture("icon/currency/"..currencyConf[priceData.id].icon..".png")
        node:getChildByName("txt_price"):setString(priceData.n)

        if i == 1 then
            local costData = vipTab[i].cost[1]
            node:getChildByName("txt_nowPrice"):setString(costData.n)
            node:getChildByName("sp_newCurrency"):setTexture("icon/currency/"..currencyConf[costData.id].icon..".png")
        end

        local btn = UIImageBox.new(node:getChildByName("btn_buy"), function()
            network.tcpSend(msgids.C_VipTakeGift, {Id = vipTab[i].Id})
        end)
        btn.giftId = vipTab[i].Id
        self.btns[i] = btn
    end

    self:refreshBtn()
    self:refreshBottom(vipIndex)
end

function VipShopWin:refreshBtn()
    for k,v in ipairs(self.btns) do
        local giftData = vipGiftConf[v.giftId]

        local taked = false
        for _,takeId in ipairs(PlayerModel.info.vipTakenGift) do
            if v.giftId == takeId then
                taked = true
                break
            end
        end
        v:setEnabled(not taked)
        if taked then
            if #giftData.cost == 0 then
                v:getChildByName("txt_rec"):setString(WordDictionary[21706])
            else
                v:getChildByName("txt_rec"):setString(WordDictionary[22150])
            end
        else
            if #giftData.cost == 0 then
                v:getChildByName("txt_rec"):setString(WordDictionary[22602])
            else
                v:getChildByName("txt_rec"):setString(WordDictionary[22151])
            end
        end
    end
end

function VipShopWin:receive(op, data)
    if op == msgids.GS_VipTakeGift_R then
        if data.Rewards then
            self:openWin("PublicGetRewardWin",{rewards = data.Rewards})
        end
        self:refreshBtn()
    end
end

function VipShopWin:refreshBottom(vipIndex)
    local vipIndex = vipIndex or self.curVip
    for i=1,7 do
        local str = self.resourceNode_:getChildByName("txt_lv" .. i)
        local bar = self.resourceNode_:getChildByName("sp_line" .. i)
        if bar then bar:setVisible(false) end
        local vipLv = vipIndex-4+i
        local vipStr = ""
        if (vipLv > 0) and (vipLv <= self.max) then
            vipStr = WordDictionary[22100+vipLv]
            -- if (vipLv < vip) and bar then
            --    bar:setVisible(true)
            -- end
        end
        str:setString(vipStr)
    end

end

function VipShopWin:getActionIn()
    Helper.enterWinAction1(self)
end

return VipShopWin