--VipGet
local WinBase = require "sandglass.core.WinBase"
local Helper = require "app.Helper"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local init = require "app.models.init"
local vipConf = require "app.configs.vip"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local AudioManager = require "sandglass.core.AudioManager"

local VipGet = class("VipGet", WinBase)

VipGet.RESOURCE_FILENAME = "layer/vip/vipTishi.csb"

local PlayerModel = init.PlayerModel

function VipGet:onCreate(vipIndex)
	local vip = vipIndex or (PlayerModel.info.vip ~= 0 and PlayerModel.info.vip or 1)
	local tData = vipConf[vip * 10 + 5]
	self.reward=tData.reward
end

function VipGet:closeSelf()
	AudioManager.stopAllEffects()
	VipGet.super.closeSelf(self)
end

function VipGet:initialView()
	AudioManager.playEffect("music/ui_boxjump.mp3",true)

	UIImageBox.new(self.resourceNode_:getChildByName("closebtn"),function ()
		self:closeSelf()
	end)

	self.resourceNode_:getChildByName("Text_1"):setString(WordDictionary[22018])
	self.resourceNode_:getChildByName("Text_2"):setString(WordDictionary[20104])
	
	local node_2=self.resourceNode_:getChildByName("Node_2")
	local tbNum = #self.reward-1
	local dis = 6
	for k,v in ipairs(self.reward) do
		local item = Helper.createGoodsItem({scale = 1,id = v.id,num = v.n})
		local width = item:getContentSize().width
		local perX = (width + dis)/2
		-- 第二个起每个相对于第一个的偏移量
		local x=(k-1)*perX*2
		-- 第一个的位置
		x = x-perX*tbNum
		display.align(item,display.CENTER,x,0)
		node_2:addChild(item)
	end

	local path = "public/ui_vipbox"
	local anim = SpineManager.createAnimation(path,1)
	anim:playAnimation("idle", -1)
	self.resourceNode_:getChildByName("Node_1"):addChild(anim)
end

return VipGet