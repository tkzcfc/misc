--VipWin.lua

local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local UIAniButton = require "sandglass.ui.UIAniButton"
local RichLabel = require "sandglass.ui.RichLabel"
local MoveLabel = require "sandglass.ui.MoveLabel"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local CoreColor = require "sandglass.core.CoreColor"
local itemConf = require "app.configs.item"
local vipConf = require "app.configs.vip"
local vipGiftConf = require "app.configs.vipGift"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local SpineManager = require "sandglass.core.SpineManager"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local AudioManager = require "sandglass.core.AudioManager"
local SDKController = require "app.sdk.SDKController"
local TeamController = require "app.battle.controllers.TeamController"
local SpineManager = require "sandglass.core.SpineManager"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skinConf = require "app.configs.skin"
local currencyConf = require "app.configs.currency"

local counterConf = require "app.configs.counter"
local RedTipsModel = init.RedTipsModel

local VipWin = class("VipWin", WinBase)

VipWin.RESOURCE_FILENAME = "vip/vip.csb"

local PlayerModel = init.PlayerModel

local giftItem = {
	[0] = {
		id = 30103,
		path = "#summon/zhaohuan-anniu4.png",
		name = WordDictionary[22032],
	},
	[1] = {
		id = 30103,
		path = "#summon/zhaohuan-anniu4.png",
		name = WordDictionary[22032],
	},
	[2] = {
		id = 20046,
		star = 1,
	},
	[3] = {
		id = 20046,
		star = 3,
	},
	[4] = {
		id = 20024,
		star = 1,
	},
	[5] = {
		id = 20024,
		star = 3,
	},
	[6] = {
		id = 20019,
		star = 1,
	},
	[7] = {
		id = 39019,
		path = "icon/head/jiansheng_icon1.png",
	},
	[8] = {
		id = 20019,
		star = 3,
	},
	[9] = {
		id = 39019,
		path = "icon/head/jiansheng_icon1.png",
	},
	[10] = {
		id = 20019,
		star = 4,
	},
	[11] = {
		id = 20019,
		star = 5,
	},
	[12] = {
		id = 20019,
		star = 6,
	},
}

local refreshPage = {}
function VipWin:onCreate()
	-- self.showType = self.WinShowType.hiddenBack
	self.shieldLayer_:setVisible(false)
	self.curPage = PlayerModel.info.vip + 1
	self:initData()
	local msgList = {
		msgids.GS_VipTakeGift_R,
		msgids.GS_VipUpdate,
	}
	network.addListener(self, msgList, handler(self, self.receiveHandler))
end

function VipWin:initData()
	self.middleData = {} --中间VIP页的内容（里面存的是contentNode）

	local finalConf = {}
	for _,v in pairs(vipConf) do
		table.insert(finalConf,v)
	end
	table.sort(finalConf, function (a,b)
		return a.vipLevel < b.vipLevel
	end)
	self.finalConf = finalConf

end

function VipWin:closeSelf()
	refreshPage = {}
	if self.boxJumpEffect then
		AudioManager.stopEffect(self.boxJumpEffect)
		self.boxJumpEffect = nil
	end
	VipWin.super.closeSelf(self)
end

function VipWin:refreshBarView()
	local node_c = self.resourceNode_:getChildByName("node_c")
	local bar = node_c:getChildByName("bar")
	local txt_loading = node_c:getChildByName("txt_loading")
	local vip = PlayerModel.info.vip
	local exp = PlayerModel.info.vipExp
	local needExp = vipConf[vip].needExp

 	local isMax = false
 	if vip >= table.nums(vipConf) - 1 then
 		isMax = true
 	end

	bar:setPercent(isMax and 100 or (exp/needExp)* 100)
	local loadingStr = isMax and string.format(WordDictionary[22006],vipConf[vip-1].needExp,vipConf[vip-1].needExp)
							 or string.format(WordDictionary[22006],exp,vipConf[vip].needExp)
	txt_loading:setString(loadingStr)

	node_c:getChildByName("img_icon"):setVisible(not isMax)
	node_c:getChildByName("txt_num"):setVisible(not isMax)
	node_c:getChildByName("img_next"):setVisible(not isMax)
	node_c:getChildByName("txt_nextLvTitle"):setVisible(not isMax)
	node_c:getChildByName("txt_upDes"):setString(isMax and WordDictionary[22031] or WordDictionary[22030])

 	local img_curLv = node_c:getChildByName("img_cur")
 	local img_nextLv = node_c:getChildByName("img_next")

 	img_curLv:loadTexture("vip/"..(isMax and vip or vip)..".png",ccui.TextureResType.plistType)
	img_nextLv:loadTexture("vip/"..(isMax and vip or vip+1)..".png",ccui.TextureResType.plistType)
	 
 	local money = needExp - exp
 	node_c:getChildByName("txt_num"):setString(money)

end

function VipWin:addHero(heroId, skinId, star)
	local node_c = self.resourceNode_:getChildByName("node_c")
    local cData = heroConf[heroId]
    local heroNode = self:createCsbNode("vip/giftNode.csb")

    heroNode:getChildByName("node_item"):setVisible(false)
    heroNode:getChildByName("node_hero"):setVisible(true)
    local path = "spine/actors/".. roleConf[cData.role].spine
    local skinId = skinId or 1
    local heroSpine = UIAniButton.new(path, function(eventType,me,point)
        if eventType == "ended" then
            self:openWin("HeroDetailWin", cData.heroID)
        end
    end, {skin = skinConf[skinId].spineName})
    if cData.heroID == 20003 then -- 八门石佛太大了缩小点
    	heroSpine:setScale(0.7)
    end
    heroSpine:playAnimation("appear", 1)
    heroNode:getChildByName("node_hero"):getChildByName("node_role"):addChild(heroSpine,1)
    heroSpine:appendNextAnimation("idle", -1)
    heroNode:getChildByName("node_hero"):getChildByName("txt_heroName"):setString(cData.heroName)
    local HERO_COLOR = {
        ["R"] = CoreColor.BLUE,
        ["SR"] = CoreColor.PURPLE,
        ["SSR"] = CoreColor.ORANGE,
    }
    local color = HERO_COLOR[cData.rare] or CoreColor.BLUE
    heroNode:getChildByName("node_hero"):getChildByName("txt_heroName"):setTextColor(color)
    heroNode:getChildByName("node_hero"):getChildByName("sp_rarity"):setSpriteFrame(Helper.getHeroRarePath(cData.rare))
    heroNode:setPositionY(-20)
    node_c:getChildByName("node_upDes"):addChild(heroNode)
    Helper.updateHeroStar(heroNode:getChildByName("node_hero"):getChildByName("starNode"), star, "star_")
end

function VipWin:initPageView()
	local node_c = self.resourceNode_:getChildByName("node_c")
	local btnList = node_c:getChildByName("list_btn")
	btnList:removeAllChildren()
	btnList:setScrollBarEnabled(false)
	self.curPage = PlayerModel.info.vip + 1
	self.isInit = true
	self.btnItem = {}
	btnList:updateListView(self.finalConf, function(cacheView,index,data)
		if cacheView == nil then
			cacheView = self:createBtnItem(data, index)
		end
		cacheView:updateView(data)
		return cacheView
    end)
end

function VipWin:createBtnItem(data,index)
	local layer = ccui.Layout:create()
	local node = self:createCsbNode("vip/btnNode.csb")
	layer.updateView = function(layer, data)
		node:getChildByName("txt_name"):setString(string.format(WordDictionary[22028], data.vipLevel))
		node:getChildByName("txt_reward"):setString(data.labelDes)
		local btn = UIImageBox.new(node:getChildByName("img_bg"),function()
			if self.curPage ~= index or self.isInit then
				self.isInit = false
				self.curPage = index
				self:refreshPageView(index)
			end
		end,{swallowTouches = false})

		node.vipLevel = data.vipLevel or 0
        table.insert(self.btnItem,node)
		if self.curPage == index then
			btn:onClick()
		end
        if index == table.nums(self.finalConf) then
			self:refreshBtnImg()
			self:checkRedTips()
        end
	end

	local size = node:getChildByName("img_bg"):getContentSize()
	layer:setContentSize(cc.size(size.width + 5, size.height + 5))
	node:setPosition(cc.p(0,0))
	node:setName("btn"..index)
	layer:addChild(node)
	return layer
end

function VipWin:checkRedTips()
	local curVip = PlayerModel.info.vip or 0

	local redFunc = function(data)
		local giftFreeData = nil
		local taked = false

		if curVip >= data.vip then
			if table.nums(data.cost) == 0 then
				giftFreeData = data
			else
				taked = true
			end
			if giftFreeData then
				for _,takeId in ipairs(PlayerModel.info.vipTakenGift) do
			        if giftFreeData.Id == takeId then
			            taked = true
			            break
			        end
			    end
			end
			if not taked then
				return true
			end
		end
		return false
	end

	for _,item in ipairs(self.btnItem) do
		local redTip = false
		for k,v in pairs(vipGiftConf) do
			if item.vipLevel == v.vip then
				if redFunc(v) then
					redTip = true
					break
				end
			end
		end
		if redTip then
			RedTipsModel:addRedTip(item:getChildByName("img_bg"), cc.p(110, 40))
		else
			RedTipsModel:removeRedTip(item:getChildByName("img_bg"))
		end
	end
end


function VipWin:refreshBtnImg()
	self:checkRedTips()
	for i,itemNode in ipairs(self.btnItem) do
		if i == self.curPage then
            itemNode:getChildByName("img_bg"):loadTexture("vip/anniu_02.png",ccui.TextureResType.plistType)
            itemNode:getChildByName("txt_reward"):setTextColor(cc.c3b(83,56,35))
            itemNode:getChildByName("txt_name"):setTextColor(cc.c3b(248,231,200))
            itemNode:getChildByName("txt_name"):enableOutline(cc.c3b(180,112,56), 2)
		else
            itemNode:getChildByName("img_bg"):loadTexture("vip/anniu_01.png",ccui.TextureResType.plistType)
            itemNode:getChildByName("txt_reward"):setTextColor(cc.c3b(174,143,99))
            itemNode:getChildByName("txt_name"):setTextColor(cc.c3b(201,170,121))
            itemNode:getChildByName("txt_name"):enableOutline(cc.c3b(54,38,25), 0)
		end 
	end
end


function VipWin:refreshGiftDes(index)
	local vip = PlayerModel.info.vip

	local des = ""
	local lv = nil

	local finalDes = ""
	local finalLv = nil

	for i,v in ipairs(self.finalConf) do
		if v.des ~= "" and vip < v.vipLevel then
			des = v.des
			lv = v.vipLevel
			break
		end

		if v.des ~= "" then
			finalDes = v.des
			finalLv = v.vipLevel
		end		
	end

	if des == "" then
		des = finalDes
		lv = finalLv
	end

	local function UpdateDes(i)
		local pageNode = self.middleData[i]
		local node_nextGift = pageNode:getChildByName("node_nextGift")
		local txt_lvGift = pageNode:getChildByName("txt_lvGift")

		node_nextGift:removeAllChildren()
		local text = RichLabel.new {
	        fontSize = 17,
	    }
	    text:setString(string.format(WordDictionary[22012],lv))
    	display.align(text,display.LEFT_CENTER,0,0)
    	node_nextGift:addChild(text)
    	txt_lvGift:setString(des)
	end
	for i=1,table.nums(self.finalConf) do
		if index then
			if index == self.finalConf[i].vipLevel then
				UpdateDes(i)
				break
			end
		else
			UpdateDes(i)
		end

	end
end

function VipWin:refreshPageView(vipIndex)
	self:refreshBtnImg()
	local node_c = self.resourceNode_:getChildByName("node_c")
	local pageNode = self:createCsbNode("vip/vipPageNode.csb")
	node_c:getChildByName("node_detail"):removeAllChildren()
	node_c:getChildByName("node_detail"):addChild(pageNode)

	--罗旭冬说了这个绝对不再改！！！
 	local nodeView = node_c:getChildByName("node_upDes")
 	nodeView:removeAllChildren()
 	local index = vipIndex - 1
 	local itemId = giftItem[index] and giftItem[index].id or 0
 	local itemData = itemConf[itemId] or currencyConf[itemId] or heroConf[itemId]
 	if heroConf[itemId] then
 		self.videoHero = itemId
 		node_c:getChildByName("btn_video"):setVisible(true)
 		self:addHero(itemId, 1, giftItem[index].star)
 	elseif itemConf[itemId] or currencyConf[itemId] then
 		node_c:getChildByName("btn_video"):setVisible(false)
 		local path = giftItem[index].path
 		local itemNode = self:createCsbNode("vip/giftNode.csb")
 		itemNode:getChildByName("node_item"):setVisible(true)
    	itemNode:getChildByName("node_hero"):setVisible(false)
 		if path then
 			local sprite = display.newSprite(path,0,0)
 			itemNode:getChildByName("node_item"):getChildByName("node_icon"):addChild(sprite)
 		end
 		local name = giftItem[index].name and giftItem[index].name or itemData.name
		itemNode:getChildByName("node_item"):getChildByName("txt_itemName"):setString(name)
		itemNode:setPositionY(-20)
		nodeView:addChild(itemNode)
 	end

 	local btn_video = node_c:getChildByName("btn_video")
	UIImageBox.new(btn_video,function()
		refreshPage = {}
        local data = TeamController.getSkillPreviewTeam(self.videoHero)
        data.params.afterLoading = c.AfterLoading.mainScene
        data.params.win = "VipWin"
        self:getApp():enterScene("SkillPreviewScene", data)
    end)

	-- 特惠礼包
	local txt_title = pageNode:getChildByName("txt_title")
	local txt_ori_cost = pageNode:getChildByName("txt_ori_cost")
	local img_ori_costIcon = pageNode:getChildByName("img_ori_costIcon")
	local txt_ori_costNum = pageNode:getChildByName("txt_ori_costNum")

	local txt_cost = pageNode:getChildByName("txt_cost")
	local img_costIcon = pageNode:getChildByName("img_costIcon")
	local txt_costNum = pageNode:getChildByName("txt_costNum")

	local node_gift = pageNode:getChildByName("node_gift")
	local btn_buy = pageNode:getChildByName("btn_buy")
	
	-- 免费礼包
	local txt_freeTitle = pageNode:getChildByName("txt_freeTitle")
	local txt_ori_cost_f = pageNode:getChildByName("txt_ori_cost_f")
	local img_ori_costIcon_f = pageNode:getChildByName("img_ori_costIcon_f")
	local txt_ori_costNum_f = pageNode:getChildByName("txt_ori_costNum_f")

	local txt_cost_f = pageNode:getChildByName("txt_cost_f")
	local img_costIcon_f = pageNode:getChildByName("img_costIcon_f")
	local txt_costNum_f = pageNode:getChildByName("txt_costNum_f")

	local node_freeGift = pageNode:getChildByName("node_freeGift")
	local btn_free = pageNode:getChildByName("btn_free")

	txt_title:setString(string.format(WordDictionary[22028],self.finalConf[vipIndex].vipLevel))
	txt_freeTitle:setString(string.format(WordDictionary[22010],self.finalConf[vipIndex].vipLevel))

	local giftData = nil
	local giftFreeData = nil

	for _,v in pairs(vipGiftConf) do
		if v.vip == self.finalConf[vipIndex].vipLevel then
			if table.nums(v.cost) ~= 0 then
				giftData = v
			else
				giftFreeData = v
			end
		end
	end

	local perWidth,spaceWidth = 60, 5

	if giftData then
		local originCostData = giftData.price[1]
		local costData = giftData.cost[1]

		local id = originCostData.id
		local num = originCostData.n
		local path = Helper.getPathById(id)
		img_ori_costIcon:loadTexture(path,ccui.TextureResType.localType)

		txt_ori_costNum:setString(num)

		local id2 = costData.id
		local num2 = costData.n
		local path2 = Helper.getPathById(id2)
		img_costIcon:loadTexture(path2,ccui.TextureResType.localType)
		txt_costNum:setString(num2)

		local rewards = giftData.rewards
		node_gift:removeAllChildren()

	    local startX = 68
	    for k,v in ipairs(rewards) do
	        local itemIcon = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.6})
	        if itemIcon then
		        display.align(itemIcon, display.CENTER, (k - 1) * startX, 0)
		        node_gift:addChild(itemIcon)
	        end
	    end

	    local taked = false
	    for _,takeId in ipairs(PlayerModel.info.vipTakenGift) do
	        if giftData.Id == takeId then
	            taked = true
	            break
	        end
	    end

	    btn_buy:setEnabled(not taked)

		if taked then
			btn_buy:getChildByName("txt"):setString(WordDictionary[22005])
			btn_buy:loadTexture("public/tongyonganniu_03_3gongge.png",ccui.TextureResType.localType)
			btn_buy:getChildByName("txt"):setTextColor(cc.c3b(207,207,207))
			btn_buy:getChildByName("txt"):enableOutline(cc.c3b(73,73,73), 1)--描边
		else
			btn_buy:getChildByName("txt"):setString(WordDictionary[22004])
			btn_buy:loadTexture("public/tongyonganniu_01_3gongge.png",ccui.TextureResType.localType)
			btn_buy:getChildByName("txt"):setTextColor(cc.c3b(255,236,202))
			btn_buy:getChildByName("txt"):enableOutline(cc.c3b(164,101,16), 1)--描边
	    end

		UIImageBox.new(btn_buy, function()
			if PlayerModel.info.vip < self.finalConf[vipIndex].vipLevel then
				MoveLabel.new(string.format(WordDictionary[22033],self.finalConf[vipIndex].vipLevel))
				return
			end
            network.tcpSend(msgids.C_VipTakeGift, {Id = giftData.Id})
        end)
	end

	if giftFreeData then
		local originCostData = giftFreeData.price[1]
		local id = originCostData.id
		local num = originCostData.n
		local path = Helper.getPathById(id)
		img_ori_costIcon_f:loadTexture(path,ccui.TextureResType.localType)
		txt_ori_costNum_f:setString(num)

		img_costIcon_f:loadTexture(path,ccui.TextureResType.localType)
		txt_costNum_f:setString(WordDictionary[22001])

		local rewards = giftFreeData.rewards
		node_freeGift:removeAllChildren()

	    local startX = 68
	    for k,v in ipairs(rewards) do
	        local itemIcon = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.6})
	        if itemIcon then
		        display.align(itemIcon, display.CENTER, (k - 1) * 68, 0)
		        node_freeGift:addChild(itemIcon)
	        end
	    end

	    local taked = false
	    for _,takeId in ipairs(PlayerModel.info.vipTakenGift) do
	        if giftFreeData.Id == takeId then
	            taked = true
	            break
	        end
	    end

	    btn_free:setEnabled(not taked)
	    if PlayerModel.info.vip >= self.finalConf[vipIndex].vipLevel then
		    if taked then
				btn_free:getChildByName("txt"):setString(WordDictionary[22003])
				btn_free:loadTexture("public/tongyonganniu_03_3gongge.png",ccui.TextureResType.localType)
				btn_free:getChildByName("txt"):setTextColor(cc.c3b(207,207,207))
				btn_free:getChildByName("txt"):enableOutline(cc.c3b(73,73,73), 1)--描边
				Helper.buttonRemoveEffect(btn_free)
			else
				btn_free:getChildByName("txt"):setString(WordDictionary[22002])
				btn_free:loadTexture("public/tongyonganniu_01_3gongge.png",ccui.TextureResType.localType)
				btn_free:getChildByName("txt"):setTextColor(cc.c3b(255,236,202))
				btn_free:getChildByName("txt"):enableOutline(cc.c3b(164,101,16), 1)--描边
	   			Helper.buttonAddEffect(btn_free,"public/ui_tongyonganniugaoliang",0.73)
		    end
		else
			Helper.buttonRemoveEffect(btn_free)
		end

		UIImageBox.new(btn_free, function()
			if PlayerModel.info.vip < self.finalConf[vipIndex].vipLevel then
				MoveLabel.new(string.format(WordDictionary[22014],self.finalConf[vipIndex].vipLevel))
				return
			end
            network.tcpSend(msgids.C_VipTakeGift, {Id = giftFreeData.Id})
        end)
        -- if PlayerModel.info.vip < self.finalConf[vipIndex].vipLevel then
        -- 	Helper.buttonRemoveEffect(btn_free)
        -- end
	end

	local diff = 0
	if self.preIndex then
		diff = vipIndex - self.preIndex
	end
	self.preIndex = vipIndex
	if not self.oldDesc or diff ~= 1 then
		self.oldDesc = {}
	end
	local list = pageNode:getChildByName("list")
	list:removeAllChildren()
	local rightData = self.finalConf[vipIndex].times
	local num = 0
	if rightData then
		local newDesc = {}
		if diff ~= 1 then
			self.oldDesc = self:hasNewFun(vipIndex - 1)
		end
		for _,v in pairs(rightData) do
			if counterConf[v.id] then
				num = num + 1
				local n = v.n
				local des = counterConf[v.id].des
				local text = RichLabel.new {
			        fontSize = 16,
			        lineSpace = 3,
			        maxWidth = 390,
			        fontColor = cc.c3b(175,149,112),
				}
				local isSame = false
				
				if self.oldDesc[v.id] then
					isSame = true
				end
				newDesc[v.id] = v.id
				text:setString(tostring(num) .."." .. string.format(des, n))
				local newIcon = nil
				if not isSame and vipIndex ~= 1 then
					newIcon = ccui.ImageView:create("vip/vip-xin.png",ccui.TextureResType.plistType)
					text:addChild(newIcon)
					newIcon:setAnchorPoint(0.5,0.5)
					newIcon:setScale(0.8)
					newIcon:setPosition(text:getContentSize().width + 20,text:getContentSize().height / 2 - 10)
				end
				local sprIcon = display.newSprite("#vip/zhuanshi.png", 12, text:getContentSize().height*0.5 + 2)
		    	display.align(text,display.LEFT_CENTER,30,text:getContentSize().height*0.5)
				local layout = ccui.Layout:create()
			    layout:setContentSize(cc.size(400, text:getContentSize().height))
			    layout:addChild(sprIcon)
			    layout:addChild(text)

			    list:pushBackCustomItem(layout)
			end
		end
		self.oldDesc = newDesc
	end
end

function VipWin:hasNewFun(preVipIndex)
	if preVipIndex <= 0 then
		return {}
	end
	local preData = self.finalConf[preVipIndex].times
	local oldDesc ={}
	if preData then
		for _,v in pairs(preData) do
			if counterConf[v.id] then
				oldDesc[v.id] = v.id
			end
		end
	end
	return oldDesc
end

function VipWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
		self:closeSelf()
	end)
	self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(WordDictionary[22000])
	self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"):hide()


	cc.SpriteFrameCache:getInstance():addSpriteFrames("summon/summon.plist")
	local node_c = self.resourceNode_:getChildByName("node_c")

	local nodeAnim = node_c:getChildByName('node_spine')
    local anim = SpineManager.createAnimation('public/ui_cha_zuiniang', 1)
    anim:playAnimation('idle', -1)
    anim:setScale(0.9, 0.9)
    anim:setFlipX(true)
    nodeAnim:addChild(anim)

	local btn_recharge = node_c:getChildByName("btn_recharge")
	UIImageBox.new(btn_recharge,function ()
		local win = display.getRunningScene().winManager:findWinByName("PayWin")
		if not win then
			self:openWin("PayWin")
		end
		self:closeSelf()
	end)

    -- 创建pageview页面
	self:initPageView()
	self:refreshBarView()
end

function VipWin:receiveHandler(op,data)
	if op == msgids.GS_VipUpdate then
		-- local node_c = self.resourceNode_:getChildByName("node_c")
		-- local pageView = node_c:getChildByName("page")
		-- pageView:scrollToPage((PlayerModel.info.vip-1),0.2)
		self.curPage = PlayerModel.info.vip + 1
		self:refreshBtnImg()
		self:refreshBarView()
		-- self:refreshGiftDes()
		if PlayerModel.info.vip > PlayerModel.info.preVip then
	        local win = display.getRunningScene().winManager:findWinByName("VipLevelUpWin")
	        if not win then
	            self:openWin("VipLevelUpWin")
	        end 
		end
	elseif op == msgids.GS_VipTakeGift_R then
        self:openWin("PublicGetRewardWin",{rewards = data.Rewards})

        local page = math.ceil(data.Id/2)
        self:refreshPageView(page)
	end
end


function VipWin:getActionIn()
    Helper.enterWinAction2(self)
end

function VipWin:getActionOut(callback)
   Helper.outWinAction(self, callback)
   return true
end


return VipWin