

local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local init = require "app.models.init"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local c = require "app.configs.constants"
local msgids = require "app.network.msgids"
local network = require "app.network.network"

local vipGiftConf = require "app.configs.vipGift"
local SpineManager = require "sandglass.core.SpineManager"

local VipLevelUpWin = class("VipLevelUpWin", WinBase)

VipLevelUpWin.RESOURCE_FILENAME = "vip/vipUpgrade.csb"

local PlayerModel = init.PlayerModel

local vipPathTab = {
	"vip/icon_renjie1-5.png",
	"vip/icon_renjie5-10.png",
	"vip/icon_renjie10-15.png",
	"vip/icon_renjie15-20.png",
}

local function getVipPicPath(vip)
 	local path = nil
 	if vip>=1 and vip<=5  then
 		path = vipPathTab[1]
 	elseif vip>=6 and vip<=10 then
 		path = vipPathTab[2]
 	elseif vip>=11 and vip<=15 then
 		path = vipPathTab[3]
 	elseif vip>=16 and vip<=20 then
 		path = vipPathTab[4]
 	end
 	return path
end

function VipLevelUpWin:closeSelf()
	if self.callback and type(self.callback) == "function" then
		self.callback()
	end
	VipLevelUpWin.super.closeSelf(self)
end

function VipLevelUpWin:setCloseCallBack(callback)
	self.callback = callback
end

function VipLevelUpWin:onCreate()
	self.priority = c.WIN_ZORDER.POPUP
end

function VipLevelUpWin:initialView()
 	-- 忍阶星星
	local preVip = PlayerModel.info.preVip
	local vip = PlayerModel.info.vip

	local img_curLv = self.resourceNode_:getChildByName("img_curLv")
	local img_nextLv = self.resourceNode_:getChildByName("img_nextLv")

 	local path1 = getVipPicPath(preVip)
 	local path2 = getVipPicPath(vip)
 	img_curLv:loadTexture(path1,ccui.TextureResType.plistType)
 	img_nextLv:loadTexture(path2,ccui.TextureResType.plistType)

	local img_starLeft = self.resourceNode_:getChildByName("img_starLeft")
 	local img_starRight = self.resourceNode_:getChildByName("img_starRight")

 	local function getMod(num)
 		local val = num%5
 		if val == 0 then
 			if num >= 5 then
 				val = 5
 			end
 		end
 		return val
 	end
 	local mod1 = getMod(preVip)
 	local mod2 = getMod(vip)

 	for i=1,5 do
 		local starL = img_starLeft:getChildByName(tostring(i))
 		local starR = img_starRight:getChildByName(tostring(i))

 		starL:setVisible(mod1 >= i)
 		starR:setVisible(mod2 >= i)
	 end

	self.resourceNode_:getChildByName("txt_pre"):setString(WordDictionary[22015 + preVip])
	self.resourceNode_:getChildByName("txt_cur"):setString(WordDictionary[22015 + vip])

	local anim = SpineManager.createAnimation("public/ui_tongyongbiaoti_cijitanchuang",1)
	local imgTitle = self.resourceNode_:getChildByName("img_title")
	anim:setScale(0.7)
	imgTitle:addChild(anim)
	anim:setPosition(imgTitle:getContentSize().width / 2,imgTitle:getContentSize().height * 0.7)
    anim:playAnimation("idle", -1)
	 
	 UIImageBox.new(self.resourceNode_:getChildByName("btn_reward"),function()
		local win = display.getRunningScene().winManager:findWinByName("VipWin")
		if not win then
			self:openWin("VipWin")
		else
			win:initPageView()
		end
		 self:closeSelf()
	 end)
	 Helper.buttonAddEffect(self.resourceNode_:getChildByName("btn_reward"),"public/ui_tongyonganniugaoliang",0.9)

 	-- -- 礼包
	-- local node_gift = self.resourceNode_:getChildByName("node_gift")
	-- local node_freeGift = self.resourceNode_:getChildByName("node_freeGift")

 	-- local giftData = nil
	-- local giftFreeData = nil

	-- for _,v in pairs(vipGiftConf) do
	-- 	if v.vip == vip then
	-- 		if table.nums(v.cost) ~= 0 then
	-- 			giftData = v
	-- 		else
	-- 			giftFreeData = v
	-- 		end
	-- 	end
	-- end

	-- local perWidth,spaceWidth = 60, 5

	-- if giftData then
	-- 	local rewards = giftData.rewards
	-- 	node_gift:removeAllChildren()

	--     local startX = -(#rewards * perWidth + (#rewards - 1) * spaceWidth) / 2
	--     for k,v in ipairs(rewards) do
	--         local itemIcon = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.6})
	--         if itemIcon then
	-- 	        display.align(itemIcon, display.LEFT_CENTER, startX + (k - 1) * (perWidth + spaceWidth), 0)
	-- 	        node_gift:addChild(itemIcon)
	--         end
	--     end
	-- end

	-- if giftFreeData then
	-- 	local rewards = giftFreeData.rewards
	-- 	node_freeGift:removeAllChildren()

	--     local startX = -(#rewards * perWidth + (#rewards - 1) * spaceWidth) / 2
	--     for k,v in ipairs(rewards) do
	--         local itemIcon = Helper.createGoodsItem({id = v.id, num = v.n, scale = 0.6})
	--         if itemIcon then
	-- 	        display.align(itemIcon, display.LEFT_CENTER, startX + (k - 1) * (perWidth + spaceWidth), 0)
	-- 	        node_freeGift:addChild(itemIcon)
	--         end
	--     end
	-- end

 	-- self:setAutoClose(self.resourceNode_)
 	self:setAutoClose(self.resourceNode_:getChildByName("bg"))
end

function VipLevelUpWin:getActionIn()
    Helper.enterWinAction1(self)
end

return VipLevelUpWin
