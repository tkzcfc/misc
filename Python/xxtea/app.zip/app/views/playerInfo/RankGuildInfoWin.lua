--RankGuildInfoWin.lua

local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local init = require "app.models.init"
local guildConf = require "app.configs.guild"
local guildHeadConf = require "app.configs.guildHead"
local globalPublicConf = require "app.configs.globalPublic"
local Helper = require "app.Helper"

local GuildModel = init.GuildModel
local PlayerModel = init.PlayerModel

local RankGuildInfoWin = class("RankGuildInfoWin", WinBase)

RankGuildInfoWin.RESOURCE_FILENAME = "layer/rank/rankGuildInfo.csb"

function RankGuildInfoWin:onCreate(info)
	self.priority = c.WIN_ZORDER.POPUP
	self.info = info or {}
end

function RankGuildInfoWin:initialView()
	UIImageBox.new(self.resourceNode_:getChildByName("closeBtn"),function()
		self:closeSelf()
	end)

	UIImageBox.new(self.resourceNode_:getChildByName("codeBtn"),function()
		self:closeSelf()
	end)

	local mbLimit = guildConf[self.info.Row.Lv].mbLimit
	if guildConf[self.info.Row.Lv].upgradeExp == 0 and PlayerModel.info.mergeCnt >= 1 then
		mbLimit = globalPublicConf[1].guildPeopleLimit
	end

	local wordDic = {
		[1] = WordDictionary[20104],
		[2] = WordDictionary[21406],
		[3] = WordDictionary[21502],
		[4] = WordDictionary[21448],
		[5] = WordDictionary[21418],
		[6] = WordDictionary[21474],
		[7] = self.info.Row.Lv,
		[8] = self.info.Row.AtkPwr,
		[9] = self.info.Row.OwnerName,
		[10] = self.info.Row.Id,
		[11] = self.info.Row.MemberN .. "/" .. mbLimit,
		[12] = WordDictionary[21475],
		[13] = self.info.Notice,
		[14] = self.info.Row.Name,
	}
	for i = 1,14 do
		self.resourceNode_:getChildByName("Text_" .. i):setString(wordDic[i])
	end

	local flagIndex, iconIndex = GuildModel:getGuildHeadIndex(self.info.Row.Head)
	local iconBack = self.resourceNode_:getChildByName("iconBack")
	iconBack:loadTexture("icon/head/" .. guildHeadConf[flagIndex].icon .. ".png", ccui.TextureResType.localType)
 	local itemIcon = display.newSprite("icon/head/" .. guildHeadConf[iconIndex].icon .. ".png")
 	local size = self.resourceNode_:getChildByName("iconBack"):getContentSize()
 	itemIcon:setPosition(size.width / 2,size.height / 2)
 	self.resourceNode_:getChildByName("iconBack"):addChild(itemIcon)
end

function RankGuildInfoWin:getActionIn()
    Helper.enterWinAction1(self)
end

return RankGuildInfoWin