local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local init = require "app.models.init"
local c = require "app.configs.constants"

local CollectionShowWin = class("CollectionShowWin", WinBase)

CollectionShowWin.RESOURCE_FILENAME = "layer/rank/collectionShow.csb"

local PlayerModel = init.PlayerModel

function CollectionShowWin:onCreate()
    self.priority = c.WIN_ZORDER.NORMAL
    
end

function CollectionShowWin:initialView()
	self:setAutoClose(self.resourceNode_:getChildByName("img_bg"))

	self:createContent()
end

function CollectionShowWin:createContent()
    local txt_name = self.resourceNode_:getChildByName("txt_name")
    local txt_attr = self.resourceNode_:getChildByName("txt_attr")
    local txt_tips = self.resourceNode_:getChildByName("txt_tips")
    local node_item = self.resourceNode_:getChildByName("node_item")
    txt_name:setString("名字")
    txt_attr:setString("非常稀有")
    txt_tips:setString("获取方式")

    UIImageBox.new(self.resourceNode_:getChildByName("img_bg"),function()
		
	end)
end


function CollectionShowWin:getActionIn()
    Helper.enterWinAction1(self)
end

return CollectionShowWin