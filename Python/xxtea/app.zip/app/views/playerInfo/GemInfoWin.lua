local c = require "app.configs.constants"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local CoreColor = require "sandglass.core.CoreColor"
local WordDictionary = require "app.configs.WordDictionary"
local MoveLabel = require "sandglass.ui.MoveLabel"
local RichLabel = require "sandglass.ui.RichLabel"
local Helper = require "app.Helper"
local init = require "app.models.init"
local ghostJadeConf = require "app.configs.ghostJade"
local itemConf = require "app.configs.item"
local UILabel = require "sandglass.ui.UILabel"
local attributeConf = require "app.configs.attribute"

local PlayerModel = init.PlayerModel

local GemInfoWin = class("GemInfoWin", WinBase)
GemInfoWin.RESOURCE_FILENAME = "playerInfo/gemInfo.csb"

function GemInfoWin:onCreate(jadeEqIds)
    self.priority = c.WIN_ZORDER.POPUP
    self.jadeEqIds = jadeEqIds.EqId or {}
end

function GemInfoWin:initialView()
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)
    
    for _,info in ipairs(ghostJadeConf) do
        local node = self.resourceNode_:getChildByName("node_"..info.pos)
        node:getChildByName("img_op"):setOpacity(0)
        local jadeId = self.jadeEqIds[info.pos] or 0
        node:getChildByName("sp_icon"):setVisible(jadeId > 0)
        node:getChildByName("img_lvBg"):setVisible(jadeId > 0)
        if jadeId > 0 then
            node:getChildByName("sp_icon"):setTexture("icon/item/"..itemConf[jadeId].icon..".png")
            node:getChildByName("img_lvBg"):getChildByName("txt_lv"):setString("Lv."..itemConf[jadeId].jadeLevel)
            local values = {swallowTouches = true} 
            values.tipsProto = require "app.CommonTip"
            values.tipsParam = {type = c.TipsType.gem, id = jadeId}  
            UIImageBox.new(node:getChildByName("img_op"),function()
            end, values)
        end
    end
end

function GemInfoWin:getActionIn()
    Helper.enterWinAction1(self)
end

return GemInfoWin

