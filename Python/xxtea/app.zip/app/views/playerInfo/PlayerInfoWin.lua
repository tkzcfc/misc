-- 玩家详情
local scheduler = require "sandglass.core.Scheduler"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local Helper = require "app.Helper"
local MoveLabel = require "sandglass.ui.MoveLabel"
local c = require "app.configs.constants"
local UILabel = require "sandglass.ui.UILabel"
local zsdforeverbuffConf = require "app.configs.zsdforeverbuff"
local rankConf = require "app.configs.rank"
local monsterConf = require "app.configs.monster"
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local jobConf = require "app.configs.job"
local medallionConf = require "app.configs.medallion"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local init = require "app.models.init"
local openConf = require "app.configs.open"
local SpineManager = require "sandglass.core.SpineManager"
local CoreColor = require "sandglass.core.CoreColor"
local ghostUpConf = require "app.configs.ghostUp"
local ghostSkinConf = require "app.configs.ghostSkin"
local UIAniButton = require "sandglass.ui.UIAniButton"
local skinConf = require "app.configs.skin"
local globalPublicConf = require "app.configs.globalPublic"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel

local PlayerInfoWin = class("PlayerInfoWin", WinBase)

PlayerInfoWin.RESOURCE_FILENAME = "playerInfo/playerInfo.csb"

local HERO_POS = {
	[1] = cc.p(592, 15),
	[2] = cc.p(790, 50),
	[3] = cc.p(395, 50),
	[4] = cc.p(990, 90),
	[5] = cc.p(170, 90),
}

local HERORARE_IMAGE = {
	["R"] = "public/public_rarity_04.png",
	["SR"] = "public/public_rarity_05.png",
	["SSR"] = "public/public_rarity_06.png",
}

function PlayerInfoWin:onCreate(info, isFromArena)
	self.priority = c.WIN_ZORDER.POPUP
	-- self.showType = self.WinShowType.hiddenBack
	self.isFromArena = isFromArena or false
	self.shieldLayer_:setVisible(false)

	self.info = info or {}
	local msgList = {
		msgids.GS_PlayerChangeHead_R,
		msgids.GS_PlayerChangeHFrame_R,
		msgids.GS_PlayerChangeName_R,
	}
	network.addListener(self, msgList, handler(self, self.receive))
 
	self.isGetIntercept = false
    self.baseNode = self.resourceNode_:getChildByName("node_cb")
    self:createContent()
	
end

function PlayerInfoWin:receive(op, data)
	if op == msgids.GS_PlayerChangeHead_R or
	   op == msgids.GS_PlayerChangeHFrame_R or
	   op == msgids.GS_PlayerChangeName_R then
        if self.info.Plrid == PlayerModel.info.userId then
        	self.info.Head = PlayerModel.info.head
        	self.info.HFrame = PlayerModel.info.hFrame
        	self.info.Name = PlayerModel.info.name
        	self:updatePlayerInfo()
        end 
	end
end

function PlayerInfoWin:initialView()
	if self.info.GName ~= "" then
		self.resourceNode_:getChildByName("node_ct"):getChildByName("txt_guild"):setString(self.info.GName)
	else
		self.resourceNode_:getChildByName("node_ct"):getChildByName("txt_guild"):setString(WordDictionary[52012])
	end
	self.closeBtn = UIImageBox.new(self.resourceNode_:getChildByName("closeNode"):getChildByName("closeBtn"),function()
		self:closeSelf()
	end)
	self.resourceNode_:getChildByName("closeNode"):getChildByName("txt_title"):setString(self.info.Plrid == PlayerModel.info.userId and WordDictionary[21544] or WordDictionary[21549])
	self.resourceNode_:getChildByName("closeNode"):getChildByName("btn_rule"):hide()
	self.btn_medal = UIImageBox.new(self.resourceNode_:getChildByName("node_rt"):getChildByName("btn_medal"),function()
		--查看其他玩家时，如果未获得勋章，不打开勋章界面
		if self.info.Plrid ~= PlayerModel.info.userId and (self.info.Medal == nil or #self.info.Medal == 0) then
			MoveLabel.new(WordDictionary[21546])
			return
		end

		local medal = {}
		for k,v in pairs(self.info.Medal or {}) do
			medal[v.T] = v
		end

		local data = {
	        Plrid = self.info.Plrid,
	        Medal = medal,
	    }
	    self:openWin("MedalWin", data)
	end)
	-- self.btn_medal:setVisible(false)
	self:updatePlayerInfo()
	local node_ct = self.resourceNode_:getChildByName("node_ct")
	local img_head = node_ct:getChildByName("img_head")
	UIImageBox.new(img_head,function()
		if self.info.Plrid == PlayerModel.info.userId then
			self:openWin("SetPlayerHeadWin", 1)
		end
	end)


	local tcxjLv, bcjLv = 0, 0
	for i,v in ipairs(self.info.Phantom or {}) do
		if v.Id == 1 then
			tcxjLv = v.Lv
		elseif v.Id == 2 then
			bcjLv = v.Lv
		end
	end
	self.resourceNode_:getChildByName("node_c"):getChildByName("img_tcyj"):getChildByName("txt_num"):setString(tcxjLv .. WordDictionary[21551])
	self.resourceNode_:getChildByName("node_c"):getChildByName("img_bcj"):getChildByName("txt_num"):setString(bcjLv .. WordDictionary[21551])
	self.resourceNode_:getChildByName("node_c"):getChildByName("img_kami"):getChildByName("txt_num"):setString(self.info.GhostId/100 .. WordDictionary[21550])
	self.resourceNode_:getChildByName("node_c"):getChildByName("img_xp"):getChildByName("txt_num"):setString(self.info.AstrolabeLevel .. WordDictionary[21550])
	self.resourceNode_:getChildByName("node_c"):getChildByName("img_zx"):getChildByName("txt_num"):setString(self.info.AstrolabePoint .. WordDictionary[21552])
	self.resourceNode_:getChildByName("node_c"):getChildByName("img_skin"):getChildByName("txt_num"):setString(ghostSkinConf[self.info.GhostSkin].name)

	UIImageBox.new(self.resourceNode_:getChildByName("node_rt"):getChildByName("btn_gem"),function()
		self:openWin("GemInfoWin", self.info.GhostJade)
	end)
end

function PlayerInfoWin:updatePlayerInfo()
	local node_ct = self.resourceNode_:getChildByName("node_ct")
	node_ct:getChildByName("txt_name"):setString(self.info.Name)
	node_ct:getChildByName("txt_lv"):setString(self.info.Lv)
	node_ct:getChildByName("txt_power"):setString(self.info.AtkPower)
	node_ct:getChildByName("txt_id"):setString(self.info.Plrid)
	node_ct:getChildByName("txt_vip"):setString(self.info.Vip)
	local headData = {
        frame = node_ct:getChildByName("img_head"),
        headId = self.info.Head,
        frameId = self.info.HFrame,
        title = self.info.Title,
    }
    Helper.createPlayerHead(headData)
end

function PlayerInfoWin:createContent()
	------幻化神
	local node_c = self.resourceNode_:getChildByName("node_c")
	local posX = 592 * self.uiScale - display.cx
	local posY = 300 * self.uiScale

	local kamiId = math.floor(self.info.GhostId / 100)

	local monsterId = ghostSkinConf[self.info.GhostSkin].monsterId
	local monsterIds = ghostSkinConf[self.info.GhostSkin].ghostUpMonsterId

	table.sort(monsterIds,function (a,b)
		return a.lv < b.lv
	end)
	local finalMonsterId = monsterId
	for _,v in pairs(monsterIds) do
		if kamiId >= v.lv then
			finalMonsterId = v.id
		end
	end

	local role = monsterConf[finalMonsterId].role
	-- local role = monsterConf[monsterId].role
	local path = "spine/actors/" .. roleConf[role].spine
	local kamiSpine = UIAniButton.new(path,function(eventType,me,point)
        if eventType == "ended" then
        end
    end, {idle = "idle", loop = -1, swallowTouches = false})
    kamiSpine:setScale(2)
    kamiSpine:setPosition(posX, posY * 0.6 - display.cy)
    node_c:addChild(kamiSpine, -1)

    local kTitleBg = display.newSprite("#playerInfo/mingzi_di.png", 0, 0, {scale9 = true, size = cc.size(40,190)})
	kTitleBg:setPosition(posX, posY - display.cy)
	kTitleBg:setRotation(-90)
	local mtPos = cc.p(posX, posY - display.cy)
	node_c:addChild(kTitleBg)
	local kTitle = UILabel.new({
		text = WordDictionary[21215],
		color = cc.c3b(254,254,211),
		back = CoreColor.BLACK,
		-- dimensions = cc.size(30, 150),
		-- dimensions = cc.size(150, 30),
		size = 20,
	})

	if not self.info.GhostId then
		self.info.GhostId = 100
	end
	local lvTitle = UILabel.new({
		text = "Lv." .. math.floor(self.info.GhostId/100),
		color = cc.c3b(255,132,1),
		back = cc.c3b(64,23,6),
		size = 20,
	})
	kTitle:setAnchorPoint(cc.p(1, 0.5))
	--lvTitle:setAnchorPoint(cc.p(0, 0.5))
	kTitle:setPosition(cc.p(mtPos.x+kTitle:getContentSize().width*0.5-15, mtPos.y))
	--lvTitle:setPosition(cc.p(mtPos.x+kTitle:getContentSize().width*0.5-15, mtPos.y))
	node_c:addChild(kTitle)
	--node_c:addChild(lvTitle)

	self:updateHero()
	self:updateBtns()
end

function PlayerInfoWin:updateHero()
	local heros = self.info.HerosInfo or {}
	-- for i=1,4 do
	-- 	table.insert(heros, heros[1])
	-- end
	for i=1,5 do
		if self.baseNode:getChildByName("hero_"..i) then
			self.baseNode:removeChildByName("hero_"..i)
		end
		local heroData = heros[i]
		if heroData then
			local v = heroData.Hero
			local conf = heroConf[v.Id] or monsterConf[v.Id]
		    local heroItem = cc.CSLoader:createNode("playerInfo/heroItem.csb")
		    local pos = clone(HERO_POS[i])
		    pos.x = pos.x * self.uiScale - display.cx
		    pos.y = pos.y * self.uiScale
		    heroItem:setPosition(pos)
		    heroItem:setName("hero_"..i)
		    self.baseNode:addChild(heroItem)
		    heroItem:getChildByName("txt_name"):setString(conf.heroName or conf.name)
		    heroItem:getChildByName("txt_lv"):setString("Lv."..v.Lv)
		    local tips = heroItem:getChildByName("txt_tips")
		    if i == 1 and not self.isFromArena then
		    	tips:setVisible(true)
		    else
		    	tips:setVisible(false)
		    end
		    local node_spine = heroItem:getChildByName("node_spine")
		    local path = "spine/actors/".. roleConf[conf.role].spine
		    local skinId = v.CurSkin or 1
		    local heroSpine = UIAniButton.new(path,function(eventType,me,point)
		        if eventType == "ended" then
		            -- if self.info.Plrid ~= PlayerModel.info.userId then
		                display.getRunningScene():getChildByName("ViewBase"):openWin("HeroInfoWin", heroData)
		            -- end
		        end
		    end, {idle = "idle", loop = -1, swallowTouches = false, skin = skinConf[skinId].spineName})		
		    node_spine:addChild(heroSpine)
		    if Helper.checkHeroIsDemon(v.Id, v.Star) then
				heroItem:getChildByName("starNode"):setVisible(false)
				heroItem:getChildByName("sp_demon"):setVisible(true)
				local auraAnim = SpineManager.createAnimation("public/"..heroConf[v.Id].auraSpine, 1)
			    auraAnim:playAnimation("idle", -1)
			    auraAnim:setPosition(3, 10)
			    heroSpine:addChild(auraAnim)
			else
				Helper.updateHeroStar(heroItem:getChildByName("starNode"), v.Star, "star_")
			end
		end
	end
end

function PlayerInfoWin:updateBtns()
	local node_lt = self.resourceNode_:getChildByName("node_lt")
	local node_rt = self.resourceNode_:getChildByName("node_rt")
	local btn_setting = node_lt:getChildByName("btn_setting")
	local btn_number = node_lt:getChildByName("btn_number")
	local btn_back = node_lt:getChildByName("btn_back")
	local btn_info = node_lt:getChildByName("btn_info")
	local btn_exchange = node_lt:getChildByName("btn_exchange")

	local btn_change = self.resourceNode_:getChildByName("node_ct"):getChildByName("btn_change")

	if self.info.Plrid ~= PlayerModel.info.userId then
		btn_setting:hide()
		btn_number:hide()
		btn_back:hide()
		btn_info:hide()
		btn_exchange:hide()
		btn_change:hide()
	else
		btn_setting:show()
		btn_number:show()
		-- btn_back:show()
		btn_change:show()
		------改名
		UIImageBox.new(btn_change,function()
			self:openWin("ChangeNameWin")
		end)

		-------返回登陆
		UIImageBox.new(btn_back,function()
	    	self:openWin("PublicTipWin", {tipLabel = {str = WordDictionary[21505]}}, function()
				local SDKController = require "app.sdk.SDKController"
				SDKController.getSDKHelper():logout({needLogoutUser = false},function(ret)
					local PlayerConfig = require "sandglass.core.PlayerConfig"
    				PlayerConfig.setSetting("playerLoginType", "")
					onLogoutResult(ret)
				end)
	        end)
		end)
		btn_back:hide()
		btn_info:setPositionY(btn_back:getPositionY())
		-------设置
		UIImageBox.new(btn_setting,function()
			self:openWin("SettingWin")
		end)
		-------兑换码
		UIImageBox.new(btn_number,function()
			self:openWin("CodeWin")
		end)
		btn_number:setVisible(not PlayerModel.info.isAudit)
		---用户中心
		UIImageBox.new(btn_info,function()
			local SDKController = require "app.sdk.SDKController"
			SDKController.getSDKHelper():showAccountCenter()
		end)
		btn_info:setVisible(SDK_PARAMS.auth == "zqb-xinyou")
		-------封测返利兑换
		UIImageBox.new(btn_exchange,function()
			self:openWin("TestRebateWin")
		end)
		local SDKController = require "app.sdk.SDKController"
		local serverInfo = SDKController.getServerInfo()
		btn_exchange:setVisible((SDK_PARAMS.DELETE_TEST == 2 and serverInfo.id == 1) and true or false)
		if not btn_info:isVisible() then
			btn_exchange:setPositionY(btn_info:getPositionY())
		end 
	end

end

function PlayerInfoWin:onEnterTransitionFinish()
    if self.info.Plrid == PlayerModel.info.userId then
    	self:registerEvent("refreshPlayerInfoHeadTips")
    	RedTipsModel:refreshPlayerInfoHeadTips()
    	self:registerEvent("refreshMedalTips")
    	RedTipsModel:refreshMedalTips()
    end
end

function PlayerInfoWin:onEventReceive(event)
    local name = event:getEventName()
    local param = event._usedata
    if name == "refreshPlayerInfoHeadTips" then
        local btn = self.resourceNode_:getChildByName("node_ct"):getChildByName("img_head") 
        if param.addtips then
            RedTipsModel:addRedTip(btn, cc.p(90, 90))
        else
            RedTipsModel:removeRedTip(btn)
        end
    elseif name == "refreshMedalTips" then
    	local btn = self.resourceNode_:getChildByName("node_rt"):getChildByName("btn_medal")
        if param.addtips then
            RedTipsModel:addRedTip(btn, cc.p(55, 55))
        else
            RedTipsModel:removeRedTip(btn)
        end
    end
end

function PlayerInfoWin:getActionIn()
    Helper.enterWinAction2(self)
end

function PlayerInfoWin:getActionOut(callback)
   Helper.outWinAction(self, callback)
   return true
end


return PlayerInfoWin