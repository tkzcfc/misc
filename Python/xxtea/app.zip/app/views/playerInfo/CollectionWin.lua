local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local init = require "app.models.init"
local c = require "app.configs.constants"

local CollectionWin = class("CollectionWin", WinBase)

CollectionWin.RESOURCE_FILENAME = "layer/rank/collection.csb"

local PlayerModel = init.PlayerModel

function CollectionWin:onCreate()
	self.priority = c.WIN_ZORDER.NORMAL
    self.curPage = 0
end

function CollectionWin:initialView()
	cc.SpriteFrameCache:getInstance():addSpriteFrames("shop/shop.plist")
	self.pageView = self.resourceNode_:getChildByName("pageView")
	UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
		self:closeSelf()
	end)


	self:createContent()
end

function CollectionWin:createContent()
	local txt_num = self.resourceNode_:getChildByName("txt_num")
	txt_num:setString("50/100")
	for k,v in pairs(self.points or {}) do
		v:removeFromParent()
	end
	self.points = {}

	local listData = {{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}}
	self.pageView:removeAllPages()
	local number = 6
	local row = 220
	local spacing = 330
	local startX = 0
	local startY = 225
	local defaultWidth = 38
	local starPosx = (display.width - math.ceil(#listData / number) * defaultWidth) / 2
	self.listNumber = math.ceil(#listData / number)
	self:stopActionByTag(0XABC)
	local pageNum = 1
    self:actionScheduleInterval(function()
        if pageNum <= self.listNumber then
        	local widget = ccui.Widget:create()
			for j = 1,number do
				local tData = listData[j + (pageNum - 1) * number]
				if not tData then
					break
				end
                local node = self:createGoodsItem(tData)
                local posX = startX + (j - math.floor((j-1)/(number/2))*number/2 - 1)*spacing
                local posY = startY - math.floor((j-1)/(number/2))*row
				display.align(node,display.BOTTOM_LEFT,posX , posY )
				widget:addChild(node)
			end
			self.pageView:addPage(widget)
			local point = display.newSprite("#shop/shop_state_06.png")
			point:setPosition(starPosx + defaultWidth * (pageNum - 1),18)
			self.resourceNode_:addChild(point)
			self.points[pageNum] = point
        else
        	self:stopActionByTag(0XABC)
        	self.pageView:setCurrentPageIndex(self.curPage)
            self:refreshPoint(self.curPage)
        end
        pageNum = pageNum + 1
    end, 1/60, 0XABC)
	
	self.leftBtn = UIImageBox.new(self.resourceNode_:getChildByName("left"),function()
		self.curPage = self.curPage - 1
		if self.curPage <= 0 then
			self.curPage = 0
		end
		self.pageView:scrollToPage(self.curPage)
	end)

	self.rightBtn = UIImageBox.new(self.resourceNode_:getChildByName("right"),function()
		self.curPage = self.curPage + 1
		if self.curPage >= math.ceil(#listData / number) then
			self.curPage = math.ceil(#listData / number)
		end
		self.pageView:scrollToPage(self.curPage)
	end)

	self.pageView:addEventListener(function(pageView)
		self.curPage = self.pageView:getCurrentPageIndex()
		self:refreshPoint(self.curPage)
	end)
end

function CollectionWin:createGoodsItem()
	local itemNode = cc.CSLoader:createNode("layer/rank/collectionItem.csb")
    local txt_name = itemNode:getChildByName("txt_name")
    local txt_attr = itemNode:getChildByName("txt_attr")
    local node_item = itemNode:getChildByName("node_item")
    txt_name:setString("名字")
    txt_attr:setString("非常稀有")

    UIImageBox.new(itemNode:getChildByName("img_bg"),function()
		self:openWin("CollectionShowWin")
	end, {swallowTouches = false})

    return itemNode
   
end

function CollectionWin:refreshPoint(idx)
	for k,v in pairs(self.points) do
		if k == idx + 1 then
			v:setSpriteFrame("shop/shop_state_05.png")
		else
			v:setSpriteFrame("shop/shop_state_06.png")
		end
	end

	if self.curPage <= 0 then
		self.leftBtn:setEnabled(false)
	else
		self.leftBtn:setEnabled(true)
	end

	if self.curPage >= self.listNumber - 1 then
		self.rightBtn:setEnabled(false)
	else
		self.rightBtn:setEnabled(true)
	end

end

function CollectionWin:getActionIn()
    Helper.enterWinAction1(self)
end

return CollectionWin