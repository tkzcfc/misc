-- 玩家英雄详情
local heroConf = require "app.configs.hero"
local roleConf = require "app.configs.role"
local skinConf = require "app.configs.skin"
local itemConf = require "app.configs.item"
local monsterConf = require "app.configs.monster"
local c = require "app.configs.constants"
local Helper = require "app.Helper"
local CoreColor = require "sandglass.core.CoreColor"
local SpineManager = require "sandglass.core.SpineManager"
local WordDictionary = require "app.configs.WordDictionary"
local UILabel = require "sandglass.ui.UILabel"
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local heroHorcruxConf = require "app.configs.heroHorcrux"
local levelUpConf = require "app.configs.levelUp"
local globalPublicConf = require "app.configs.globalPublic"
local attributeConf = require "app.configs.attribute"
local runeConf = require "app.configs.rune"
local skillConf = require "app.configs.skill"
local init = require "app.models.init"
local RuneModel = init.RuneModel

local HeroInfoWin = class("HeroInfoWin", WinBase)
HeroInfoWin.RESOURCE_FILENAME = "playerInfo/heroInfo.csb"

local HERO_COLOR = {
	["R"] = CoreColor.BLUE,
	["SR"] = CoreColor.PURPLE,
	["SSR"] = CoreColor.ORANGE,
	["KKK"] = CoreColor.RED,
}

local WASH_ATTR_BG = {
    [4] = "heroList/hunqi-di2.png",
    [5] = "heroList/hunqi-di3.png",
    [6] = "heroList/hunqi-di4.png",
    [7] = "heroList/hunqi-di7.png",
}

local WASH_ATTR_AROW_BG = {
    [4] = "heroList/hunqi-zhuangshi1.png",
    [5] = "heroList/hunqi-zhuangshi2.png",
    [6] = "heroList/hunqi-zhuangshi3.png",
    [7] = "heroList/hunqi-zhuangshi4.png",
}

function HeroInfoWin:onCreate(info)
	self.priority = c.WIN_ZORDER.POPUP
	self.curPage = 1
	self.info = info
end

function HeroInfoWin:initialView()
	self:setAutoClose(self.resourceNode_:getChildByName("bg"))

	for i=1,3 do
		local btnImg = self.resourceNode_:getChildByName("btn_"..i)
		UIImageBox.new(btnImg,function()
			if self.curPage ~= i then
				self.curPage = i
				self:updateView()
			end 
		end)
	end

	self:updateView()
end

function HeroInfoWin:updateView()
	for i=1,3 do
		if i == self.curPage then
			self.resourceNode_:getChildByName("btn_"..i):loadTexture("public/yingxiong-yeka1.png", ccui.TextureResType.plistType)
            self.resourceNode_:getChildByName("btn_"..i):getChildByName("txt_str"):setTextColor(cc.c3b(246,228,116))
            self.resourceNode_:getChildByName("btn_"..i):getChildByName("txt_str"):enableOutline(cc.c3b(164,101,16), 2)
		else
			self.resourceNode_:getChildByName("btn_"..i):loadTexture("public/yingxiong-yeka2.png", ccui.TextureResType.plistType)
            self.resourceNode_:getChildByName("btn_"..i):getChildByName("txt_str"):setTextColor(cc.c3b(175,149,112))
            self.resourceNode_:getChildByName("btn_"..i):getChildByName("txt_str"):enableOutline(cc.c3b(60,43,37), 2)
		end
	end
	if self.horcruxNode then
		self.horcruxNode:setVisible(false)
	end
	if self.heroNode then
		self.heroNode:setVisible(false)
	end
    if self.runeNode then
        self.runeNode:setVisible(false)
    end

	if self.curPage == 1 then
		if self.heroNode then
			self.heroNode:setVisible(true)
		else
			self:createHeroInfo()
		end
		self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[21553])
	elseif self.curPage == 2 then
		if self.horcruxNode then
			self.horcruxNode:setVisible(true)
		else
			self:createHorcruxInfo()
		end
		self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[21554])
    elseif self.curPage == 3 then
        if self.runeNode then
            self.runeNode:setVisible(true)
        else
            self:createRuneInfo()
        end
        self.resourceNode_:getChildByName("txt_title"):setString(WordDictionary[21555])
	end
end

function HeroInfoWin:createRuneInfo()
    local cNode = self.resourceNode_:getChildByName("node")
    local node = self:createCsbNode("playerInfo/runeNode.csb")
    cNode:addChild(node)
    self.runeNode = node
    local runes = self.info.Rune or {}
    for i=1,2 do
        local sp_nil = node:getChildByName("sp_nil" .. i)
        local infoNode = node:getChildByName("node_" .. i)
        local runeInfo = runes[i]
        if runeInfo then
            local conf = itemConf[runeInfo.Id]
            sp_nil:setVisible(false)
            infoNode:setVisible(true)
            infoNode:getChildByName("sp_icon"):setTexture("icon/item/" .. conf.icon .. ".png")
            local txt_name = infoNode:getChildByName("txt_name")
            txt_name:setString(conf.name)
            txt_name:setTextColor(c.ITEM_COLOR[conf.color])
            local lv = runeConf[conf.type].level
            local txt_lv = infoNode:getChildByName("txt_lv")
            txt_lv:setString("Lv."..lv)
            txt_lv:setTextColor(c.ITEM_COLOR[conf.color])
            ----属性
            local attrs = runeInfo.RProp or {}
            local col = 2
            local colSpacing = 20
            local spacing = 130
            local startY = (math.ceil(#attrs/col)-1)*(colSpacing/2)
            for i,v in ipairs(attrs) do
                local attrStr = UILabel.new({
                    text = attributeConf[v.Id].name .." +".. Helper.getAttriValue(v.Id, v.Val),
                    color = cc.c3b(182,235,49),
                    size = 16,
                    back = CoreColor.BLACK,
                })
                display.align(attrStr, display.LEFT_CENTER, (i-math.floor((i-1)/col)*col-1)*spacing, startY - (math.floor((i-1)/col)*colSpacing))
                infoNode:getChildByName("node_attr"):addChild(attrStr)
            end
            if runeInfo.Skill and runeInfo.Skill[1] and skillConf[runeInfo.Skill[1]] then
                local skillC = skillConf[runeInfo.Skill[1]] 
                infoNode:getChildByName("txt_skillName"):setString(skillC.name)
                infoNode:getChildByName("txt_skillName"):setTextColor(CoreColor[RuneModel:getRuneSkillColor(skillC.Id)])
                infoNode:getChildByName("txt_skillDes"):setString(skillC.des)
                local sItem = Helper.createSkillIcon({id = skillC.Id, scale = 0.8})
                infoNode:getChildByName("node_skill"):addChild(sItem)
            else
                infoNode:getChildByName("txt_skillName"):setString(WordDictionary[50113])
                infoNode:getChildByName("txt_skillDes"):setString("")
            end 
        else
            sp_nil:setVisible(true)
            infoNode:setVisible(false)
        end
    end
end


function HeroInfoWin:createHeroInfo()
	local cNode = self.resourceNode_:getChildByName("node")
	local node = self:createCsbNode("playerInfo/heroNode.csb")
	cNode:addChild(node)
	self.heroNode = node
	local hero = self.info.Hero
	local conf = heroConf[hero.Id] or monsterConf[hero.Id]
	node:getChildByName("img_name"):getChildByName("img_rare"):loadTexture("public/yingxiong-" .. string.upper(conf.rare) ..".png", ccui.TextureResType.plistType)
	local txt_name = node:getChildByName("img_name"):getChildByName("txt_name")
	txt_name:setString(conf.heroName)
	txt_name:setTextColor(HERO_COLOR[conf.rare])

	local path = "spine/actors/".. roleConf[conf.role].spine
	local anim = SpineManager.createAnimation(path)
	local skinId = hero.CurSkin or 1
	anim:registerSkin(skinConf[skinId] and skinConf[skinId].spineName or "normal")
	anim:playAnimation("idle", -1)
	node:getChildByName("node_spine"):addChild(anim)

	node:getChildByName("txt_level"):setString("Lv."..hero.Lv)
	node:getChildByName("txt_talent"):setString(hero.Cls)
	local horcrux = hero.Horcrux and hero.Horcrux.Lv or 1
	node:getChildByName("txt_horcrux"):setString("Lv."..horcrux)
	--星级 
	Helper.updateHeroStar(node:getChildByName("starNode"),hero.Star)

	if hero.Id == 20053 and skinId == 5 then---龙琴十二烛皮肤展示(权权说写死)
		local anim = SpineManager.createAnimation("activity/advertisement/ui_cha_longqin", 1)
		anim:playAnimation("idle", -1)
		anim:setScale(0.7)
		node:getChildByName("node_skin"):addChild(anim)
	end
    if hero.Id == 20050 and skinId == 5 then---太慈雪一皮肤展示(权权说写死)
        local anim = SpineManager.createAnimation("activity/advertisement/ui_cha_taici", 1)
        anim:playAnimation("idle", -1)
        anim:setScale(0.7)
        node:getChildByName("node_skin"):addChild(anim)
    end

	local node_equip = node:getChildByName("node_equip")
    node_equip:removeAllChildren()
	cc.SpriteFrameCache:getInstance():addSpriteFrames("equip/equip.plist")

	local armors = {}
	local index = 0
	local perX = 0
	local oldPosX = node_equip:getPositionX()
	node:getChildByName("txt_status"):setVisible(not self.info.Armor)
	for _, armor in pairs(self.info.Armor or {}) do
	    index = index + 1
		local equip = Helper.createGoodsItem(
	        {
	            haveTip = true,
	            level = armor.Lv,
	            scale = 0.75,
	            id = armor.Id,
	            star = armor.Star,
	            smeltLv = armor.SmtLv
	        })
		perX = equip:getContentSize().width * equip:getScale()
		equip:setPositionX(((index - 1) * (perX + 5)) + 25)
	    node_equip:addChild(equip)
	end
	node_equip:setPositionX(oldPosX - (index/2) * perX)
end

function HeroInfoWin:createHorcruxInfo()
	local cNode = self.resourceNode_:getChildByName("node")
	local node = self:createCsbNode("playerInfo/HorcruxNode.csb")
	cNode:addChild(node)
	self.horcruxNode = node

	local horcruxConf = heroHorcruxConf[self.info.Hero.Id]
    node:getChildByName("txt_lv"):setString(horcruxConf.name.." Lv."..self.info.Horcrux.Lv)
    local horcruxAnim = SpineManager.createAnimation("spine/artifact/"..horcruxConf.spine, 1)
    horcruxAnim:playAnimation("idle", -1)
    horcruxAnim:setAutoRemove(true)
    horcruxAnim:setScale(0.8)
    node:getChildByName("node_icon"):addChild(horcruxAnim)
    horcruxAnim:runAction(cc.RepeatForever:create(
        cc.Sequence:create(
            cc.MoveBy:create(0.5, cc.p(0, 30)),
            cc.MoveBy:create(1, cc.p(0, -60)),
            cc.MoveBy:create(0.5, cc.p(0, 30))
        )
    ))

    --属性显示
    local node_attr = node:getChildByName("node_attr")
    local lvUpConf = levelUpConf[self.info.Horcrux.Lv]
    local spacing = 180
    local startX = - (#lvUpConf.horcruxLvAttr - 1)*(spacing/2)
    for k,info in ipairs(lvUpConf.horcruxLvAttr) do
        local attrConf = attributeConf[info.id]
     	local nameStr = UILabel.new({
	        text = attrConf.name..": +",
	        color = cc.c3b(214, 198, 182),
	        back = CoreColor.BLACK,
	        size = 16,
	    })
	    local valStr = UILabel.new({
	        text = self:getAttrValByJob(info.id, info.val),
	        color = CoreColor.GREEN,
	        back = CoreColor.BLACK,
	        size = 16,
	    })
	    display.align(nameStr, display.CENTER, startX + (k-1)*spacing, 0)
	    node_attr:addChild(nameStr)
	    display.align(valStr, display.LEFT_CENTER, startX + (k-1)*spacing + nameStr:getContentSize().width/2 + 2 , 0)
	    node_attr:addChild(valStr)
    end

    local lockData = horcruxConf.unlockAddAttrLv
    for i=1,6 do
        local node_ = node:getChildByName("node_"..i)
        local unOpen = self.info.Horcrux.XProps == nil or self.info.Horcrux.XProps[i] == nil
        local bg ="heroList/hunqi-di1.png"
        node_:getChildByName("sp_arow1"):setVisible(not unOpen)
        node_:getChildByName("sp_arow2"):setVisible(not unOpen)
        node_:getChildByName("btn_lock"):setVisible(false)
        if not unOpen then
            local attr = self.info.Horcrux.XProps[i]
            local color = Helper.getAttrColor(attr.Id, attr.Val)
            if WASH_ATTR_BG[color] then
                bg = WASH_ATTR_BG[color]
            end
            node_:getChildByName("txt_attr"):setTextColor(c.ITEM_COLOR[color])
            node_:getChildByName("txt_attr"):setString(attributeConf[attr.Id].name.."+"..Helper.getAttriValue(attr.Id, attr.Val))
            node_:getChildByName("sp_arow1"):setVisible(color > 3)
            node_:getChildByName("sp_arow2"):setVisible(color > 3)
            if color > 3 then
                node_:getChildByName("sp_arow1"):setSpriteFrame(WASH_ATTR_AROW_BG[color])
                node_:getChildByName("sp_arow2"):setSpriteFrame(WASH_ATTR_AROW_BG[color])
            end
        else
            node_:getChildByName("txt_unlock"):setString(string.format(WordDictionary[50078], lockData[i]))
        end
        node_:getChildByName("sp_di"):setSpriteFrame(bg)
        node_:getChildByName("txt_attr"):setVisible(not unOpen)
        node_:getChildByName("txt_unlock"):setVisible(unOpen)
    end
end

function HeroInfoWin:getAttrValByJob(attrId, attrVal)
    local val = attrVal
    local heroConf = heroConf[self.info.Hero.Id]
    if heroConf then
        local job = heroConf.jobId
        if attrId == 10 then
            for k,v in ipairs(globalPublicConf[1].occupationAtkParam) do
                if v.id == job then
                    val = val * v.n
                    break
                end
            end
        elseif attrId == 11 then
            for k,v in ipairs(globalPublicConf[1].occupationDefParam) do
                if v.id == job then
                    val = val * v.n
                    break
                end
            end
        elseif attrId == 12 then
            for k,v in ipairs(globalPublicConf[1].occupationHpParam) do
                if v.id == job then
                    val = val * v.n
                    break
                end
            end
        end
    end
    return val
end

function HeroInfoWin:getActionIn()
    Helper.enterWinAction1(self)
end

return HeroInfoWin
