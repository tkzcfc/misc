-- 排行榜

local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local c = require "app.configs.constants"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local init = require "app.models.init"
local AudioManager = require "sandglass.core.AudioManager"
local SpineManager = require "sandglass.core.SpineManager"
local guildHeadConf = require "app.configs.guildHead"

local rankConf = require "app.configs.rank"
local arenaBotConf = require "app.configs.arenaBot"
local towerConf = require "app.configs.tower"
local GuildModel = init.GuildModel
local RankWin = class("RankWin", WinBase)

RankWin.RESOURCE_FILENAME = "rank/rank.csb"

local PlayerModel = init.PlayerModel

function RankWin:onCreate(selectPage)
	self.priority = c.WIN_ZORDER.POPUP
	self.selectPage = selectPage
	self.pages = {}
	self.curTypeConfData = nil--当前选择的排行类型配置数据
	self.curSelectItemData = nil--当前选择的右边列表Item数据

	local msgList = {
		msgids.GS_RankGetTop_R,
		msgids.GS_PlayerInfo_R,
		msgids.GS_GuildInfo_R,
	}
	network.addListener(self, msgList, handler(self, self.receive))
end

function RankWin:initialView()

	local moveAction = cc.CSLoader:createTimeline(self.RESOURCE_FILENAME)
    self.resourceNode_:runAction(moveAction)
    moveAction:play("animation0", false)
    AudioManager.playEffect("music/ui_openshop.mp3")

	UIImageBox.new(self.resourceNode_:getChildByName("btn_close"), function()
		self:closeSelf()
	end)

    local anim = SpineManager.createAnimation("public/ui_cha_zuiniang",1)
    self.resourceNode_:getChildByName("node_npc"):addChild(anim)
    anim:playAnimation("idle", -1)
    anim:setFlipX(true)
    anim:setScale(1)

	--初始化两个滚动容器
	self.scrollView_1,self.sv1Size = self:initScrollView("scrollView_1")
	self.scrollView_2,self.sv2Size = self:initScrollView("scrollView_2")
	self.resourceNode_:getChildByName("myRankLabel"):setString(WordDictionary[21200])
	self.resourceNode_:getChildByName("myRankText"):setString("")

	self:initTypeList()

end

function RankWin:initScrollView(name)
	local scrollView = self.resourceNode_:getChildByName(name)
	scrollView:removeAllChildren()
	scrollView:setScrollBarEnabled(false)
	local svSize = scrollView:getContentSize()
	return scrollView,svSize
end

--拉取排行榜数据
function RankWin:getRankData()
	local id = self.curTypeConfData.id or 0
	network.tcpSend(msgids.C_RankGetTop, {Id = id})
end

--左边列表
function RankWin:initTypeList()
	local rankConfData = {}
	for k,v in pairs(rankConf) do
		if v.type == 2 then
			if Helper.getOpenState(20, true) then
				rankConfData[#rankConfData + 1] = v
			end
		else
			rankConfData[#rankConfData + 1] = v
		end
	end

	table.sort(rankConfData,function (a,b)
		return a.id < b.id
	end)

	local cnt = #rankConfData
	local offsetX = 10
	local offsetY = 43
	local scrollViewHeight = cnt * offsetY

	if self.sv1Size.height > scrollViewHeight then
		scrollViewHeight = self.sv1Size.height
	end
	self.scrollView_1:setInnerContainerSize(cc.size(self.sv1Size.width,scrollViewHeight))

	local idx = 1
	local dt = 0.01
	local animCount = 9
	for k,v in ipairs(rankConfData) do
		if true then--开启条件
			local item = self:createTypeItem(v)
			display.align(item,display.BOTTOM_LEFT, offsetX , scrollViewHeight - animCount * offsetY)
			if idx < animCount then
				item:runAction(cc.Sequence:create(
					cc.DelayTime:create(dt),
					cc.EaseSineOut:create(cc.MoveTo:create(0.55, cc.p(offsetX, scrollViewHeight - idx * offsetY)))
				))
				dt = dt + 0.1
			else
				item:setPosition(offsetX, scrollViewHeight - idx * offsetY)
			end
			self.scrollView_1:addChild(item)

			if self.selectPage then
				if self.selectPage == v.id then
					self.pages[self.selectPage]:onClick()
					self.scrollView_1:jumpToPercentVertical(100 * idx / cnt)
				end
			elseif idx == 1 then--默认选择第一个
				self.pages[v.id]:onClick()
			end
			idx = idx + 1
		end
	end
end

function RankWin:refreshSelectPage(id)
    if self.curTypeConfData and self.curTypeConfData.id == id then
        return
    end

    --切换按钮图片
    for _id,btn in pairs(self.pages) do
        local titleText = btn:getParent():getChildByName("Panel_Name"):getChildByName("titleText")
        if _id == id then
            titleText:setTextColor(cc.c3b(235,215,188))
            titleText:enableOutline(cc.c3b(164,101,16), 2)--描边
            btn:setImage("rank/fenyeanniu_xuanzhong.png",{isPlist = true})
        else
            btn:setImage("rank/fenyeanniu_weixuanzhong.png",{isPlist = true})
            titleText:setTextColor(cc.c3b(175,149,112))
            titleText:enableOutline(cc.c3b(60,43,37), 2)--描边
        end
    end
end

--左边类型item
function RankWin:createTypeItem(conf)
	local node = cc.CSLoader:createNode("rank/rankTypeNode.csb")

	-- node:getChildByName("titleText"):setString(conf.name)

	local panel_name = node:getChildByName("Panel_Name")
	local text_title = panel_name:getChildByName("titleText");
	text_title:setString(conf.name)
	
	-- 名字过长滚动
	local panel_size = panel_name:getContentSize();
	local txtSize = text_title:getContentSize()
	if txtSize.width > panel_size.width then
	    text_title:setPositionX(0)
	    local offsetX = txtSize.width - 170
	    local moveTime = offsetX / 30
	    text_title:stopAllActions()
	    text_title:runAction(cc.RepeatForever:create(
	        cc.Sequence:create(
	            cc.DelayTime:create(1),
	            cc.MoveBy:create(moveTime, cc.p(-offsetX, 0)),
	            cc.DelayTime:create(1),
	            cc.FadeOut:create(0.2),
	            cc.CallFunc:create(function()
	                text_title:setPosition(cc.p(0,0))
	            end),
	            cc.FadeIn:create(0.2)
	        )
	    ))
	else
	    text_title:setPositionX((panel_size.width-txtSize.width)/2)
	end

	local btn = UIImageBox.new(node:getChildByName("bg"), function()
		if not self.curTypeConfData or conf.id ~= self.curTypeConfData.id then
			self:refreshSelectPage(conf.id)
			self.curTypeConfData = conf
			self:getRankData()
		end
	end,{swallowTouches = false, playEffect = "ui_button1.mp3"})

	self.pages[conf.id] = btn

	return node
end

--右边列表
function RankWin:initItemList(data)
	Helper.lockWindow(true)
	self.resourceNode_:runAction(cc.Sequence:create(cc.DelayTime:create(0.5), cc.CallFunc:create(function()
		Helper.unlockWindow()
	end)))
	local data = data or {}
	local myRank = data.Idx or WordDictionary[21201]
	if myRank <= 0 then
		myRank = WordDictionary[21201]
	end
	self.resourceNode_:getChildByName("myRankText"):setString(myRank)

	self.scrollView_2:removeAllChildren()
	local records = data.Records or {}

	local cnt = #records
	local offsetX = 5
	local offsetY = 83
	local scrollViewHeight = cnt * offsetY

	if self.sv2Size.height > scrollViewHeight then
		scrollViewHeight = self.sv2Size.height
	end
	self.scrollView_2:setInnerContainerSize(cc.size(self.sv2Size.width,scrollViewHeight))
	self.scrollView_2:scrollToTop(0.01, false);
	local dt = 0.01
	local animCount = 7
	for i,v in ipairs(records) do
		local item = self:createRankItem(v)
		display.align(item,display.BOTTOM_LEFT, offsetX , scrollViewHeight - animCount * offsetY)
		if(i < animCount) then
			item:runAction(cc.Sequence:create(
				cc.DelayTime:create(dt),
				cc.EaseSineOut:create(cc.MoveTo:create(0.55, cc.p(offsetX, scrollViewHeight - i * offsetY)))
			))
			dt = dt + 0.1
		else
			item:setPosition(offsetX, scrollViewHeight - i * offsetY)
		end
		self.scrollView_2:addChild(item)
	end
end

--右边排行item
function RankWin:createRankItem(data)
	local node = cc.CSLoader:createNode("rank/listItemNode.csb")

	local btn = UIImageBox.new(node:getChildByName("bg"), function()
		self.curSelectItemData = data
		if self.curTypeConfData.type == 1 then
			if data.IsBot then
				self:produceBotData()
			else
				network.tcpSend(msgids.C_PlayerInfo, {PlrId = data.Plrid})
			end
		elseif self.curTypeConfData.type == 2 then
			network.tcpSend(msgids.C_GuildInfo, {GuildId = data.Plrid})
		end
	end,{swallowTouches = false})
	node.btn = btn

	--排名

	local rankIcon = node:getChildByName("rankIcon")
	local rankText = node:getChildByName("rankText")
	if data.Idx <= 3 then
		rankText:setVisible(false)
		rankIcon:setSpriteFrame("public/0"..data.Idx..".png")
		-- btn:setImage("rank/rank_slat_0" .. (data.Idx + 5) .. ".png")
	else
		rankIcon:setVisible(false)
		rankText:setString(data.Idx)
	end

	--头像
	local flagIndex,iconIndex = nil,nil
	if data.Head < 10 then
		flagIndex,iconIndex = GuildModel:getGuildHeadIndex(data.Head)
	else
		iconIndex = data.Head%10000
    	flagIndex = data.Head - iconIndex
    	if not guildHeadConf[flagIndex] then
    		flagIndex = nil
    	end
	end
	if not flagIndex then
		local headData = {
	        frame = node:getChildByName("headFrame"),
	        headId = data.Head,
	        frameId = data.HFrame,
	        title = data.Title,
	    }
	    Helper.createPlayerHead(headData)
		node:getChildByName("guildFrame"):setVisible(false)
	else
		-- local guildFrame = node:getChildByName("guildFrame")
		-- guildFrame:loadTexture("icon/head/"..guildHeadConf[flagIndex].icon..".png")
 	-- 	local item = display.newSprite("icon/head/" .. guildHeadConf[iconIndex].icon .. ".png")
 	-- 	display.align(item,display.CENTER, guildFrame:getContentSize().width * 0.5 , guildFrame:getContentSize().height * 0.5)
 	-- 	item:setScale(1.3)
 	-- 	guildFrame:loadTexture("public/public_slat_38.png",ccui.TextureResType.localType)
 	-- 	guildFrame:addChild(item)
	 	node:getChildByName("levelBg"):setVisible(false)
	 	node:getChildByName("levelText"):setVisible(false)
	 	node:getChildByName("guildFrame"):setVisible(false)
 		node:getChildByName("headFrame"):setVisible(false)
 		node:getChildByName("unionText"):setVisible(false)

 		node:getChildByName("nameText"):setPositionX(100)
 		node:getChildByName("descText"):setPositionX(100)
	end

	--等级
	node:getChildByName("levelText"):setString(data.Lv)

	--名字
	node:getChildByName("nameText"):setString(data.Name)

	--工会信息
	if not data.GName or data.GName == "" or data.IsBot then
		data.GName = WordDictionary[21203]
	end
	local unionName = string.format(WordDictionary[21202],data.GName)
	node:getChildByName("unionText"):setString(unionName)

	--排名值
	if self.curTypeConfData.id == 110 then --秘术之塔
		data.Score = towerConf[data.Score].floorName
	end
	--print(data.Score)
	local desc = self.curTypeConfData.rankDes or ""
	node:getChildByName("descText"):setString(string.format(desc,data.Score))
	return node
end

function RankWin:produceBotData()
 	local heros = {}
 	local lv = arenaBotConf[1].object
 	local atkPower = arenaBotConf[1].botpower
 	for i=1,5 do
 		local ids = arenaBotConf[1]["monster"..i]
 		local idx = math.random(1,#ids)
 		local hero = {Id = ids[idx], Lv = lv, Star = 1, Cls = 0, AtkPower = atkPower,}
 		heros[#heros + 1] = {Hero = hero}
 	end
	
	local info = {
		AtkPower = arenaBotConf[1].botpower,
		Vip = 0,
		HerosInfo = heros,
		Medal = {},
		ZsyzId = 10010,
		GhostId = 100,
		ReinGodSkills = {0,0,0,0,0},
		ReinGodLv = 1,
	}
	for key,val in pairs(self.curSelectItemData or {}) do
		info[key] = val
	end
	self:openWin("PlayerInfoWin",info)
end

function RankWin:receive(op, data)
	if op == msgids.GS_RankGetTop_R then--获取排行榜top信息
		self:initItemList(data.Rank)
	elseif op == msgids.GS_PlayerInfo_R then--排行榜获取玩家信息
		local info = data.Info
		for key,val in pairs(self.curSelectItemData or {}) do
			info[key] = val
		end
		self:openWin("PlayerInfoWin",info)
	elseif op == msgids.GS_GuildInfo_R then
		-- local win = self:getScene().winManager:findWinByName("RankGuildInfoWin")
		-- if not win then
		-- 	self:openWin("RankGuildInfoWin",data.Info)
		-- end
	end
end

function RankWin:getActionIn()
    Helper.enterWinAction1(self)
end


return RankWin