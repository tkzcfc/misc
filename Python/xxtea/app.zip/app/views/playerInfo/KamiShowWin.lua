local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local init = require "app.models.init"
local c = require "app.configs.constants"
local monsterConf = require "app.configs.monster"
local ghostUpConf = require "app.configs.ghostUp"
local roleConf = require "app.configs.role"
local SpineManager = require "sandglass.core.SpineManager"

local KamiShowWin = class("KamiShowWin", WinBase)

KamiShowWin.RESOURCE_FILENAME = "layer/rank/kamiShow.csb"

local PlayerModel = init.PlayerModel

function KamiShowWin:onCreate(info)
    self.priority = c.WIN_ZORDER.NORMAL
    self.info = info or {}
end

function KamiShowWin:initialView()
	self:setAutoClose(self.resourceNode_:getChildByName("img_bg"))

	self:createContent()
end

function KamiShowWin:createContent()
    local txt_kamiLv = self.resourceNode_:getChildByName("txt_lv")
    -- local txt_godLv = self.resourceNode_:getChildByName("txt_lv2")
    local node_skill = self.resourceNode_:getChildByName("node_skill")
    local node_spine = self.resourceNode_:getChildByName("node_spine")
    txt_kamiLv:setString(math.floor(self.info.GhostId/100))
    -- txt_godLv:setString(self.info.ReinGodLv)
    local monsterData = monsterConf[ghostUpConf[math.floor(self.info.GhostId/100)].monsterID]
    local kamiRoleData = roleConf[monsterData.role]
    local path = "spine/actors/" .. kamiRoleData.spine
    local spine = SpineManager.createAnimation(path, 1)
    spine:playAnimation("idle", -1)
    spine:setScale(2)
    node_spine:addChild(spine)

    -- for i = 1,5 do
    --     local skillId = self.info.ReinGodSkills[i]
    --     if skillId and skillId ~= 0 then
    --         local icon = Helper.createSkillIcon({id = skillId, scale = 0.8})
    --         icon:setPositionX((i-1)*77)
    --         node_skill:addChild(icon)
    --     end
    -- end

    
end


function KamiShowWin:getActionIn()
    Helper.enterWinAction1(self)
end

return KamiShowWin