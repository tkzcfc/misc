
local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local WordDictionary = require "app.configs.WordDictionary"
local network = require "app.network.network"
local msgids = require "app.network.msgids"
local Helper = require "app.Helper"
local init = require "app.models.init"
local playerHeadConf = require "app.configs.playerHead"
local heroConf = require "app.configs.hero"
local itemConf = require "app.configs.item"
local playerFrameConf = require "app.configs.playerFrame"
local playerTitleConf = require "app.configs.playerTitle"
local attributeConf = require "app.configs.attribute"
local UILabel = require "sandglass.ui.UILabel"
local CoreColor = require "sandglass.core.CoreColor"
local c = require "app.configs.constants"
require "sandglass.ui.UIGridView"
local MoveLabel = require "sandglass.ui.MoveLabel"
local SpineManager = require "sandglass.core.SpineManager"
local globalPublicConf = require "app.configs.globalPublic"

local PlayerModel = init.PlayerModel
local RedTipsModel = init.RedTipsModel
local HeroModel = init.HeroModel

local SetPlayerHeadWin = class("SetPlayerHeadWin", WinBase)

SetPlayerHeadWin.RESOURCE_FILENAME = "playerInfo/headFrame.csb"

local HEAD_TYPE = {
	Head = 1,
	HeadFrame = 2,
	Title = 3 -- 新增称号
}

function SetPlayerHeadWin:onCreate(headType)
	self.priority = c.WIN_ZORDER.POPUP
	self.headType = headType
    
	local msgList = {
	    msgids.GS_PlayerChangeHead_R,
		msgids.GS_PlayerChangeHFrame_R,
		msgids.GS_PlayerChangeTitle_R,
	}
	network.addListener(self, msgList, handler(self, self.receive))
end

function SetPlayerHeadWin:receive(op, data)
	self:closeSelf()
end

-- 界面选择
function SetPlayerHeadWin:selectPage(selectPage)
	self.headType = selectPage

	local txt_title = self.resourceNode_:getChildByName("txt_title")

    if self.headType == HEAD_TYPE.Head then
    	RedTipsModel:removeNewAvatar()
    	txt_title:setString(WordDictionary[21540])
        self:createHead()

        self.selectAvatar = display.newSprite("#playerInfo/xuanzhong2.png")
		self.selectAvatar:setVisible(false)
		self.selectAvatar:setAnchorPoint(display.BOTTOM_LEFT)
		self.selectAvatar:retain()
		self.selectAvatar:setVisible(false)
	elseif self.headType == HEAD_TYPE.HeadFrame then
		RedTipsModel:removeNewFrame()
		txt_title:setString(WordDictionary[21539])
		self:createHeadFrame()

		self.selectFrame = display.newSprite("#playerInfo/xuanzhong2.png")
		self.selectFrame:setVisible(false)
		self.selectFrame:setAnchorPoint(display.BOTTOM_LEFT)
		self.selectFrame:retain()
		self.selectFrame:setVisible(false)
	elseif self.headType == HEAD_TYPE.Title then
		RedTipsModel:removeNewFrame()
		txt_title:setString(WordDictionary[21556])
		self:createTitle()

		self.selectTitle = display.newSprite("#playerInfo/xuanzhong2.png")
		self.selectTitle:setVisible(false)
		self.selectTitle:setAnchorPoint(display.BOTTOM_LEFT)
		self.selectTitle:retain()
		self.selectTitle:setVisible(false)
	end

	local p1 = "public/yingxiong-yeka1.png"
	local p2 = "public/yingxiong-yeka2.png"

	local c1 = cc.c3b(77,77,77)
	local c2 = cc.c3b(255,255,255)
	
 	for i=1,3 do
 		local page = self.resourceNode_:getChildByName("page_"..i)
 		local txt_title = page:getChildByName("txt_title")
 		if i == selectPage then
 			page:loadTexture(p1, ccui.TextureResType.plistType)
 			txt_title:setTextColor(c1)
 		else
 			page:loadTexture(p2, ccui.TextureResType.plistType)
 			txt_title:setTextColor(c2)
 		end
 	end

end

function SetPlayerHeadWin:initialView()
	self.listView = self.resourceNode_:getChildByName("listView")
	local txt_title = self.resourceNode_:getChildByName("txt_title")
	txt_title:setString("")
	UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
		self:closeSelf()
	end)

	UIImageBox.new(self.resourceNode_:getChildByName("btn_ok"),function()
		if self.headType == HEAD_TYPE.Head then
			if self.selectId and self.selectId ~= 0 then
				network.tcpSend(msgids.C_PlayerChangeHead,{Id = self.selectId})
			else
				MoveLabel.new(WordDictionary[21514])
			end
		elseif self.headType == HEAD_TYPE.HeadFrame then
			if self.selectId and self.selectId ~= 0 then
				network.tcpSend(msgids.C_PlayerChangeHFrame,{Id = self.selectId})
			else
				MoveLabel.new(WordDictionary[21514])
			end
		elseif self.headType == HEAD_TYPE.Title then
			if self.selectId and self.selectId ~= 0 then
				network.tcpSend(msgids.C_PlayerChangeTitle,{Id = self.selectId})
			else
				MoveLabel.new(WordDictionary[21514])
			end
		end
	end)

 	local page_1 = self.resourceNode_:getChildByName("page_1")
 	local page_2 = self.resourceNode_:getChildByName("page_2")
 	local page_3 = self.resourceNode_:getChildByName("page_3")

	UIImageBox.new(page_1,function()
 		self:selectPage(HEAD_TYPE.Head)
	end)

 	UIImageBox.new(page_2,function()
 		self:selectPage(HEAD_TYPE.HeadFrame)
	end)

	UIImageBox.new(page_3,function()
 		self:selectPage(HEAD_TYPE.Title)
	end)
 	self:selectPage(HEAD_TYPE.Head)
 	-- self:selectPage(HEAD_TYPE.HeadFrame)

end

function SetPlayerHeadWin:createHead()
	local data = {}
	local lockedData = {}
	local headStore = PlayerModel.info.headStore
	for k,v in pairs(playerHeadConf) do
		if v.hide ~= 1 then
			local tmp = clone(v)
			if tmp.type == 0 and (not heroConf[tmp.id] or HeroModel:getHero(tmp.id)) then
				data[#data + 1] = tmp
			elseif tmp.type == 1 and table.indexof(headStore, tmp.id) then
				data[#data +1] = tmp
			else
				tmp.isLocked = true
				lockedData[#lockedData + 1] = tmp
			end
		end
	end

	table.sort(data, function(a,b)
		return a.id < b.id
	end)
	table.sort(lockedData,function(a,b)
		return a.id < b.id
	end)

	table.insertto(data, lockedData)
	self.listView:removeAllChildren()
	self.listView:updateGridAsyn(5, data,function(cacheView,index,v)
		if cacheView == nil then
			cacheView = self:createHeadItem(v)
		end
		cacheView:updateView(data, index)
		return cacheView
	end, false, true)

end


function SetPlayerHeadWin:createHeadItem(v)
	local layer = ccui.Layout:create()
	layer.updateView = function(layer,data, updateIndex)
        
	end
	local node = cc.CSLoader:createNode("playerInfo/headNode.csb")
	local framePath = "icon/frame/" ..playerFrameConf[1].icon.. ".png"
	local frame = display.newSprite(framePath)
	UIImageBox.new(node:getChildByName("img_bg"),function(me)
		if v.isLocked then
			MoveLabel.new(v.des)
		else
			self.selectId = v.id
			self.selectAvatar:removeFromParent(false)
			node:getChildByName("sp_frame"):addChild(self.selectAvatar)
			self.selectAvatar:setVisible(true)
		end
	end,{ableGLProgram = not v.isLocked, swallowTouches = false})

	local headData = {
        frame = frame,
        headId = v.id,
    }
    Helper.createPlayerHead(headData)

	node:getChildByName("node_head"):addChild(frame)

	node:getChildByName("txt_name"):setString(v.name)
	local str = WordDictionary[21526]
	if #v.attachAttrId >= 1 then
		str = attributeConf[v.attachAttrId[1].id].name .. Helper.getAttriValue(v.attachAttrId[1].id,v.attachAttrId[1].val)
	end
	node:getChildByName("txt_attr"):setString(str)

	if v.isLocked then
		Helper.greyFunc(frame)
		Helper.greyFunc(node:getChildByName("txt_attr"))
		local noGetimg=display.newSprite("#public/yingxiong-di3.png",0,0,{scale9 = true, size = cc.size(100,25)})
		local noGetText=UILabel.new({
			text = WordDictionary[21516],
			size = 16,
			color = cc.c3b(177,63,63),
			back = CoreColor.BLACK,
		})
		display.align(noGetimg,display.CENTER,frame:getContentSize().width/2,frame:getContentSize().height/2)
		display.align(noGetText,display.CENTER,frame:getContentSize().width/2,frame:getContentSize().height/2)
		frame:addChild(noGetimg)
		frame:addChild(noGetText)
	else
		RedTipsModel:addNewTipsOnItems("newAvatar", v.id, node:getChildByName("sp_frame"), cc.p(node:getChildByName("sp_frame"):getContentSize().width - 10, node:getChildByName("sp_frame"):getContentSize().height - 10))
	end

	local size = node:getChildByName("img_bg"):getContentSize()
	layer:setContentSize(cc.size(size.width+4,size.height + 10))
	layer:setAnchorPoint(cc.p(0,0))
	node:setPosition(size.width/2 + 2,size.height/2)
	layer:addChild(node)
	return layer
end

function SetPlayerHeadWin:createHeadFrame()
	local data = {}
	local hFStore = PlayerModel.info.hFStore
	local lockedData = {}
	for k,v in pairs(playerFrameConf) do
		if v.hide == 0 then
			local tmp = clone(v)
			if table.indexof(hFStore, v.id) then
				data[#data + 1] = tmp
			else
				tmp.isLocked = true
				lockedData[#lockedData + 1] = tmp
			end
		end
	end
	table.insertto(data, lockedData)
	table.sort(data,function(a,b)
		if a.isLocked and not b.isLocked then
			return false
		elseif not a.isLocked and b.isLocked then
			return true
		end
		return a.id < b.id
		end)
	self.listView:removeAllChildren()
	self.listView:updateGridAsyn(4, data,function(cacheView,index,v)
		if cacheView == nil then
			cacheView = self:createHeadFrameItem(v)
		end
		cacheView:updateView(data, index)
		return cacheView
	end, false, true)
end


function SetPlayerHeadWin:createHeadFrameItem(v)
	local layer = ccui.Layout:create()

	layer.updateView = function(layer,data, updateIndex)
        
	end
	local node = cc.CSLoader:createNode("playerInfo/frameNode.csb")
	local size = node:getChildByName("img_bg"):getContentSize()
    local frameIcon = display.newSprite("icon/frame/frame_initial_01.png")
	if v.res and v.res ~= "" then
        local resArr = string.split(v.res,"|")
        for _, path in pairs(resArr) do
            local anim = SpineManager.createAnimation("public/"..path,1)
            anim:playAnimation("idle",-1)
            frameIcon:addChild(anim)
            display.align(anim,display.CENTER, frameIcon:getContentSize().width * 0.5 , frameIcon:getContentSize().height * 0.5+5)
        end
    else
    	frameIcon = display.newSprite("icon/frame/"..v.icon..".png")
    end
	frameIcon:setScale(0.8)

	UIImageBox.new(node:getChildByName("img_bg"),function(me)
		if v.isLocked then
			MoveLabel.new(v.des)
		else
			self.selectId = v.id
			self.selectFrame:removeFromParent(false)
			layer:addChild(self.selectFrame)
			local pos = node:getChildByName("node_fram"):getPosition()
			local sz = node:getChildByName("node_fram"):getPosition()
			self.selectFrame:setPosition(cc.p(size.width*0.5 - 30, size.height*0.5 - 30))
			self.selectFrame:setVisible(true)
		end
	end,{ableGLProgram = not v.isLocked, swallowTouches = false})


	if v.isLocked then
		Helper.greyFunc(frameIcon)
		local noGetimg=display.newSprite("#public/yingxiong-di3.png",0,0,{scale9 = true, size = cc.size(100,25)})
		local noGetText=UILabel.new({
			text = WordDictionary[21516],
			size = 16,
			color = cc.c3b(177,63,63),
			back = CoreColor.BLACK,
		})
		display.align(noGetimg,display.CENTER,frameIcon:getContentSize().width/2,frameIcon:getContentSize().height/2)
		display.align(noGetText,display.CENTER,frameIcon:getContentSize().width/2,frameIcon:getContentSize().height/2)
		frameIcon:addChild(noGetimg)
		frameIcon:addChild(noGetText)
	else
		RedTipsModel:addNewTipsOnItems("newFrame", v.id, frameIcon, cc.p(frameIcon:getContentSize().width - 20, frameIcon:getContentSize().height - 20))
	end

	node:getChildByName("node_fram"):addChild(frameIcon)
	node:getChildByName("txt_name"):setString(v.name)
	local str = WordDictionary[21526]
	if #v.attachAttrId >= 1 then
		str = attributeConf[v.attachAttrId[1].id].name .. Helper.getAttriValue(v.attachAttrId[1].id,v.attachAttrId[1].val)
	end

	-- if v.id == globalPublicConf[1].rechargeFrame[1].id then
	-- 	-- str = string.format(, (globalPublicConf[1].rechargeFrame[1].n * 100))
	-- end

	node:getChildByName("txt_attr"):setString(str)

	local size = node:getChildByName("img_bg"):getContentSize()
	layer:setContentSize(cc.size(size.width + 40,size.height + 10))
	layer:setAnchorPoint(cc.p(0,0))
	node:setPosition(size.width/2 + 20,size.height/2)
	layer:addChild(node)
	return layer
end

function SetPlayerHeadWin:createTitle()
	local data = {}
	local titleStore = PlayerModel.info.titleStore
	local lockData = {}
	for k,v in ipairs(playerTitleConf) do
		local temp = clone(v)
		if table.indexof(titleStore, v.id) or PlayerModel.info.title == v.id then
			data[#data + 1] = temp
		else
			temp.isLocked = true
			lockData[#lockData + 1] = temp
		end
	end
	table.insertto(data, lockData)
	table.sort(data,function(a,b)
		if a.isLocked and not b.isLocked then
			return false
		elseif not a.isLocked and b.isLocked then
			return true
		end
		return a.id < b.id
	end)
	self.listView:removeAllChildren()
	self.listView:updateGridAsyn(5, data,function(cacheView,index,v)
		if cacheView == nil then
			cacheView = self:createTitleItem(v)
		end
		cacheView:updateView(data, index)
		return cacheView
	end, false, true)
end

function SetPlayerHeadWin:createTitleItem(v)
	local layer = ccui.Layout:create()
	layer.updateView = function(layer,data, updateIndex)
	end
	local node = cc.CSLoader:createNode("playerInfo/titleNode.csb")
	local size = node:getChildByName("img_bg"):getContentSize()
    local frameIcon = ccui.ImageView:create("public/chenghao_zunzhe.png", ccui.TextureResType.plistType)
	if v.icon then
    	frameIcon:loadTexture("public/"..v.icon..".png", ccui.TextureResType.plistType)
    	local values = {isPlist = true,swallowTouches = true, ableGLProgram = false,noAnimEffect = true}
        values.tipsProto = require "app.CommonTip"
        values.tipsParam = {type = 8, id = v.id}
	    UIImageBox.new(frameIcon,nil,values)
    end
	frameIcon:setScale(0.5)

	UIImageBox.new(node:getChildByName("img_bg"),function(me)
		if v.isLocked then
			MoveLabel.new(WordDictionary[21516])
		else
			self.selectId = v.id
			self.selectTitle:removeFromParent(false)
			layer:addChild(self.selectTitle)
			local pos = node:getChildByName("node_type"):getPosition()
			self.selectTitle:setPosition(cc.p(0, 0))
			self.selectTitle:setContentSize(cc.size(size.width,size.height))
			self.selectTitle:setVisible(true)
		end
	end,{ableGLProgram = not v.isLocked, swallowTouches = false})


	if v.isLocked then
		Helper.greyFunc(frameIcon)
		local noGetimg=display.newSprite("#public/yingxiong-di3.png",0,0,{scale9 = true, size = cc.size(100,25)})
		local noGetText=UILabel.new({
			text = WordDictionary[21516],
			size = 16,
			color = cc.c3b(177,63,63),
			back = CoreColor.BLACK,
		})
		display.align(noGetimg,display.CENTER,size.width/2,size.height/2 - 50)
		display.align(noGetText,display.CENTER,size.width/2,size.height/2 - 50)
		node:getChildByName("img_bg"):addChild(noGetimg)
		node:getChildByName("img_bg"):addChild(noGetText)
	else
		RedTipsModel:addNewTipsOnItems("newTitle", v.id, frameIcon, cc.p(frameIcon:getContentSize().width - 20, frameIcon:getContentSize().height - 20))
	end

	node:getChildByName("node_type"):addChild(frameIcon)
	
	local size = node:getChildByName("img_bg"):getContentSize()
	layer:setContentSize(cc.size(size.width+4,size.height + 10))
	layer:setAnchorPoint(cc.p(0,0))
	node:setPosition(size.width/2 + 2,size.height/2)
	layer:addChild(node)
	return layer
end

function SetPlayerHeadWin:onExit()
	if self.headType == HEAD_TYPE.Head then
		RedTipsModel:removeNewAvatar()
	elseif self.headType == HEAD_TYPE.HeadFrame then
		RedTipsModel:removeNewFrame()
	elseif self.headType == HEAD_TYPE.Title then
		RedTipsModel:removeNewTitle()
	end

	-- local win = display.getRunningScene().winManager:findWinByName("MainWin")
	-- if win then
	-- 	win:refreshHeadFrameRedTips()
	-- end
end

function SetPlayerHeadWin:getActionIn()
    Helper.enterWinAction1(self)
end

return SetPlayerHeadWin