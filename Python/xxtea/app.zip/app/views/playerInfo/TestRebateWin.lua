local WinBase = require "sandglass.core.WinBase"
local UIImageBox = require "sandglass.ui.UIImageBox"
local c = require "app.configs.constants"
local UILabel = require "sandglass.ui.UILabel"
local WordDictionary = require "app.configs.WordDictionary"
local CoreColor = require "sandglass.core.CoreColor"
local Helper = require "app.Helper"
local RichLabel = require "sandglass.ui.RichLabel"
local ui = require "sandglass.ui.ui"
local msgids = require "app.network.msgids"
local network = require "app.network.network"
local MoveLabel = require "sandglass.ui.MoveLabel"

local TestRebateWin = class("TestRebateWin", WinBase)
TestRebateWin.RESOURCE_FILENAME = "playerInfo/testRebate.csb"

function TestRebateWin:onCreate()
    self.priority = c.WIN_ZORDER.POPUP
    local msgList = {
        msgids.GS_BillRefundTake_R,
    }
    network.addListener(self, msgList, handler(self, self.receive))
end

function TestRebateWin:receive(op,data)
    if op == msgids.GS_BillRefundTake_R then
        if data.Rewards then
            display.getRunningScene():getChildByName("ViewBase"):openWin("PublicGetRewardWin",{rewards = data.Rewards})
        end
    end
end

function TestRebateWin:initialView()
    -- 关闭
    UIImageBox.new(self.resourceNode_:getChildByName("btn_close"),function()
        self:closeSelf()
    end)

    local inputBg = self.resourceNode_:getChildByName('img_di')
    inputBg:setVisible(false)
    local size = inputBg:getContentSize()
    local inputText = ui.newEditBox({
        size = cc.size(size.width,size.height),
        image = "public/tongyong-di8.png",
    })
    inputText:setFontSize(24)
    inputText:setPlaceholderFontName(c.NORMALFONT)
    inputText:setPlaceholderFontColor(cc.c3b(67,53,41))

    inputText:setFontName(c.NORMALFONT)
    inputText:setFontColor(cc.c3b(255,245,231))
    
    inputText:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)--单行
    inputText:setPlaceHolder("")
    inputText:setInputFlag(2)
    inputText:setText("")
    display.align(inputText,display.CENTER,inputBg:getPositionX(),inputBg:getPositionY())
    inputText:setName("inputText")
    self.resourceNode_:addChild(inputText)

    UIImageBox.new(self.resourceNode_:getChildByName("btn_ok"),function()
        if inputText:getText() == "" then  
            MoveLabel.new(WordDictionary[71042])
        else    
            network.tcpSend(msgids.C_BillRefundTake, {Code = inputText:getText()})
        end
    end)
end


function TestRebateWin:getActionIn()
    Helper.enterWinAction1(self)
end

return TestRebateWin