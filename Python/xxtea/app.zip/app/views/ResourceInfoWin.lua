--ResourceInfoWin.lua

local WinBase = require "sandglass.core.WinBase"
local UILabel = require "sandglass.ui.UILabel"
local UIImageBox = require "sandglass.ui.UIImageBox"
local msgids = require "app.network.msgids"
local c = require "app.configs.constants"
local network = require "app.network.network"
local init = require "app.models.init"
local Helper = require "app.Helper"
local mineWarConf = require "app.configs.mineWar"
local rglobalPublicConfig = require "app.configs.globalPublic"
local shopItemConf = require "app.configs.shopItem"

local PlayerModel = init.PlayerModel
local ActivityModel = init.ActivityModel
local RedTipsModel = init.RedTipsModel
local ShopModel = init.ShopModel

local ResourceInfoWin = class("ResourceInfoWin", WinBase)
ResourceInfoWin.RESOURCE_FILENAME = "public/resourceInfo.csb"

---默认显示的货币---
local DEF_ICON_ID = {
    [1] = 10200,
    [2] = 10700,
    [3] = 10100,
}

local CURRENCY_ = {
    Gold = 10100,
    Diamond = 10200,
    Strength = 10700,
}

function ResourceInfoWin:onCreate()
    self.notSupportBack = true
    self.priority = c.WIN_ZORDER.PERMANENT
    self.showType = self.WinShowType.normal + self.WinShowType.canNotClose
    self.shieldLayer_:setVisible(false)
    self:setTouchListenerEnable(false)

    self.redtips = {}--记录红点
    self.addBtns = {}
    self.curCurrency = {}

    local msgList = {
        msgids.GS_BagUpdate,
        msgids.GS_VipUpdate,
        msgids.GS_BuyStrength_R,
        msgids.GS_BuyGold_R,
        msgids.GS_ActConfGet_R,
        msgids.GS_ActDayGiftInfo_R,
        msgids.GS_ActWeekGiftInfo_R,
        msgids.GS_ActFesGiftInfo_R,
    }
    network.addListener(self, msgList, handler(self, self.recieve))
end

function ResourceInfoWin:recieve(op, data)
    if op == msgids.GS_BagUpdate then
        self:updateResource(self.curCurrency, true)
    elseif op == msgids.GS_VipUpdate then
        if PlayerModel.info.vip > PlayerModel.info.preVip then
            local win = display.getRunningScene().winManager:findWinByName("VipLevelUpWin")
            if not win then
                self:openWin("VipLevelUpWin")
            end 
        end
    elseif op == msgids.GS_BuyStrength_R then
        RedTipsModel:refreshStrengthBuyTips()
    elseif op == msgids.GS_BuyGold_R then
        RedTipsModel:refreshGlobBuyTips()
    elseif op == msgids.GS_ActConfGet_R 
        or op == msgids.GS_ActDayGiftInfo_R
        or op == msgids.GS_ActWeekGiftInfo_R
        or op == msgids.GS_ActFesGiftInfo_R then
        self:initActData()
    end
end

function ResourceInfoWin:initialView()
    self:initActData()
end

function ResourceInfoWin:returnUpdate(winList)
    local TOP_WINS = {
        SwitchWin = true,
        ChatWin = true,
        ResourceInfoWin = true,
    }
    local findResWin = false
    local totalWin = #winList
    local topWinName = winList[totalWin].window.__cname
    if TOP_WINS[topWinName] then
        for idx = totalWin, 1, -1 do
            local win = winList[idx] and winList[idx].window or {}
            if win.__cname == "ResourceInfoWin" then
                findResWin = true
            elseif findResWin then
                if win.resourceNode_ then
                    local component = win.resourceNode_:getComponent("ComExtensionData")
                    local property = ""
                    if component then
                        property = component:getCustomProperty()
                    end
                    if property == "FULL" then
                        local currencys = win.showCurrency or DEF_ICON_ID
                        if currencys ~= self.curCurrency then
                            self:moveAction(function()
                                self:updateResource(currencys)
                            end)
                        end
                        break
                    end
                end
            end
        end
    end
end

function ResourceInfoWin:updateResource(iconIds, isUpdate)
    if not isUpdate and iconIds == self.curCurrency then
        return
    end
    self.curCurrency = iconIds
    self.addBtns = {}
    local rootNode = self.resourceNode_:getChildByName("node_rt")
    for i=1,5 do
        local node = rootNode:getChildByName("node_"..i)
        local id = iconIds[i]
        if id then
            node:setVisible(true)
            node:getChildByName("sp_icon"):setTexture(Helper.getPathById(id))
            node:getChildByName("txt_num"):setString(Helper.getShortNum(Helper.getItemOrCurrencyCnt(id), true))
            if id == c.CurrencyName.ration   then
                node:getChildByName("txt_num"):setString(Helper.getShortNum(Helper.getItemOrCurrencyCnt(id), true) .. "/" .. rglobalPublicConfig[1].actionLimit)
            elseif id == c.CurrencyName.assaultOrder then
                node:getChildByName("txt_num"):setString(Helper.getShortNum(Helper.getItemOrCurrencyCnt(id), true) .. "/" .. rglobalPublicConfig[1].minebattleLimit)
            end
            UIImageBox.new(node:getChildByName("img_bg"),function()
                self:openFunc(id)
            end)
            self.addBtns[id] = node:getChildByName("btn_add")
        else
            node:setVisible(false)
        end
    end
    self:updateRedTips()
end

function ResourceInfoWin:moveAction(callBack)
    local node = self.resourceNode_:getChildByName("node_rt")
    node:stopAllActions()
    node:setPosition(display.width, display.height)
    node:runAction(cc.Sequence:create(
        cc.MoveTo:create(0.3, cc.p(display.width, display.height+50)),
        cc.CallFunc:create(function()
            if callBack then
                callBack()
            end
        end),
        cc.MoveTo:create(0.3, cc.p(display.width, display.height))
    ))
end

function ResourceInfoWin:initActData()
    self.actDayGiftData = ActivityModel:getActivityCalendar(c.ACTIVITY_NAME.ActDayGift)
    self.actWeekGiftData = ActivityModel:getActivityCalendar(c.ACTIVITY_NAME.ActWeekGift)
    self.actFestGiftData = ActivityModel:getActivityCalendar(c.ACTIVITY_NAME.ActFestGiftBuy)
    self.actFestAddReset = ActivityModel:getActivityCalendar(c.ACTIVITY_NAME.ActFestAddReset)
    if self.actDayGiftData and not self.actDayGiftData.Confs then
        network.tcpSend(msgids.C_ActConfGet, {Id = c.ACTIVITY_NAME.ActDayGift})
        return
    elseif self.actDayGiftData and not self.actDayGiftData.UserData then
        ActivityModel:sendGetActivityData(c.ACTIVITY_NAME.ActDayGift)
        return
    elseif self.actWeekGiftData and not self.actWeekGiftData.Confs then
        network.tcpSend(msgids.C_ActConfGet, {Id = c.ACTIVITY_NAME.ActWeekGift})
        return
    elseif self.actWeekGiftData and not self.actWeekGiftData.UserData then
        ActivityModel:sendGetActivityData(c.ACTIVITY_NAME.ActWeekGift)
        return
    elseif self.actFestGiftData and not self.actFestGiftData.Confs then
        network.tcpSend(msgids.C_ActConfGet, {Id = c.ACTIVITY_NAME.ActFestGiftBuy})
        return
    elseif self.actFestGiftData and not self.actFestGiftData.UserData then
        ActivityModel:sendGetActivityData(c.ACTIVITY_NAME.ActFestGiftBuy)
        return
    elseif self.actFestAddReset and not self.actFestAddReset.Confs then
        network.tcpSend(msgids.C_ActConfGet, {Id = c.ACTIVITY_NAME.ActFestAddReset})
        return
    elseif self.actFestAddReset and not self.actFestAddReset.UserData then
        ActivityModel:sendGetActivityData(c.ACTIVITY_NAME.ActFestAddReset)
        return
    end
    self.actRefresh = true
    self:refreshStrengthBuyTips()
end

function ResourceInfoWin:refreshStrengthBuyTips()
    if self.actRefresh then
        self.dayRed = ActivityModel:checkRedTips(c.ACTIVITY_NAME.ActDayGift)
        self.weekRed = ActivityModel:checkRedTips(c.ACTIVITY_NAME.ActWeekGift)
        self.festRed = ActivityModel:checkRedTips(c.ACTIVITY_NAME.ActFestGiftBuy)
        if self.weekRed or self.dayRed then
            Helper.sendEvent("refreshDiamondBuyTips", {addtips = (self.weekRed or self.dayRed or self.festRed)})
        end
    end
end


function ResourceInfoWin:updateRedTips()
    for id,btn in pairs(self.addBtns) do
        if self.redtips[id] then
            RedTipsModel:addRedTip(btn, cc.p(28, 22))
        else
            RedTipsModel:removeRedTip(btn)
        end
    end
end

function ResourceInfoWin:openFunc(id)
    if id == CURRENCY_.Gold or id == CURRENCY_.Strength then
        self:openWin("BuyGoldWin")
    elseif id == CURRENCY_.Diamond then
        local winName = "PayWin"
        if PlayerModel.info.isAudit then
            winName = "YouthPayWin"
        end

        local win = display.getRunningScene().winManager:findWinByName(winName)
        if not win then
            display.getRunningScene():getChildByName("ViewBase"):openWin(winName)
        end 
    elseif id == c.CurrencyName.ration then
        local maxCnt = rglobalPublicConfig[1].actionLimit
        local curCnt = Helper.getShortNum(Helper.getItemOrCurrencyCnt(id), true)
        local maxNum  = maxCnt - curCnt
        if maxNum < 0 then
            maxNum = 0
        end

        local params = {
            maxNum = maxNum,
            currencyId = 10200,
            priceStr = "actionCost",
            canBuy = -1,
            msg = msgids.C_MineBuyAction,
            buyCnt = PlayerModel:getCounterByID(1000065),
            changeNumber = 50,
        }
        self:openWin("ResetWin",params)
    elseif id == c.CurrencyName.assaultOrder then
        local maxCnt = rglobalPublicConfig[1].minebattleLimit
        local curCnt = Helper.getShortNum(Helper.getItemOrCurrencyCnt(id), true)
        local maxNum  = maxCnt - curCnt
        if maxNum < 0 then
            maxNum = 0
        end
        local params = {
            maxNum = maxNum,
            currencyId = 10200,
            priceStr = "minebattleCost",
            canBuy = -1,
            msg = msgids.C_MineBuyBattle,
            buyCnt = PlayerModel:getCounterByID(1000066),
        }
        self:openWin("ResetWin",params)
    elseif id == c.CurrencyName.refresh then
        local sItem = nil
        for k,v in pairs(shopItemConf) do
            if v.item == c.CurrencyName.refresh then
                sItem = v
                break
            end
        end
        if sItem then
            self:openWin("BuyShopWin",{sdata = sItem, bdata = 0, shopID = sItem.shopType, price = math.ceil(sItem.discount * sItem.num / 10000), exCost = sItem.extCost},function(id,num)
                ShopModel:setBuyData({ShopId = sItem.shopType, ItemId = id, Num = num})
            end)
        end
    else
        self:openWin("SourceWin", id)
    end
end

function ResourceInfoWin:onEnterTransitionFinish()
    self:registerEvent("refreshGlobBuyTips")
    RedTipsModel:refreshGlobBuyTips()
    self:registerEvent("refreshStrengthBuyTips")
    RedTipsModel:refreshStrengthBuyTips()
    self:registerEvent("refreshDiamondBuyTips")
    self:refreshStrengthBuyTips()

end

function ResourceInfoWin:onEventReceive(event)
    local name = event:getEventName()
    local param = event._usedata
    if name == "refreshGlobBuyTips" then
        self.redtips[CURRENCY_.Gold] = param.addtips
        if self.addBtns[CURRENCY_.Gold] then
            if param.addtips then
                RedTipsModel:addRedTip(self.addBtns[CURRENCY_.Gold], cc.p(28, 22))
            else
                RedTipsModel:removeRedTip(self.addBtns[CURRENCY_.Gold])
            end
        end
    elseif name == "refreshStrengthBuyTips" then
        self.redtips[CURRENCY_.Strength] = param.addtips
        if self.addBtns[CURRENCY_.Strength] then
            if param.addtips then
                RedTipsModel:addRedTip(self.addBtns[CURRENCY_.Strength], cc.p(28, 22))
            else
                RedTipsModel:removeRedTip(self.addBtns[CURRENCY_.Strength])
            end
        end
    elseif name == "refreshDiamondBuyTips" then
        self.redtips[CURRENCY_.Diamond] = param.addtips
        if self.addBtns[CURRENCY_.Diamond] then
            if param.addtips then
                RedTipsModel:addRedTip(self.addBtns[CURRENCY_.Diamond], cc.p(28, 22))
            else
                RedTipsModel:removeRedTip(self.addBtns[CURRENCY_.Diamond])
            end
        end
    elseif name == "moveResourceInfoPosition" then
    end
end

function ResourceInfoWin:outAction(time)
    local node = self.resourceNode_:getChildByName("node_rt")
    node:stopAllActions()
    node:setPosition(display.width, display.height)
    node:runAction(cc.MoveTo:create(time or 1, cc.p(display.width, display.height+100)))
end

return ResourceInfoWin
