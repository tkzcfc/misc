--
-- Author: hexianxiong
-- Date: 2018-04-24 15:25:29
--
local FarBackgroundSprite = class("FarBackgroundSprite", function(...) return display.newSprite(...) end )

function FarBackgroundSprite:ctor(imgPath)
end

function FarBackgroundSprite:setNearBackgroundSize(size)
	self.nearBackgroundSize = size
end

function FarBackgroundSprite:update(targetPt)
	local size = self:getContentSize()
	local scale = self:getScale()
	size = cc.size(size.width*scale,size.height*scale)

	local x = targetPt.x / self.nearBackgroundSize.width * size.width
	local y = targetPt.y / self.nearBackgroundSize.height * size.height

	-- print(targetPt.x / self.nearBackgroundSize.width,targetPt.y / self.nearBackgroundSize.height,x,y)

	if (x + display.cx) > size.width then
		x = size.width - display.cx 
	elseif (x - display.cx) < 0 then
		x = display.cx
	end

	if (y + display.cy) > size.height then
		y = size.height - display.cy 
	elseif (y - display.cy) < 0 then
		y = display.cy
	end

	local x = x - display.cx
	local y = y - display.cy

	self:setPosition(cc.p(-x/scale,-y/scale))
end

return FarBackgroundSprite