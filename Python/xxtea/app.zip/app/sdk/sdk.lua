--
-- Author: hexianxiong
-- Date: 2018-01-17 15:57:19
-- SDK全局回调
--
--SDK是否初始化成功，一般SDK只需要初始化一次
cc.exports.isInitSuccess = cc.exports.isInitSuccess or nil

--设备信息
cc.exports.gPhoneInfo = cc.exports.gPhoneInfo or {
    imei = "unknown",
    deviceId = "unknown",
    mac = "00:00:00:00",
    resolution = "640x1136",
    os = "MacOS",
    osVersion = "1",
    model = "MAC",
    packageName = "and",
}

--原生代码调用该接口，设置手机相关属性
cc.exports.setPhoneInfos = function(_data)
	if type(_data) == "string" then
        _data = loadstring("return ".._data)();
    end

    cc.exports.gPhoneInfo = _data;
end

 cc.exports.onInitResult = function(data)
    local ret = nil
    if type(data) == 'string' then
          ret = loadstring('return ' .. data)()
    else
          ret = data
    end
    if ret.code == 0 then
        cc.exports.isInitSuccess = true
        local event = cc.EventCustom:new("onInitSuccess")
        cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
    else
        cc.exports.isInitSuccess = false
        local event = cc.EventCustom:new("onInitFailed")
        cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
    end
end

 cc.exports.onLoginResult = function(data)
    local ret = nil
    if type(data) == 'string' then
          ret = loadstring('return '..data)()
    else
          ret = data
    end

    print("onLoginResult","ret.code",ret.code)

    local SDKController = require "app.sdk.SDKController"
    SDKController.getSDKHelper():setLoginInfo(ret)
    --全局登录成功回调，通知登录界面切换为可以选服务器界面了
    local event = cc.EventCustom:new("onLoginResult")
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
end

 cc.exports.onLogoutResult = function(data)
    local ret = nil
    if type(data) == 'string' then
    	ret = loadstring('return '..data)()
    else
    	ret = data
    end
    print("onLogoutResult","ret.code",ret.code);

    local SDKController = require "app.sdk.SDKController"
    if ret.code == SDKController.CODE_SUCCESS then
        SDKController.logoutGame()
    end
end

cc.exports.onGetPayInfoResult = function(data)
    local ret = nil
    if type(data) == 'string' then
        ret = loadstring('return '..data)()
    else
        ret = data
    end

    local SDKController = require "app.sdk.SDKController"
    local sdkHelper = SDKController.getSDKHelper()
    if ret and sdkHelper.updateBillProduct then
        sdkHelper:updateBillProduct(ret)
    end

    --全局获取成功回调，通知登录界面切换为可以选服务器界面了
    local event = cc.EventCustom:new("onGetPayInfoResult")
    cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
end