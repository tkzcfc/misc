--
-- Author: hexianxiong
-- Date: 2018-01-17 14:04:57
--
local IGameSDK = require("app.sdk.IGameSDK")

---
--@type TestHelper
local TestHelper = class("TestHelper",IGameSDK)

function TestHelper:ctor()
	TestHelper.super.ctor(self,"")
end

function TestHelper:checkPermission(permissionName,callBack)
    callBack({code = 0})
end

return TestHelper