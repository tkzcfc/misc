--
-- Author: hexianxiong
-- Date: 2018-01-17 10:07:02
--
local SDKController = require "app.sdk.SDKController"
local luaj_error = {
    [-1]='不支持的参数类型或返回值类型',
    [-2]='无效的签名',
    [-3]='没有找到指定的方法',
    [-4]='Java 方法执行时抛出了异常',
    [-5]='Java 虚拟机出错',
    [-6]='Java 虚拟机出错',
}

---
--@type IGameSDK
local IGameSDK = class("IGameSDK")

function IGameSDK:ctor(className,objName)
	self.SDK_className = className
    self.objName = objName
	self.loginInfo = {
		code = 0,
		token = "token",
		name = "temp",
		account = "-",
        channelId = "",
        channelAction = "",
        extInfo = "",
		}
end

function IGameSDK:initSDK(params,callBack)
    local ret = {code=SDKController.CODE_SUCCESS}
    callBack(ret)
end

--初始化参数
function IGameSDK:getInitParams()
	local params = SDK_PARAMS or {}
    return params
end

function IGameSDK:login(params,callBack)
    local ret = self.loginInfo
    callBack(ret)
end

function IGameSDK:setLoginInfo(data)
    for key,v in pairs(data) do
        if v == "" then
            self.loginInfo[key] = nil
        else
            self.loginInfo[key] = v
        end
    end
end

function IGameSDK:getLoginInfo()
	return self.loginInfo
end

function IGameSDK:logout(params,callBack)
    local ret = {code=SDKController.CODE_SUCCESS}
    callBack(ret)
end

function IGameSDK:pay(params,callBack)
    local MoveLabel = require "sandglass.ui.MoveLabel"
    MoveLabel.new("测试版本，无法充值")
end

function IGameSDK:onBackPressed(params)
    
end

function IGameSDK:openAccountCenter(params)
    
end

function IGameSDK:submitData(params)
end

function IGameSDK:callStaticMethod(methodName,args,sig,callBack)
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if targetPlatform == cc.PLATFORM_OS_ANDROID then
        -- 调用方法并获得返回值
        local ok, ret = luaj.callStaticMethod(self.SDK_className, methodName, args, sig)

        if not ok then
           print(string.format("luaj error %s, %s, %d, %s", self.SDK_className,methodName,ret,luaj_error[ret]))
        else
           print(string.format("luaj ok %s, %s", self.SDK_className,methodName))
        end
    elseif targetPlatform == cc.PLATFORM_OS_IPAD or targetPlatform == cc.PLATFORM_OS_IPHONE then
        --CCLuaObjcBridge调Objective-C方法传索引数组报invalid key to 'next'错调试
        --http://blog.csdn.net/lixianlin/article/details/24310789
        local ocParams = {}
        for k,v in pairs(args) do
            if type(k) == 'number' then
                ocParams['_'..tostring(k)] = v
            else
                ocParams[k] = v
            end
        end

        luaoc.callStaticMethod(self.objName, methodName, ocParams)
    else
       -- print(self.SDK_className,"模拟调用",methodName)
    end
end

function IGameSDK:getSDKParam()
    if SDK_PARAMS and SDK_PARAMS.auth then
        return SDK_PARAMS.auth
    end
    return ""
end

--获取SDK返回的额外参数，通过登录login接口传给服务器
function IGameSDK:getSDKExtraParam()
    return ""
end

function IGameSDK:getChannelId()
    if self.loginInfo and self.loginInfo.channelId and self.loginInfo.channelId ~= "" then
        return self.loginInfo.channelId
    end
    return self:getSDKParam()
end

function IGameSDK:antiAddiction(params,callBack)
end

function IGameSDK:realNameRegistration(params,callBack)
end

function IGameSDK:decodeBase64(str64)
    local b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local temp={}
    for i=1,64 do
        temp[string.sub(b64chars,i,i)] = i
    end
    temp['=']=0
    local str=""
    for i=1,#str64,4 do
        if i>#str64 then
            break
        end
        local data = 0
        local str_count=0
        for j=0,3 do
            local str1=string.sub(str64,i+j,i+j)
            if not temp[str1] then
                return
            end
            if temp[str1] < 1 then
                data = data * 64
            else
                data = data * 64 + temp[str1]-1
                str_count = str_count + 1
            end
        end
        for j=16,0,-8 do
            if str_count > 0 then
                str=str..string.char(math.floor(data/math.pow(2,j)))
                data=math.mod(data,math.pow(2,j))
                str_count = str_count - 1
            end
        end
    end
    return str
end
return IGameSDK