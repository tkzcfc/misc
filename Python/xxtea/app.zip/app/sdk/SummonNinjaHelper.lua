local IGameSDK = require("app.sdk.IGameSDK")

local SummonNinjaHelper = class("SummonNinjaHelper",IGameSDK)

function SummonNinjaHelper:ctor()
    SummonNinjaHelper.super.ctor(self, "com/sandglass/sdk/GameSDKProxy", "SummonNinjaHelper")
end

function SummonNinjaHelper:loadPhoneInfo()
    local pTbl = {}
    self:callStaticMethod("summonLoadInfo", pTbl)
end

function SummonNinjaHelper:initSDK(params,callBack)
    local _params = params or {}

    local pTbl = {
        json.encode(_params),
        function (_retDat)
            if type(_retDat) == 'string' then
                _retDat = loadstring("return ".._retDat)()
            end
            callBack(_retDat)
        end
    }

    self:callStaticMethod("summonInitSDK", pTbl)
end

function SummonNinjaHelper:login(params,callBack)
    local _params = params or {}

    local pTbl = {
        json.encode(_params),
        function (_retDat)
            if type(_retDat) == 'string' then
                _retDat = loadstring("return ".._retDat)()
            end
            self.loginInfo = _retDat
            callBack(_retDat)
        end
    }

    self:callStaticMethod("summonLogin", pTbl)
end

function SummonNinjaHelper:logout(params,callBack)
    local _params = params or {}

    local pTbl = {
        json.encode(_params),
        function (_retDat)
            if type(_retDat) == 'string' then
                _retDat = loadstring("return ".._retDat)()
            end
            callBack(_retDat)
        end
    }

    self:callStaticMethod("logout", pTbl)
end

function SummonNinjaHelper:pay(params,callBack)
    local _params = {}
    local init = require("app.models.init")
    local PlayerModel = init.PlayerModel
    local SDKController = require("app.sdk.SDKController")
    local PlayerConfig = require "sandglass.core.PlayerConfig"
    local userId = PlayerModel.info.userId
    local serverInfo = SDKController.getServerInfo()
    local loginInfo = self:getLoginInfo()
    _params.userId = tostring(loginInfo.userId)
    _params.productId = params.StoreId
     if params.Goods and #params.Goods > 0 then
        _params.productName = string.format(params.Name,params.Goods[1].N)
        _params.currency = params.Goods[1].N
    else
        _params.productName = params.Name
        _params.currency = 0
    end
    _params.notifyUrl = URL_PAYMENT
    _params.amount = params.Price
    _params.roleId = userId
    _params.roleName = PlayerModel.info.name
    _params.serverId = serverInfo.id
    _params.serverName = serverInfo.text
    _params.vipLevel = PlayerModel.info.vip
    _params.roleLevel = PlayerModel.info.level
    _params.unionName = PlayerModel.info.guildName
    _params.orderID = _params.roleId .. "-" .. _params.productId .. "-" .. os.time();
    _params.extInfo = self:getSDKParam() .. "_" .. string.gsub(userId, "-", "_") .. "_" .. params.Id
    local pTbl = {
        json.encode(_params),
        function (_retDat)
            if type(_retDat) == 'string' then
                _retDat = loadstring("return " .. _retDat)()
            end
            callBack(_retDat)
        end
    }
    self:callStaticMethod("summonIAP", pTbl)
end

function SummonNinjaHelper:onBackPressed(params,callBack)
    local _params = params or {}
    local pTbl = {
        json.encode(_params),
        function (_retDat)
            if type(_retDat) == 'string' then
                _retDat = loadstring("return ".._retDat)()
            end
            callBack(_retDat)
        end
    }

    self:callStaticMethod("onBackPressed", pTbl)
end

function SummonNinjaHelper:submitData(params)
        local init = require "app.models.init"
    local SDKController = require "app.sdk.SDKController"
    local PlayerModel = init.PlayerModel
    local info = PlayerModel.info
    if not info.userId then
        return
    end
    local serverInfo = SDKController.getServerInfo()
    local loginInfo = self:getLoginInfo()
    local data = {
        userId = tostring(loginInfo.account),
        roleId = tostring(info.userId),
        roleName = tostring(info.name),
        roleLevel = tostring(info.level),
        serverId = serverInfo.id,
        serverName = tostring(serverInfo.text),
        vipLevel = tostring(info.vip),
        unionName = info.guildName,
        money = PlayerModel:getPlayerCurrency("diamond"),
        createTime = PlayerModel.info.createTime,
        stateTag = params,
    }
    local _params = data
    local pTbl = {
        json.encode(_params),
    }
    self:callStaticMethod("summonSubmitData", pTbl)
end

function SummonNinjaHelper:getSDKExtraParam()
    return "5.0.1";
end

function SummonNinjaHelper:switchAccount(params)
    local _params = params or {}
    local pTbl = {
        json.encode(_params),
    }

    self:callStaticMethod("switchAccount", pTbl)
end

function SummonNinjaHelper:findMusic(params,callBack)
    local _params = params or {}

    local pTbl = {
        json.encode(_params),
        function (_retDat)
            if type(_retDat) == 'string' then
                _retDat = loadstring("return ".._retDat)()
            end
            self.loginInfo = _retDat
            callBack(_retDat)
        end
    }
    self:callStaticMethod("findMusic", pTbl)
end

return SummonNinjaHelper