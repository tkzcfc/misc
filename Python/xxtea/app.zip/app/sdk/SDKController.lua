--
-- Author: hexianxiong
-- Date: 2018-01-17 11:46:48
--
local SDKController = {}
local self = SDKController

SDKController.CODE_SUCCESS = 0
SDKController.CODE_FAIL = 1
SDKController.CODE_CANCEL = 2
SDKController.CODE_UNKNOWN = 3
SDKController.CODE_WAIT = 4 --等待确认

SDKController.CREATE_ROLE_TAG = 0
SDKController.LOGIN_GAME_TAG = 1
SDKController.EXIT_GAME_TAG = 2
SDKController.LEVEL_UP_TAG = 3
SDKController.PAY_TAG = 4
SDKController.SELECT_SERVER = 5
SDKController.CHANGE_NAME = 6--改名
SDKController.PASS_ORDINARY = 7--通关副本
SDKController.FIRSTVIDEO_FINISH = 8 --首次播放动画结束时
SDKController.FIRSTFIGHT_FINISH = 9 --体验战斗结束时
SDKController.FILMSVIDEO_FINISH = 10 --播放新版本动画结束时
SDKController.MAINLINE_FINISH = 11 --MainLineModel:getNowCpt() - 1 获取完成章节
SDKController.GUIDE_POINT = 12 --新手引导步数 GuideManager.getNewbieStep() 获取新手引导步数
SDKController.ENTER_SHOP_TAG = 13 --进入商店
SDKController.VIP_UP_TAG = 14 --vip升级

function SDKController.ctor()
	self.sdkHelper = nil
end

--是否支持back
function SDKController.getSupportBack()
    return cc.UserDefault:getInstance():getBoolForKey("support_back", false)
end
--是否支持用户中心
function SDKController.getSupportAccountCenter()
    return cc.UserDefault:getInstance():getBoolForKey("support_account_center", false)
end
--是否支持注销
function SDKController.getSupportSwitchAccount()
    return cc.UserDefault:getInstance():getBoolForKey("support_switch_account", false)
end

function SDKController.initSDK()
	if SDK_PLATFORM then
    	self.sdkHelper = require("app.sdk."..SDK_PLATFORM).new()
    end
    if isInitSuccess then
        return
    end
    --获取手机信息
    local SDK_className = "com/sandglass/sdk/LuaHelper"
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if SDK_PLATFORM ~= "TestHelper" then
        if targetPlatform == cc.PLATFORM_OS_ANDROID then
            -- 调用方法并获得返回值
            local ok, ret = luaj.callStaticMethod(SDK_className, "loadPhoneInfo", {}, nil)

            if not ok then
               print(string.format("luaj error %s, %s, %d", SDK_className,"loadPhoneInfo",ret))
            else
               print(string.format("luaj ok %s, %s", SDK_className,"loadPhoneInfo"))
            end
        elseif targetPlatform == cc.PLATFORM_OS_IPAD or targetPlatform == cc.PLATFORM_OS_IPHONE then
            --CCLuaObjcBridge调Objective-C方法传索引数组报invalid key to 'next'错调试
            --http://blog.csdn.net/lixianlin/article/details/24310789
            if self.sdkHelper.loadPhoneInfo then
                self.sdkHelper:loadPhoneInfo()
            else
                local ocParams = {}
                luaoc.callStaticMethod("LuaHelper", "loadPhoneInfo", ocParams)
            end
        end
    end

    if SDK_PLATFORM then
        self.sdkHelper:initSDK(self.sdkHelper:getInitParams(),function(data)
        	onInitResult(data)
        	end)
    end
end

function SDKController.getSDKHelper()
   return self.sdkHelper
end

function SDKController.logoutGame(auto)
    local DivideManager = require "sandglass.core.DivideManager"
    DivideManager.pause()
    display.getRunningScene():getChildByName("ViewBase"):getApp():restart()
end

function SDKController.quitGame()
    local c = require "app.configs.constants"
    local sdkHelper = self.sdkHelper

    if sdkHelper ~= nil and self.getSupportBack() then
        sdkHelper:onBackPressed({},function(ret) 
            if ret.code == SDKController.CODE_SUCCESS then
                sdkHelper:submitData(SDKController.EXIT_GAME_TAG,function() end)
                cc.Director:getInstance():endToLua()
            end
        end)
    else
        local WordDictionary = require "app.configs.WordDictionary"

        local dialogWins = display.getRunningScene().winManager:findWinsByName("DialogWin")
        local hasWin = false
        for k,v in ipairs(dialogWins) do
            if v.tab == "quit" then
                v:closeSelf()
                hasWin = true
                break
            end
        end

        if not hasWin then
            display.getRunningScene():getChildByName("ViewBase"):openWin("DialogWin", WordDictionary[22309],{{handler=function()
                    sdkHelper:submitData(SDKController.EXIT_GAME_TAG,function() end)
                    cc.Director:getInstance():endToLua()
                end},{}}, "quit")
        end
    end
end

function SDKController.setServerInfo(serverData)
    self.serverInfo = serverData
end

function SDKController.getServerInfo()
    return self.serverInfo
end

return SDKController